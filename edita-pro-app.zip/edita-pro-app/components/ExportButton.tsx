import React from 'react';
import { StyleSheet, TouchableOpacity, Text, ActivityIndicator } from 'react-native';
import { Upload } from 'lucide-react-native';
import Colors from '@/constants/Colors';

interface ExportButtonProps {
  onPress: () => void;
  isExporting?: boolean;
}

export default function ExportButton({ onPress, isExporting = false }: ExportButtonProps) {
  return (
    <TouchableOpacity 
      style={styles.button}
      onPress={onPress}
      disabled={isExporting}
    >
      {isExporting ? (
        <ActivityIndicator color="#FFF\" size="small" />
      ) : (
        <>
          <Upload size={18} color="#FFF" />
          <Text style={styles.text}>Export</Text>
        </>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: Colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  text: {
    color: '#FFF',
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    marginLeft: 8,
  },
});