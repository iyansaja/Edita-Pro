import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { Clock, MoreVertical } from 'lucide-react-native';
import { router } from 'expo-router';
import Colors from '@/constants/Colors';

interface RecentProjectItemProps {
  project: {
    id: string;
    title: string;
    duration: string;
    date: string;
  };
}

export default function RecentProjectItem({ project }: RecentProjectItemProps) {
  return (
    <TouchableOpacity 
      style={styles.container}
      onPress={() => router.push('/editor')}
    >
      <View style={styles.info}>
        <Text style={styles.title}>{project.title}</Text>
        <View style={styles.details}>
          <Clock size={14} color={Colors.secondaryText} />
          <Text style={styles.duration}>{project.duration}</Text>
          <Text style={styles.date}>{project.date}</Text>
        </View>
      </View>
      
      <TouchableOpacity style={styles.menuButton}>
        <MoreVertical size={20} color={Colors.text} />
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: Colors.cardBackground,
    borderRadius: 8,
    marginBottom: 12,
  },
  info: {
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: Colors.text,
    marginBottom: 6,
  },
  details: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  duration: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.secondaryText,
    marginLeft: 6,
    marginRight: 12,
  },
  date: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.secondaryText,
  },
  menuButton: {
    padding: 8,
  },
});