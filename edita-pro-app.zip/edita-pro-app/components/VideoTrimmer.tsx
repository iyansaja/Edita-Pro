import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, PanResponder, Animated } from 'react-native';
import Colors from '@/constants/Colors';

interface VideoTrimmerProps {
  duration: number;
  onValueChange: (values: { start: number; end: number }) => void;
  initialValues: { start: number; end: number };
}

export default function VideoTrimmer({ duration, onValueChange, initialValues }: VideoTrimmerProps) {
  const [width, setWidth] = useState(0);
  const leftHandlePos = useState(new Animated.Value(0))[0];
  const rightHandlePos = useState(new Animated.Value(0))[0];

  useEffect(() => {
    // Set initial positions when width is known
    if (width > 0 && duration > 0) {
      const startPos = (initialValues.start / duration) * width;
      const endPos = (initialValues.end / duration) * width || width;
      
      leftHandlePos.setValue(startPos);
      rightHandlePos.setValue(endPos);
    }
  }, [width, duration, initialValues]);

  const formatTime = (milliseconds: number) => {
    const totalSeconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const leftPanResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderMove: (_, gestureState) => {
      const newLeftPosition = Math.max(0, Math.min(rightHandlePos._value - 30, gestureState.moveX));
      leftHandlePos.setValue(newLeftPosition);
    },
    onPanResponderRelease: () => {
      const startValue = (leftHandlePos._value / width) * duration;
      const endValue = (rightHandlePos._value / width) * duration;
      onValueChange({ start: startValue, end: endValue });
    }
  });

  const rightPanResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderMove: (_, gestureState) => {
      const newRightPosition = Math.min(width, Math.max(leftHandlePos._value + 30, gestureState.moveX));
      rightHandlePos.setValue(newRightPosition);
    },
    onPanResponderRelease: () => {
      const startValue = (leftHandlePos._value / width) * duration;
      const endValue = (rightHandlePos._value / width) * duration;
      onValueChange({ start: startValue, end: endValue });
    }
  });

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Trim Video</Text>
      
      <View 
        style={styles.timeline}
        onLayout={(e) => setWidth(e.nativeEvent.layout.width)}
      >
        {/* Timeline markers */}
        <View style={styles.timelineMarkers}>
          {Array.from({ length: 5 }).map((_, i) => (
            <View key={i} style={styles.marker} />
          ))}
        </View>
        
        {/* Selected area */}
        <Animated.View 
          style={[
            styles.selectedArea,
            {
              left: leftHandlePos,
              right: Animated.subtract(width, rightHandlePos)
            }
          ]}
        />
        
        {/* Left handle */}
        <Animated.View 
          style={[styles.handle, { left: leftHandlePos }]}
          {...leftPanResponder.panHandlers}
        >
          <View style={styles.handleBar} />
        </Animated.View>
        
        {/* Right handle */}
        <Animated.View 
          style={[styles.handle, { left: rightHandlePos }]}
          {...rightPanResponder.panHandlers}
        >
          <View style={styles.handleBar} />
        </Animated.View>
      </View>
      
      <View style={styles.timeLabels}>
        <Text style={styles.timeLabel}>{formatTime(initialValues.start)}</Text>
        <Text style={styles.timeLabel}>{formatTime(initialValues.end || duration)}</Text>
      </View>
      
      <Text style={styles.instructions}>
        Drag the handles to trim your video
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 16,
  },
  title: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: Colors.text,
    marginBottom: 16,
  },
  timeline: {
    height: 50,
    backgroundColor: Colors.cardBackground,
    borderRadius: 8,
    position: 'relative',
    overflow: 'hidden',
  },
  timelineMarkers: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 8,
    height: '100%',
    alignItems: 'center',
  },
  marker: {
    width: 1,
    height: 20,
    backgroundColor: Colors.border,
  },
  selectedArea: {
    position: 'absolute',
    top: 0,
    height: '100%',
    backgroundColor: `${Colors.primary}40`,
    borderLeftWidth: 3,
    borderRightWidth: 3,
    borderColor: Colors.primary,
  },
  handle: {
    position: 'absolute',
    top: 0,
    width: 20,
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: -10,
    zIndex: 10,
  },
  handleBar: {
    width: 6,
    height: 36,
    backgroundColor: Colors.primary,
    borderRadius: 3,
  },
  timeLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  timeLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.text,
  },
  instructions: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.secondaryText,
    marginTop: 16,
    textAlign: 'center',
  },
});