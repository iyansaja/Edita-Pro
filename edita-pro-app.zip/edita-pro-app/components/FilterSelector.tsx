import React from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import Colors from '@/constants/Colors';

interface FilterSelectorProps {
  currentFilter: string;
  onSelectFilter: (filter: string) => void;
}

export default function FilterSelector({ currentFilter, onSelectFilter }: FilterSelectorProps) {
  const filters = [
    { id: 'normal', name: 'Normal' },
    { id: 'vintage', name: 'Vintage' },
    { id: 'b&w', name: 'B&W' },
    { id: 'sepia', name: 'Sepia' },
    { id: 'vivid', name: 'Vivid' },
    { id: 'cool', name: 'Cool' },
    { id: 'warm', name: 'Warm' },
  ];

  const demoImageUrl = 'https://images.pexels.com/photos/1640773/pexels-photo-1640773.jpeg?auto=compress&cs=tinysrgb&w=400';

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Apply Filter</Text>
      
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filtersContainer}
      >
        {filters.map(filter => (
          <TouchableOpacity
            key={filter.id}
            style={[
              styles.filterItem,
              currentFilter === filter.id && styles.selectedFilterItem
            ]}
            onPress={() => onSelectFilter(filter.id)}
          >
            <View style={styles.filterImageContainer}>
              <Image 
                source={{ uri: demoImageUrl }} 
                style={[
                  styles.filterImage,
                  getFilterStyle(filter.id)
                ]} 
              />
            </View>
            <Text style={[
              styles.filterName,
              currentFilter === filter.id && styles.selectedFilterName
            ]}>
              {filter.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      
      <Text style={styles.instructions}>
        Swipe to browse filters. Tap to apply.
      </Text>
    </View>
  );
}

const getFilterStyle = (filterId: string) => {
  switch (filterId) {
    case 'vintage':
      return { opacity: 0.8, tintColor: '#d0955e' };
    case 'b&w':
      return { tintColor: '#000000' };
    case 'sepia':
      return { tintColor: '#704214' };
    case 'vivid':
      return { tintColor: '#00a0ff' };
    case 'cool':
      return { tintColor: '#0099cc' };
    case 'warm':
      return { tintColor: '#ff9966' };
    default:
      return {};
  }
};

const styles = StyleSheet.create({
  container: {
    paddingVertical: 16,
  },
  title: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: Colors.text,
    marginBottom: 16,
  },
  filtersContainer: {
    paddingVertical: 8,
  },
  filterItem: {
    alignItems: 'center',
    marginRight: 20,
  },
  selectedFilterItem: {
    transform: [{ scale: 1.05 }],
  },
  filterImageContainer: {
    width: 80,
    height: 80,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  filterImage: {
    width: '100%',
    height: '100%',
  },
  filterName: {
    marginTop: 8,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.text,
  },
  selectedFilterName: {
    color: Colors.primary,
    fontFamily: 'Inter-Medium',
  },
  instructions: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.secondaryText,
    marginTop: 16,
    textAlign: 'center',
  },
});