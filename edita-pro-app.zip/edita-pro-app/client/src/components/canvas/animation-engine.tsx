import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Zap, 
  Move3D, 
  RotateCw, 
  Scale, 
  Eye, 
  Palette, 
  Waves, 
  Sparkles,
  Target,
  Clock,
  Play,
  Pause,
  Square,
  Plus,
  Trash2,
  Copy
} from 'lucide-react';

interface AnimationKeyframe {
  id: string;
  time: number; // 0-1 (percentage of animation)
  value: number | string | { x: number; y: number } | { r: number; g: number; b: number; a: number };
  easing: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out' | 'bounce' | 'elastic' | 'back';
}

interface AnimationTrack {
  id: string;
  name: string;
  property: 'x' | 'y' | 'scale' | 'rotation' | 'opacity' | 'color' | 'blur' | 'brightness';
  keyframes: AnimationKeyframe[];
  enabled: boolean;
  layerId: string;
}

interface AnimationProject {
  id: string;
  name: string;
  duration: number; // in milliseconds
  fps: number;
  tracks: AnimationTrack[];
  currentTime: number;
  isPlaying: boolean;
}

interface AnimationEngineProps {
  onAnimationUpdate?: (project: AnimationProject) => void;
  initialProject?: AnimationProject;
}

export function AnimationEngine({ onAnimationUpdate, initialProject }: AnimationEngineProps) {
  const [project, setProject] = useState<AnimationProject>(
    initialProject || {
      id: 'default',
      name: 'New Animation',
      duration: 3000,
      fps: 60,
      tracks: [],
      currentTime: 0,
      isPlaying: false
    }
  );

  const [selectedTrack, setSelectedTrack] = useState<string>('');
  const [timelineZoom, setTimelineZoom] = useState(1);
  const [previewMode, setPreviewMode] = useState<'realtime' | 'keyframes'>('realtime');
  const animationFrameRef = useRef<number>();

  // Animation presets
  const animationPresets = {
    'fade-in': {
      property: 'opacity' as const,
      keyframes: [
        { time: 0, value: 0, easing: 'ease-out' as const },
        { time: 1, value: 1, easing: 'ease-out' as const }
      ]
    },
    'slide-in-left': {
      property: 'x' as const,
      keyframes: [
        { time: 0, value: -100, easing: 'ease-out' as const },
        { time: 1, value: 0, easing: 'ease-out' as const }
      ]
    },
    'bounce-scale': {
      property: 'scale' as const,
      keyframes: [
        { time: 0, value: 0, easing: 'bounce' as const },
        { time: 0.6, value: 1.2, easing: 'bounce' as const },
        { time: 1, value: 1, easing: 'bounce' as const }
      ]
    },
    'rotate-360': {
      property: 'rotation' as const,
      keyframes: [
        { time: 0, value: 0, easing: 'linear' as const },
        { time: 1, value: 360, easing: 'linear' as const }
      ]
    },
    'pulse': {
      property: 'scale' as const,
      keyframes: [
        { time: 0, value: 1, easing: 'ease-in-out' as const },
        { time: 0.5, value: 1.1, easing: 'ease-in-out' as const },
        { time: 1, value: 1, easing: 'ease-in-out' as const }
      ]
    },
    'shake': {
      property: 'x' as const,
      keyframes: [
        { time: 0, value: 0, easing: 'linear' as const },
        { time: 0.1, value: -10, easing: 'linear' as const },
        { time: 0.2, value: 10, easing: 'linear' as const },
        { time: 0.3, value: -10, easing: 'linear' as const },
        { time: 0.4, value: 10, easing: 'linear' as const },
        { time: 0.5, value: 0, easing: 'linear' as const }
      ]
    }
  };

  // Easing functions
  const easingFunctions = {
    linear: (t: number) => t,
    'ease-in': (t: number) => t * t,
    'ease-out': (t: number) => 1 - (1 - t) * (1 - t),
    'ease-in-out': (t: number) => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2,
    bounce: (t: number) => {
      const n1 = 7.5625;
      const d1 = 2.75;
      if (t < 1 / d1) return n1 * t * t;
      else if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75;
      else if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375;
      else return n1 * (t -= 2.625 / d1) * t + 0.984375;
    },
    elastic: (t: number) => {
      const c4 = (2 * Math.PI) / 3;
      return t === 0 ? 0 : t === 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
    },
    back: (t: number) => {
      const c1 = 1.70158;
      const c3 = c1 + 1;
      return c3 * t * t * t - c1 * t * t;
    }
  };

  // Animation playback
  const playAnimation = () => {
    setProject(prev => ({ ...prev, isPlaying: true }));
  };

  const pauseAnimation = () => {
    setProject(prev => ({ ...prev, isPlaying: false }));
  };

  const stopAnimation = () => {
    setProject(prev => ({ ...prev, isPlaying: false, currentTime: 0 }));
  };

  // Track management
  const addTrack = (property: AnimationTrack['property'], layerId: string = 'layer1') => {
    const newTrack: AnimationTrack = {
      id: `track_${Date.now()}`,
      name: `${property.charAt(0).toUpperCase() + property.slice(1)} Animation`,
      property,
      keyframes: [
        {
          id: `kf_${Date.now()}_1`,
          time: 0,
          value: getDefaultValueForProperty(property),
          easing: 'ease-out'
        },
        {
          id: `kf_${Date.now()}_2`,
          time: 1,
          value: getDefaultValueForProperty(property, true),
          easing: 'ease-out'
        }
      ],
      enabled: true,
      layerId
    };

    setProject(prev => ({
      ...prev,
      tracks: [...prev.tracks, newTrack]
    }));
  };

  const removeTrack = (trackId: string) => {
    setProject(prev => ({
      ...prev,
      tracks: prev.tracks.filter(track => track.id !== trackId)
    }));
  };

  const duplicateTrack = (trackId: string) => {
    const track = project.tracks.find(t => t.id === trackId);
    if (track) {
      const newTrack: AnimationTrack = {
        ...track,
        id: `track_${Date.now()}`,
        name: `${track.name} Copy`,
        keyframes: track.keyframes.map(kf => ({
          ...kf,
          id: `kf_${Date.now()}_${Math.random()}`
        }))
      };
      setProject(prev => ({
        ...prev,
        tracks: [...prev.tracks, newTrack]
      }));
    }
  };

  const applyPreset = (presetName: keyof typeof animationPresets, layerId: string = 'layer1') => {
    const preset = animationPresets[presetName];
    const newTrack: AnimationTrack = {
      id: `track_${Date.now()}`,
      name: `${presetName.charAt(0).toUpperCase() + presetName.slice(1).replace('-', ' ')}`,
      property: preset.property,
      keyframes: preset.keyframes.map((kf, index) => ({
        id: `kf_${Date.now()}_${index}`,
        time: kf.time,
        value: kf.value,
        easing: kf.easing
      })),
      enabled: true,
      layerId
    };

    setProject(prev => ({
      ...prev,
      tracks: [...prev.tracks, newTrack]
    }));
  };

  const getDefaultValueForProperty = (property: AnimationTrack['property'], isEnd: boolean = false): any => {
    switch (property) {
      case 'x':
      case 'y':
        return isEnd ? 100 : 0;
      case 'scale':
        return isEnd ? 1.2 : 1;
      case 'rotation':
        return isEnd ? 360 : 0;
      case 'opacity':
        return isEnd ? 1 : 0;
      case 'blur':
        return isEnd ? 0 : 10;
      case 'brightness':
        return isEnd ? 100 : 50;
      case 'color':
        return isEnd ? { r: 255, g: 255, b: 255, a: 1 } : { r: 0, g: 0, b: 0, a: 1 };
      default:
        return 0;
    }
  };

  // Keyframe management
  const addKeyframe = (trackId: string, time: number) => {
    setProject(prev => ({
      ...prev,
      tracks: prev.tracks.map(track => {
        if (track.id === trackId) {
          const newKeyframe: AnimationKeyframe = {
            id: `kf_${Date.now()}`,
            time,
            value: interpolateValueAtTime(track, time),
            easing: 'ease-out'
          };
          return {
            ...track,
            keyframes: [...track.keyframes, newKeyframe].sort((a, b) => a.time - b.time)
          };
        }
        return track;
      })
    }));
  };

  const removeKeyframe = (trackId: string, keyframeId: string) => {
    setProject(prev => ({
      ...prev,
      tracks: prev.tracks.map(track => {
        if (track.id === trackId) {
          return {
            ...track,
            keyframes: track.keyframes.filter(kf => kf.id !== keyframeId)
          };
        }
        return track;
      })
    }));
  };

  const updateKeyframe = (trackId: string, keyframeId: string, updates: Partial<AnimationKeyframe>) => {
    setProject(prev => ({
      ...prev,
      tracks: prev.tracks.map(track => {
        if (track.id === trackId) {
          return {
            ...track,
            keyframes: track.keyframes.map(kf => 
              kf.id === keyframeId ? { ...kf, ...updates } : kf
            ).sort((a, b) => a.time - b.time)
          };
        }
        return track;
      })
    }));
  };

  const interpolateValueAtTime = (track: AnimationTrack, time: number): any => {
    const keyframes = track.keyframes.sort((a, b) => a.time - b.time);
    
    if (keyframes.length === 0) return 0;
    if (time <= keyframes[0].time) return keyframes[0].value;
    if (time >= keyframes[keyframes.length - 1].time) return keyframes[keyframes.length - 1].value;

    for (let i = 0; i < keyframes.length - 1; i++) {
      const current = keyframes[i];
      const next = keyframes[i + 1];
      
      if (time >= current.time && time <= next.time) {
        const progress = (time - current.time) / (next.time - current.time);
        const easedProgress = easingFunctions[current.easing](progress);
        
        if (typeof current.value === 'number' && typeof next.value === 'number') {
          return current.value + (next.value - current.value) * easedProgress;
        }
        
        return easedProgress < 0.5 ? current.value : next.value;
      }
    }
    
    return keyframes[0].value;
  };

  // Animation loop
  useEffect(() => {
    if (project.isPlaying) {
      const animate = () => {
        setProject(prev => {
          const newTime = prev.currentTime + (1000 / prev.fps);
          const normalizedTime = newTime >= prev.duration ? 0 : newTime;
          
          return {
            ...prev,
            currentTime: normalizedTime
          };
        });
        
        animationFrameRef.current = requestAnimationFrame(animate);
      };
      
      animationFrameRef.current = requestAnimationFrame(animate);
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [project.isPlaying, project.fps]);

  // Notify parent of updates
  useEffect(() => {
    if (onAnimationUpdate) {
      onAnimationUpdate(project);
    }
  }, [project, onAnimationUpdate]);

  const getPropertyIcon = (property: AnimationTrack['property']) => {
    switch (property) {
      case 'x':
      case 'y':
        return <Move3D className="h-4 w-4" />;
      case 'scale':
        return <Scale className="h-4 w-4" />;
      case 'rotation':
        return <RotateCw className="h-4 w-4" />;
      case 'opacity':
        return <Eye className="h-4 w-4" />;
      case 'color':
        return <Palette className="h-4 w-4" />;
      case 'blur':
      case 'brightness':
        return <Sparkles className="h-4 w-4" />;
      default:
        return <Zap className="h-4 w-4" />;
    }
  };

  return (
    <div className="w-full h-full bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 p-6 rounded-lg">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Zap className="h-6 w-6 text-yellow-400" />
            Animation Engine Pro
          </h2>
          
          <div className="flex items-center gap-2">
            <Button onClick={playAnimation} disabled={project.isPlaying} variant="default" size="sm">
              <Play className="h-4 w-4" />
            </Button>
            <Button onClick={pauseAnimation} disabled={!project.isPlaying} variant="secondary" size="sm">
              <Pause className="h-4 w-4" />
            </Button>
            <Button onClick={stopAnimation} variant="secondary" size="sm">
              <Square className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <Tabs defaultValue="timeline" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
            <TabsTrigger value="properties">Properties</TabsTrigger>
            <TabsTrigger value="presets">Presets</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="timeline" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Animation Timeline
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-400">
                    Time: {Math.round(project.currentTime)}ms / {project.duration}ms
                  </div>
                  <div className="flex items-center gap-2">
                    <Label>Zoom:</Label>
                    <Slider
                      value={[timelineZoom]}
                      onValueChange={(value) => setTimelineZoom(value[0])}
                      max={5}
                      min={0.5}
                      step={0.1}
                      className="w-20"
                    />
                  </div>
                </div>

                <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all duration-75"
                    style={{ width: `${(project.currentTime / project.duration) * 100}%` }}
                  />
                </div>

                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {project.tracks.map(track => (
                    <div key={track.id} className="p-3 bg-black/30 rounded-lg border border-purple-500/20">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {getPropertyIcon(track.property)}
                          <span className="text-sm font-medium text-white">{track.name}</span>
                          <Badge variant={track.enabled ? "default" : "secondary"}>
                            {track.property}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button 
                            onClick={() => duplicateTrack(track.id)} 
                            variant="ghost" 
                            size="sm"
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                          <Button 
                            onClick={() => removeTrack(track.id)} 
                            variant="ghost" 
                            size="sm"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        {track.keyframes.map(keyframe => (
                          <div
                            key={keyframe.id}
                            className="w-3 h-3 bg-yellow-400 rounded-full cursor-pointer hover:bg-yellow-300"
                            style={{ 
                              marginLeft: `${keyframe.time * 200 * timelineZoom}px` 
                            }}
                            onClick={() => setSelectedTrack(track.id)}
                          />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <Button onClick={() => addTrack('opacity')} variant="outline" size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Track
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="properties" className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {['x', 'y', 'scale', 'rotation', 'opacity', 'color', 'blur', 'brightness'].map(property => (
                <Button
                  key={property}
                  onClick={() => addTrack(property as AnimationTrack['property'])}
                  variant="outline"
                  className="h-20 flex-col gap-2"
                >
                  {getPropertyIcon(property as AnimationTrack['property'])}
                  <span className="capitalize">{property}</span>
                </Button>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="presets" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Object.keys(animationPresets).map(presetName => (
                <Card key={presetName} className="cursor-pointer hover:border-purple-500/50 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-white capitalize">
                        {presetName.replace('-', ' ')}
                      </h4>
                      <Button 
                        onClick={() => applyPreset(presetName as keyof typeof animationPresets)}
                        variant="ghost" 
                        size="sm"
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <p className="text-xs text-gray-400">
                      {animationPresets[presetName as keyof typeof animationPresets].property} animation
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Animation Name</Label>
                    <Input 
                      value={project.name}
                      onChange={(e) => setProject(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Duration (ms)</Label>
                    <Input 
                      type="number"
                      value={project.duration}
                      onChange={(e) => setProject(prev => ({ ...prev, duration: parseInt(e.target.value) || 3000 }))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Frame Rate (FPS)</Label>
                    <Select 
                      value={project.fps.toString()}
                      onValueChange={(value) => setProject(prev => ({ ...prev, fps: parseInt(value) }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="24">24 FPS</SelectItem>
                        <SelectItem value="30">30 FPS</SelectItem>
                        <SelectItem value="60">60 FPS</SelectItem>
                        <SelectItem value="120">120 FPS</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Preview Mode</Label>
                    <Select 
                      value={previewMode}
                      onValueChange={(value: 'realtime' | 'keyframes') => setPreviewMode(value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="realtime">Real-time</SelectItem>
                        <SelectItem value="keyframes">Keyframes Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="text-center text-sm text-gray-400">
          Tracks: {project.tracks.length} | Keyframes: {project.tracks.reduce((sum, track) => sum + track.keyframes.length, 0)} | FPS: {project.fps}
        </div>
      </div>
    </div>
  );
}