import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Play, Pause, Square, RotateCcw, Download, Layers, Palette, Sparkles } from 'lucide-react';

interface CanvasLayer {
  id: string;
  name: string;
  type: 'text' | 'image' | 'video' | 'shape' | 'effect';
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  opacity: number;
  visible: boolean;
  data: any;
}

interface Animation {
  id: string;
  layerId: string;
  property: string;
  keyframes: Array<{
    time: number;
    value: any;
    easing: string;
  }>;
  duration: number;
  loop: boolean;
}

interface CanvasRendererProps {
  width?: number;
  height?: number;
  onExport?: (dataUrl: string) => void;
}

export function CanvasRenderer({ width = 1920, height = 1080, onExport }: CanvasRendererProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  const [layers, setLayers] = useState<CanvasLayer[]>([]);
  const [animations, setAnimations] = useState<Animation[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(5000); // 5 seconds
  const [selectedLayer, setSelectedLayer] = useState<string>('');
  const [renderMode, setRenderMode] = useState<'2d' | 'webgl'>('2d');

  // Animation engine core
  const animate = useCallback((timestamp: number) => {
    if (!isPlaying) return;

    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Apply background
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, '#1a1a2e');
    gradient.addColorStop(0.5, '#16213e');
    gradient.addColorStop(1, '#0f172a');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Render each layer with animations
    layers.forEach(layer => {
      if (!layer.visible) return;

      ctx.save();
      
      // Apply transformations
      ctx.translate(layer.x + layer.width / 2, layer.y + layer.height / 2);
      ctx.rotate((layer.rotation * Math.PI) / 180);
      ctx.globalAlpha = layer.opacity;

      // Apply animations
      const layerAnimations = animations.filter(anim => anim.layerId === layer.id);
      layerAnimations.forEach(animation => {
        const progress = (currentTime % animation.duration) / animation.duration;
        applyAnimationFrame(layer, animation, progress, ctx);
      });

      // Render layer based on type
      switch (layer.type) {
        case 'text':
          renderTextLayer(ctx, layer);
          break;
        case 'shape':
          renderShapeLayer(ctx, layer);
          break;
        case 'effect':
          renderEffectLayer(ctx, layer);
          break;
        case 'image':
          renderImageLayer(ctx, layer);
          break;
      }

      ctx.restore();
    });

    setCurrentTime(prev => (prev + 16) % duration); // 60fps
    
    if (isPlaying) {
      animationFrameRef.current = requestAnimationFrame(animate);
    }
  }, [isPlaying, layers, animations, currentTime, duration, width, height]);

  // Text rendering with effects
  const renderTextLayer = (ctx: CanvasRenderingContext2D, layer: CanvasLayer) => {
    const { text, fontSize, fontFamily, color, strokeColor, strokeWidth, shadow } = layer.data;
    
    ctx.font = `${fontSize}px ${fontFamily}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // Shadow effect
    if (shadow) {
      ctx.shadowColor = shadow.color;
      ctx.shadowBlur = shadow.blur;
      ctx.shadowOffsetX = shadow.offsetX;
      ctx.shadowOffsetY = shadow.offsetY;
    }

    // Stroke
    if (strokeColor && strokeWidth > 0) {
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = strokeWidth;
      ctx.strokeText(text, 0, 0);
    }

    // Fill
    ctx.fillStyle = color;
    ctx.fillText(text, 0, 0);
  };

  // Shape rendering with gradients
  const renderShapeLayer = (ctx: CanvasRenderingContext2D, layer: CanvasLayer) => {
    const { shape, fillColor, strokeColor, strokeWidth, gradient } = layer.data;
    
    ctx.beginPath();
    
    const halfWidth = layer.width / 2;
    const halfHeight = layer.height / 2;

    switch (shape) {
      case 'rectangle':
        ctx.rect(-halfWidth, -halfHeight, layer.width, layer.height);
        break;
      case 'circle':
        ctx.arc(0, 0, Math.min(halfWidth, halfHeight), 0, 2 * Math.PI);
        break;
      case 'triangle':
        ctx.moveTo(0, -halfHeight);
        ctx.lineTo(-halfWidth, halfHeight);
        ctx.lineTo(halfWidth, halfHeight);
        ctx.closePath();
        break;
      case 'star':
        drawStar(ctx, 0, 0, 5, Math.min(halfWidth, halfHeight), Math.min(halfWidth, halfHeight) * 0.5);
        break;
    }

    // Apply gradient or solid fill
    if (gradient) {
      const canvasGradient = ctx.createLinearGradient(-halfWidth, -halfHeight, halfWidth, halfHeight);
      gradient.stops.forEach((stop: any) => {
        canvasGradient.addColorStop(stop.offset, stop.color);
      });
      ctx.fillStyle = canvasGradient;
    } else {
      ctx.fillStyle = fillColor;
    }

    ctx.fill();

    if (strokeColor && strokeWidth > 0) {
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = strokeWidth;
      ctx.stroke();
    }
  };

  // Particle effects rendering
  const renderEffectLayer = (ctx: CanvasRenderingContext2D, layer: CanvasLayer) => {
    const { effect, particles, intensity, color } = layer.data;
    
    switch (effect) {
      case 'sparkles':
        renderSparkles(ctx, particles, intensity, color);
        break;
      case 'rain':
        renderRain(ctx, particles, intensity, color);
        break;
      case 'snow':
        renderSnow(ctx, particles, intensity, color);
        break;
      case 'fire':
        renderFire(ctx, particles, intensity, color);
        break;
    }
  };

  const renderImageLayer = (ctx: CanvasRenderingContext2D, layer: CanvasLayer) => {
    const { imageData, filter } = layer.data;
    if (imageData) {
      // Apply filters
      if (filter) {
        ctx.filter = filter;
      }
      ctx.drawImage(imageData, -layer.width / 2, -layer.height / 2, layer.width, layer.height);
      ctx.filter = 'none';
    }
  };

  // Animation frame application
  const applyAnimationFrame = (layer: CanvasLayer, animation: Animation, progress: number, ctx: CanvasRenderingContext2D) => {
    const { keyframes, property } = animation;
    
    // Find current keyframe
    const currentKeyframe = keyframes.find((kf, index) => {
      const nextKeyframe = keyframes[index + 1];
      return progress >= kf.time && (!nextKeyframe || progress < nextKeyframe.time);
    });

    if (!currentKeyframe) return;

    const nextKeyframe = keyframes.find(kf => kf.time > progress);
    
    if (nextKeyframe) {
      // Interpolate between keyframes
      const t = (progress - currentKeyframe.time) / (nextKeyframe.time - currentKeyframe.time);
      const easedT = applyEasing(t, currentKeyframe.easing);
      const value = interpolateValue(currentKeyframe.value, nextKeyframe.value, easedT);
      
      applyAnimationProperty(layer, property, value, ctx);
    } else {
      applyAnimationProperty(layer, property, currentKeyframe.value, ctx);
    }
  };

  const applyEasing = (t: number, easing: string): number => {
    switch (easing) {
      case 'ease-in':
        return t * t;
      case 'ease-out':
        return 1 - (1 - t) * (1 - t);
      case 'ease-in-out':
        return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      case 'bounce':
        return bounce(t);
      default:
        return t;
    }
  };

  const interpolateValue = (start: any, end: any, t: number): any => {
    if (typeof start === 'number' && typeof end === 'number') {
      return start + (end - start) * t;
    }
    return t < 0.5 ? start : end;
  };

  const applyAnimationProperty = (layer: CanvasLayer, property: string, value: any, ctx: CanvasRenderingContext2D) => {
    switch (property) {
      case 'scale':
        ctx.scale(value, value);
        break;
      case 'rotation':
        ctx.rotate((value * Math.PI) / 180);
        break;
      case 'opacity':
        ctx.globalAlpha *= value;
        break;
    }
  };

  // Utility functions
  const drawStar = (ctx: CanvasRenderingContext2D, cx: number, cy: number, spikes: number, outerRadius: number, innerRadius: number) => {
    let rot = Math.PI / 2 * 3;
    const step = Math.PI / spikes;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);

    for (let i = 0; i < spikes; i++) {
      const x = cx + Math.cos(rot) * outerRadius;
      const y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      const x2 = cx + Math.cos(rot) * innerRadius;
      const y2 = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x2, y2);
      rot += step;
    }

    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
  };

  const renderSparkles = (ctx: CanvasRenderingContext2D, particles: any[], intensity: number, color: string) => {
    particles.forEach(particle => {
      ctx.save();
      ctx.translate(particle.x, particle.y);
      ctx.rotate(particle.rotation);
      ctx.globalAlpha = particle.alpha * intensity;
      
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(0, 0, particle.size, 0, 2 * Math.PI);
      ctx.fill();
      
      ctx.restore();
    });
  };

  const renderRain = (ctx: CanvasRenderingContext2D, particles: any[], intensity: number, color: string) => {
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.globalAlpha = intensity;
    
    particles.forEach(particle => {
      ctx.beginPath();
      ctx.moveTo(particle.x, particle.y);
      ctx.lineTo(particle.x, particle.y + particle.length);
      ctx.stroke();
    });
  };

  const renderSnow = (ctx: CanvasRenderingContext2D, particles: any[], intensity: number, color: string) => {
    ctx.fillStyle = color;
    ctx.globalAlpha = intensity;
    
    particles.forEach(particle => {
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size, 0, 2 * Math.PI);
      ctx.fill();
    });
  };

  const renderFire = (ctx: CanvasRenderingContext2D, particles: any[], intensity: number, color: string) => {
    particles.forEach(particle => {
      const gradient = ctx.createRadialGradient(particle.x, particle.y, 0, particle.x, particle.y, particle.size);
      gradient.addColorStop(0, color);
      gradient.addColorStop(1, 'transparent');
      
      ctx.fillStyle = gradient;
      ctx.globalAlpha = particle.alpha * intensity;
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size, 0, 2 * Math.PI);
      ctx.fill();
    });
  };

  const bounce = (t: number): number => {
    const n1 = 7.5625;
    const d1 = 2.75;

    if (t < 1 / d1) {
      return n1 * t * t;
    } else if (t < 2 / d1) {
      return n1 * (t -= 1.5 / d1) * t + 0.75;
    } else if (t < 2.5 / d1) {
      return n1 * (t -= 2.25 / d1) * t + 0.9375;
    } else {
      return n1 * (t -= 2.625 / d1) * t + 0.984375;
    }
  };

  // Control functions
  const play = () => {
    setIsPlaying(true);
  };

  const pause = () => {
    setIsPlaying(false);
  };

  const stop = () => {
    setIsPlaying(false);
    setCurrentTime(0);
  };

  const reset = () => {
    stop();
    setLayers([]);
    setAnimations([]);
  };

  const exportCanvas = () => {
    const canvas = canvasRef.current;
    if (canvas && onExport) {
      const dataUrl = canvas.toDataURL('image/png');
      onExport(dataUrl);
    }
  };

  // Add sample layers and animations
  const addTextLayer = () => {
    const newLayer: CanvasLayer = {
      id: `text_${Date.now()}`,
      name: 'Text Layer',
      type: 'text',
      x: width / 2 - 100,
      y: height / 2 - 25,
      width: 200,
      height: 50,
      rotation: 0,
      opacity: 1,
      visible: true,
      data: {
        text: 'Edita Pro',
        fontSize: 48,
        fontFamily: 'Arial',
        color: '#ffffff',
        strokeColor: '#000000',
        strokeWidth: 2,
        shadow: {
          color: 'rgba(0,0,0,0.5)',
          blur: 10,
          offsetX: 2,
          offsetY: 2
        }
      }
    };
    setLayers(prev => [...prev, newLayer]);
  };

  const addShapeLayer = () => {
    const newLayer: CanvasLayer = {
      id: `shape_${Date.now()}`,
      name: 'Shape Layer',
      type: 'shape',
      x: width / 2 - 50,
      y: height / 2 - 50,
      width: 100,
      height: 100,
      rotation: 0,
      opacity: 1,
      visible: true,
      data: {
        shape: 'circle',
        fillColor: '#ff6b6b',
        strokeColor: '#ffffff',
        strokeWidth: 3,
        gradient: {
          stops: [
            { offset: 0, color: '#ff6b6b' },
            { offset: 1, color: '#feca57' }
          ]
        }
      }
    };
    setLayers(prev => [...prev, newLayer]);
  };

  const addEffectLayer = () => {
    const particles = Array.from({ length: 50 }, (_, i) => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 3 + 1,
      alpha: Math.random(),
      rotation: Math.random() * Math.PI * 2
    }));

    const newLayer: CanvasLayer = {
      id: `effect_${Date.now()}`,
      name: 'Effect Layer',
      type: 'effect',
      x: 0,
      y: 0,
      width: width,
      height: height,
      rotation: 0,
      opacity: 1,
      visible: true,
      data: {
        effect: 'sparkles',
        particles,
        intensity: 0.8,
        color: '#ffd700'
      }
    };
    setLayers(prev => [...prev, newLayer]);
  };

  useEffect(() => {
    if (isPlaying) {
      animationFrameRef.current = requestAnimationFrame(animate);
    }
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [animate, isPlaying]);

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6 rounded-lg">
      <div className="mb-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-purple-400" />
            Canvas Renderer & Animation Engine
          </h2>
          
          <div className="flex items-center gap-2">
            <Button onClick={play} disabled={isPlaying} variant="default" size="sm">
              <Play className="h-4 w-4" />
            </Button>
            <Button onClick={pause} disabled={!isPlaying} variant="secondary" size="sm">
              <Pause className="h-4 w-4" />
            </Button>
            <Button onClick={stop} variant="secondary" size="sm">
              <Square className="h-4 w-4" />
            </Button>
            <Button onClick={reset} variant="destructive" size="sm">
              <RotateCcw className="h-4 w-4" />
            </Button>
            <Button onClick={exportCanvas} variant="default" size="sm">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-white">Render Mode</label>
            <Select value={renderMode} onValueChange={(value: '2d' | 'webgl') => setRenderMode(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2d">2D Canvas</SelectItem>
                <SelectItem value="webgl">WebGL</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-white">Duration (ms)</label>
            <Slider
              value={[duration]}
              onValueChange={(value) => setDuration(value[0])}
              max={10000}
              min={1000}
              step={100}
              className="w-full"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-white">Current Time: {currentTime}ms</label>
            <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-purple-500 transition-all duration-75"
                style={{ width: `${(currentTime / duration) * 100}%` }}
              />
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button onClick={addTextLayer} variant="outline" size="sm">
            <Layers className="h-4 w-4 mr-2" />
            Add Text
          </Button>
          <Button onClick={addShapeLayer} variant="outline" size="sm">
            <Palette className="h-4 w-4 mr-2" />
            Add Shape
          </Button>
          <Button onClick={addEffectLayer} variant="outline" size="sm">
            <Sparkles className="h-4 w-4 mr-2" />
            Add Effect
          </Button>
        </div>
      </div>

      <div className="border border-purple-500/30 rounded-lg overflow-hidden bg-black/50">
        <canvas
          ref={canvasRef}
          width={width}
          height={height}
          className="w-full h-auto max-h-[500px] object-contain"
        />
      </div>

      <div className="mt-4 text-center text-sm text-gray-400">
        Canvas Size: {width} × {height} | Layers: {layers.length} | Playing: {isPlaying ? 'Yes' : 'No'}
      </div>
    </div>
  );
}