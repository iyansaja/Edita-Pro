import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Play, 
  Pause, 
  Square, 
  Download, 
  Share2, 
  Heart, 
  Bookmark,
  MoreHorizontal,
  Zap,
  Sparkles,
  Rocket,
  Star,
  Award,
  Gift,
  Crown,
  Flame
} from 'lucide-react';

interface ActionButtonsProps {
  onPlay?: () => void;
  onPause?: () => void;
  onStop?: () => void;
  onDownload?: () => void;
  onShare?: () => void;
  onLike?: () => void;
  onBookmark?: () => void;
  isPlaying?: boolean;
  isLiked?: boolean;
  isBookmarked?: boolean;
  downloadCount?: number;
  likeCount?: number;
}

export function ActionButtons({
  onPlay,
  onPause,
  onStop,
  onDownload,
  onShare,
  onLike,
  onBookmark,
  isPlaying = false,
  isLiked = false,
  isBookmarked = false,
  downloadCount = 0,
  likeCount = 0
}: ActionButtonsProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <Card className="modern-card glass-morphism">
      <CardContent className="p-4">
        <div className="flex items-center justify-between space-x-3">
          {/* Playback Controls */}
          <div className="flex items-center space-x-2">
            <Button
              onClick={isPlaying ? onPause : onPlay}
              size="lg"
              className="relative overflow-hidden bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105"
              onMouseEnter={() => setIsHovered(true)}
              onMouseLeave={() => setIsHovered(false)}
            >
              {isPlaying ? (
                <Pause className="h-5 w-5 text-white" />
              ) : (
                <Play className="h-5 w-5 text-white" />
              )}
              {isHovered && (
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 animate-pulse" />
              )}
            </Button>
            
            <Button
              onClick={onStop}
              variant="outline"
              size="lg"
              className="hover:bg-red-50 hover:border-red-200 dark:hover:bg-red-900/20 transition-all duration-200"
            >
              <Square className="h-4 w-4 text-red-500" />
            </Button>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            {/* Download Button */}
            <Button
              onClick={onDownload}
              variant="outline"
              size="lg"
              className="relative group hover:bg-green-50 hover:border-green-200 dark:hover:bg-green-900/20 transition-all duration-300"
            >
              <Download className="h-4 w-4 text-green-600 group-hover:animate-bounce" />
              {downloadCount > 0 && (
                <Badge variant="secondary" className="ml-2 text-xs">
                  {downloadCount}
                </Badge>
              )}
            </Button>

            {/* Like Button */}
            <Button
              onClick={onLike}
              variant="outline"
              size="lg"
              className={`relative group transition-all duration-300 ${
                isLiked 
                  ? 'bg-red-50 border-red-200 dark:bg-red-900/20' 
                  : 'hover:bg-red-50 hover:border-red-200 dark:hover:bg-red-900/20'
              }`}
            >
              <Heart 
                className={`h-4 w-4 transition-all duration-200 ${
                  isLiked 
                    ? 'text-red-500 fill-current animate-pulse' 
                    : 'text-red-500 group-hover:scale-110'
                }`} 
              />
              {likeCount > 0 && (
                <Badge variant="secondary" className="ml-2 text-xs">
                  {likeCount}
                </Badge>
              )}
            </Button>

            {/* Bookmark Button */}
            <Button
              onClick={onBookmark}
              variant="outline"
              size="lg"
              className={`relative group transition-all duration-300 ${
                isBookmarked 
                  ? 'bg-yellow-50 border-yellow-200 dark:bg-yellow-900/20' 
                  : 'hover:bg-yellow-50 hover:border-yellow-200 dark:hover:bg-yellow-900/20'
              }`}
            >
              <Bookmark 
                className={`h-4 w-4 transition-all duration-200 ${
                  isBookmarked 
                    ? 'text-yellow-500 fill-current' 
                    : 'text-yellow-500 group-hover:scale-110'
                }`} 
              />
            </Button>

            {/* Share Button */}
            <Button
              onClick={onShare}
              variant="outline"
              size="lg"
              className="relative group hover:bg-blue-50 hover:border-blue-200 dark:hover:bg-blue-900/20 transition-all duration-300"
            >
              <Share2 className="h-4 w-4 text-blue-600 group-hover:rotate-12 transition-transform duration-200" />
            </Button>

            {/* More Actions */}
            <Button
              variant="outline"
              size="lg"
              className="hover:bg-gray-50 hover:border-gray-200 dark:hover:bg-gray-800 transition-all duration-200"
            >
              <MoreHorizontal className="h-4 w-4 text-gray-600" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Quick Action Buttons untuk berbagai fitur
export function QuickActionButtons() {
  const quickActions = [
    { 
      icon: Zap, 
      label: 'Quick Edit', 
      color: 'from-yellow-400 to-orange-500',
      description: 'Edit cepat dengan AI'
    },
    { 
      icon: Sparkles, 
      label: 'Magic Effects', 
      color: 'from-purple-400 to-pink-500',
      description: 'Efek ajaib otomatis'
    },
    { 
      icon: Rocket, 
      label: 'Export Pro', 
      color: 'from-blue-400 to-cyan-500',
      description: 'Export kualitas tinggi'
    },
    { 
      icon: Star, 
      label: 'Premium', 
      color: 'from-amber-400 to-yellow-500',
      description: 'Fitur premium'
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {quickActions.map((action, index) => (
        <Card 
          key={index}
          className="modern-card glass-morphism hover:scale-105 transition-all duration-300 cursor-pointer group"
        >
          <CardContent className="p-4 text-center">
            <div className={`w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-r ${action.color} flex items-center justify-center group-hover:rotate-12 transition-transform duration-300`}>
              <action.icon className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-semibold text-sm mb-1 gradient-text">{action.label}</h3>
            <p className="text-xs text-gray-600 dark:text-gray-400">{action.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// Floating Action Button
export function FloatingActionButton({ 
  icon: Icon = Flame, 
  onClick, 
  variant = 'primary' 
}: { 
  icon?: any, 
  onClick?: () => void,
  variant?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger'
}) {
  const variants = {
    primary: 'from-blue-500 to-purple-600 shadow-blue-500/25',
    secondary: 'from-gray-500 to-gray-600 shadow-gray-500/25',
    success: 'from-green-500 to-emerald-600 shadow-green-500/25',
    warning: 'from-yellow-500 to-orange-600 shadow-yellow-500/25',
    danger: 'from-red-500 to-pink-600 shadow-red-500/25'
  };

  return (
    <Button
      onClick={onClick}
      size="lg"
      className={`fixed bottom-6 right-6 w-14 h-14 rounded-full bg-gradient-to-r ${variants[variant]} hover:scale-110 transition-all duration-300 shadow-xl hover:shadow-2xl z-50`}
    >
      <Icon className="h-6 w-6 text-white" />
    </Button>
  );
}

// Achievement Badges
export function AchievementBadges() {
  const achievements = [
    { icon: Award, label: 'Pro Editor', unlocked: true },
    { icon: Crown, label: 'Master Creator', unlocked: true },
    { icon: Gift, label: 'Early Adopter', unlocked: false },
    { icon: Star, label: 'Featured Creator', unlocked: false },
  ];

  return (
    <div className="flex space-x-2">
      {achievements.map((achievement, index) => (
        <div
          key={index}
          className={`relative group ${
            achievement.unlocked 
              ? 'opacity-100' 
              : 'opacity-40 grayscale'
          }`}
        >
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
            achievement.unlocked
              ? 'bg-gradient-to-r from-amber-400 to-yellow-500 shadow-lg'
              : 'bg-gray-300 dark:bg-gray-600'
          }`}>
            <achievement.icon className="h-5 w-5 text-white" />
          </div>
          
          {/* Tooltip */}
          <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-black text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
            {achievement.label}
          </div>
        </div>
      ))}
    </div>
  );
}