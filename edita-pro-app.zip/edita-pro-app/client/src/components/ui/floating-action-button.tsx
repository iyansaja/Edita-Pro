import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  FileText, 
  Video, 
  Music, 
  Image,
  Sparkles,
  X,
  Zap,
  Palette,
  Camera,
  Mic
} from 'lucide-react';
import { useLocation } from 'wouter';

interface FABProps {
  onCreateNew?: (type: string) => void;
}

export function FloatingActionButton({ onCreateNew }: FABProps) {
  const [, setLocation] = useLocation();
  const [isExpanded, setIsExpanded] = useState(false);

  const projectTypes = [
    {
      id: 'document',
      label: 'Dokumen',
      icon: FileText,
      color: 'from-blue-500 to-cyan-500',
      description: 'Buat dokumen baru',
      action: () => {
        setLocation('/editor?type=document');
        onCreateNew?.('document');
        setIsExpanded(false);
      }
    },
    {
      id: 'video',
      label: 'Video',
      icon: Video,
      color: 'from-red-500 to-pink-500',
      description: 'Project video editing',
      action: () => {
        setLocation('/editor?type=video');
        onCreateNew?.('video');
        setIsExpanded(false);
      }
    },
    {
      id: 'audio',
      label: 'Audio',
      icon: Music,
      color: 'from-green-500 to-emerald-500',
      description: 'Project audio editing',
      action: () => {
        setLocation('/editor?type=audio');
        onCreateNew?.('audio');
        setIsExpanded(false);
      }
    },
    {
      id: 'canvas',
      label: 'Canvas',
      icon: Palette,
      color: 'from-purple-500 to-violet-500',
      description: 'Canvas & Animation',
      action: () => {
        setLocation('/editor?type=canvas');
        onCreateNew?.('canvas');
        setIsExpanded(false);
      }
    },
    {
      id: 'camera',
      label: 'Camera',
      icon: Camera,
      color: 'from-orange-500 to-yellow-500',
      description: 'Capture photo/video',
      action: () => {
        setLocation('/editor?type=camera');
        onCreateNew?.('camera');
        setIsExpanded(false);
      }
    }
  ];

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <div className="fixed bottom-8 right-8 z-50 flex flex-col items-end space-y-4">
      
      {/* Expanded Menu Items */}
      {isExpanded && (
        <div className="flex flex-col space-y-3 animate-in slide-in-from-bottom-2 fade-in duration-300">
          {projectTypes.map((type, index) => {
            const Icon = type.icon;
            return (
              <div
                key={type.id}
                className="flex items-center space-x-3 animate-in slide-in-from-right-2 fade-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                {/* Label */}
                <div className="bg-black/80 backdrop-blur-md rounded-lg px-3 py-2 border border-purple-500/30">
                  <div className="text-sm font-medium text-white">{type.label}</div>
                  <div className="text-xs text-gray-400">{type.description}</div>
                </div>
                
                {/* Action Button */}
                <Button
                  onClick={type.action}
                  className={`w-14 h-14 rounded-full bg-gradient-to-r ${type.color} hover:scale-110 shadow-lg hover:shadow-xl transition-all duration-300 border-2 border-white/20`}
                >
                  <Icon className="h-6 w-6 text-white" />
                </Button>
              </div>
            );
          })}
        </div>
      )}

      {/* Main FAB */}
      <Button
        onClick={toggleExpanded}
        className={`w-16 h-16 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 shadow-2xl hover:shadow-purple-500/25 transition-all duration-300 border-2 border-white/20 ${
          isExpanded ? 'rotate-45 scale-110' : 'hover:scale-110'
        }`}
      >
        {isExpanded ? (
          <X className="h-8 w-8 text-white" />
        ) : (
          <Plus className="h-8 w-8 text-white" />
        )}
      </Button>

      {/* Pulse Animation Ring */}
      {!isExpanded && (
        <div className="absolute inset-0 w-16 h-16 rounded-full bg-purple-500/30 animate-ping pointer-events-none" />
      )}
    </div>
  );
}

// Advanced FAB with Quick Actions
export function AdvancedFAB() {
  const [, setLocation] = useLocation();
  const [isExpanded, setIsExpanded] = useState(false);
  const [hoveredAction, setHoveredAction] = useState<string | null>(null);

  const quickActions = [
    {
      id: 'quick-edit',
      label: 'Quick Edit',
      icon: Zap,
      color: 'from-yellow-500 to-orange-500',
      hotkey: 'Ctrl+N',
      action: () => setLocation('/editor')
    },
    {
      id: 'template',
      label: 'Template',
      icon: Sparkles,
      color: 'from-pink-500 to-rose-500',
      hotkey: 'Ctrl+T',
      action: () => setLocation('/templates')
    },
    {
      id: 'voice-record',
      label: 'Voice Record',
      icon: Mic,
      color: 'from-green-500 to-teal-500',
      hotkey: 'Ctrl+R',
      action: () => setLocation('/editor?type=voice')
    },
    {
      id: 'canvas-studio',
      label: 'Canvas Studio',
      icon: Palette,
      color: 'from-purple-500 to-indigo-500',
      hotkey: 'Ctrl+C',
      action: () => setLocation('/editor?type=canvas')
    }
  ];

  return (
    <div className="fixed bottom-8 left-8 z-50">
      <div className="relative">
        
        {/* Radial Menu */}
        {isExpanded && (
          <div className="absolute bottom-0 left-0">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              const angle = (index * 90) - 45; // Spread in arc
              const radius = 80;
              const x = Math.cos((angle * Math.PI) / 180) * radius;
              const y = Math.sin((angle * Math.PI) / 180) * radius;
              
              return (
                <div
                  key={action.id}
                  className="absolute transition-all duration-300 animate-in zoom-in-50"
                  style={{
                    left: `${x}px`,
                    bottom: `${-y}px`,
                    animationDelay: `${index * 100}ms`
                  }}
                  onMouseEnter={() => setHoveredAction(action.id)}
                  onMouseLeave={() => setHoveredAction(null)}
                >
                  {/* Tooltip */}
                  {hoveredAction === action.id && (
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-black/90 backdrop-blur-md rounded-lg px-3 py-2 border border-purple-500/30 whitespace-nowrap animate-in fade-in zoom-in-95 duration-200">
                      <div className="text-sm font-medium text-white">{action.label}</div>
                      <div className="text-xs text-gray-400">{action.hotkey}</div>
                    </div>
                  )}
                  
                  <Button
                    onClick={() => {
                      action.action();
                      setIsExpanded(false);
                    }}
                    className={`w-12 h-12 rounded-full bg-gradient-to-r ${action.color} hover:scale-110 shadow-lg hover:shadow-xl transition-all duration-300 border border-white/20`}
                  >
                    <Icon className="h-5 w-5 text-white" />
                  </Button>
                </div>
              );
            })}
          </div>
        )}

        {/* Main FAB */}
        <Button
          onClick={() => setIsExpanded(!isExpanded)}
          className={`w-14 h-14 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 shadow-2xl hover:shadow-indigo-500/25 transition-all duration-500 border-2 border-white/20 ${
            isExpanded ? 'rotate-45 scale-110' : 'hover:scale-105'
          }`}
        >
          {isExpanded ? (
            <X className="h-6 w-6 text-white" />
          ) : (
            <Sparkles className="h-6 w-6 text-white" />
          )}
        </Button>

        {/* Animated Background Ring */}
        <div className={`absolute inset-0 w-14 h-14 rounded-full transition-all duration-500 ${
          isExpanded 
            ? 'bg-indigo-500/20 scale-150' 
            : 'bg-indigo-500/10 scale-100 animate-pulse'
        }`} />
      </div>
    </div>
  );
}

// Compact FAB for mobile
export function MobileFAB() {
  const [, setLocation] = useLocation();
  
  return (
    <div className="fixed bottom-6 right-6 z-50 md:hidden">
      <Button
        onClick={() => setLocation('/editor')}
        className="w-14 h-14 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 shadow-2xl hover:shadow-purple-500/25 transition-all duration-300 hover:scale-110 border-2 border-white/20"
      >
        <Plus className="h-6 w-6 text-white" />
      </Button>
      
      {/* Badge notification */}
      <Badge className="absolute -top-2 -right-2 bg-red-500 text-white border-0 w-6 h-6 rounded-full flex items-center justify-center text-xs animate-bounce">
        !
      </Badge>
    </div>
  );
}