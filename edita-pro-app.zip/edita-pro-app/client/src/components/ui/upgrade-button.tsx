import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Crown,
  Zap,
  ArrowRight,
  CreditCard,
  Loader2
} from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

// Initialize Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY!);

interface UpgradeButtonProps {
  variant?: 'monthly' | 'yearly';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  showBadge?: boolean;
}

export function UpgradeButton({ 
  variant = 'monthly', 
  size = 'md', 
  className = '',
  showBadge = true 
}: UpgradeButtonProps) {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const formatRupiah = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const paketInfo = {
    monthly: {
      price: 304000,
      period: 'bulan',
      stripePriceId: 'price_premium_monthly',
      label: 'Premium Bulanan',
      savings: null
    },
    yearly: {
      price: 3040000,
      period: 'tahun',
      stripePriceId: 'price_premium_yearly',
      label: 'Premium Tahunan',
      savings: 608000
    }
  };

  const paket = paketInfo[variant];

  const handleUpgrade = async () => {
    setLoading(true);

    try {
      const stripe = await stripePromise;
      if (!stripe) {
        throw new Error('Stripe tidak tersedia');
      }

      // Create checkout session
      const response = await apiRequest('POST', '/api/create-checkout-session', {
        priceId: paket.stripePriceId,
        mode: 'subscription',
        successUrl: `${window.location.origin}/dashboard?upgrade=success`,
        cancelUrl: `${window.location.origin}/pilih-paket?upgrade=cancelled`,
        userId: 1, // Mock user ID - in real app, get from auth context
        metadata: {
          plan: variant,
          source: 'upgrade_button'
        }
      });

      const { sessionId } = await response.json();

      // Redirect to Stripe Checkout
      const { error } = await stripe.redirectToCheckout({
        sessionId: sessionId,
      });

      if (error) {
        throw new Error(error.message);
      }
    } catch (error: any) {
      console.error('Upgrade error:', error);
      toast({
        title: "Terjadi Kesalahan",
        description: error.message || "Silakan coba lagi dalam beberapa saat",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  const buttonSizes = {
    sm: 'h-9 px-4 text-sm',
    md: 'h-11 px-6',
    lg: 'h-14 px-8 text-lg'
  };

  return (
    <div className="space-y-2">
      {showBadge && paket.savings && (
        <Badge className="bg-green-500/20 text-green-300 border-green-500/30 mx-auto block w-fit">
          <Zap className="h-3 w-3 mr-1" />
          Hemat {formatRupiah(paket.savings)}!
        </Badge>
      )}
      
      <Button
        onClick={handleUpgrade}
        disabled={loading}
        className={`bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 ${buttonSizes[size]} ${className}`}
      >
        {loading ? (
          <div className="flex items-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin" />
            Memproses...
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Crown className="h-4 w-4" />
            <span>Upgrade Sekarang</span>
            <ArrowRight className="h-4 w-4" />
          </div>
        )}
      </Button>
      
      <div className="text-center text-sm text-gray-400">
        <p className="font-medium text-white">{formatRupiah(paket.price)}/{paket.period}</p>
        <p>Batal kapan saja • Garansi 30 hari</p>
      </div>
    </div>
  );
}

// Quick upgrade components for different contexts
export function QuickUpgradeMonthly({ className }: { className?: string }) {
  return (
    <UpgradeButton 
      variant="monthly" 
      size="md" 
      className={className}
      showBadge={false}
    />
  );
}

export function QuickUpgradeYearly({ className }: { className?: string }) {
  return (
    <UpgradeButton 
      variant="yearly" 
      size="md" 
      className={className}
      showBadge={true}
    />
  );
}

// Compact upgrade button for sidebars/navbars
export function CompactUpgradeButton({ className }: { className?: string }) {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleQuickUpgrade = async () => {
    setLoading(true);

    try {
      const stripe = await stripePromise;
      if (!stripe) {
        throw new Error('Stripe tidak tersedia');
      }

      // Default to monthly plan for quick upgrade
      const response = await apiRequest('POST', '/api/create-checkout-session', {
        priceId: 'price_premium_monthly',
        mode: 'subscription',
        successUrl: `${window.location.origin}/dashboard?upgrade=success`,
        cancelUrl: `${window.location.origin}${window.location.pathname}`,
        userId: 1,
        metadata: {
          plan: 'monthly',
          source: 'compact_button'
        }
      });

      const { sessionId } = await response.json();

      const { error } = await stripe.redirectToCheckout({
        sessionId: sessionId,
      });

      if (error) {
        throw new Error(error.message);
      }
    } catch (error: any) {
      toast({
        title: "Terjadi Kesalahan",
        description: error.message || "Silakan coba lagi",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  return (
    <Button
      onClick={handleQuickUpgrade}
      disabled={loading}
      size="sm"
      className={`bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 ${className}`}
    >
      {loading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <>
          <Crown className="h-4 w-4 mr-2" />
          Upgrade
        </>
      )}
    </Button>
  );
}