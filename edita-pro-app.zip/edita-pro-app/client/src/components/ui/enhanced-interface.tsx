import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Sparkles,
  Zap,
  Star,
  Heart,
  Flame,
  Diamond,
  Crown,
  Wand2,
  Eye
} from 'lucide-react';

interface EnhancedInterfaceProps {
  children: React.ReactNode;
  theme?: 'dark' | 'neon' | 'glassmorphism' | 'holographic';
  animations?: boolean;
  particles?: boolean;
}

export function EnhancedInterface({ 
  children, 
  theme = 'glassmorphism', 
  animations = true, 
  particles = true 
}: EnhancedInterfaceProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    if (animations) {
      window.addEventListener('mousemove', handleMouseMove);
      return () => window.removeEventListener('mousemove', handleMouseMove);
    }
  }, [animations]);

  const getThemeClasses = () => {
    switch (theme) {
      case 'neon':
        return 'bg-black text-cyan-400 border-cyan-500/50';
      case 'holographic':
        return 'bg-gradient-to-br from-purple-900/20 via-pink-900/20 to-blue-900/20 backdrop-blur-xl border-white/20';
      case 'glassmorphism':
        return 'bg-white/5 backdrop-blur-xl border-white/10';
      default:
        return 'bg-slate-900 text-white border-slate-700';
    }
  };

  return (
    <div className={`relative min-h-screen ${getThemeClasses()}`}>
      {/* Animated Background */}
      {animations && (
        <div className="fixed inset-0 overflow-hidden pointer-events-none">
          {/* Gradient Orbs */}
          <div 
            className="absolute w-96 h-96 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-3xl animate-pulse"
            style={{
              left: `${mousePosition.x / 10}px`,
              top: `${mousePosition.y / 10}px`,
              transform: 'translate(-50%, -50%)'
            }}
          />
          <div 
            className="absolute w-72 h-72 bg-gradient-to-r from-blue-500/15 to-cyan-500/15 rounded-full blur-3xl animate-pulse"
            style={{
              right: `${(window.innerWidth - mousePosition.x) / 15}px`,
              bottom: `${(window.innerHeight - mousePosition.y) / 15}px`,
              transform: 'translate(50%, 50%)'
            }}
          />
          
          {/* Floating Shapes */}
          <div className="absolute inset-0">
            {Array.from({ length: 20 }).map((_, i) => (
              <div
                key={i}
                className={`absolute w-2 h-2 bg-white/20 rounded-full animate-bounce`}
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 2}s`,
                  animationDuration: `${2 + Math.random() * 2}s`
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Particles */}
      {particles && (
        <div className="fixed inset-0 overflow-hidden pointer-events-none">
          {Array.from({ length: 50 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${1 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>
      )}

      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>

      {/* Cursor Glow Effect */}
      {animations && (
        <div
          className="fixed w-8 h-8 bg-gradient-to-r from-purple-500/50 to-pink-500/50 rounded-full blur-lg pointer-events-none z-50 transition-opacity duration-300"
          style={{
            left: mousePosition.x - 16,
            top: mousePosition.y - 16,
            opacity: isHovered ? 1 : 0.5
          }}
        />
      )}
    </div>
  );
}

// Enhanced Button Component
export function GlowButton({ 
  children, 
  onClick, 
  variant = 'primary',
  size = 'md',
  glowColor = 'purple',
  ...props 
}: any) {
  const [isHovered, setIsHovered] = useState(false);

  const getVariantClasses = () => {
    switch (variant) {
      case 'neon':
        return `bg-transparent border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400/20 hover:shadow-[0_0_30px_rgba(34,211,238,0.5)]`;
      case 'holographic':
        return `bg-gradient-to-r from-purple-600/80 to-pink-600/80 text-white hover:from-purple-500/90 hover:to-pink-500/90 hover:shadow-[0_0_30px_rgba(168,85,247,0.5)]`;
      case 'glass':
        return `bg-white/10 backdrop-blur-xl border border-white/20 text-white hover:bg-white/20 hover:shadow-[0_0_30px_rgba(255,255,255,0.2)]`;
      default:
        return `bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-500 hover:to-pink-500 hover:shadow-[0_0_30px_rgba(168,85,247,0.5)]`;
    }
  };

  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return 'px-4 py-2 text-sm';
      case 'lg':
        return 'px-8 py-4 text-lg';
      case 'xl':
        return 'px-12 py-6 text-xl';
      default:
        return 'px-6 py-3';
    }
  };

  return (
    <button
      className={`
        ${getVariantClasses()}
        ${getSizeClasses()}
        rounded-xl font-semibold transition-all duration-300 transform
        ${isHovered ? 'scale-105' : 'scale-100'}
        relative overflow-hidden group
      `}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
      {...props}
    >
      {/* Shimmer Effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
      
      {/* Content */}
      <span className="relative z-10 flex items-center gap-2">
        {children}
      </span>
    </button>
  );
}

// Enhanced Card Component
export function GlowCard({ 
  children, 
  title, 
  icon: Icon, 
  variant = 'glass',
  glow = true,
  ...props 
}: any) {
  const [isHovered, setIsHovered] = useState(false);

  const getVariantClasses = () => {
    switch (variant) {
      case 'neon':
        return 'bg-black/80 border-2 border-cyan-400/50 hover:border-cyan-400';
      case 'holographic':
        return 'bg-gradient-to-br from-purple-900/30 via-pink-900/30 to-blue-900/30 backdrop-blur-xl border border-white/20';
      case 'premium':
        return 'bg-gradient-to-br from-yellow-900/20 via-orange-900/20 to-red-900/20 backdrop-blur-xl border border-yellow-500/30';
      default:
        return 'bg-white/5 backdrop-blur-xl border border-white/10';
    }
  };

  return (
    <Card
      className={`
        ${getVariantClasses()}
        transition-all duration-300 transform hover:scale-105
        ${glow && isHovered ? 'shadow-[0_0_40px_rgba(168,85,247,0.3)]' : ''}
        relative overflow-hidden group
      `}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      {...props}
    >
      {/* Animated Border */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 via-pink-500/20 to-blue-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      
      {title && (
        <CardHeader className="relative z-10">
          <CardTitle className="text-white flex items-center gap-2">
            {Icon && <Icon className="h-5 w-5 text-purple-400" />}
            {title}
          </CardTitle>
        </CardHeader>
      )}
      
      <CardContent className="relative z-10">
        {children}
      </CardContent>
    </Card>
  );
}

// Floating Action Button with Glow
export function FloatingGlowButton({ 
  icon: Icon = Sparkles, 
  onClick, 
  position = 'bottom-right',
  color = 'purple' 
}: any) {
  const [isExpanded, setIsExpanded] = useState(false);

  const getPositionClasses = () => {
    switch (position) {
      case 'bottom-left':
        return 'bottom-6 left-6';
      case 'top-right':
        return 'top-6 right-6';
      case 'top-left':
        return 'top-6 left-6';
      default:
        return 'bottom-6 right-6';
    }
  };

  const getColorClasses = () => {
    switch (color) {
      case 'blue':
        return 'bg-gradient-to-r from-blue-500 to-cyan-500 hover:shadow-[0_0_30px_rgba(59,130,246,0.5)]';
      case 'green':
        return 'bg-gradient-to-r from-green-500 to-emerald-500 hover:shadow-[0_0_30px_rgba(34,197,94,0.5)]';
      case 'pink':
        return 'bg-gradient-to-r from-pink-500 to-rose-500 hover:shadow-[0_0_30px_rgba(236,72,153,0.5)]';
      default:
        return 'bg-gradient-to-r from-purple-500 to-pink-500 hover:shadow-[0_0_30px_rgba(168,85,247,0.5)]';
    }
  };

  return (
    <div className={`fixed ${getPositionClasses()} z-50`}>
      <button
        className={`
          ${getColorClasses()}
          w-14 h-14 rounded-full text-white
          transition-all duration-300 transform hover:scale-110
          flex items-center justify-center
          shadow-lg hover:shadow-2xl
          relative overflow-hidden group
        `}
        onMouseEnter={() => setIsExpanded(true)}
        onMouseLeave={() => setIsExpanded(false)}
        onClick={onClick}
      >
        {/* Pulse Ring */}
        <div className="absolute inset-0 rounded-full bg-white/20 animate-ping" />
        
        {/* Icon */}
        <Icon className="h-6 w-6 relative z-10" />
        
        {/* Ripple Effect */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-r from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </button>
    </div>
  );
}

// Premium Badge with Animation
export function PremiumBadge({ 
  text = 'Premium', 
  animated = true,
  size = 'md' 
}: any) {
  return (
    <Badge className={`
      bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 
      text-white border-0 font-semibold
      ${animated ? 'animate-pulse' : ''}
      ${size === 'lg' ? 'text-base px-4 py-2' : 'text-sm px-3 py-1'}
      relative overflow-hidden
    `}>
      {/* Shimmer Effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer" />
      
      <Crown className="h-3 w-3 mr-1" />
      {text}
    </Badge>
  );
}

// Achievement Notification
export function AchievementToast({ 
  title, 
  description, 
  icon: Icon = Star,
  show = false,
  onClose 
}: any) {
  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onClose?.();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [show, onClose]);

  if (!show) return null;

  return (
    <div className="fixed top-6 right-6 z-50 animate-slide-in-right">
      <GlowCard variant="premium" className="w-80">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-yellow-500/20 rounded-lg">
            <Icon className="h-6 w-6 text-yellow-400" />
          </div>
          <div className="flex-1">
            <h4 className="font-semibold text-white">{title}</h4>
            <p className="text-sm text-gray-300 mt-1">{description}</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            ✕
          </button>
        </div>
      </GlowCard>
    </div>
  );
}