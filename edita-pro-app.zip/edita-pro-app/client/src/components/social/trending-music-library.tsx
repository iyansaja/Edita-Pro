import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Music,
  Play,
  Pause,
  Download,
  TrendingUp,
  Heart,
  Users,
  Clock,
  Volume2,
  Headphones,
  Zap,
  Star,
  Hash,
  Target
} from 'lucide-react';

interface TrendingTrack {
  id: string;
  title: string;
  artist: string;
  duration: number;
  bpm: number;
  genre: string;
  mood: string;
  platform: 'tiktok' | 'instagram' | 'youtube';
  popularity: number;
  trending_score: number;
  usage_count: number;
  preview_url: string;
  hashtags: string[];
  difficulty: 'easy' | 'medium' | 'hard';
}

interface TrendingMusicLibraryProps {
  onTrackSelect?: (track: TrendingTrack) => void;
  onTrackDownload?: (track: TrendingTrack) => void;
}

export function TrendingMusicLibrary({ onTrackSelect, onTrackDownload }: TrendingMusicLibraryProps) {
  const [playingTrack, setPlayingTrack] = useState<string>('');
  const [selectedGenre, setSelectedGenre] = useState<string>('all');
  const [selectedMood, setSelectedMood] = useState<string>('all');
  const [selectedPlatform, setSelectedPlatform] = useState<string>('all');

  // Sample trending tracks data - in real implementation, this would come from actual API
  const [trendingTracks] = useState<TrendingTrack[]>([
    {
      id: '1',
      title: 'Aesthetic Vibes',
      artist: 'LoFi Collective',
      duration: 45,
      bpm: 120,
      genre: 'LoFi',
      mood: 'Chill',
      platform: 'tiktok',
      popularity: 95,
      trending_score: 92,
      usage_count: 2400000,
      preview_url: '/audio/aesthetic-vibes.mp3',
      hashtags: ['#aesthetic', '#morningroutine', '#studywithme'],
      difficulty: 'easy'
    },
    {
      id: '2',
      title: 'Energy Boost',
      artist: 'Workout Beats',
      duration: 60,
      bpm: 140,
      genre: 'Electronic',
      mood: 'Energetic',
      platform: 'instagram',
      popularity: 87,
      trending_score: 89,
      usage_count: 1800000,
      preview_url: '/audio/energy-boost.mp3',
      hashtags: ['#workout', '#motivation', '#fitness'],
      difficulty: 'medium'
    },
    {
      id: '3',
      title: 'Sunset Dreams',
      artist: 'Chill Nation',
      duration: 75,
      bpm: 100,
      genre: 'Ambient',
      mood: 'Relaxed',
      platform: 'youtube',
      popularity: 78,
      trending_score: 85,
      usage_count: 950000,
      preview_url: '/audio/sunset-dreams.mp3',
      hashtags: ['#sunset', '#relaxing', '#nature'],
      difficulty: 'easy'
    }
  ]);

  const genres = ['All', 'LoFi', 'Electronic', 'Pop', 'Hip-Hop', 'Ambient', 'Rock'];
  const moods = ['All', 'Chill', 'Energetic', 'Happy', 'Relaxed', 'Dramatic', 'Upbeat'];
  const platforms = ['All', 'TikTok', 'Instagram', 'YouTube'];

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getPlatformColor = (platform: string) => {
    switch (platform) {
      case 'tiktok': return 'from-pink-500 to-red-500';
      case 'instagram': return 'from-purple-500 to-pink-500';
      case 'youtube': return 'from-red-500 to-red-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getTrendingColor = (score: number): string => {
    if (score >= 90) return 'text-green-400';
    if (score >= 80) return 'text-yellow-400';
    if (score >= 70) return 'text-orange-400';
    return 'text-red-400';
  };

  const getDifficultyColor = (difficulty: string): string => {
    switch (difficulty) {
      case 'easy': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'hard': return 'bg-red-500/20 text-red-300 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const handlePlayPause = (trackId: string) => {
    if (playingTrack === trackId) {
      setPlayingTrack('');
    } else {
      setPlayingTrack(trackId);
    }
  };

  const filteredTracks = trendingTracks.filter(track => {
    const genreMatch = selectedGenre === 'all' || track.genre.toLowerCase() === selectedGenre.toLowerCase();
    const moodMatch = selectedMood === 'all' || track.mood.toLowerCase() === selectedMood.toLowerCase();
    const platformMatch = selectedPlatform === 'all' || track.platform.toLowerCase() === selectedPlatform.toLowerCase();
    return genreMatch && moodMatch && platformMatch;
  });

  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Music className="h-6 w-6 text-purple-400" />
            Trending Music Library
            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 ml-auto">
              <TrendingUp className="h-3 w-3 mr-1" />
              Live Trends
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Filters */}
      <Card className="bg-slate-800/50 border-indigo-500/30">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Genre</label>
              <select
                value={selectedGenre}
                onChange={(e) => setSelectedGenre(e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
              >
                {genres.map(genre => (
                  <option key={genre} value={genre.toLowerCase()}>{genre}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Mood</label>
              <select
                value={selectedMood}
                onChange={(e) => setSelectedMood(e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
              >
                {moods.map(mood => (
                  <option key={mood} value={mood.toLowerCase()}>{mood}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Platform</label>
              <select
                value={selectedPlatform}
                onChange={(e) => setSelectedPlatform(e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
              >
                {platforms.map(platform => (
                  <option key={platform} value={platform.toLowerCase()}>{platform}</option>
                ))}
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Trending Tracks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredTracks.map((track) => (
          <Card
            key={track.id}
            className="bg-slate-800/50 border-purple-500/30 hover:bg-slate-800/70 transition-colors"
          >
            <CardContent className="p-4">
              <div className="space-y-4">
                {/* Track Header */}
                <div className="flex items-start gap-3">
                  <div className={`p-3 rounded-lg bg-gradient-to-r ${getPlatformColor(track.platform)}`}>
                    <Music className="h-6 w-6 text-white" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-white">{track.title}</h3>
                      <Badge className={getDifficultyColor(track.difficulty)}>
                        {track.difficulty}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-400">{track.artist}</p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                      <span>{formatDuration(track.duration)}</span>
                      <span>{track.bpm} BPM</span>
                      <span className="capitalize">{track.platform}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className={`text-lg font-bold ${getTrendingColor(track.trending_score)}`}>
                      {track.trending_score}%
                    </div>
                    <div className="text-xs text-gray-400">Trend Score</div>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="p-2 bg-slate-700/50 rounded">
                    <Users className="h-4 w-4 mx-auto mb-1 text-blue-400" />
                    <div className="text-sm font-semibold text-white">{formatNumber(track.usage_count)}</div>
                    <div className="text-xs text-gray-400">Uses</div>
                  </div>
                  
                  <div className="p-2 bg-slate-700/50 rounded">
                    <Star className="h-4 w-4 mx-auto mb-1 text-yellow-400" />
                    <div className="text-sm font-semibold text-white">{track.popularity}%</div>
                    <div className="text-xs text-gray-400">Popular</div>
                  </div>
                  
                  <div className="p-2 bg-slate-700/50 rounded">
                    <Target className="h-4 w-4 mx-auto mb-1 text-green-400" />
                    <div className="text-sm font-semibold text-white">{track.genre}</div>
                    <div className="text-xs text-gray-400">{track.mood}</div>
                  </div>
                </div>

                {/* Hashtags */}
                <div className="flex flex-wrap gap-1">
                  {track.hashtags.map((hashtag, index) => (
                    <Badge
                      key={index}
                      className="bg-indigo-500/20 text-indigo-300 border-indigo-500/30 text-xs"
                    >
                      <Hash className="h-3 w-3 mr-1" />
                      {hashtag.replace('#', '')}
                    </Badge>
                  ))}
                </div>

                {/* Controls */}
                <div className="flex gap-2">
                  <Button
                    onClick={() => handlePlayPause(track.id)}
                    className="flex-1 bg-purple-600 hover:bg-purple-700"
                  >
                    {playingTrack === track.id ? (
                      <>
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Preview
                      </>
                    )}
                  </Button>
                  
                  <Button
                    onClick={() => onTrackSelect?.(track)}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    Use Track
                  </Button>
                  
                  <Button
                    onClick={() => onTrackDownload?.(track)}
                    variant="outline"
                    className="border-gray-500 text-gray-300 hover:bg-gray-700"
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* API Notice */}
      <Card className="bg-gradient-to-r from-yellow-800/50 to-orange-800/50 border border-yellow-500/30">
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <Headphones className="h-12 w-12 text-yellow-400 mx-auto" />
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Live Trending Music</h3>
              <p className="text-gray-300 text-sm">
                This library shows sample trending music. To access real-time trending tracks from TikTok, 
                Instagram, and YouTube, please provide the necessary API credentials for music data access.
              </p>
            </div>
            <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
              <Volume2 className="h-4 w-4 mr-2" />
              Enable Live Music Data
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}