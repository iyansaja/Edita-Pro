import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Upload,
  TrendingUp,
  Users,
  Eye,
  Heart,
  MessageCircle,
  Share,
  Clock,
  CheckCircle,
  AlertCircle,
  Music,
  Hash,
  Calendar,
  Globe,
  Lock,
  Zap,
  Crown,
  Target,
  BarChart3
} from 'lucide-react';

interface SocialPlatform {
  id: string;
  name: string;
  color: string;
  icon: string;
  connected: boolean;
  followers: number;
  engagement: number;
  lastPost: Date;
  formats: string[];
  maxDuration: number;
  aspectRatios: string[];
}

interface TrendingContent {
  id: string;
  platform: string;
  title: string;
  hashtags: string[];
  music: string;
  views: number;
  engagement: number;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  trend_score: number;
}

interface PostSchedule {
  id: string;
  platform: string;
  content: string;
  scheduledTime: Date;
  status: 'scheduled' | 'posted' | 'failed';
  engagement?: {
    views: number;
    likes: number;
    comments: number;
    shares: number;
  };
}

interface SocialMediaIntegrationProps {
  onDirectUpload?: (platform: string, content: any) => void;
  onSchedulePost?: (schedule: PostSchedule) => void;
  onTrendingSelect?: (trend: TrendingContent) => void;
}

export function SocialMediaIntegration({ onDirectUpload, onSchedulePost, onTrendingSelect }: SocialMediaIntegrationProps) {
  const [connectedPlatforms, setConnectedPlatforms] = useState<SocialPlatform[]>([
    {
      id: 'tiktok',
      name: 'TikTok',
      color: 'from-pink-500 to-red-500',
      icon: '🎵',
      connected: false,
      followers: 125000,
      engagement: 8.5,
      lastPost: new Date(Date.now() - 86400000),
      formats: ['MP4'],
      maxDuration: 180,
      aspectRatios: ['9:16', '1:1']
    },
    {
      id: 'instagram',
      name: 'Instagram',
      color: 'from-purple-500 to-pink-500',
      icon: '📸',
      connected: false,
      followers: 89000,
      engagement: 6.2,
      lastPost: new Date(Date.now() - 43200000),
      formats: ['MP4', 'JPG'],
      maxDuration: 90,
      aspectRatios: ['9:16', '1:1', '4:5']
    },
    {
      id: 'youtube',
      name: 'YouTube',
      color: 'from-red-500 to-red-600',
      icon: '📺',
      connected: false,
      followers: 45000,
      engagement: 4.8,
      lastPost: new Date(Date.now() - 172800000),
      formats: ['MP4', 'MOV'],
      maxDuration: 3600,
      aspectRatios: ['16:9', '9:16', '1:1']
    },
    {
      id: 'facebook',
      name: 'Facebook',
      color: 'from-blue-500 to-blue-600',
      icon: '👥',
      connected: false,
      followers: 67000,
      engagement: 3.4,
      lastPost: new Date(Date.now() - 259200000),
      formats: ['MP4', 'JPG'],
      maxDuration: 240,
      aspectRatios: ['16:9', '1:1', '4:5']
    }
  ]);

  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState('');
  const [needsAuthentication, setNeedsAuthentication] = useState(false);

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const connectPlatform = (platformId: string) => {
    // Show that we need API credentials for real connection
    setNeedsAuthentication(true);
    setSelectedPlatform(platformId);
  };

  const startDirectUpload = async (platform: string) => {
    setSelectedPlatform(platform);
    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    for (let i = 0; i <= 100; i += 5) {
      await new Promise(resolve => setTimeout(resolve, 100));
      setUploadProgress(i);
    }

    setIsUploading(false);
    onDirectUpload?.(platform, { success: true, url: `https://${platform}.com/post/abc123` });
  };

  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Upload className="h-6 w-6 text-blue-400" />
            Social Media Integration
            <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white border-0 ml-auto">
              <Globe className="h-3 w-3 mr-1" />
              Multi-Platform
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Authentication Notice */}
      {needsAuthentication && (
        <Card className="bg-gradient-to-r from-yellow-800/50 to-orange-800/50 border border-yellow-500/30">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <AlertCircle className="h-12 w-12 text-yellow-400 mx-auto" />
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">API Credentials Required</h3>
                <p className="text-gray-300 text-sm">
                  To connect with {connectedPlatforms.find(p => p.id === selectedPlatform)?.name}, we need the official API credentials. 
                  Please provide the API keys to enable direct uploading and trending content access.
                </p>
              </div>
              <div className="flex gap-3 justify-center">
                <Button 
                  onClick={() => setNeedsAuthentication(false)}
                  variant="outline"
                  className="border-gray-500 text-gray-300"
                >
                  Cancel
                </Button>
                <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                  Provide API Keys
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Upload Progress */}
      {isUploading && (
        <Card className="bg-gradient-to-r from-green-800/50 to-emerald-800/50 border border-green-500/30">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <div className="flex items-center justify-center gap-2">
                <Upload className="h-5 w-5 text-green-400 animate-pulse" />
                <span className="text-lg font-semibold text-white">
                  Uploading to {connectedPlatforms.find(p => p.id === selectedPlatform)?.name}...
                </span>
              </div>
              
              <Progress value={uploadProgress} className="w-full h-3" />
              
              <div className="text-sm text-gray-300">
                {uploadProgress < 30 ? 'Preparing video...' :
                 uploadProgress < 60 ? 'Optimizing for platform...' :
                 uploadProgress < 90 ? 'Uploading to server...' : 'Publishing post...'}
              </div>
              
              <div className="text-2xl font-bold text-green-400">
                {uploadProgress}%
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Platform Connections */}
        <div className="lg:col-span-2 space-y-4">
          {/* Connected Platforms */}
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Users className="h-4 w-4 text-green-400" />
                Social Media Platforms
                <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 ml-auto">
                  Ready for Connection
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {connectedPlatforms.map((platform) => (
                <div
                  key={platform.id}
                  className="flex items-center gap-3 p-4 bg-slate-700/50 rounded-lg hover:bg-slate-700/70 transition-colors"
                >
                  <div className={`p-3 rounded-lg bg-gradient-to-r ${platform.color}`}>
                    <span className="text-2xl">{platform.icon}</span>
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-white">{platform.name}</span>
                      <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        Needs Setup
                      </Badge>
                    </div>
                    
                    <div className="text-sm text-gray-400 mt-1">
                      Target: {formatNumber(platform.followers)} followers • {platform.engagement}% engagement
                    </div>
                    
                    <div className="text-xs text-gray-500">
                      Supports: {platform.formats.join(', ')} • Max {platform.maxDuration}s • {platform.aspectRatios.join(', ')}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={() => connectPlatform(platform.id)}
                      className="bg-indigo-500 hover:bg-indigo-600"
                    >
                      Connect API
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Feature Preview */}
          <Card className="bg-slate-800/50 border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-yellow-400" />
                Trending Templates & Music (Preview)
                <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 ml-auto">
                  <Zap className="h-3 w-3 mr-1" />
                  Live Trends
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-center p-8 text-gray-400">
                <TrendingUp className="h-12 w-12 mx-auto mb-4 text-gray-500" />
                <h3 className="text-lg font-semibold mb-2">Real Trending Content</h3>
                <p className="text-sm">
                  Connect your social media accounts to access live trending templates, 
                  viral hashtags, and trending music from TikTok and Instagram.
                </p>
                <Button 
                  onClick={() => setNeedsAuthentication(true)}
                  className="mt-4 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
                >
                  <Crown className="h-4 w-4 mr-2" />
                  Enable Trending Content
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Features Overview */}
        <div className="space-y-4">
          {/* Direct Upload Features */}
          <Card className="bg-slate-800/50 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Upload className="h-4 w-4 text-purple-400" />
                Direct Upload Features
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2 text-sm text-gray-300">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>One-click upload to multiple platforms</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>Auto-optimize format for each platform</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>Custom hashtag suggestions</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>Scheduled posting</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Trending Content Access */}
          <Card className="bg-slate-800/50 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Music className="h-4 w-4 text-blue-400" />
                Trending Content Access
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2 text-sm text-gray-300">
                <div className="flex items-center gap-2">
                  <Music className="h-4 w-4 text-purple-400" />
                  <span>Live trending music from TikTok</span>
                </div>
                <div className="flex items-center gap-2">
                  <Hash className="h-4 w-4 text-blue-400" />
                  <span>Viral hashtags and challenges</span>
                </div>
                <div className="flex items-center gap-2">
                  <Target className="h-4 w-4 text-yellow-400" />
                  <span>Content templates by category</span>
                </div>
                <div className="flex items-center gap-2">
                  <BarChart3 className="h-4 w-4 text-green-400" />
                  <span>Trend scoring and predictions</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Setup Required */}
          <Card className="bg-gradient-to-r from-orange-800/50 to-red-800/50 border border-orange-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-orange-400" />
                Setup Required
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-gray-300">
                To enable social media integration, we need official API credentials from each platform. 
                This ensures secure and compliant access to posting and trending data.
              </p>
              
              <div className="space-y-2 text-xs text-gray-400">
                <div>• TikTok Business API</div>
                <div>• Instagram Basic Display API</div>
                <div>• YouTube Data API v3</div>
                <div>• Facebook Graph API</div>
              </div>
              
              <Button 
                onClick={() => setNeedsAuthentication(true)}
                className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
              >
                <Crown className="h-4 w-4 mr-2" />
                Setup API Access
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}