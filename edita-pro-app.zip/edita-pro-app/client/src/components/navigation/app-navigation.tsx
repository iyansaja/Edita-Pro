import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  FileText, 
  Layout, 
  FolderOpen, 
  Settings, 
  User, 
  Bell, 
  Search,
  Plus,
  Crown,
  Sparkles,
  Video,
  Music,
  Image as ImageIcon,
  ChevronDown,
  Home,
  LogOut,
  HelpCircle
} from 'lucide-react';
import { useLocation } from 'wouter';

interface NavigationProps {
  currentPage?: 'lobby' | 'editor' | 'templates' | 'drafts' | 'settings';
}

export function AppNavigation({ currentPage = 'lobby' }: NavigationProps) {
  const [, setLocation] = useLocation();
  const [notificationCount] = useState(3);

  const navigationItems = [
    {
      id: 'lobby',
      label: 'Beranda',
      icon: Home,
      path: '/',
      description: 'Dashboard utama Edita Pro'
    },
    {
      id: 'editor',
      label: 'Edit',
      icon: FileText,
      path: '/editor',
      description: 'Buat dan edit dokumen'
    },
    {
      id: 'templates',
      label: 'Template',
      icon: Layout,
      path: '/templates',
      description: 'Jelajahi template profesional'
    },
    {
      id: 'drafts',
      label: 'Draft Saya',
      icon: FolderOpen,
      path: '/drafts',
      description: 'Project yang sedang dikerjakan'
    }
  ];

  const createMenuItems = [
    {
      label: 'Dokumen Baru',
      icon: FileText,
      action: () => setLocation('/editor'),
      description: 'Buat dokumen kosong'
    },
    {
      label: 'Video Project',
      icon: Video,
      action: () => setLocation('/editor?type=video'),
      description: 'Buat project video'
    },
    {
      label: 'Audio Project',
      icon: Music,
      action: () => setLocation('/editor?type=audio'),
      description: 'Buat project audio'
    },
    {
      label: 'Dari Template',
      icon: Layout,
      action: () => setLocation('/templates'),
      description: 'Pilih dari template'
    }
  ];

  const userMenuItems = [
    {
      label: 'Profil Saya',
      icon: User,
      action: () => console.log('Profile')
    },
    {
      label: 'Pengaturan',
      icon: Settings,
      action: () => setLocation('/settings')
    },
    {
      label: 'Bantuan',
      icon: HelpCircle,
      action: () => console.log('Help')
    },
    {
      label: 'Keluar',
      icon: LogOut,
      action: () => console.log('Logout')
    }
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-purple-500/20 bg-black/80 backdrop-blur-xl">
      <div className="flex h-16 items-center justify-between px-6">
        
        {/* Logo & Brand */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <span className="font-bold text-xl text-white">Edita Pro</span>
            <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0 text-xs">
              <Crown className="h-3 w-3 mr-1" />
              Premium
            </Badge>
          </div>
        </div>

        {/* Main Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            return (
              <Button
                key={item.id}
                onClick={() => setLocation(item.path)}
                variant={isActive ? "default" : "ghost"}
                className={`relative px-4 py-2 transition-all duration-200 ${
                  isActive 
                    ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white shadow-lg' 
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <Icon className="h-4 w-4 mr-2" />
                {item.label}
                {isActive && (
                  <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-white rounded-full" />
                )}
              </Button>
            );
          })}
        </nav>

        {/* Right Side Actions */}
        <div className="flex items-center gap-3">
          
          {/* Search */}
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-300 hover:text-white hover:bg-white/10"
          >
            <Search className="h-4 w-4" />
          </Button>

          {/* Create New Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="default"
                size="sm"
                className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white shadow-lg"
              >
                <Plus className="h-4 w-4 mr-2" />
                Buat Baru
                <ChevronDown className="h-3 w-3 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent 
              align="end" 
              className="w-56 bg-black/90 backdrop-blur-xl border-purple-500/30"
            >
              {createMenuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <DropdownMenuItem
                    key={item.label}
                    onClick={item.action}
                    className="flex items-center gap-3 p-3 cursor-pointer hover:bg-purple-500/10 text-white"
                  >
                    <Icon className="h-4 w-4 text-purple-400" />
                    <div className="flex flex-col">
                      <span className="font-medium">{item.label}</span>
                      <span className="text-xs text-gray-400">{item.description}</span>
                    </div>
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Notifications */}
          <Button
            variant="ghost"
            size="sm"
            className="relative text-gray-300 hover:text-white hover:bg-white/10"
          >
            <Bell className="h-4 w-4" />
            {notificationCount > 0 && (
              <Badge 
                className="absolute -top-1 -right-1 h-5 w-5 p-0 bg-red-500 text-white text-xs flex items-center justify-center"
              >
                {notificationCount}
              </Badge>
            )}
          </Button>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="" alt="User" />
                  <AvatarFallback className="bg-gradient-to-br from-purple-500 to-blue-500 text-white">
                    EP
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent 
              className="w-56 bg-black/90 backdrop-blur-xl border-purple-500/30" 
              align="end"
            >
              <div className="flex items-center justify-start gap-2 p-3">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="" alt="User" />
                  <AvatarFallback className="bg-gradient-to-br from-purple-500 to-blue-500 text-white text-sm">
                    EP
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium text-white">Edita Pro User</p>
                  <p className="text-xs text-gray-400">user@editapro.com</p>
                </div>
              </div>
              <DropdownMenuSeparator className="bg-purple-500/20" />
              {userMenuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <DropdownMenuItem
                    key={item.label}
                    onClick={item.action}
                    className="flex items-center gap-2 p-3 cursor-pointer hover:bg-purple-500/10 text-white"
                  >
                    <Icon className="h-4 w-4" />
                    {item.label}
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Mobile Navigation (Hidden on desktop) */}
      <div className="md:hidden px-4 pb-3">
        <div className="flex items-center justify-between space-x-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            return (
              <Button
                key={item.id}
                onClick={() => setLocation(item.path)}
                variant={isActive ? "default" : "ghost"}
                size="sm"
                className={`flex-1 ${
                  isActive 
                    ? 'bg-gradient-to-r from-purple-500 to-blue-500 text-white' 
                    : 'text-gray-300'
                }`}
              >
                <Icon className="h-4 w-4" />
              </Button>
            );
          })}
        </div>
      </div>
    </header>
  );
}