import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Sparkles,
  Palette,
  Zap,
  Eye,
  Sun,
  Moon,
  Star,
  Heart,
  Flame,
  Droplets,
  Snowflake,
  Waves,
  Wind,
  Mountain,
  Flower,
  Diamond,
  Wand2,
  Filter,
  Focus,
  Camera,
  Film,
  Aperture,
  Contrast,
  Settings
} from 'lucide-react';

interface VisualEffect {
  id: string;
  name: string;
  category: 'filter' | 'particle' | 'lighting' | 'distortion' | 'artistic' | 'motion';
  intensity: number;
  color: string;
  speed: number;
  size: number;
  opacity: number;
  enabled: boolean;
}

interface VisualEffectsStudioProps {
  onEffectApply?: (effects: VisualEffect[]) => void;
  onClose?: () => void;
}

export function VisualEffectsStudio({ onEffectApply, onClose }: VisualEffectsStudioProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeEffects, setActiveEffects] = useState<VisualEffect[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('filter');
  const [selectedEffect, setSelectedEffect] = useState<string>('');
  const [isRealTimePreview, setIsRealTimePreview] = useState(true);

  const effectCategories = [
    { id: 'filter', name: 'Filters', icon: Filter, color: 'text-purple-400' },
    { id: 'particle', name: 'Particles', icon: Sparkles, color: 'text-pink-400' },
    { id: 'lighting', name: 'Lighting', icon: Sun, color: 'text-yellow-400' },
    { id: 'distortion', name: 'Distortion', icon: Waves, color: 'text-blue-400' },
    { id: 'artistic', name: 'Artistic', icon: Palette, color: 'text-green-400' },
    { id: 'motion', name: 'Motion', icon: Zap, color: 'text-red-400' }
  ];

  const availableEffects = [
    // Filter Effects
    { id: 'blur', name: 'Gaussian Blur', category: 'filter', icon: Filter },
    { id: 'sharpen', name: 'Sharpen', category: 'filter', icon: Eye },
    { id: 'vintage', name: 'Vintage', category: 'filter', icon: Camera },
    { id: 'black_white', name: 'Black & White', category: 'filter', icon: Contrast },
    { id: 'sepia', name: 'Sepia', category: 'filter', icon: Film },
    
    // Particle Effects
    { id: 'sparkles', name: 'Sparkles', category: 'particle', icon: Sparkles },
    { id: 'snow', name: 'Snow', category: 'particle', icon: Snowflake },
    { id: 'rain', name: 'Rain', category: 'particle', icon: Droplets },
    { id: 'fire', name: 'Fire', category: 'particle', icon: Flame },
    { id: 'stars', name: 'Stars', category: 'particle', icon: Star },
    
    // Lighting Effects
    { id: 'glow', name: 'Soft Glow', category: 'lighting', icon: Sun },
    { id: 'lens_flare', name: 'Lens Flare', category: 'lighting', icon: Sun },
    { id: 'god_rays', name: 'God Rays', category: 'lighting', icon: Mountain },
    { id: 'neon', name: 'Neon Light', category: 'lighting', icon: Zap },
    { id: 'moonlight', name: 'Moonlight', category: 'lighting', icon: Moon },
    
    // Distortion Effects
    { id: 'wave', name: 'Wave Distortion', category: 'distortion', icon: Waves },
    { id: 'ripple', name: 'Ripple', category: 'distortion', icon: Droplets },
    { id: 'wind', name: 'Wind Effect', category: 'distortion', icon: Wind },
    { id: 'twist', name: 'Twist', category: 'distortion', icon: Wand2 },
    
    // Artistic Effects
    { id: 'oil_paint', name: 'Oil Painting', category: 'artistic', icon: Palette },
    { id: 'watercolor', name: 'Watercolor', category: 'artistic', icon: Droplets },
    { id: 'sketch', name: 'Pencil Sketch', category: 'artistic', icon: Aperture },
    { id: 'mosaic', name: 'Mosaic', category: 'artistic', icon: Diamond },
    
    // Motion Effects
    { id: 'motion_blur', name: 'Motion Blur', category: 'motion', icon: Zap },
    { id: 'zoom_blur', name: 'Zoom Blur', category: 'motion', icon: Eye },
    { id: 'radial_blur', name: 'Radial Blur', category: 'motion', icon: Aperture },
    { id: 'shake', name: 'Camera Shake', category: 'motion', icon: Settings }
  ];

  const presetEffects = [
    {
      id: 'cinematic',
      name: 'Cinematic Glow',
      description: 'Hollywood-style dramatic lighting',
      effects: [
        { id: 'glow_1', name: 'Soft Glow', category: 'lighting' as const, intensity: 75, color: '#ffd700', speed: 1, size: 50, opacity: 60, enabled: true },
        { id: 'lens_flare_1', name: 'Lens Flare', category: 'lighting' as const, intensity: 40, color: '#ffffff', speed: 0.5, size: 30, opacity: 80, enabled: true }
      ]
    },
    {
      id: 'vintage',
      name: 'Vintage Film',
      description: 'Classic film grain and color',
      effects: [
        { id: 'sepia_1', name: 'Sepia Tone', category: 'filter' as const, intensity: 65, color: '#deb887', speed: 1, size: 100, opacity: 85, enabled: true },
        { id: 'grain_1', name: 'Film Grain', category: 'artistic' as const, intensity: 45, color: '#8b7355', speed: 0.8, size: 1, opacity: 30, enabled: true }
      ]
    },
    {
      id: 'neon',
      name: 'Neon Cyber',
      description: 'Futuristic neon effects',
      effects: [
        { id: 'neon_1', name: 'Neon Glow', category: 'lighting' as const, intensity: 90, color: '#00ffff', speed: 3, size: 40, opacity: 95, enabled: true }
      ]
    }
  ];

  // Add effect to active list
  const addEffect = useCallback((effectId: string) => {
    const effectTemplate = availableEffects.find(e => e.id === effectId);
    if (!effectTemplate) return;

    const newEffect: VisualEffect = {
      id: `${effectId}_${Date.now()}`,
      name: effectTemplate.name,
      category: effectTemplate.category as VisualEffect['category'],
      intensity: 50,
      color: '#ffffff',
      speed: 1,
      size: 50,
      opacity: 80,
      enabled: true
    };

    setActiveEffects(prev => [...prev, newEffect]);
    setSelectedEffect(newEffect.id);
  }, []);

  // Apply preset
  const applyPreset = useCallback((preset: typeof presetEffects[0]) => {
    setActiveEffects(preset.effects);
  }, []);

  // Update effect property
  const updateEffect = useCallback((effectId: string, property: keyof VisualEffect, value: any) => {
    setActiveEffects(prev =>
      prev.map(effect =>
        effect.id === effectId ? { ...effect, [property]: value } : effect
      )
    );
  }, []);

  // Remove effect
  const removeEffect = useCallback((effectId: string) => {
    setActiveEffects(prev => prev.filter(effect => effect.id !== effectId));
    if (selectedEffect === effectId) {
      setSelectedEffect('');
    }
  }, [selectedEffect]);

  // Render canvas preview
  const renderPreview = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw gradient background
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, '#1a1a2e');
    gradient.addColorStop(0.5, '#16213e');
    gradient.addColorStop(1, '#0f3460');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Apply visual effects
    activeEffects.forEach(effect => {
      if (!effect.enabled) return;

      ctx.save();
      ctx.globalAlpha = effect.opacity / 100;

      switch (effect.category) {
        case 'particle':
          ctx.fillStyle = effect.color;
          for (let i = 0; i < effect.intensity / 5; i++) {
            const x = Math.random() * canvas.width;
            const y = Math.random() * canvas.height;
            const size = effect.size / 10;
            ctx.beginPath();
            ctx.arc(x, y, size, 0, Math.PI * 2);
            ctx.fill();
          }
          break;

        case 'lighting':
          const centerX = canvas.width / 2;
          const centerY = canvas.height / 2;
          const glowGradient = ctx.createRadialGradient(
            centerX, centerY, 0,
            centerX, centerY, effect.size * 2
          );
          glowGradient.addColorStop(0, effect.color + '80');
          glowGradient.addColorStop(1, effect.color + '00');
          ctx.fillStyle = glowGradient;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          break;

        case 'filter':
          ctx.fillStyle = effect.color + Math.floor(effect.intensity * 0.6).toString(16).padStart(2, '0');
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          break;
      }

      ctx.restore();
    });
  }, [activeEffects]);

  useEffect(() => {
    if (isRealTimePreview) {
      renderPreview();
    }
  }, [activeEffects, isRealTimePreview, renderPreview]);

  const selectedEffectData = activeEffects.find(e => e.id === selectedEffect);
  const filteredEffects = availableEffects.filter(e => e.category === selectedCategory);

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Wand2 className="h-6 w-6 text-purple-400" />
              Visual Effects Studio
              <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 ml-auto">
                <Sparkles className="h-3 w-3 mr-1" />
                Advanced
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Effects Library */}
          <div className="space-y-4">
            {/* Category Tabs */}
            <Card className="bg-slate-800/50 border-indigo-500/30">
              <CardContent className="p-4">
                <div className="grid grid-cols-2 gap-2">
                  {effectCategories.map((category) => {
                    const Icon = category.icon;
                    return (
                      <Button
                        key={category.id}
                        onClick={() => setSelectedCategory(category.id)}
                        variant={selectedCategory === category.id ? "default" : "outline"}
                        className={`h-auto p-3 ${
                          selectedCategory === category.id 
                            ? "bg-indigo-500 text-white" 
                            : "border-indigo-500/30 hover:bg-indigo-500/20"
                        }`}
                      >
                        <div className="text-center">
                          <Icon className={`h-4 w-4 mx-auto mb-1 ${category.color}`} />
                          <div className="text-xs">{category.name}</div>
                        </div>
                      </Button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Presets */}
            <Card className="bg-slate-800/50 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm">Quick Presets</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {presetEffects.map((preset) => (
                  <Button
                    key={preset.id}
                    onClick={() => applyPreset(preset)}
                    variant="outline"
                    className="w-full h-auto p-3 text-left border-green-500/30 hover:bg-green-500/20"
                  >
                    <div>
                      <div className="font-medium text-white text-sm">{preset.name}</div>
                      <div className="text-xs text-gray-400">{preset.description}</div>
                    </div>
                  </Button>
                ))}
              </CardContent>
            </Card>

            {/* Individual Effects */}
            <Card className="bg-slate-800/50 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm">
                  {effectCategories.find(c => c.id === selectedCategory)?.name} Effects
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-64 overflow-y-auto">
                {filteredEffects.map((effect) => {
                  const Icon = effect.icon;
                  return (
                    <Button
                      key={effect.id}
                      onClick={() => addEffect(effect.id)}
                      variant="outline"
                      className="w-full justify-start border-purple-500/30 hover:bg-purple-500/20"
                    >
                      <Icon className="h-4 w-4 mr-2 text-purple-400" />
                      {effect.name}
                    </Button>
                  );
                })}
              </CardContent>
            </Card>
          </div>

          {/* Preview */}
          <div className="space-y-4">
            <Card className="bg-slate-800/50 border-yellow-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Eye className="h-4 w-4 text-yellow-400" />
                  Live Preview
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <canvas
                  ref={canvasRef}
                  width={300}
                  height={200}
                  className="w-full border border-slate-600 rounded-lg bg-slate-900"
                />
                
                <div className="flex items-center gap-2 mt-3">
                  <Button
                    onClick={() => setIsRealTimePreview(!isRealTimePreview)}
                    variant="outline"
                    size="sm"
                    className="border-yellow-500/30"
                  >
                    {isRealTimePreview ? 'Live' : 'Manual'}
                  </Button>
                  
                  {!isRealTimePreview && (
                    <Button
                      onClick={renderPreview}
                      size="sm"
                      className="bg-yellow-500 hover:bg-yellow-600"
                    >
                      Update
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <div className="space-y-4">
            {/* Active Effects */}
            <Card className="bg-slate-800/50 border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm">
                  Active Effects ({activeEffects.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-48 overflow-y-auto">
                {activeEffects.map((effect) => (
                  <div
                    key={effect.id}
                    className={`p-2 rounded border cursor-pointer transition-all ${
                      selectedEffect === effect.id 
                        ? 'bg-blue-500/20 border-blue-400' 
                        : 'bg-slate-700/50 border-slate-600 hover:border-slate-500'
                    }`}
                    onClick={() => setSelectedEffect(effect.id)}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-white text-sm">{effect.name}</span>
                      <div className="flex items-center gap-1">
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            updateEffect(effect.id, 'enabled', !effect.enabled);
                          }}
                          variant="ghost"
                          size="sm"
                          className="p-1 h-6 w-6"
                        >
                          <Eye className={`h-3 w-3 ${effect.enabled ? 'text-green-400' : 'text-gray-400'}`} />
                        </Button>
                        
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            removeEffect(effect.id);
                          }}
                          variant="ghost"
                          size="sm"
                          className="p-1 h-6 w-6 text-red-400 hover:bg-red-500/20"
                        >
                          ✕
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                
                {activeEffects.length === 0 && (
                  <div className="text-center text-gray-400 py-8">
                    <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>No effects applied</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Effect Properties */}
            {selectedEffectData && (
              <Card className="bg-slate-800/50 border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-sm">Effect Properties</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs text-gray-300">Intensity</label>
                      <Badge className="bg-green-500/20 text-green-300 border-0 text-xs">
                        {selectedEffectData.intensity}%
                      </Badge>
                    </div>
                    <Slider
                      value={[selectedEffectData.intensity]}
                      onValueChange={([value]) => updateEffect(selectedEffectData.id, 'intensity', value)}
                      max={100}
                      min={0}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs text-gray-300">Opacity</label>
                      <Badge className="bg-blue-500/20 text-blue-300 border-0 text-xs">
                        {selectedEffectData.opacity}%
                      </Badge>
                    </div>
                    <Slider
                      value={[selectedEffectData.opacity]}
                      onValueChange={([value]) => updateEffect(selectedEffectData.id, 'opacity', value)}
                      max={100}
                      min={0}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-gray-300 mb-2 block">Color</label>
                    <input
                      type="color"
                      value={selectedEffectData.color}
                      onChange={(e) => updateEffect(selectedEffectData.id, 'color', e.target.value)}
                      className="w-full h-8 rounded border border-slate-600 bg-slate-700"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Apply Button */}
            <Card className="bg-gradient-to-r from-green-800/50 to-emerald-800/50 border border-green-500/30">
              <CardContent className="p-4">
                <Button
                  onClick={() => onEffectApply?.(activeEffects)}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
                  disabled={activeEffects.length === 0}
                >
                  <Wand2 className="h-4 w-4 mr-2" />
                  Apply {activeEffects.length} Effects
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}