import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Users, 
  Wifi, 
  WifiOff, 
  Share2, 
  MessageCircle, 
  Video, 
  Phone,
  Settings,
  Crown,
  Eye,
  Edit,
  Clock,
  Globe,
  Lock,
  Unlock,
  UserPlus,
  Copy,
  CheckCircle,
  AlertCircle,
  Zap,
  Sparkles
} from 'lucide-react';

interface CollaboratorUser {
  id: string;
  name: string;
  avatar: string;
  email: string;
  role: 'owner' | 'editor' | 'viewer' | 'commenter';
  status: 'online' | 'away' | 'offline';
  cursor?: {
    x: number;
    y: number;
    selection?: {
      start: number;
      end: number;
    };
  };
  lastActive: Date;
}

interface DocumentVersion {
  id: string;
  timestamp: Date;
  author: string;
  changes: string;
  content: string;
}

interface RealTimeEditorProps {
  documentId?: string;
  onCollaborationStart?: (collaborators: CollaboratorUser[]) => void;
  onDocumentSync?: (content: string) => void;
}

export function RealTimeEditor({ documentId, onCollaborationStart, onDocumentSync }: RealTimeEditorProps) {
  const [isConnected, setIsConnected] = useState(true);
  const [collaborators, setCollaborators] = useState<CollaboratorUser[]>([
    {
      id: '1',
      name: 'Ahmad Rizki',
      avatar: '/avatars/ahmad.jpg',
      email: 'ahmad@gmail.com',
      role: 'owner',
      status: 'online',
      cursor: { x: 120, y: 45 },
      lastActive: new Date()
    },
    {
      id: '2',
      name: 'Siti Nurhaliza',
      avatar: '/avatars/siti.jpg',
      email: 'siti@gmail.com',
      role: 'editor',
      status: 'online',
      cursor: { x: 200, y: 78 },
      lastActive: new Date(Date.now() - 300000)
    },
    {
      id: '3',
      name: 'Budi Santoso',
      avatar: '/avatars/budi.jpg',
      email: 'budi@yahoo.com',
      role: 'viewer',
      status: 'away',
      lastActive: new Date(Date.now() - 900000)
    }
  ]);

  const [documentVersions, setDocumentVersions] = useState<DocumentVersion[]>([
    {
      id: 'v1',
      timestamp: new Date(),
      author: 'Ahmad Rizki',
      changes: 'Added introduction paragraph',
      content: 'Current version...'
    },
    {
      id: 'v2',
      timestamp: new Date(Date.now() - 600000),
      author: 'Siti Nurhaliza',
      changes: 'Fixed typos and formatting',
      content: 'Previous version...'
    }
  ]);

  const [shareLink, setShareLink] = useState('');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [documentAccess, setDocumentAccess] = useState<'private' | 'link' | 'public'>('private');
  const [autoSyncEnabled, setAutoSyncEnabled] = useState(true);

  // Simulate real-time connection
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate occasional disconnections
      if (Math.random() < 0.1) {
        setIsConnected(false);
        setTimeout(() => setIsConnected(true), 2000);
      }

      // Update collaborator cursors
      setCollaborators(prev => prev.map(collab => ({
        ...collab,
        cursor: collab.status === 'online' ? {
          x: Math.random() * 800,
          y: Math.random() * 600,
          selection: Math.random() > 0.7 ? {
            start: Math.floor(Math.random() * 100),
            end: Math.floor(Math.random() * 100) + 50
          } : undefined
        } : collab.cursor
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const generateShareLink = () => {
    const randomId = Math.random().toString(36).substring(2, 15);
    const link = `https://editapro.app/doc/${randomId}`;
    setShareLink(link);
    setIsShareModalOpen(true);
  };

  const copyShareLink = () => {
    navigator.clipboard.writeText(shareLink);
    // Show toast notification
  };

  const inviteCollaborator = (email: string, role: 'editor' | 'viewer' | 'commenter') => {
    // Simulate adding new collaborator
    const newCollaborator: CollaboratorUser = {
      id: Date.now().toString(),
      name: email.split('@')[0],
      avatar: '',
      email,
      role,
      status: 'offline',
      lastActive: new Date()
    };
    setCollaborators(prev => [...prev, newCollaborator]);
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner': return Crown;
      case 'editor': return Edit;
      case 'viewer': return Eye;
      case 'commenter': return MessageCircle;
      default: return Users;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'owner': return 'text-yellow-400';
      case 'editor': return 'text-green-400';
      case 'viewer': return 'text-blue-400';
      case 'commenter': return 'text-purple-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-400';
      case 'away': return 'bg-yellow-400';
      case 'offline': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  return (
    <div className="w-full space-y-6">
      {/* Connection Status Header */}
      <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            {isConnected ? (
              <>
                <Wifi className="h-6 w-6 text-green-400" />
                Real-Time Collaboration
              </>
            ) : (
              <>
                <WifiOff className="h-6 w-6 text-red-400 animate-pulse" />
                Reconnecting...
              </>
            )}
            <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0 ml-auto">
              <Users className="h-3 w-3 mr-1" />
              {collaborators.filter(c => c.status === 'online').length} Online
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Collaborators Panel */}
        <div className="lg:col-span-2 space-y-4">
          {/* Active Collaborators */}
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Users className="h-4 w-4 text-green-400" />
                Active Collaborators
                <Button 
                  size="sm" 
                  onClick={() => setIsShareModalOpen(true)}
                  className="bg-indigo-500 hover:bg-indigo-600 ml-auto h-8"
                >
                  <UserPlus className="h-3 w-3 mr-1" />
                  Invite
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {collaborators.map((collaborator) => {
                const RoleIcon = getRoleIcon(collaborator.role);
                return (
                  <div
                    key={collaborator.id}
                    className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg hover:bg-slate-700/70 transition-colors"
                  >
                    <div className="relative">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={collaborator.avatar} />
                        <AvatarFallback className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
                          {collaborator.name.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-slate-800 ${getStatusColor(collaborator.status)}`} />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-white">{collaborator.name}</span>
                        <RoleIcon className={`h-4 w-4 ${getRoleColor(collaborator.role)}`} />
                      </div>
                      <div className="text-sm text-gray-400">{collaborator.email}</div>
                      <div className="text-xs text-gray-500">
                        {collaborator.status === 'online' ? 'Active now' : 
                         `Last seen ${Math.floor((Date.now() - collaborator.lastActive.getTime()) / 60000)} min ago`}
                      </div>
                    </div>

                    {collaborator.status === 'online' && (
                      <Badge className="bg-green-500/20 text-green-300 border-green-500/30 text-xs">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse mr-1" />
                        Live
                      </Badge>
                    )}
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Document Versions */}
          <Card className="bg-slate-800/50 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Clock className="h-4 w-4 text-blue-400" />
                Version History
                <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 ml-auto">
                  Auto-save: {autoSyncEnabled ? 'ON' : 'OFF'}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {documentVersions.map((version, index) => (
                <div
                  key={version.id}
                  className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg hover:bg-slate-700/70 transition-colors cursor-pointer"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-white">
                        {index === 0 ? 'Current Version' : `Version ${documentVersions.length - index}`}
                      </span>
                      {index === 0 && (
                        <Badge className="bg-green-500/20 text-green-300 border-green-500/30 text-xs">
                          Latest
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-gray-400">{version.changes}</div>
                    <div className="text-xs text-gray-500">
                      by {version.author} • {version.timestamp.toLocaleTimeString('id-ID')}
                    </div>
                  </div>

                  <Button size="sm" variant="ghost" className="text-indigo-400 hover:text-indigo-300">
                    Restore
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Settings & Controls */}
        <div className="space-y-4">
          {/* Cloud Sync Status */}
          <Card className="bg-slate-800/50 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Globe className="h-4 w-4 text-purple-400" />
                Cloud Sync
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-300 text-sm">Auto-sync</span>
                <button
                  onClick={() => setAutoSyncEnabled(!autoSyncEnabled)}
                  className={`w-12 h-6 rounded-full transition-colors ${
                    autoSyncEnabled ? 'bg-green-500' : 'bg-gray-600'
                  }`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                    autoSyncEnabled ? 'translate-x-6' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>Synced across all devices</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>Last backup: 2 min ago</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <Zap className="h-4 w-4 text-yellow-400" />
                  <span>Real-time collaboration active</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Document Access */}
          <Card className="bg-slate-800/50 border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                {documentAccess === 'private' ? (
                  <Lock className="h-4 w-4 text-yellow-400" />
                ) : (
                  <Unlock className="h-4 w-4 text-green-400" />
                )}
                Document Access
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="access"
                    checked={documentAccess === 'private'}
                    onChange={() => setDocumentAccess('private')}
                    className="w-4 h-4 text-indigo-500"
                  />
                  <div>
                    <div className="text-white font-medium">Private</div>
                    <div className="text-xs text-gray-400">Only invited users can access</div>
                  </div>
                </label>

                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="access"
                    checked={documentAccess === 'link'}
                    onChange={() => setDocumentAccess('link')}
                    className="w-4 h-4 text-indigo-500"
                  />
                  <div>
                    <div className="text-white font-medium">Anyone with link</div>
                    <div className="text-xs text-gray-400">Can view or edit with link</div>
                  </div>
                </label>

                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="access"
                    checked={documentAccess === 'public'}
                    onChange={() => setDocumentAccess('public')}
                    className="w-4 h-4 text-indigo-500"
                  />
                  <div>
                    <div className="text-white font-medium">Public</div>
                    <div className="text-xs text-gray-400">Anyone can find and access</div>
                  </div>
                </label>
              </div>

              <Button
                onClick={generateShareLink}
                className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600"
              >
                <Share2 className="h-4 w-4 mr-2" />
                Generate Share Link
              </Button>
            </CardContent>
          </Card>

          {/* Communication Tools */}
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <MessageCircle className="h-4 w-4 text-green-400" />
                Communication
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full bg-green-600 hover:bg-green-700">
                <Video className="h-4 w-4 mr-2" />
                Start Video Call
              </Button>
              
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                <Phone className="h-4 w-4 mr-2" />
                Voice Call
              </Button>
              
              <Button className="w-full bg-purple-600 hover:bg-purple-700">
                <MessageCircle className="h-4 w-4 mr-2" />
                Open Chat
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Share Modal */}
      {isShareModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="bg-slate-800 border-indigo-500/30 w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Share2 className="h-5 w-5 text-indigo-400" />
                Share Document
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm text-gray-300">Share Link</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={shareLink || 'https://editapro.app/doc/abc123xyz'}
                    readOnly
                    className="flex-1 bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
                  />
                  <Button onClick={copyShareLink} size="sm" className="bg-indigo-500 hover:bg-indigo-600">
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-gray-300">Invite by Email</label>
                <div className="flex gap-2">
                  <input
                    type="email"
                    placeholder="email@example.com"
                    className="flex-1 bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
                  />
                  <select className="bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm">
                    <option value="editor">Editor</option>
                    <option value="viewer">Viewer</option>
                    <option value="commenter">Commenter</option>
                  </select>
                </div>
                <Button className="w-full bg-green-500 hover:bg-green-600">
                  Send Invitation
                </Button>
              </div>

              <div className="flex gap-2">
                <Button 
                  onClick={() => setIsShareModalOpen(false)}
                  variant="outline" 
                  className="flex-1"
                >
                  Close
                </Button>
                <Button 
                  onClick={copyShareLink}
                  className="flex-1 bg-indigo-500 hover:bg-indigo-600"
                >
                  Copy Link
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}