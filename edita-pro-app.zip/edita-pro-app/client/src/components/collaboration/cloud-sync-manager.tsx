import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Cloud, 
  CloudOff, 
  Smartphone, 
  Monitor, 
  Tablet, 
  CheckCircle, 
  AlertTriangle, 
  RefreshCw,
  HardDrive,
  Wifi,
  Clock,
  Download,
  Upload,
  Database,
  Shield,
  Zap,
  Globe
} from 'lucide-react';

interface SyncDevice {
  id: string;
  name: string;
  type: 'mobile' | 'desktop' | 'tablet' | 'web';
  lastSync: Date;
  status: 'synced' | 'syncing' | 'offline' | 'conflict';
  platform: string;
  location: string;
}

interface SyncStatus {
  isOnline: boolean;
  lastSync: Date;
  totalFiles: number;
  syncedFiles: number;
  pendingChanges: number;
  storageUsed: number;
  storageLimit: number;
}

interface CloudSyncManagerProps {
  onSyncStart?: () => void;
  onSyncComplete?: () => void;
  onConflictResolve?: (conflicts: any[]) => void;
}

export function CloudSyncManager({ onSyncStart, onSyncComplete, onConflictResolve }: CloudSyncManagerProps) {
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    isOnline: true,
    lastSync: new Date(),
    totalFiles: 47,
    syncedFiles: 45,
    pendingChanges: 2,
    storageUsed: 2.4,
    storageLimit: 15
  });

  const [syncDevices, setSyncDevices] = useState<SyncDevice[]>([
    {
      id: '1',
      name: 'iPhone 14 Pro',
      type: 'mobile',
      lastSync: new Date(),
      status: 'synced',
      platform: 'iOS 17.1',
      location: 'Jakarta, Indonesia'
    },
    {
      id: '2',
      name: 'MacBook Pro',
      type: 'desktop',
      lastSync: new Date(Date.now() - 300000),
      status: 'syncing',
      platform: 'macOS Sonoma',
      location: 'Jakarta, Indonesia'
    },
    {
      id: '3',
      name: 'Chrome Browser',
      type: 'web',
      lastSync: new Date(Date.now() - 600000),
      status: 'synced',
      platform: 'Windows 11',
      location: 'Bandung, Indonesia'
    },
    {
      id: '4',
      name: 'iPad Air',
      type: 'tablet',
      lastSync: new Date(Date.now() - 1800000),
      status: 'conflict',
      platform: 'iPadOS 17',
      location: 'Surabaya, Indonesia'
    }
  ]);

  const [isSyncing, setIsSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  const [autoSyncEnabled, setAutoSyncEnabled] = useState(true);

  // Simulate sync process
  useEffect(() => {
    if (isSyncing) {
      const interval = setInterval(() => {
        setSyncProgress(prev => {
          if (prev >= 100) {
            setIsSyncing(false);
            onSyncComplete?.();
            return 0;
          }
          return prev + 10;
        });
      }, 500);

      return () => clearInterval(interval);
    }
  }, [isSyncing, onSyncComplete]);

  // Auto-sync simulation
  useEffect(() => {
    if (autoSyncEnabled) {
      const interval = setInterval(() => {
        // Simulate periodic sync
        setSyncStatus(prev => ({
          ...prev,
          lastSync: new Date(),
          syncedFiles: prev.totalFiles
        }));
      }, 30000); // Sync every 30 seconds

      return () => clearInterval(interval);
    }
  }, [autoSyncEnabled]);

  const startManualSync = () => {
    setIsSyncing(true);
    setSyncProgress(0);
    onSyncStart?.();
  };

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'mobile': return Smartphone;
      case 'desktop': return Monitor;
      case 'tablet': return Tablet;
      case 'web': return Globe;
      default: return Monitor;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'synced': return 'text-green-400';
      case 'syncing': return 'text-blue-400';
      case 'offline': return 'text-gray-400';
      case 'conflict': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'synced': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'syncing': return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 'offline': return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
      case 'conflict': return 'bg-red-500/20 text-red-300 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const storagePercentage = (syncStatus.storageUsed / syncStatus.storageLimit) * 100;

  return (
    <div className="w-full space-y-6">
      {/* Sync Status Overview */}
      <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            {syncStatus.isOnline ? (
              <>
                <Cloud className="h-6 w-6 text-blue-400" />
                Cloud Sync Active
              </>
            ) : (
              <>
                <CloudOff className="h-6 w-6 text-red-400" />
                Offline Mode
              </>
            )}
            <Badge className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-0 ml-auto">
              <Database className="h-3 w-3 mr-1" />
              {syncStatus.syncedFiles}/{syncStatus.totalFiles} Files
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {isSyncing && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-300">
                <span>Syncing files...</span>
                <span>{syncProgress}%</span>
              </div>
              <Progress value={syncProgress} className="h-2" />
            </div>
          )}

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-slate-700/50 rounded-lg">
              <CheckCircle className="h-5 w-5 mx-auto mb-2 text-green-400" />
              <div className="text-lg font-bold text-white">{syncStatus.syncedFiles}</div>
              <div className="text-xs text-gray-400">Files Synced</div>
            </div>
            
            <div className="text-center p-3 bg-slate-700/50 rounded-lg">
              <RefreshCw className="h-5 w-5 mx-auto mb-2 text-blue-400" />
              <div className="text-lg font-bold text-white">{syncStatus.pendingChanges}</div>
              <div className="text-xs text-gray-400">Pending</div>
            </div>
            
            <div className="text-center p-3 bg-slate-700/50 rounded-lg">
              <HardDrive className="h-5 w-5 mx-auto mb-2 text-purple-400" />
              <div className="text-lg font-bold text-white">{syncStatus.storageUsed} GB</div>
              <div className="text-xs text-gray-400">Storage Used</div>
            </div>
            
            <div className="text-center p-3 bg-slate-700/50 rounded-lg">
              <Clock className="h-5 w-5 mx-auto mb-2 text-orange-400" />
              <div className="text-lg font-bold text-white">
                {Math.floor((Date.now() - syncStatus.lastSync.getTime()) / 60000)}m
              </div>
              <div className="text-xs text-gray-400">Last Sync</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Connected Devices */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Wifi className="h-4 w-4 text-green-400" />
                Connected Devices
                <Badge className="bg-green-500/20 text-green-300 border-green-500/30 ml-auto">
                  {syncDevices.filter(d => d.status !== 'offline').length} Active
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {syncDevices.map((device) => {
                const DeviceIcon = getDeviceIcon(device.type);
                return (
                  <div
                    key={device.id}
                    className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg hover:bg-slate-700/70 transition-colors"
                  >
                    <div className="p-2 bg-indigo-500/20 rounded-lg">
                      <DeviceIcon className="h-5 w-5 text-indigo-400" />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-white">{device.name}</span>
                        <Badge className={getStatusBadge(device.status)}>
                          {device.status}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-400">{device.platform}</div>
                      <div className="text-xs text-gray-500">{device.location}</div>
                    </div>

                    <div className="text-right text-sm">
                      <div className={`${getStatusColor(device.status)} font-medium`}>
                        {device.status === 'syncing' ? 'Syncing...' : 
                         device.status === 'synced' ? 'Up to date' :
                         device.status === 'conflict' ? 'Needs attention' : 'Offline'}
                      </div>
                      <div className="text-xs text-gray-500">
                        {Math.floor((Date.now() - device.lastSync.getTime()) / 60000)}m ago
                      </div>
                    </div>

                    {device.status === 'conflict' && (
                      <Button size="sm" className="bg-red-500 hover:bg-red-600">
                        Resolve
                      </Button>
                    )}
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Sync Activity */}
          <Card className="bg-slate-800/50 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <RefreshCw className="h-4 w-4 text-blue-400" />
                Recent Sync Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-center gap-3 p-2 bg-slate-700/30 rounded">
                  <Upload className="h-4 w-4 text-green-400" />
                  <span className="text-sm text-gray-300">Video Project.mp4 uploaded</span>
                  <span className="text-xs text-gray-500 ml-auto">2 min ago</span>
                </div>
                
                <div className="flex items-center gap-3 p-2 bg-slate-700/30 rounded">
                  <Download className="h-4 w-4 text-blue-400" />
                  <span className="text-sm text-gray-300">Document sync from iPhone</span>
                  <span className="text-xs text-gray-500 ml-auto">5 min ago</span>
                </div>
                
                <div className="flex items-center gap-3 p-2 bg-slate-700/30 rounded">
                  <AlertTriangle className="h-4 w-4 text-yellow-400" />
                  <span className="text-sm text-gray-300">Conflict resolved on iPad</span>
                  <span className="text-xs text-gray-500 ml-auto">10 min ago</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sync Controls */}
        <div className="space-y-4">
          {/* Manual Sync */}
          <Card className="bg-slate-800/50 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <RefreshCw className="h-4 w-4 text-purple-400" />
                Sync Controls
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={startManualSync}
                disabled={isSyncing}
                className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600"
              >
                {isSyncing ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Syncing... {syncProgress}%
                  </>
                ) : (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Sync Now
                  </>
                )}
              </Button>

              <div className="flex items-center justify-between">
                <span className="text-gray-300 text-sm">Auto-sync</span>
                <button
                  onClick={() => setAutoSyncEnabled(!autoSyncEnabled)}
                  className={`w-12 h-6 rounded-full transition-colors ${
                    autoSyncEnabled ? 'bg-green-500' : 'bg-gray-600'
                  }`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                    autoSyncEnabled ? 'translate-x-6' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>

              <div className="text-xs text-gray-400">
                Next auto-sync in 25 seconds
              </div>
            </CardContent>
          </Card>

          {/* Storage Usage */}
          <Card className="bg-slate-800/50 border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <HardDrive className="h-4 w-4 text-yellow-400" />
                Storage Usage
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">Used</span>
                  <span className="text-white">{syncStatus.storageUsed} GB / {syncStatus.storageLimit} GB</span>
                </div>
                <Progress value={storagePercentage} className="h-2" />
                <div className="text-xs text-gray-400">
                  {(syncStatus.storageLimit - syncStatus.storageUsed).toFixed(1)} GB available
                </div>
              </div>

              {storagePercentage > 80 && (
                <div className="p-3 bg-yellow-500/20 border border-yellow-500/30 rounded-lg">
                  <div className="flex items-center gap-2 text-yellow-300 text-sm">
                    <AlertTriangle className="h-4 w-4" />
                    <span>Storage almost full</span>
                  </div>
                </div>
              )}

              <Button className="w-full bg-yellow-600 hover:bg-yellow-700">
                Upgrade Storage
              </Button>
            </CardContent>
          </Card>

          {/* Security */}
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Shield className="h-4 w-4 text-green-400" />
                Security
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>End-to-end encryption</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>Two-factor authentication</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <Zap className="h-4 w-4 text-blue-400" />
                  <span>Real-time backup</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}