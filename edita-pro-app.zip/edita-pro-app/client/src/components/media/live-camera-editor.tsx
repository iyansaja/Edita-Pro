import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Camera,
  Video,
  Square,
  RotateCcw,
  SwitchCamera,
  Zap,
  Sparkles,
  Sun,
  Moon,
  Heart,
  Smile,
  Eye,
  Timer,
  Gauge,
  Settings,
  Download,
  Share,
  Pause,
  Play,
  FastForward,
  Rewind,
  CircleDot,
  StopCircle,
  FlipHorizontal,
  FlipVertical,
  Palette,
  Wand2
} from 'lucide-react';

interface CameraFilter {
  id: string;
  name: string;
  icon: any;
  color: string;
  description: string;
  adjustments: {
    brightness: number;
    contrast: number;
    saturation: number;
    warmth: number;
    blur: number;
    vignette: number;
  };
  realTimeCompatible: boolean;
}

interface RecordingSettings {
  resolution: '720p' | '1080p' | '4K';
  fps: 24 | 30 | 60 | 120;
  mode: 'normal' | 'slow_motion' | 'time_lapse';
  duration: number;
  quality: 'low' | 'medium' | 'high' | 'ultra';
}

interface LiveCameraEditorProps {
  onRecordingComplete?: (videoUrl: string, settings: RecordingSettings) => void;
  onPhotoCapture?: (photoUrl: string) => void;
}

export function LiveCameraEditor({ onRecordingComplete, onPhotoCapture }: LiveCameraEditorProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  
  const [isRecording, setIsRecording] = useState(false);
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [activeFilter, setActiveFilter] = useState<string>('none');
  const [recordingTime, setRecordingTime] = useState(0);
  const [recordingSettings, setRecordingSettings] = useState<RecordingSettings>({
    resolution: '1080p',
    fps: 30,
    mode: 'normal',
    duration: 60,
    quality: 'high'
  });

  const [beautySettings, setBeautySettings] = useState({
    smoothing: 30,
    brightening: 20,
    eyeEnhancement: 15,
    lipColor: 0,
    faceSlimming: 0
  });

  const [speedSettings, setSpeedSettings] = useState({
    slowMotionRate: 0.5,
    timeLapseRate: 4.0,
    customSpeed: 1.0
  });

  const cameraFilters: CameraFilter[] = [
    {
      id: 'none',
      name: 'Natural',
      icon: Eye,
      color: 'from-gray-500 to-gray-600',
      description: 'No filter applied',
      adjustments: { brightness: 0, contrast: 0, saturation: 0, warmth: 0, blur: 0, vignette: 0 },
      realTimeCompatible: true
    },
    {
      id: 'beauty',
      name: 'Beauty',
      icon: Sparkles,
      color: 'from-pink-500 to-rose-500',
      description: 'Automatic skin smoothing and enhancement',
      adjustments: { brightness: 15, contrast: 5, saturation: 10, warmth: 20, blur: 2, vignette: 0 },
      realTimeCompatible: true
    },
    {
      id: 'vintage',
      name: 'Vintage',
      icon: Sun,
      color: 'from-yellow-500 to-orange-500',
      description: 'Classic vintage film look',
      adjustments: { brightness: -5, contrast: 15, saturation: -10, warmth: 30, blur: 1, vignette: 20 },
      realTimeCompatible: true
    },
    {
      id: 'dramatic',
      name: 'Dramatic',
      icon: Moon,
      color: 'from-purple-600 to-indigo-600',
      description: 'High contrast dramatic effect',
      adjustments: { brightness: -10, contrast: 40, saturation: 20, warmth: -10, blur: 0, vignette: 30 },
      realTimeCompatible: true
    },
    {
      id: 'soft',
      name: 'Soft Focus',
      icon: Heart,
      color: 'from-pink-400 to-purple-400',
      description: 'Dreamy soft focus effect',
      adjustments: { brightness: 20, contrast: -10, saturation: 15, warmth: 15, blur: 5, vignette: 10 },
      realTimeCompatible: true
    }
  ];

  // Initialize camera
  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, [facingMode]);

  // Recording timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const startCamera = async () => {
    try {
      const constraints = {
        video: {
          facingMode,
          width: { ideal: 1920 },
          height: { ideal: 1080 },
          frameRate: { ideal: 30 }
        },
        audio: true
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      setCameraStream(stream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsPreviewing(true);
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
      setIsPreviewing(false);
    }
  };

  const switchCamera = () => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
  };

  const applyFilter = (filterId: string) => {
    setActiveFilter(filterId);
    const filter = cameraFilters.find(f => f.id === filterId);
    
    if (videoRef.current && filter) {
      const { brightness, contrast, saturation, warmth, blur, vignette } = filter.adjustments;
      
      const filterString = `
        brightness(${1 + brightness / 100})
        contrast(${1 + contrast / 100})
        saturate(${1 + saturation / 100})
        sepia(${warmth / 100})
        blur(${blur}px)
      `;
      
      videoRef.current.style.filter = filterString;
    }
  };

  const startRecording = async () => {
    if (!cameraStream) return;

    try {
      const options = {
        mimeType: 'video/webm;codecs=vp9',
        videoBitsPerSecond: recordingSettings.quality === 'ultra' ? 8000000 : 
                           recordingSettings.quality === 'high' ? 5000000 :
                           recordingSettings.quality === 'medium' ? 2000000 : 1000000
      };

      const mediaRecorder = new MediaRecorder(cameraStream, options);
      mediaRecorderRef.current = mediaRecorder;

      const chunks: Blob[] = [];
      mediaRecorder.ondataavailable = (event) => {
        chunks.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        const videoUrl = URL.createObjectURL(blob);
        onRecordingComplete?.(videoUrl, recordingSettings);
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
    } catch (error) {
      console.error('Error starting recording:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      
      // Apply current filter to photo
      const filter = cameraFilters.find(f => f.id === activeFilter);
      if (filter) {
        ctx.filter = videoRef.current.style.filter;
      }
      
      ctx.drawImage(videoRef.current, 0, 0);
      
      canvas.toBlob((blob) => {
        if (blob) {
          const photoUrl = URL.createObjectURL(blob);
          onPhotoCapture?.(photoUrl);
        }
      }, 'image/jpeg', 0.9);
    }
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getSpeedLabel = (mode: string): string => {
    switch (mode) {
      case 'slow_motion': return `${speedSettings.slowMotionRate}x Slow`;
      case 'time_lapse': return `${speedSettings.timeLapseRate}x Fast`;
      default: return 'Normal Speed';
    }
  };

  return (
    <div className="w-full h-full space-y-4">
      {/* Camera Preview */}
      <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-cover"
        />
        
        <canvas ref={canvasRef} className="hidden" />

        {/* Recording Indicator */}
        {isRecording && (
          <div className="absolute top-4 left-4 flex items-center gap-2 bg-red-500/90 px-3 py-2 rounded-lg">
            <CircleDot className="h-4 w-4 text-white animate-pulse" />
            <span className="text-white font-medium">{formatTime(recordingTime)}</span>
          </div>
        )}

        {/* Active Filter Badge */}
        {activeFilter !== 'none' && (
          <div className="absolute top-4 right-4">
            <Badge className="bg-purple-500/90 text-white border-0">
              <Wand2 className="h-3 w-3 mr-1" />
              {cameraFilters.find(f => f.id === activeFilter)?.name}
            </Badge>
          </div>
        )}

        {/* Speed Mode Indicator */}
        {recordingSettings.mode !== 'normal' && (
          <div className="absolute bottom-4 left-4">
            <Badge className="bg-blue-500/90 text-white border-0">
              <Gauge className="h-3 w-3 mr-1" />
              {getSpeedLabel(recordingSettings.mode)}
            </Badge>
          </div>
        )}

        {/* Camera Controls Overlay */}
        <div className="absolute bottom-4 right-4 flex gap-2">
          <Button
            onClick={switchCamera}
            className="bg-black/50 hover:bg-black/70 text-white border-0"
            size="sm"
          >
            <SwitchCamera className="h-4 w-4" />
          </Button>
          
          <Button
            onClick={() => setFacingMode('user')}
            className="bg-black/50 hover:bg-black/70 text-white border-0"
            size="sm"
          >
            <FlipHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Main Controls */}
        <div className="lg:col-span-2 space-y-4">
          {/* Recording Controls */}
          <Card className="bg-slate-800/50 border-red-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Video className="h-4 w-4 text-red-400" />
                Recording Controls
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-3">
                <Button
                  onClick={isRecording ? stopRecording : startRecording}
                  className={`flex-1 h-12 ${
                    isRecording 
                      ? 'bg-red-600 hover:bg-red-700' 
                      : 'bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600'
                  }`}
                >
                  {isRecording ? (
                    <>
                      <StopCircle className="h-5 w-5 mr-2" />
                      Stop Recording
                    </>
                  ) : (
                    <>
                      <CircleDot className="h-5 w-5 mr-2" />
                      Start Recording
                    </>
                  )}
                </Button>
                
                <Button
                  onClick={capturePhoto}
                  className="bg-blue-600 hover:bg-blue-700 h-12"
                >
                  <Camera className="h-5 w-5" />
                </Button>
              </div>

              {/* Recording Mode */}
              <div className="grid grid-cols-3 gap-2">
                <Button
                  onClick={() => setRecordingSettings(prev => ({ ...prev, mode: 'normal' }))}
                  className={`p-3 h-auto flex flex-col gap-1 ${
                    recordingSettings.mode === 'normal' 
                      ? 'bg-indigo-600 hover:bg-indigo-700' 
                      : 'bg-slate-700 hover:bg-slate-600'
                  }`}
                >
                  <Play className="h-4 w-4" />
                  <span className="text-xs">Normal</span>
                </Button>
                
                <Button
                  onClick={() => setRecordingSettings(prev => ({ ...prev, mode: 'slow_motion' }))}
                  className={`p-3 h-auto flex flex-col gap-1 ${
                    recordingSettings.mode === 'slow_motion' 
                      ? 'bg-indigo-600 hover:bg-indigo-700' 
                      : 'bg-slate-700 hover:bg-slate-600'
                  }`}
                >
                  <Rewind className="h-4 w-4" />
                  <span className="text-xs">Slow Mo</span>
                </Button>
                
                <Button
                  onClick={() => setRecordingSettings(prev => ({ ...prev, mode: 'time_lapse' }))}
                  className={`p-3 h-auto flex flex-col gap-1 ${
                    recordingSettings.mode === 'time_lapse' 
                      ? 'bg-indigo-600 hover:bg-indigo-700' 
                      : 'bg-slate-700 hover:bg-slate-600'
                  }`}
                >
                  <FastForward className="h-4 w-4" />
                  <span className="text-xs">Time Lapse</span>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Live Filters */}
          <Card className="bg-slate-800/50 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Palette className="h-4 w-4 text-purple-400" />
                Live Filters
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-3 gap-2">
                {cameraFilters.map((filter) => {
                  const IconComponent = filter.icon;
                  return (
                    <Button
                      key={filter.id}
                      onClick={() => applyFilter(filter.id)}
                      className={`p-3 h-auto flex flex-col gap-2 ${
                        activeFilter === filter.id 
                          ? 'bg-gradient-to-r from-purple-600 to-pink-600' 
                          : 'bg-slate-700 hover:bg-slate-600'
                      }`}
                    >
                      <div className={`p-2 rounded bg-gradient-to-r ${filter.color}`}>
                        <IconComponent className="h-4 w-4 text-white" />
                      </div>
                      <span className="text-xs">{filter.name}</span>
                    </Button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Settings */}
        <div className="lg:col-span-2 space-y-4">
          {/* Beauty Settings */}
          <Card className="bg-slate-800/50 border-pink-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-pink-400" />
                Beauty Enhancement
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(beautySettings).map(([key, value]) => (
                <div key={key} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="text-sm text-gray-300 capitalize">
                      {key.replace(/([A-Z])/g, ' $1')}
                    </label>
                    <Badge className="bg-pink-500/20 text-pink-300 border-0 text-xs">
                      {value}%
                    </Badge>
                  </div>
                  <Slider
                    value={[value]}
                    onValueChange={([newValue]) => 
                      setBeautySettings(prev => ({ ...prev, [key]: newValue }))
                    }
                    max={100}
                    min={0}
                    step={1}
                    className="w-full"
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Speed Settings */}
          <Card className="bg-slate-800/50 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Gauge className="h-4 w-4 text-blue-400" />
                Speed Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-sm text-gray-300">Slow Motion Rate</label>
                  <Badge className="bg-blue-500/20 text-blue-300 border-0 text-xs">
                    {speedSettings.slowMotionRate}x
                  </Badge>
                </div>
                <Slider
                  value={[speedSettings.slowMotionRate]}
                  onValueChange={([value]) => 
                    setSpeedSettings(prev => ({ ...prev, slowMotionRate: value }))
                  }
                  max={1}
                  min={0.1}
                  step={0.1}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-sm text-gray-300">Time Lapse Rate</label>
                  <Badge className="bg-blue-500/20 text-blue-300 border-0 text-xs">
                    {speedSettings.timeLapseRate}x
                  </Badge>
                </div>
                <Slider
                  value={[speedSettings.timeLapseRate]}
                  onValueChange={([value]) => 
                    setSpeedSettings(prev => ({ ...prev, timeLapseRate: value }))
                  }
                  max={10}
                  min={2}
                  step={0.5}
                  className="w-full"
                />
              </div>
            </CardContent>
          </Card>

          {/* Recording Settings */}
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Settings className="h-4 w-4 text-green-400" />
                Recording Quality
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm text-gray-300 mb-2 block">Resolution</label>
                  <select
                    value={recordingSettings.resolution}
                    onChange={(e) => setRecordingSettings(prev => ({ 
                      ...prev, 
                      resolution: e.target.value as '720p' | '1080p' | '4K' 
                    }))}
                    className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
                  >
                    <option value="720p">720p HD</option>
                    <option value="1080p">1080p FHD</option>
                    <option value="4K">4K UHD</option>
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-300 mb-2 block">Frame Rate</label>
                  <select
                    value={recordingSettings.fps}
                    onChange={(e) => setRecordingSettings(prev => ({ 
                      ...prev, 
                      fps: parseInt(e.target.value) as 24 | 30 | 60 | 120 
                    }))}
                    className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
                  >
                    <option value={24}>24 FPS</option>
                    <option value={30}>30 FPS</option>
                    <option value={60}>60 FPS</option>
                    <option value={120}>120 FPS</option>
                  </select>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}