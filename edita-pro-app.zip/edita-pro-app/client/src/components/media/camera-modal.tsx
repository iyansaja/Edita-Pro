import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Camera, Video, Square, Download, RotateCcw, Palette } from "lucide-react";

interface CameraModalProps {
  open: boolean;
  onClose: () => void;
  onMediaCaptured: (mediaUrl: string, type: 'photo' | 'video') => void;
}

export function CameraModal({ open, onClose, onMediaCaptured }: CameraModalProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedChunks, setRecordedChunks] = useState<Blob[]>([]);
  const [selectedFilter, setSelectedFilter] = useState<string>("none");
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");

  const filters = [
    { value: "none", label: "No Filter" },
    { value: "grayscale", label: "Grayscale" },
    { value: "sepia", label: "Sepia" },
    { value: "blur", label: "Blur" },
    { value: "brightness", label: "Bright" },
    { value: "contrast", label: "High Contrast" },
    { value: "hue-rotate", label: "Rainbow" },
    { value: "invert", label: "Invert" },
  ];

  const getFilterStyle = (filter: string) => {
    switch (filter) {
      case "grayscale": return "grayscale(100%)";
      case "sepia": return "sepia(100%)";
      case "blur": return "blur(2px)";
      case "brightness": return "brightness(150%)";
      case "contrast": return "contrast(150%)";
      case "hue-rotate": return "hue-rotate(180deg)";
      case "invert": return "invert(100%)";
      default: return "none";
    }
  };

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode },
        audio: true
      });
      
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error) {
      console.error("Error accessing camera:", error);
      alert("Unable to access camera. Please check permissions.");
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const takePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const video = videoRef.current;
    const context = canvas.getContext('2d');

    if (!context) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Apply filter to canvas
    context.filter = getFilterStyle(selectedFilter);
    context.drawImage(video, 0, 0);

    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        onMediaCaptured(url, 'photo');
      }
    }, 'image/jpeg', 0.9);
  };

  const startRecording = () => {
    if (!stream) return;

    const mediaRecorder = new MediaRecorder(stream);
    mediaRecorderRef.current = mediaRecorder;
    setRecordedChunks([]);

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        setRecordedChunks(prev => [...prev, event.data]);
      }
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(recordedChunks, { type: 'video/webm' });
      const url = URL.createObjectURL(blob);
      onMediaCaptured(url, 'video');
    };

    mediaRecorder.start();
    setIsRecording(true);
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const switchCamera = () => {
    stopCamera();
    setFacingMode(prev => prev === "user" ? "environment" : "user");
  };

  useEffect(() => {
    if (open) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => stopCamera();
  }, [open, facingMode]);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl w-full h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Camera className="h-5 w-5" />
            <span>Camera & Recording Studio</span>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex flex-col space-y-4">
          {/* Camera Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Select value={selectedFilter} onValueChange={setSelectedFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Select filter" />
                </SelectTrigger>
                <SelectContent>
                  {filters.map((filter) => (
                    <SelectItem key={filter.value} value={filter.value}>
                      {filter.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Button
                onClick={switchCamera}
                variant="outline"
                size="sm"
                title="Switch Camera"
              >
                <RotateCcw className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex items-center space-x-2">
              <Button
                onClick={takePhoto}
                variant="outline"
                disabled={!stream}
                className="flex items-center space-x-2"
              >
                <Camera className="h-4 w-4" />
                <span>Take Photo</span>
              </Button>

              <Button
                onClick={isRecording ? stopRecording : startRecording}
                variant={isRecording ? "destructive" : "default"}
                disabled={!stream}
                className="flex items-center space-x-2"
              >
                {isRecording ? (
                  <>
                    <Square className="h-4 w-4" />
                    <span>Stop Recording</span>
                  </>
                ) : (
                  <>
                    <Video className="h-4 w-4" />
                    <span>Start Recording</span>
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Camera Preview */}
          <div className="flex-1 relative bg-black rounded-lg overflow-hidden">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
              style={{
                filter: getFilterStyle(selectedFilter),
                transform: facingMode === "user" ? "scaleX(-1)" : "none"
              }}
            />
            
            {isRecording && (
              <div className="absolute top-4 right-4 flex items-center space-x-2 bg-red-600 text-white px-3 py-1 rounded-full">
                <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                <span className="text-sm font-medium">Recording</span>
              </div>
            )}

            {!stream && (
              <div className="absolute inset-0 flex items-center justify-center text-white">
                <div className="text-center">
                  <Camera className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Camera not available</p>
                  <p className="text-sm opacity-75">Please check permissions</p>
                </div>
              </div>
            )}
          </div>

          {/* Hidden canvas for photo capture */}
          <canvas ref={canvasRef} className="hidden" />

          {/* Usage Tips */}
          <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
            <p><strong>Tips:</strong></p>
            <p>• Use filters to add creative effects to your photos and videos</p>
            <p>• Switch between front and back camera with the rotate button</p>
            <p>• Photos and videos will be inserted directly into your document</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}