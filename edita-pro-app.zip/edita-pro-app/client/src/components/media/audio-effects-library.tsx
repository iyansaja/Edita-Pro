import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Volume2,
  Play,
  Pause,
  Download,
  Search,
  Waveform,
  Zap,
  Bell,
  Car,
  Droplets,
  Wind,
  Bird,
  Music2,
  Mic,
  Speaker,
  Headphones,
  Radio,
  Archive,
  Star,
  TrendingUp,
  Clock,
  Users
} from 'lucide-react';

interface AudioEffect {
  id: string;
  name: string;
  category: string;
  duration: number;
  size: string;
  bpm?: number;
  key?: string;
  mood: string;
  description: string;
  tags: string[];
  downloads: number;
  popularity: number;
  license: 'free' | 'premium';
  waveform: string;
  preview_url: string;
}

interface AudioEffectsLibraryProps {
  onEffectSelect?: (effect: AudioEffect) => void;
  onEffectDownload?: (effect: AudioEffect) => void;
}

export function AudioEffectsLibrary({ onEffectSelect, onEffectDownload }: AudioEffectsLibraryProps) {
  const [audioEffects] = useState<AudioEffect[]>([
    // Interface Sounds
    {
      id: 'ui_001',
      name: 'Success Notification',
      category: 'Interface',
      duration: 1.2,
      size: '45 KB',
      mood: 'Positive',
      description: 'Clean success notification sound for UI interactions',
      tags: ['notification', 'success', 'ui', 'positive', 'clean'],
      downloads: 234567,
      popularity: 95,
      license: 'free',
      waveform: 'short-bell',
      preview_url: '/sfx/success-notification.wav'
    },
    {
      id: 'ui_002',
      name: 'Button Click',
      category: 'Interface',
      duration: 0.3,
      size: '12 KB',
      mood: 'Neutral',
      description: 'Subtle button click sound effect',
      tags: ['click', 'button', 'ui', 'interface', 'tap'],
      downloads: 456789,
      popularity: 92,
      license: 'free',
      waveform: 'click-pop',
      preview_url: '/sfx/button-click.wav'
    },
    
    // Nature Sounds
    {
      id: 'nature_001',
      name: 'Forest Birds',
      category: 'Nature',
      duration: 30,
      size: '2.1 MB',
      mood: 'Peaceful',
      description: 'Peaceful forest birds chirping ambience',
      tags: ['birds', 'forest', 'nature', 'peaceful', 'ambient'],
      downloads: 123456,
      popularity: 89,
      license: 'free',
      waveform: 'ambient-long',
      preview_url: '/sfx/forest-birds.wav'
    },
    {
      id: 'nature_002',
      name: 'Ocean Waves',
      category: 'Nature',
      duration: 45,
      size: '3.2 MB',
      mood: 'Relaxing',
      description: 'Gentle ocean waves for background ambience',
      tags: ['ocean', 'waves', 'water', 'relaxing', 'ambient'],
      downloads: 198765,
      popularity: 94,
      license: 'free',
      waveform: 'wave-pattern',
      preview_url: '/sfx/ocean-waves.wav'
    },
    
    // Transition Effects
    {
      id: 'transition_001',
      name: 'Whoosh Swipe',
      category: 'Transition',
      duration: 0.8,
      size: '78 KB',
      mood: 'Dynamic',
      description: 'Fast whoosh sound for quick transitions',
      tags: ['whoosh', 'swipe', 'transition', 'fast', 'dynamic'],
      downloads: 345678,
      popularity: 97,
      license: 'free',
      waveform: 'whoosh-curve',
      preview_url: '/sfx/whoosh-swipe.wav'
    },
    {
      id: 'transition_002',
      name: 'Cinematic Rise',
      category: 'Transition',
      duration: 3.5,
      size: '245 KB',
      mood: 'Epic',
      description: 'Dramatic cinematic rise for build-ups',
      tags: ['cinematic', 'rise', 'buildup', 'dramatic', 'epic'],
      downloads: 287654,
      popularity: 91,
      license: 'premium',
      waveform: 'rise-pattern',
      preview_url: '/sfx/cinematic-rise.wav'
    },
    
    // Impact Sounds
    {
      id: 'impact_001',
      name: 'Heavy Bass Drop',
      category: 'Impact',
      duration: 2.1,
      size: '156 KB',
      bpm: 120,
      mood: 'Powerful',
      description: 'Heavy bass drop for dramatic moments',
      tags: ['bass', 'drop', 'impact', 'heavy', 'dramatic'],
      downloads: 567890,
      popularity: 96,
      license: 'free',
      waveform: 'bass-drop',
      preview_url: '/sfx/bass-drop.wav'
    },
    
    // Musical Elements
    {
      id: 'music_001',
      name: 'Piano Chord Progression',
      category: 'Musical',
      duration: 8.0,
      size: '567 KB',
      bpm: 80,
      key: 'C Major',
      mood: 'Emotional',
      description: 'Beautiful piano chord progression in C Major',
      tags: ['piano', 'chords', 'emotional', 'musical', 'progression'],
      downloads: 156789,
      popularity: 88,
      license: 'premium',
      waveform: 'piano-chords',
      preview_url: '/sfx/piano-progression.wav'
    }
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [playingEffect, setPlayingEffect] = useState<string>('');
  const [sortBy, setSortBy] = useState<'popularity' | 'downloads' | 'duration'>('popularity');

  const categories = ['All', 'Interface', 'Nature', 'Transition', 'Impact', 'Musical'];

  const filteredEffects = audioEffects
    .filter(effect => {
      const categoryMatch = selectedCategory === 'all' || effect.category.toLowerCase() === selectedCategory.toLowerCase();
      const searchMatch = searchQuery === '' || 
        effect.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        effect.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      return categoryMatch && searchMatch;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'popularity': return b.popularity - a.popularity;
        case 'downloads': return b.downloads - a.downloads;
        case 'duration': return a.duration - b.duration;
        default: return 0;
      }
    });

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const formatDuration = (seconds: number): string => {
    if (seconds < 60) return `${seconds.toFixed(1)}s`;
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toFixed(0).padStart(2, '0')}`;
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'interface': return Bell;
      case 'nature': return Bird;
      case 'transition': return Zap;
      case 'impact': return Speaker;
      case 'musical': return Music2;
      default: return Volume2;
    }
  };

  const handlePlayEffect = (effectId: string) => {
    if (playingEffect === effectId) {
      setPlayingEffect('');
    } else {
      setPlayingEffect(effectId);
      // In real implementation, would play actual audio
      setTimeout(() => setPlayingEffect(''), 3000); // Auto-stop after 3s for demo
    }
  };

  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-green-900/80 to-blue-900/80 border border-green-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Headphones className="h-6 w-6 text-green-400" />
            Audio Effects Library
            <Badge className="bg-gradient-to-r from-green-500 to-blue-500 text-white border-0 ml-auto">
              <Volume2 className="h-3 w-3 mr-1" />
              {audioEffects.length} Effects
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Search & Filters */}
      <Card className="bg-slate-800/50 border-purple-500/30">
        <CardContent className="p-4 space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search sound effects by name, category, or mood..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400"
            />
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
              >
                {categories.map(category => (
                  <option key={category} value={category.toLowerCase()}>{category}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Sort By</label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'popularity' | 'downloads' | 'duration')}
                className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
              >
                <option value="popularity">Most Popular</option>
                <option value="downloads">Most Downloaded</option>
                <option value="duration">Shortest First</option>
              </select>
            </div>

            <div className="flex items-end">
              <Button className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600">
                <Archive className="h-4 w-4 mr-2" />
                Browse All Categories
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Effects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredEffects.map((effect) => {
          const CategoryIcon = getCategoryIcon(effect.category);
          
          return (
            <Card key={effect.id} className="bg-slate-800/50 border-green-500/30 hover:bg-slate-800/70 transition-colors">
              <CardContent className="p-4 space-y-4">
                {/* Header */}
                <div className="flex items-start gap-3">
                  <div className="p-3 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg">
                    <CategoryIcon className="h-5 w-5 text-white" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium text-white">{effect.name}</h3>
                      {effect.license === 'premium' && (
                        <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                          Premium
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-400">{effect.description}</p>
                  </div>
                </div>

                {/* Waveform Visualization */}
                <div className="h-12 bg-slate-700/50 rounded-lg flex items-center justify-center">
                  <Waveform className="h-6 w-6 text-green-400" />
                  <span className="ml-2 text-xs text-gray-400">Waveform Preview</span>
                </div>

                {/* Details */}
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="space-y-1">
                    <div className="text-gray-400">Duration</div>
                    <div className="text-white font-medium">{formatDuration(effect.duration)}</div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-gray-400">Size</div>
                    <div className="text-white font-medium">{effect.size}</div>
                  </div>
                  
                  {effect.bpm && (
                    <div className="space-y-1">
                      <div className="text-gray-400">BPM</div>
                      <div className="text-white font-medium">{effect.bpm}</div>
                    </div>
                  )}
                  
                  {effect.key && (
                    <div className="space-y-1">
                      <div className="text-gray-400">Key</div>
                      <div className="text-white font-medium">{effect.key}</div>
                    </div>
                  )}
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1">
                  {effect.tags.slice(0, 3).map((tag, index) => (
                    <Badge
                      key={index}
                      className="bg-purple-500/20 text-purple-300 border-purple-500/30 text-xs"
                    >
                      {tag}
                    </Badge>
                  ))}
                  {effect.tags.length > 3 && (
                    <Badge className="bg-gray-500/20 text-gray-300 border-gray-500/30 text-xs">
                      +{effect.tags.length - 3}
                    </Badge>
                  )}
                </div>

                {/* Stats */}
                <div className="flex items-center gap-4 text-xs text-gray-500">
                  <div className="flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    <span>{formatNumber(effect.downloads)}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    <span>{effect.popularity}%</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="h-3 w-3" />
                    <span>{effect.mood}</span>
                  </div>
                </div>

                {/* Controls */}
                <div className="flex gap-2">
                  <Button
                    onClick={() => handlePlayEffect(effect.id)}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    {playingEffect === effect.id ? (
                      <>
                        <Pause className="h-4 w-4 mr-2" />
                        Playing...
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Preview
                      </>
                    )}
                  </Button>
                  
                  <Button
                    onClick={() => onEffectSelect?.(effect)}
                    className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                  >
                    Use Effect
                  </Button>
                  
                  <Button
                    onClick={() => onEffectDownload?.(effect)}
                    variant="outline"
                    className="border-gray-500 text-gray-300"
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Library Stats */}
      <Card className="bg-slate-800/50 border-blue-500/30">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="space-y-1">
              <div className="text-2xl font-bold text-green-400">{audioEffects.filter(e => e.license === 'free').length}</div>
              <div className="text-sm text-gray-400">Free Effects</div>
            </div>
            
            <div className="space-y-1">
              <div className="text-2xl font-bold text-yellow-400">{audioEffects.filter(e => e.license === 'premium').length}</div>
              <div className="text-sm text-gray-400">Premium Effects</div>
            </div>
            
            <div className="space-y-1">
              <div className="text-2xl font-bold text-blue-400">{categories.length - 1}</div>
              <div className="text-sm text-gray-400">Categories</div>
            </div>
            
            <div className="space-y-1">
              <div className="text-2xl font-bold text-purple-400">
                {formatNumber(audioEffects.reduce((sum, effect) => sum + effect.downloads, 0))}
              </div>
              <div className="text-sm text-gray-400">Total Downloads</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}