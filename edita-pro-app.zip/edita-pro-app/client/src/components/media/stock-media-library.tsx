import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Image as ImageIcon,
  Video,
  Music,
  Volume2,
  Download,
  Search,
  Filter,
  Play,
  Pause,
  Heart,
  Star,
  Zap,
  Crown,
  Grid3X3,
  List,
  Eye,
  Clock,
  Users,
  TrendingUp,
  Camera,
  Headphones,
  FileAudio,
  Palette
} from 'lucide-react';

interface MediaAsset {
  id: string;
  title: string;
  type: 'photo' | 'video' | 'audio' | 'sound_effect';
  url: string;
  thumbnail: string;
  duration?: number;
  size: string;
  category: string;
  tags: string[];
  license: 'free' | 'premium' | 'royalty_free';
  downloads: number;
  popularity: number;
  resolution?: string;
  author: string;
  description: string;
}

interface StockMediaLibraryProps {
  onAssetSelect?: (asset: MediaAsset) => void;
  onAssetDownload?: (asset: MediaAsset) => void;
  selectedType?: 'all' | 'photo' | 'video' | 'audio' | 'sound_effect';
}

export function StockMediaLibrary({ onAssetSelect, onAssetDownload, selectedType = 'all' }: StockMediaLibraryProps) {
  const [mediaAssets] = useState<MediaAsset[]>([
    // Stock Photos
    {
      id: 'photo_001',
      title: 'Morning Coffee Aesthetic',
      type: 'photo',
      url: '/stock/photos/morning-coffee.jpg',
      thumbnail: '/stock/thumbnails/morning-coffee-thumb.jpg',
      size: '4K (3840×2160)',
      category: 'Lifestyle',
      tags: ['coffee', 'morning', 'aesthetic', 'lifestyle', 'cozy'],
      license: 'free',
      downloads: 45230,
      popularity: 95,
      resolution: '4K',
      author: 'Creative Commons',
      description: 'Beautiful morning coffee setup with natural lighting'
    },
    {
      id: 'photo_002',
      title: 'Urban Sunset Cityscape',
      type: 'photo',
      url: '/stock/photos/urban-sunset.jpg',
      thumbnail: '/stock/thumbnails/urban-sunset-thumb.jpg',
      size: '4K (3840×2160)',
      category: 'Urban',
      tags: ['city', 'sunset', 'urban', 'skyline', 'golden hour'],
      license: 'royalty_free',
      downloads: 38950,
      popularity: 92,
      resolution: '4K',
      author: 'Stock Collective',
      description: 'Stunning urban skyline during golden hour'
    },
    {
      id: 'photo_003',
      title: 'Minimalist Workspace',
      type: 'photo',
      url: '/stock/photos/workspace.jpg',
      thumbnail: '/stock/thumbnails/workspace-thumb.jpg',
      size: '4K (3840×2160)',
      category: 'Business',
      tags: ['workspace', 'minimal', 'productivity', 'desk', 'clean'],
      license: 'free',
      downloads: 52100,
      popularity: 89,
      resolution: '4K',
      author: 'Open Source Photos',
      description: 'Clean, minimalist workspace setup'
    },
    
    // Stock Videos
    {
      id: 'video_001',
      title: 'Ocean Waves Motion',
      type: 'video',
      url: '/stock/videos/ocean-waves.mp4',
      thumbnail: '/stock/thumbnails/ocean-waves-thumb.jpg',
      duration: 30,
      size: '1080p',
      category: 'Nature',
      tags: ['ocean', 'waves', 'water', 'nature', 'relaxing'],
      license: 'free',
      downloads: 67890,
      popularity: 96,
      resolution: '1080p',
      author: 'Nature Stock',
      description: 'Peaceful ocean waves in slow motion'
    },
    {
      id: 'video_002',
      title: 'City Traffic Timelapse',
      type: 'video',
      url: '/stock/videos/city-traffic.mp4',
      thumbnail: '/stock/thumbnails/city-traffic-thumb.jpg',
      duration: 15,
      size: '4K',
      category: 'Urban',
      tags: ['city', 'traffic', 'timelapse', 'urban', 'busy'],
      license: 'royalty_free',
      downloads: 43200,
      popularity: 88,
      resolution: '4K',
      author: 'Urban Media',
      description: 'Fast-paced city traffic in timelapse'
    },
    
    // Background Music
    {
      id: 'music_001',
      title: 'Upbeat Corporate',
      type: 'audio',
      url: '/stock/audio/upbeat-corporate.mp3',
      thumbnail: '/stock/thumbnails/music-wave.jpg',
      duration: 120,
      size: '5.2 MB',
      category: 'Corporate',
      tags: ['upbeat', 'corporate', 'motivational', 'positive', 'business'],
      license: 'royalty_free',
      downloads: 89450,
      popularity: 94,
      author: 'Audio Pro',
      description: 'Energetic corporate background music'
    },
    {
      id: 'music_002',
      title: 'Chill LoFi Beats',
      type: 'audio',
      url: '/stock/audio/lofi-beats.mp3',
      thumbnail: '/stock/thumbnails/lofi-wave.jpg',
      duration: 180,
      size: '7.8 MB',
      category: 'LoFi',
      tags: ['lofi', 'chill', 'relaxing', 'study', 'ambient'],
      license: 'free',
      downloads: 156780,
      popularity: 97,
      author: 'LoFi Collective',
      description: 'Smooth and relaxing LoFi beats'
    },
    
    // Sound Effects
    {
      id: 'sfx_001',
      title: 'Notification Bell',
      type: 'sound_effect',
      url: '/stock/sfx/notification-bell.wav',
      thumbnail: '/stock/thumbnails/sound-wave.jpg',
      duration: 2,
      size: '340 KB',
      category: 'Interface',
      tags: ['notification', 'bell', 'alert', 'ui', 'interface'],
      license: 'free',
      downloads: 234560,
      popularity: 91,
      author: 'SFX Library',
      description: 'Clean notification bell sound'
    },
    {
      id: 'sfx_002',
      title: 'Whoosh Transition',
      type: 'sound_effect',
      url: '/stock/sfx/whoosh-transition.wav',
      thumbnail: '/stock/thumbnails/whoosh-wave.jpg',
      duration: 1.5,
      size: '256 KB',
      category: 'Transition',
      tags: ['whoosh', 'transition', 'swipe', 'movement', 'dynamic'],
      license: 'free',
      downloads: 187320,
      popularity: 93,
      author: 'Transition FX',
      description: 'Dynamic whoosh transition effect'
    }
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [playingAudio, setPlayingAudio] = useState<string>('');
  const [sortBy, setSortBy] = useState<'popularity' | 'downloads' | 'newest'>('popularity');

  const categories = ['All', 'Lifestyle', 'Urban', 'Business', 'Nature', 'Corporate', 'LoFi', 'Interface', 'Transition'];
  const mediaTypes = [
    { id: 'all', name: 'All Media', icon: Grid3X3 },
    { id: 'photo', name: 'Photos', icon: ImageIcon },
    { id: 'video', name: 'Videos', icon: Video },
    { id: 'audio', name: 'Music', icon: Music },
    { id: 'sound_effect', name: 'Sound FX', icon: Volume2 }
  ];

  const filteredAssets = mediaAssets
    .filter(asset => {
      const typeMatch = selectedType === 'all' || asset.type === selectedType;
      const categoryMatch = selectedCategory === 'all' || asset.category.toLowerCase() === selectedCategory.toLowerCase();
      const searchMatch = searchQuery === '' || 
        asset.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        asset.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      return typeMatch && categoryMatch && searchMatch;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'popularity': return b.popularity - a.popularity;
        case 'downloads': return b.downloads - a.downloads;
        case 'newest': return a.id.localeCompare(b.id);
        default: return 0;
      }
    });

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'photo': return ImageIcon;
      case 'video': return Video;
      case 'audio': return Music;
      case 'sound_effect': return Volume2;
      default: return ImageIcon;
    }
  };

  const getLicenseColor = (license: string) => {
    switch (license) {
      case 'free': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'premium': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'royalty_free': return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const handlePlayAudio = (assetId: string) => {
    if (playingAudio === assetId) {
      setPlayingAudio('');
    } else {
      setPlayingAudio(assetId);
    }
  };

  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Palette className="h-6 w-6 text-indigo-400" />
            Stock Media Library
            <Badge className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-0 ml-auto">
              <Star className="h-3 w-3 mr-1" />
              Free & Premium
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Filters & Search */}
      <Card className="bg-slate-800/50 border-blue-500/30">
        <CardContent className="p-4 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search photos, videos, music, sound effects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400"
            />
          </div>

          {/* Type Filters */}
          <div className="grid grid-cols-5 gap-2">
            {mediaTypes.map((type) => {
              const IconComponent = type.icon;
              return (
                <Button
                  key={type.id}
                  onClick={() => {/* Type selection handled by parent */}}
                  className={`p-3 h-auto flex flex-col gap-2 ${
                    type.id === selectedType 
                      ? 'bg-indigo-600 hover:bg-indigo-700' 
                      : 'bg-slate-700 hover:bg-slate-600'
                  }`}
                >
                  <IconComponent className="h-5 w-5" />
                  <span className="text-xs">{type.name}</span>
                </Button>
              );
            })}
          </div>

          {/* Category & Sort */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
              >
                {categories.map(category => (
                  <option key={category} value={category.toLowerCase()}>{category}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Sort By</label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'popularity' | 'downloads' | 'newest')}
                className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white text-sm"
              >
                <option value="popularity">Most Popular</option>
                <option value="downloads">Most Downloaded</option>
                <option value="newest">Newest</option>
              </select>
            </div>

            <div className="flex items-end gap-2">
              <Button
                onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
                variant="outline"
                className="border-gray-500 text-gray-300"
              >
                {viewMode === 'grid' ? <List className="h-4 w-4" /> : <Grid3X3 className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Media Grid */}
      <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4' : 'space-y-3'}>
        {filteredAssets.map((asset) => {
          const TypeIcon = getTypeIcon(asset.type);
          
          if (viewMode === 'list') {
            return (
              <Card key={asset.id} className="bg-slate-800/50 border-purple-500/30 hover:bg-slate-800/70 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="relative w-20 h-20 rounded-lg overflow-hidden bg-slate-700 flex-shrink-0">
                      <img 
                        src={asset.thumbnail} 
                        alt={asset.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                          target.parentElement!.innerHTML = `<div class="w-full h-full flex items-center justify-center"><${TypeIcon.name} class="h-8 w-8 text-gray-400" /></div>`;
                        }}
                      />
                      <div className="absolute top-2 left-2">
                        <TypeIcon className="h-4 w-4 text-white bg-black/50 rounded p-0.5" />
                      </div>
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-medium text-white">{asset.title}</h3>
                        <Badge className={getLicenseColor(asset.license)}>
                          {asset.license === 'free' ? 'Free' : asset.license === 'premium' ? 'Premium' : 'Royalty Free'}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-400 mb-2">{asset.description}</p>
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <span>{asset.size}</span>
                        {asset.duration && <span>{formatDuration(asset.duration)}</span>}
                        <span>{formatNumber(asset.downloads)} downloads</span>
                        <span>{asset.popularity}% popular</span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      {(asset.type === 'audio' || asset.type === 'sound_effect') && (
                        <Button
                          onClick={() => handlePlayAudio(asset.id)}
                          size="sm"
                          className="bg-green-600 hover:bg-green-700"
                        >
                          {playingAudio === asset.id ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                      )}
                      <Button
                        onClick={() => onAssetSelect?.(asset)}
                        size="sm"
                        className="bg-indigo-600 hover:bg-indigo-700"
                      >
                        Use
                      </Button>
                      <Button
                        onClick={() => onAssetDownload?.(asset)}
                        size="sm"
                        variant="outline"
                        className="border-gray-500 text-gray-300"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          }

          return (
            <Card key={asset.id} className="bg-slate-800/50 border-purple-500/30 hover:bg-slate-800/70 transition-colors group">
              <CardContent className="p-0">
                <div className="relative aspect-video bg-slate-700 rounded-t-lg overflow-hidden">
                  <img 
                    src={asset.thumbnail} 
                    alt={asset.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      target.parentElement!.innerHTML = `<div class="w-full h-full flex items-center justify-center bg-slate-700"><${TypeIcon.name} class="h-12 w-12 text-gray-400" /></div>`;
                    }}
                  />
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <div className="flex gap-2">
                      {(asset.type === 'audio' || asset.type === 'sound_effect') && (
                        <Button
                          onClick={() => handlePlayAudio(asset.id)}
                          size="sm"
                          className="bg-green-600 hover:bg-green-700"
                        >
                          {playingAudio === asset.id ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                      )}
                      <Button
                        onClick={() => onAssetSelect?.(asset)}
                        size="sm"
                        className="bg-indigo-600 hover:bg-indigo-700"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Type Badge */}
                  <div className="absolute top-2 left-2">
                    <Badge className="bg-black/70 text-white border-0">
                      <TypeIcon className="h-3 w-3 mr-1" />
                      {asset.type}
                    </Badge>
                  </div>

                  {/* License Badge */}
                  <div className="absolute top-2 right-2">
                    <Badge className={getLicenseColor(asset.license)}>
                      {asset.license === 'free' ? 'Free' : asset.license === 'premium' ? <Crown className="h-3 w-3" /> : 'RF'}
                    </Badge>
                  </div>

                  {/* Duration for media */}
                  {asset.duration && (
                    <div className="absolute bottom-2 right-2">
                      <Badge className="bg-black/70 text-white border-0 text-xs">
                        <Clock className="h-3 w-3 mr-1" />
                        {formatDuration(asset.duration)}
                      </Badge>
                    </div>
                  )}
                </div>

                <div className="p-4">
                  <h3 className="font-medium text-white mb-1 line-clamp-1">{asset.title}</h3>
                  <p className="text-sm text-gray-400 mb-2 line-clamp-2">{asset.description}</p>
                  
                  <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                    <span>{asset.size}</span>
                    <div className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      <span>{formatNumber(asset.downloads)}</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={() => onAssetSelect?.(asset)}
                      className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                    >
                      Use Asset
                    </Button>
                    <Button
                      onClick={() => onAssetDownload?.(asset)}
                      variant="outline"
                      className="border-gray-500 text-gray-300"
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Results Info */}
      <Card className="bg-slate-800/50 border-gray-500/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between text-sm text-gray-300">
            <span>Showing {filteredAssets.length} assets</span>
            <div className="flex items-center gap-4">
              <span>Free: {filteredAssets.filter(a => a.license === 'free').length}</span>
              <span>Premium: {filteredAssets.filter(a => a.license === 'premium').length}</span>
              <span>Royalty Free: {filteredAssets.filter(a => a.license === 'royalty_free').length}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}