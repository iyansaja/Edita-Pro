import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Image, Film, Music, Upload, X } from "lucide-react";

interface MediaItem {
  id: string;
  url: string;
  type: 'photo' | 'video' | 'audio';
  name: string;
  createdAt: Date;
}

interface MediaGalleryProps {
  open: boolean;
  onClose: () => void;
  onInsertMedia: (mediaUrl: string, type: string) => void;
  capturedMedia: MediaItem[];
}

export function MediaGallery({ open, onClose, onInsertMedia, capturedMedia }: MediaGalleryProps) {
  const [selectedTab, setSelectedTab] = useState("photos");

  const handleInsert = (item: MediaItem) => {
    onInsertMedia(item.url, item.type);
    onClose();
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString() + " " + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderMediaItem = (item: MediaItem) => (
    <div key={item.id} className="relative group">
      <div className="aspect-square bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
        {item.type === 'photo' && (
          <img
            src={item.url}
            alt={item.name}
            className="w-full h-full object-cover"
          />
        )}
        {item.type === 'video' && (
          <video
            src={item.url}
            className="w-full h-full object-cover"
            controls
            muted
          />
        )}
        {item.type === 'audio' && (
          <div className="w-full h-full flex items-center justify-center">
            <Music className="h-12 w-12 text-gray-400" />
          </div>
        )}
      </div>
      
      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-opacity rounded-lg flex items-center justify-center">
        <Button
          onClick={() => handleInsert(item)}
          className="opacity-0 group-hover:opacity-100 transition-opacity"
          size="sm"
        >
          Insert
        </Button>
      </div>
      
      <div className="mt-2">
        <p className="text-xs text-gray-600 dark:text-gray-400 truncate">
          {item.name}
        </p>
        <p className="text-xs text-gray-500 dark:text-gray-500">
          {formatDate(item.createdAt)}
        </p>
      </div>
    </div>
  );

  const photoItems = capturedMedia.filter(item => item.type === 'photo');
  const videoItems = capturedMedia.filter(item => item.type === 'video');
  const audioItems = capturedMedia.filter(item => item.type === 'audio');

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl w-full h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Image className="h-5 w-5" />
            <span>Media Gallery</span>
          </DialogTitle>
        </DialogHeader>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="photos" className="flex items-center space-x-2">
              <Image className="h-4 w-4" />
              <span>Photos ({photoItems.length})</span>
            </TabsTrigger>
            <TabsTrigger value="videos" className="flex items-center space-x-2">
              <Film className="h-4 w-4" />
              <span>Videos ({videoItems.length})</span>
            </TabsTrigger>
            <TabsTrigger value="audio" className="flex items-center space-x-2">
              <Music className="h-4 w-4" />
              <span>Audio ({audioItems.length})</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="photos" className="flex-1 overflow-auto">
            {photoItems.length > 0 ? (
              <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 p-4">
                {photoItems.map(renderMediaItem)}
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-center">
                <div>
                  <Image className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600 dark:text-gray-400">No photos captured yet</p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">
                    Use the camera to take your first photo
                  </p>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="videos" className="flex-1 overflow-auto">
            {videoItems.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4">
                {videoItems.map(renderMediaItem)}
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-center">
                <div>
                  <Film className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600 dark:text-gray-400">No videos recorded yet</p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">
                    Use the camera to record your first video
                  </p>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="audio" className="flex-1 overflow-auto">
            {audioItems.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
                {audioItems.map(renderMediaItem)}
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center text-center">
                <div>
                  <Music className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600 dark:text-gray-400">No audio recorded yet</p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">
                    Audio recording feature coming soon
                  </p>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>

        <div className="border-t pt-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Total: {capturedMedia.length} media files
            </p>
            <Button onClick={onClose} variant="outline">
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}