import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Save,
  Download,
  FileDown,
  Undo,
  Redo,
  Bold,
  Italic,
  Underline,
  Strikethrough,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Search,
  Replace,
  List,
  Camera,
  Image,
  Video,
  Music2,
} from "lucide-react";
import type { Document } from "@shared/schema";

interface ToolbarProps {
  activeDocument?: Document;
  onSave: () => void;
  onExportPDF: () => void;
  onToggleSearch: () => void;
  onToggleLineNumbers: () => void;
  lineNumbersVisible: boolean;
  onUpdateSettings: (id: number, settings: { fontSize?: number; fontFamily?: string }) => void;
  onOpenCamera: () => void;
  onOpenMediaGallery: () => void;
  onOpenVideoEditor: () => void;
  onOpenAudioEditor: () => void;
}

export function Toolbar({
  activeDocument,
  onSave,
  onExportPDF,
  onToggleSearch,
  onToggleLineNumbers,
  lineNumbersVisible,
  onUpdateSettings,
  onOpenCamera,
  onOpenMediaGallery,
  onOpenVideoEditor,
  onOpenAudioEditor,
}: ToolbarProps) {
  const fontSizes = [12, 14, 16, 18, 20, 24, 28, 32];
  const fontFamilies = [
    { value: "Inter", label: "Inter" },
    { value: "Arial", label: "Arial" },
    { value: "Georgia", label: "Georgia" },
    { value: "Times New Roman", label: "Times New Roman" },
    { value: "Courier New", label: "Courier New" },
    { value: "Helvetica", label: "Helvetica" },
  ];

  const handleFontSizeChange = (value: string) => {
    if (activeDocument) {
      onUpdateSettings(activeDocument.id, { fontSize: parseInt(value) });
    }
  };

  const handleFontFamilyChange = (value: string) => {
    if (activeDocument) {
      onUpdateSettings(activeDocument.id, { fontFamily: value });
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-3">
      <div className="flex items-center space-x-3 overflow-x-auto">
        {/* File Operations */}
        <div className="flex items-center space-x-1">
          <Button
            onClick={onSave}
            variant="ghost"
            size="sm"
            title="Save (Ctrl+S)"
            disabled={!activeDocument}
          >
            <Save className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            title="Save As"
            disabled={!activeDocument}
          >
            <Download className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
          <Button
            onClick={onExportPDF}
            variant="ghost"
            size="sm"
            title="Export PDF"
            disabled={!activeDocument}
          >
            <FileDown className="h-4 w-4 text-red-600" />
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Undo/Redo */}
        <div className="flex items-center space-x-1">
          <Button variant="ghost" size="sm" title="Undo (Ctrl+Z)" disabled={!activeDocument}>
            <Undo className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
          <Button variant="ghost" size="sm" title="Redo (Ctrl+Y)" disabled={!activeDocument}>
            <Redo className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Font Controls */}
        <div className="flex items-center space-x-2">
          <Select
            value={activeDocument?.fontFamily || "Inter"}
            onValueChange={handleFontFamilyChange}
            disabled={!activeDocument}
          >
            <SelectTrigger className="w-32 h-8">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {fontFamilies.map((font) => (
                <SelectItem key={font.value} value={font.value}>
                  {font.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select
            value={activeDocument?.fontSize?.toString() || "16"}
            onValueChange={handleFontSizeChange}
            disabled={!activeDocument}
          >
            <SelectTrigger className="w-16 h-8">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {fontSizes.map((size) => (
                <SelectItem key={size} value={size.toString()}>
                  {size}px
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Text Formatting */}
        <div className="flex items-center space-x-1">
          <Button variant="ghost" size="sm" title="Bold (Ctrl+B)" disabled={!activeDocument}>
            <Bold className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
          <Button variant="ghost" size="sm" title="Italic (Ctrl+I)" disabled={!activeDocument}>
            <Italic className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
          <Button variant="ghost" size="sm" title="Underline (Ctrl+U)" disabled={!activeDocument}>
            <Underline className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
          <Button variant="ghost" size="sm" title="Strikethrough" disabled={!activeDocument}>
            <Strikethrough className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Text Alignment */}
        <div className="flex items-center space-x-1">
          <Button variant="ghost" size="sm" title="Align Left" disabled={!activeDocument}>
            <AlignLeft className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
          <Button variant="ghost" size="sm" title="Align Center" disabled={!activeDocument}>
            <AlignCenter className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
          <Button variant="ghost" size="sm" title="Align Right" disabled={!activeDocument}>
            <AlignRight className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
          <Button variant="ghost" size="sm" title="Justify" disabled={!activeDocument}>
            <AlignJustify className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Search */}
        <div className="flex items-center space-x-1">
          <Button
            onClick={onToggleSearch}
            variant="ghost"
            size="sm"
            title="Find (Ctrl+F)"
            disabled={!activeDocument}
          >
            <Search className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
          <Button variant="ghost" size="sm" title="Replace (Ctrl+H)" disabled={!activeDocument}>
            <Replace className="h-4 w-4 text-gray-600 dark:text-gray-400" />
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Media Tools */}
        <div className="flex items-center space-x-1">
          <Button
            onClick={onOpenCamera}
            variant="ghost"
            size="sm"
            title="Open Camera"
            disabled={!activeDocument}
          >
            <Camera className="h-4 w-4 text-blue-600" />
          </Button>
          <Button
            onClick={onOpenMediaGallery}
            variant="ghost"
            size="sm"
            title="Media Gallery"
            disabled={!activeDocument}
          >
            <Image className="h-4 w-4 text-green-600" />
          </Button>
          <Button
            onClick={onOpenVideoEditor}
            variant="ghost"
            size="sm"
            title="Video Editor"
            disabled={!activeDocument}
          >
            <Video className="h-4 w-4 text-purple-600" />
          </Button>
          <Button
            onClick={onOpenAudioEditor}
            variant="ghost"
            size="sm"
            title="Audio & Musik Editor"
            disabled={!activeDocument}
          >
            <Music2 className="h-4 w-4 text-orange-600" />
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* View Options */}
        <div className="flex items-center space-x-1">
          <Button
            onClick={onToggleLineNumbers}
            variant={lineNumbersVisible ? "default" : "ghost"}
            size="sm"
            title="Toggle Line Numbers"
            disabled={!activeDocument}
          >
            <List className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
