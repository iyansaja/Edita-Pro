import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/theme-provider";
import { FileEdit, Moon, Sun, Menu } from "lucide-react";
import type { Document } from "@shared/schema";

interface AppHeaderProps {
  activeDocument?: Document;
  onToggleSidebar: () => void;
}

export function AppHeader({ activeDocument, onToggleSidebar }: AppHeaderProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-2 flex items-center justify-between shadow-sm">
      <div className="flex items-center space-x-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleSidebar}
          className="lg:hidden"
        >
          <Menu className="h-4 w-4" />
        </Button>
        
        <div className="flex items-center space-x-2">
          <FileEdit className="text-primary text-xl" />
          <h1 className="text-lg font-semibold text-gray-900 dark:text-white">
            Edita Pro
          </h1>
        </div>
        
        <div className="hidden md:flex items-center space-x-1 text-sm text-gray-600 dark:text-gray-400">
          <span>{activeDocument?.name || "No document"}</span>
          <span className="text-gray-400">•</span>
          <span className={`${activeDocument?.saved ? 'text-green-600 dark:text-green-400' : 'text-amber-600 dark:text-amber-400'}`}>
            {activeDocument?.saved ? "Saved" : "Unsaved"}
          </span>
        </div>
      </div>
      
      <div className="flex items-center space-x-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleTheme}
          className="p-2"
        >
          {theme === "light" ? (
            <Moon className="h-4 w-4 text-gray-600" />
          ) : (
            <Sun className="h-4 w-4 text-yellow-400" />
          )}
        </Button>
        
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-sm font-medium">
            EP
          </div>
        </div>
      </div>
    </header>
  );
}
