import { Button } from "@/components/ui/button";
import { FilePlus, FolderOpen, FileText } from "lucide-react";
import type { Document } from "@shared/schema";

interface SidebarProps {
  recentDocuments: Document[];
  onNewDocument: () => void;
  onOpenDocument: (document: Document) => void;
}

export function Sidebar({ recentDocuments, onNewDocument, onOpenDocument }: SidebarProps) {
  const formatDate = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    if (diffInHours < 48) return "Yesterday";
    return `${Math.floor(diffInHours / 24)} days ago`;
  };

  return (
    <aside className="w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col h-full">
      {/* File Operations */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="space-y-2">
          <Button
            onClick={onNewDocument}
            className="w-full justify-start space-x-2"
            variant="ghost"
          >
            <FilePlus className="h-4 w-4 text-primary" />
            <span>New Document</span>
          </Button>
          <Button
            className="w-full justify-start space-x-2"
            variant="ghost"
            onClick={() => {
              const input = document.createElement('input');
              input.type = 'file';
              input.accept = '.txt,.md';
              input.onchange = (e) => {
                const file = (e.target as HTMLInputElement).files?.[0];
                if (file) {
                  const reader = new FileReader();
                  reader.onload = () => {
                    // Handle file content
                    console.log('File loaded:', file.name, reader.result);
                  };
                  reader.readAsText(file);
                }
              };
              input.click();
            }}
          >
            <FolderOpen className="h-4 w-4 text-gray-600 dark:text-gray-400" />
            <span>Open</span>
          </Button>
        </div>
      </div>

      {/* Recent Files */}
      <div className="flex-1 p-4">
        <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
          Recent Files
        </h3>
        <div className="space-y-1">
          {recentDocuments.map((document) => (
            <button
              key={document.id}
              onClick={() => onOpenDocument(document)}
              className="w-full flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200 text-left"
            >
              <FileText className="h-4 w-4 text-gray-400 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm text-gray-900 dark:text-white truncate">
                  {document.name}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {formatDate(new Date(document.lastModified))}
                </p>
              </div>
            </button>
          ))}
          {recentDocuments.length === 0 && (
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-4">
              No recent files
            </p>
          )}
        </div>
      </div>
    </aside>
  );
}
