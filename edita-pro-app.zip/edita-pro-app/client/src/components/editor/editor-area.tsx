import { useEffect, useRef, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Type, 
  Bold, 
  Italic, 
  Underline, 
  AlignLeft, 
  AlignCenter, 
  AlignRight,
  List,
  Link,
  Image,
  Zap,
  Sparkles,
  Eye,
  Code,
  Save,
  Undo,
  Redo
} from "lucide-react";
import type { Document } from "@shared/schema";

interface EditorAreaProps {
  document?: Document;
  onContentChange: (id: number, content: string) => void;
  showLineNumbers: boolean;
}

export function EditorArea({ document, onContentChange, showLineNumbers }: EditorAreaProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [isTyping, setIsTyping] = useState(false);
  const [selectedText, setSelectedText] = useState('');

  useEffect(() => {
    if (document && textareaRef.current) {
      textareaRef.current.value = document.content;
      updateCounts(document.content);
    }
  }, [document?.id]);

  const updateCounts = (content: string) => {
    setWordCount(content.trim().split(/\s+/).filter(word => word.length > 0).length);
    setCharCount(content.length);
  };

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (document) {
      const content = e.target.value;
      onContentChange(document.id, content);
      updateCounts(content);
      setIsTyping(true);
      
      // Stop typing indicator after 1 second
      setTimeout(() => setIsTyping(false), 1000);
    }
  };

  const handleTextSelection = () => {
    if (textareaRef.current) {
      const start = textareaRef.current.selectionStart;
      const end = textareaRef.current.selectionEnd;
      const selected = textareaRef.current.value.substring(start, end);
      setSelectedText(selected);
    }
  };

  const insertFormatting = (prefix: string, suffix: string = '') => {
    if (textareaRef.current) {
      const textarea = textareaRef.current;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const selectedText = textarea.value.substring(start, end);
      
      const newText = textarea.value.substring(0, start) + 
                     prefix + selectedText + suffix + 
                     textarea.value.substring(end);
      
      textarea.value = newText;
      if (document) {
        onContentChange(document.id, newText);
        updateCounts(newText);
      }
      
      // Reset cursor position
      const newCursorPos = start + prefix.length + selectedText.length + suffix.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
      textarea.focus();
    }
  };

  if (!document) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900">
        <Card className="bg-slate-800/50 border-indigo-500/30 max-w-md mx-auto">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Type className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Start Creating</h3>
            <p className="text-gray-400 mb-4">
              Buat dokumen baru atau buka file yang sudah ada untuk mulai menulis
            </p>
            <Button className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600">
              <Sparkles className="h-4 w-4 mr-2" />
              Create New Document
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col relative bg-gradient-to-br from-slate-900 via-purple-900 to-indigo-900 overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Floating Geometric Shapes */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-48 h-48 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-full blur-xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-32 left-32 w-40 h-40 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 rounded-full blur-xl animate-pulse delay-2000"></div>
        
        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(139,92,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(139,92,246,0.03)_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        
        {/* Subtle Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-black/10"></div>
        
        {/* Floating Particles */}
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-indigo-400/30 rounded-full animate-ping"></div>
        <div className="absolute top-3/4 right-1/3 w-1 h-1 bg-purple-400/40 rounded-full animate-ping delay-500"></div>
        <div className="absolute top-1/2 left-3/4 w-1.5 h-1.5 bg-pink-400/30 rounded-full animate-ping delay-1000"></div>
      </div>

      {/* Modern Toolbar */}
      <div className="relative bg-slate-800/80 backdrop-blur-sm border-b border-indigo-500/30 p-4 z-10">
        <div className="flex items-center gap-2 flex-wrap">
          {/* Text Formatting */}
          <div className="flex items-center gap-1 bg-slate-700/50 rounded-lg p-1">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => insertFormatting('**', '**')}
              className="text-gray-300 hover:text-white hover:bg-indigo-500/20"
            >
              <Bold className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => insertFormatting('*', '*')}
              className="text-gray-300 hover:text-white hover:bg-indigo-500/20"
            >
              <Italic className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => insertFormatting('<u>', '</u>')}
              className="text-gray-300 hover:text-white hover:bg-indigo-500/20"
            >
              <Underline className="h-4 w-4" />
            </Button>
          </div>

          {/* Alignment */}
          <div className="flex items-center gap-1 bg-slate-700/50 rounded-lg p-1">
            <Button
              size="sm"
              variant="ghost"
              className="text-gray-300 hover:text-white hover:bg-green-500/20"
            >
              <AlignLeft className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="text-gray-300 hover:text-white hover:bg-green-500/20"
            >
              <AlignCenter className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="text-gray-300 hover:text-white hover:bg-green-500/20"
            >
              <AlignRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Lists & Links */}
          <div className="flex items-center gap-1 bg-slate-700/50 rounded-lg p-1">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => insertFormatting('- ')}
              className="text-gray-300 hover:text-white hover:bg-blue-500/20"
            >
              <List className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => insertFormatting('[', '](url)')}
              className="text-gray-300 hover:text-white hover:bg-blue-500/20"
            >
              <Link className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => insertFormatting('![alt](', ')')}
              className="text-gray-300 hover:text-white hover:bg-blue-500/20"
            >
              <Image className="h-4 w-4" />
            </Button>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 bg-slate-700/50 rounded-lg p-1 ml-auto">
            <Button
              size="sm"
              variant="ghost"
              className="text-gray-300 hover:text-white hover:bg-yellow-500/20"
            >
              <Undo className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="text-gray-300 hover:text-white hover:bg-yellow-500/20"
            >
              <Redo className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="text-gray-300 hover:text-white hover:bg-green-500/20"
            >
              <Save className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Document Info */}
        <div className="flex items-center gap-4 mt-3 text-sm">
          <Badge className="bg-indigo-500/20 text-indigo-300 border-indigo-500/30">
            <Type className="h-3 w-3 mr-1" />
            {document.name}
          </Badge>
          
          <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
            Words: {wordCount}
          </Badge>
          
          <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">
            Characters: {charCount}
          </Badge>

          {isTyping && (
            <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 animate-pulse">
              <Zap className="h-3 w-3 mr-1" />
              Typing...
            </Badge>
          )}

          {selectedText && (
            <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
              Selected: {selectedText.length} chars
            </Badge>
          )}
        </div>
      </div>

      {/* Editor Container */}
      <div className="flex-1 flex relative z-10">
        {/* Line Numbers */}
        {showLineNumbers && (
          <div className="bg-slate-800/50 border-r border-indigo-500/30 px-3 py-4 text-sm text-gray-400 font-mono select-none min-w-[60px]">
            {Array.from({ length: Math.max((document.content.split('\n').length), 20) }, (_, i) => (
              <div key={i + 1} className="leading-6 text-right hover:text-indigo-400 transition-colors">
                {i + 1}
              </div>
            ))}
          </div>
        )}

        {/* Main Editor */}
        <div className="flex-1 relative">
          <textarea
            ref={textareaRef}
            onChange={handleContentChange}
            onSelect={handleTextSelection}
            placeholder="Mulai menulis di sini... ✨"
            className={`w-full h-full resize-none border-0 outline-0 bg-transparent text-white placeholder-gray-500 p-6 font-mono text-base leading-6 ${
              document.fontFamily === 'serif' ? 'font-serif' : document.fontFamily === 'mono' ? 'font-mono' : 'font-sans'
            }`}
            style={{ 
              fontSize: `${document.fontSize}px`,
              minHeight: 'calc(100vh - 200px)'
            }}
          />

          {/* Floating Writing Stats */}
          <div className="absolute bottom-4 right-4 bg-slate-800/90 backdrop-blur-sm rounded-lg p-3 border border-indigo-500/30">
            <div className="flex items-center gap-4 text-xs text-gray-300">
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span>Auto-saved</span>
              </div>
              <div>Lines: {document.content.split('\n').length}</div>
              <div>Reading: ~{Math.ceil(wordCount / 200)} min</div>
            </div>
          </div>

          {/* AI Writing Assistant (Floating) */}
          <div className="absolute top-4 right-4 bg-gradient-to-r from-indigo-600/90 to-purple-600/90 backdrop-blur-sm rounded-lg p-3 border border-indigo-400/30">
            <div className="flex items-center gap-2 text-white text-sm">
              <Sparkles className="h-4 w-4 text-yellow-300 animate-pulse" />
              <span>AI Assistant Ready</span>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Bottom Status Bar */}
      <div className="bg-slate-800/80 backdrop-blur-sm border-t border-indigo-500/30 p-3">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-4">
            <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
              <Eye className="h-3 w-3 mr-1" />
              {document.saved ? 'Saved' : 'Unsaved'}
            </Badge>
            
            <div className="text-gray-400">
              Font: {document.fontFamily} • Size: {document.fontSize}px
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-gray-400">
              Last modified: {new Date(document.lastModified).toLocaleTimeString('id-ID')}
            </div>
            
            <Button 
              size="sm" 
              className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600"
            >
              <Code className="h-3 w-3 mr-1" />
              Export
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}