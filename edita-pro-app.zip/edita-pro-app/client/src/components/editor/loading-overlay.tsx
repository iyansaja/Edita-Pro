import { useEffect, useState } from "react";
import { exportToPDF } from "@/lib/pdf-export";

interface LoadingOverlayProps {
  onComplete: () => void;
}

export function LoadingOverlay({ onComplete }: LoadingOverlayProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const simulateExport = async () => {
      // Simulate PDF export progress
      const intervals = [20, 40, 60, 80, 100];
      
      for (let i = 0; i < intervals.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 300));
        setProgress(intervals[i]);
      }
      
      // Actually export PDF here
      try {
        await exportToPDF("Document Content", "Exported Document");
      } catch (error) {
        console.error("Export failed:", error);
      }
      
      setTimeout(() => {
        onComplete();
        setProgress(0);
      }, 500);
    };

    simulateExport();
  }, [onComplete]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-sm w-full mx-4 animate-fade-in">
        <div className="flex items-center space-x-3">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary" />
          <div>
            <h3 className="text-sm font-medium text-gray-900 dark:text-white">
              Exporting PDF
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Please wait...
            </p>
          </div>
        </div>
        <div className="mt-4 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
          <div
            className="bg-primary h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
}
