import { Button } from "@/components/ui/button";
import { FileText, X, Plus } from "lucide-react";
import type { Document } from "@shared/schema";

interface DocumentTabsProps {
  documents: Document[];
  activeDocumentId?: number;
  onSelectDocument: (id: number) => void;
  onCloseDocument: (id: number) => void;
  onNewDocument: () => void;
}

export function DocumentTabs({
  documents,
  activeDocumentId,
  onSelectDocument,
  onCloseDocument,
  onNewDocument,
}: DocumentTabsProps) {
  if (documents.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-2">
        <Button onClick={onNewDocument} variant="ghost" size="sm" className="h-8">
          <Plus className="h-4 w-4 mr-1" />
          New Document
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4">
      <div className="flex items-center space-x-1 overflow-x-auto">
        {documents.map((doc) => (
          <div
            key={doc.id}
            className={`flex items-center rounded-t-lg px-3 py-2 min-w-0 transition-colors ${
              doc.id === activeDocumentId
                ? "bg-gray-100 dark:bg-gray-700"
                : "hover:bg-gray-50 dark:hover:bg-gray-700/50"
            }`}
          >
            <button
              onClick={() => onSelectDocument(doc.id)}
              className="flex items-center space-x-2 min-w-0"
            >
              <FileText className="h-4 w-4 text-primary flex-shrink-0" />
              <span className="text-sm text-gray-900 dark:text-white truncate max-w-32">
                {doc.name}
              </span>
              {!doc.saved && (
                <div className="w-2 h-2 bg-amber-500 rounded-full" title="Unsaved changes" />
              )}
            </button>
            <Button
              onClick={(e) => {
                e.stopPropagation();
                onCloseDocument(doc.id);
              }}
              variant="ghost"
              size="sm"
              className="ml-2 h-6 w-6 p-0 hover:bg-gray-200 dark:hover:bg-gray-600"
            >
              <X className="h-3 w-3 text-gray-400" />
            </Button>
          </div>
        ))}
        <Button
          onClick={onNewDocument}
          variant="ghost"
          size="sm"
          className="p-2 h-8 w-8"
        >
          <Plus className="h-4 w-4 text-gray-400" />
        </Button>
      </div>
    </div>
  );
}
