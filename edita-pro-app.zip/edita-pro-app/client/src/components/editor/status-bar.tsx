import type { Document } from "@shared/schema";

interface StatusBarProps {
  document?: Document;
}

export function StatusBar({ document }: StatusBarProps) {
  const getWordCount = (text: string) => {
    return text.trim().split(/\s+/).filter(word => word.length > 0).length;
  };

  const getCharacterCount = (text: string) => {
    return text.length;
  };

  const getLineCount = (text: string) => {
    return text.split('\n').length;
  };

  if (!document) {
    return (
      <div className="bg-gray-50 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600 px-4 py-2 flex items-center justify-center text-sm text-gray-600 dark:text-gray-400">
        No document selected
      </div>
    );
  }

  const wordCount = getWordCount(document.content);
  const charCount = getCharacterCount(document.content);
  const lineCount = getLineCount(document.content);

  return (
    <div className="bg-gray-50 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600 px-4 py-2 flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
      <div className="flex items-center space-x-4">
        <span>
          Line <span className="font-medium">{lineCount}</span>
        </span>
        <span className="text-gray-400">•</span>
        <span>
          <span className="font-medium">{wordCount}</span> words
        </span>
        <span className="text-gray-400">•</span>
        <span>
          <span className="font-medium">{charCount}</span> characters
        </span>
      </div>
      
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${document.saved ? 'bg-green-500' : 'bg-amber-500'}`} />
          <span>Auto-save {document.saved ? 'on' : 'pending'}</span>
        </div>
        <span className="text-gray-400">•</span>
        <span>UTF-8</span>
      </div>
    </div>
  );
}
