import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X } from "lucide-react";

interface SearchPanelProps {
  onClose: () => void;
}

export function SearchPanel({ onClose }: SearchPanelProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [replaceTerm, setReplaceTerm] = useState("");

  const handleFindNext = () => {
    // Implementation would search for the next occurrence
    console.log("Finding:", searchTerm);
  };

  const handleReplace = () => {
    // Implementation would replace current occurrence
    console.log("Replacing:", searchTerm, "with:", replaceTerm);
  };

  const handleReplaceAll = () => {
    // Implementation would replace all occurrences
    console.log("Replacing all:", searchTerm, "with:", replaceTerm);
  };

  return (
    <div className="absolute top-4 right-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg shadow-lg p-4 w-80 animate-slide-down z-10">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-gray-900 dark:text-white">
          Find & Replace
        </h3>
        <Button
          onClick={onClose}
          variant="ghost"
          size="sm"
          className="h-6 w-6 p-0"
        >
          <X className="h-4 w-4 text-gray-400" />
        </Button>
      </div>
      
      <div className="space-y-3">
        <Input
          type="text"
          placeholder="Find"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full"
          autoFocus
        />
        
        <Input
          type="text"
          placeholder="Replace with"
          value={replaceTerm}
          onChange={(e) => setReplaceTerm(e.target.value)}
          className="w-full"
        />
        
        <div className="flex space-x-2">
          <Button
            onClick={handleFindNext}
            className="flex-1"
            disabled={!searchTerm}
          >
            Find Next
          </Button>
          <Button
            onClick={handleReplace}
            variant="outline"
            className="flex-1"
            disabled={!searchTerm}
          >
            Replace
          </Button>
        </div>
        
        <Button
          onClick={handleReplaceAll}
          variant="outline"
          className="w-full"
          disabled={!searchTerm}
        >
          Replace All
        </Button>
      </div>
    </div>
  );
}
