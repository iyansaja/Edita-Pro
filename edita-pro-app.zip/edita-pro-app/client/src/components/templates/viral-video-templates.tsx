import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Play, 
  Edit, 
  TrendingUp, 
  Eye, 
  Heart, 
  Share, 
  Download,
  Zap,
  Sparkles,
  Crown,
  Clock,
  Users
} from 'lucide-react';

interface ViralTemplate {
  id: string;
  title: string;
  description: string;
  category: 'tiktok' | 'instagram' | 'youtube' | 'twitter';
  duration: string;
  views: string;
  engagement: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  isPremium: boolean;
  trending: boolean;
  tags: string[];
  thumbnail: string;
  previewUrl?: string;
}

export function ViralVideoTemplates() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [hoveredTemplate, setHoveredTemplate] = useState<string | null>(null);

  const viralTemplates: ViralTemplate[] = [
    {
      id: 'viral_1',
      title: 'TikTok Transition Challenge',
      description: 'Template viral dengan transisi outfit yang smooth dan eye-catching',
      category: 'tiktok',
      duration: '15s',
      views: '2.5M',
      engagement: '18.3%',
      difficulty: 'beginner',
      isPremium: false,
      trending: true,
      tags: ['transition', 'outfit', 'trending', 'dance'],
      thumbnail: ''
    },
    {
      id: 'viral_2',
      title: 'Instagram Reels Story Time',
      description: 'Format storytelling yang engaging dengan text overlay dinamis',
      category: 'instagram',
      duration: '30s',
      views: '1.8M',
      engagement: '22.1%',
      difficulty: 'intermediate',
      isPremium: true,
      trending: true,
      tags: ['story', 'text', 'engaging', 'viral'],
      thumbnail: ''
    },
    {
      id: 'viral_3',
      title: 'YouTube Shorts Hook',
      description: 'Template opening yang powerful untuk meningkatkan retention rate',
      category: 'youtube',
      duration: '60s',
      views: '950K',
      engagement: '15.7%',
      difficulty: 'advanced',
      isPremium: true,
      trending: false,
      tags: ['hook', 'retention', 'shorts', 'youtube'],
      thumbnail: ''
    },
    {
      id: 'viral_4',
      title: 'Before After Transformation',
      description: 'Template transformasi yang dramatis dengan split screen effect',
      category: 'instagram',
      duration: '20s',
      views: '3.2M',
      engagement: '25.4%',
      difficulty: 'beginner',
      isPremium: false,
      trending: true,
      tags: ['transformation', 'before-after', 'split', 'dramatic'],
      thumbnail: ''
    },
    {
      id: 'viral_5',
      title: 'Trending Dance Template',
      description: 'Template dance viral terbaru dengan beat sync yang perfect',
      category: 'tiktok',
      duration: '15s',
      views: '4.1M',
      engagement: '31.2%',
      difficulty: 'intermediate',
      isPremium: false,
      trending: true,
      tags: ['dance', 'beat-sync', 'viral', 'trending'],
      thumbnail: ''
    },
    {
      id: 'viral_6',
      title: 'Product Showcase Viral',
      description: 'Template showcase produk yang aesthetic dan conversion-friendly',
      category: 'instagram',
      duration: '25s',
      views: '1.3M',
      engagement: '19.8%',
      difficulty: 'intermediate',
      isPremium: true,
      trending: false,
      tags: ['product', 'showcase', 'aesthetic', 'conversion'],
      thumbnail: ''
    }
  ];

  const categories = [
    { id: 'all', name: 'Semua Platform', color: 'bg-purple-500' },
    { id: 'tiktok', name: 'TikTok', color: 'bg-pink-500' },
    { id: 'instagram', name: 'Instagram', color: 'bg-gradient-to-r from-purple-500 to-pink-500' },
    { id: 'youtube', name: 'YouTube', color: 'bg-red-500' },
    { id: 'twitter', name: 'Twitter', color: 'bg-blue-500' }
  ];

  const filteredTemplates = viralTemplates.filter(template => 
    selectedCategory === 'all' || template.category === selectedCategory
  );

  const getPlatformColor = (category: ViralTemplate['category']) => {
    switch (category) {
      case 'tiktok': return 'bg-pink-500';
      case 'instagram': return 'bg-gradient-to-r from-purple-500 to-pink-500';
      case 'youtube': return 'bg-red-500';
      case 'twitter': return 'bg-blue-500';
      default: return 'bg-purple-500';
    }
  };

  const getDifficultyColor = (difficulty: ViralTemplate['difficulty']) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-500';
      case 'intermediate': return 'bg-yellow-500';
      case 'advanced': return 'bg-red-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <TrendingUp className="h-6 w-6 text-pink-400" />
              Template Video Viral
            </h2>
            <p className="text-gray-400">Template terpopuler untuk konten yang engaging dan viral</p>
          </div>
          
          <Badge className="bg-gradient-to-r from-pink-500 to-red-500 text-white border-0">
            <Zap className="h-3 w-3 mr-1" />
            Trending Now
          </Badge>
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide">
          {categories.map((category) => (
            <Button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              variant={selectedCategory === category.id ? "default" : "outline"}
              size="sm"
              className={selectedCategory === category.id 
                ? `${category.color} text-white border-0` 
                : "border-purple-500/30 hover:bg-purple-500/10"
              }
            >
              {category.name}
            </Button>
          ))}
        </div>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((template) => (
          <Card
            key={template.id}
            className="bg-gradient-to-br from-slate-800/80 to-purple-900/80 border border-purple-500/30 hover:border-pink-400/60 transition-all duration-300 hover:scale-105 cursor-pointer group"
            onMouseEnter={() => setHoveredTemplate(template.id)}
            onMouseLeave={() => setHoveredTemplate(null)}
          >
            <CardContent className="p-0">
              {/* Thumbnail & Preview */}
              <div className="relative h-48 bg-gradient-to-br from-pink-600/20 to-purple-600/20 rounded-t-lg overflow-hidden">
                {/* Viral Indicator */}
                {template.trending && (
                  <div className="absolute top-3 left-3">
                    <Badge className="bg-gradient-to-r from-pink-500 to-red-500 text-white border-0 animate-pulse">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      Viral
                    </Badge>
                  </div>
                )}

                {/* Premium Badge */}
                {template.isPremium && (
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0">
                      <Crown className="h-3 w-3 mr-1" />
                      Pro
                    </Badge>
                  </div>
                )}

                {/* Platform Badge */}
                <div className="absolute bottom-3 left-3">
                  <Badge className={`${getPlatformColor(template.category)} text-white border-0 capitalize`}>
                    {template.category}
                  </Badge>
                </div>

                {/* Play Button Overlay */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <Play className="h-8 w-8 text-white ml-1" />
                  </div>
                </div>

                {/* Hover Actions */}
                {hoveredTemplate === template.id && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center gap-3 transition-all duration-300">
                    <Button
                      variant="default"
                      size="sm"
                      className="bg-pink-500 hover:bg-pink-600"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      Preview
                    </Button>
                    <Button
                      variant="default"
                      size="sm"
                      className="bg-purple-500 hover:bg-purple-600"
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Template
                    </Button>
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-4 space-y-3">
                <div className="space-y-2">
                  <h3 className="font-semibold text-white line-clamp-1 group-hover:text-pink-300 transition-colors">
                    {template.title}
                  </h3>
                  <p className="text-sm text-gray-400 line-clamp-2">
                    {template.description}
                  </p>
                </div>

                {/* Stats */}
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-3 text-gray-400">
                    <div className="flex items-center gap-1">
                      <Eye className="h-4 w-4" />
                      <span>{template.views}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="h-4 w-4" />
                      <span>{template.engagement}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{template.duration}</span>
                    </div>
                  </div>
                  
                  <Badge className={`${getDifficultyColor(template.difficulty)} text-white border-0 text-xs`}>
                    {template.difficulty}
                  </Badge>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1">
                  {template.tags.slice(0, 3).map((tag) => (
                    <Badge
                      key={tag}
                      variant="outline"
                      className="text-xs bg-pink-500/10 border-pink-500/30 text-pink-300"
                    >
                      #{tag}
                    </Badge>
                  ))}
                  {template.tags.length > 3 && (
                    <Badge
                      variant="outline"
                      className="text-xs bg-gray-500/10 border-gray-500/30 text-gray-400"
                    >
                      +{template.tags.length - 3}
                    </Badge>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 border-pink-500/30 hover:bg-pink-500/20 text-pink-300"
                  >
                    <Download className="h-3 w-3 mr-2" />
                    Gunakan
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-purple-500/30 hover:bg-purple-500/20"
                  >
                    <Share className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-purple-500/30 hover:bg-purple-500/20"
                  >
                    <Heart className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
        <Card className="bg-black/20 border-pink-500/30">
          <CardContent className="p-4 text-center">
            <TrendingUp className="h-8 w-8 mx-auto mb-2 text-pink-400" />
            <div className="text-2xl font-bold text-white">12.8M</div>
            <div className="text-sm text-gray-400">Total Views</div>
          </CardContent>
        </Card>
        
        <Card className="bg-black/20 border-purple-500/30">
          <CardContent className="p-4 text-center">
            <Users className="h-8 w-8 mx-auto mb-2 text-purple-400" />
            <div className="text-2xl font-bold text-white">23.2%</div>
            <div className="text-sm text-gray-400">Avg Engagement</div>
          </CardContent>
        </Card>
        
        <Card className="bg-black/20 border-yellow-500/30">
          <CardContent className="p-4 text-center">
            <Crown className="h-8 w-8 mx-auto mb-2 text-yellow-400" />
            <div className="text-2xl font-bold text-white">6</div>
            <div className="text-sm text-gray-400">Viral Templates</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}