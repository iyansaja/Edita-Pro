import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Film, 
  Play, 
  Zap, 
  Sparkles, 
  ArrowRight,
  RotateCw,
  Layers,
  Eye,
  Download,
  Settings,
  Crown,
  Timer,
  Palette
} from 'lucide-react';

interface TransitionTemplate {
  id: string;
  name: string;
  category: 'fade' | 'slide' | 'zoom' | 'rotate' | 'glitch' | 'cinematic';
  duration: string;
  complexity: 'simple' | 'moderate' | 'complex';
  isPremium: boolean;
  isPopular: boolean;
  description: string;
  usageCount: number;
  tags: string[];
  previewFrames: string[];
}

export function CinematicTransitions() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [hoveredTransition, setHoveredTransition] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState<string | null>(null);

  const transitionTemplates: TransitionTemplate[] = [
    {
      id: 'transition_1',
      name: 'Cinematic Fade Cross',
      category: 'fade',
      duration: '1.5s',
      complexity: 'simple',
      isPremium: false,
      isPopular: true,
      description: 'Transisi fade yang smooth dengan color grading sinematik',
      usageCount: 15420,
      tags: ['smooth', 'professional', 'versatile', 'beginner'],
      previewFrames: []
    },
    {
      id: 'transition_2',
      name: 'Dynamic Slide Wipe',
      category: 'slide',
      duration: '0.8s',
      complexity: 'moderate',
      isPremium: true,
      isPopular: true,
      description: 'Slide transition dengan motion blur dan depth effect',
      usageCount: 12890,
      tags: ['dynamic', 'motion-blur', 'modern', 'fast'],
      previewFrames: []
    },
    {
      id: 'transition_3',
      name: 'Epic Zoom Burst',
      category: 'zoom',
      duration: '2.0s',
      complexity: 'complex',
      isPremium: true,
      isPopular: false,
      description: 'Zoom dramatis dengan particle effects dan lens flare',
      usageCount: 8760,
      tags: ['epic', 'dramatic', 'particles', 'cinematic'],
      previewFrames: []
    },
    {
      id: 'transition_4',
      name: 'Glitch Digital Distort',
      category: 'glitch',
      duration: '0.5s',
      complexity: 'moderate',
      isPremium: false,
      isPopular: true,
      description: 'Efek glitch modern dengan RGB shift dan noise',
      usageCount: 18950,
      tags: ['glitch', 'digital', 'modern', 'tech'],
      previewFrames: []
    },
    {
      id: 'transition_5',
      name: 'Cinematic Iris Out',
      category: 'cinematic',
      duration: '2.5s',
      complexity: 'complex',
      isPremium: true,
      isPopular: false,
      description: 'Transisi iris klasik dengan vignette effect',
      usageCount: 5670,
      tags: ['classic', 'iris', 'vignette', 'artistic'],
      previewFrames: []
    },
    {
      id: 'transition_6',
      name: 'Spin Rotate Matrix',
      category: 'rotate',
      duration: '1.2s',
      complexity: 'moderate',
      isPremium: false,
      isPopular: true,
      description: 'Rotasi 3D dengan perspective shift yang dinamis',
      usageCount: 11230,
      tags: ['3d', 'rotate', 'perspective', 'dynamic'],
      previewFrames: []
    },
    {
      id: 'transition_7',
      name: 'Layer Mask Reveal',
      category: 'cinematic',
      duration: '1.8s',
      complexity: 'complex',
      isPremium: true,
      isPopular: false,
      description: 'Reveal dengan animated mask dan depth layers',
      usageCount: 7340,
      tags: ['mask', 'reveal', 'layers', 'professional'],
      previewFrames: []
    },
    {
      id: 'transition_8',
      name: 'Light Leak Transition',
      category: 'cinematic',
      duration: '2.2s',
      complexity: 'moderate',
      isPremium: true,
      isPopular: true,
      description: 'Transisi dengan light leak dan film grain aesthetic',
      usageCount: 13560,
      tags: ['light-leak', 'film-grain', 'aesthetic', 'vintage'],
      previewFrames: []
    }
  ];

  const categories = [
    { id: 'all', name: 'Semua Efek', icon: Sparkles, color: 'bg-purple-500' },
    { id: 'fade', name: 'Fade', icon: Eye, color: 'bg-blue-500' },
    { id: 'slide', name: 'Slide', icon: ArrowRight, color: 'bg-green-500' },
    { id: 'zoom', name: 'Zoom', icon: Zap, color: 'bg-yellow-500' },
    { id: 'rotate', name: 'Rotate', icon: RotateCw, color: 'bg-orange-500' },
    { id: 'glitch', name: 'Glitch', icon: Layers, color: 'bg-red-500' },
    { id: 'cinematic', name: 'Cinematic', icon: Film, color: 'bg-indigo-500' }
  ];

  const filteredTransitions = transitionTemplates.filter(transition => 
    selectedCategory === 'all' || transition.category === selectedCategory
  );

  const getCategoryColor = (category: TransitionTemplate['category']) => {
    const categoryObj = categories.find(c => c.id === category);
    return categoryObj?.color || 'bg-purple-500';
  };

  const getComplexityColor = (complexity: TransitionTemplate['complexity']) => {
    switch (complexity) {
      case 'simple': return 'bg-green-500';
      case 'moderate': return 'bg-yellow-500';
      case 'complex': return 'bg-red-500';
    }
  };

  const startPreview = (transitionId: string) => {
    setPreviewMode(transitionId);
    setTimeout(() => setPreviewMode(null), 3000); // Preview for 3 seconds
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Film className="h-6 w-6 text-indigo-400" />
              Efek Transisi & Edit Sinematik
            </h2>
            <p className="text-gray-400">Koleksi transisi profesional untuk video yang memukau</p>
          </div>
          
          <Badge className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-0">
            <Film className="h-3 w-3 mr-1" />
            Hollywood Style
          </Badge>
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <Button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                className={selectedCategory === category.id 
                  ? `${category.color} text-white border-0` 
                  : "border-purple-500/30 hover:bg-purple-500/10"
                }
              >
                <Icon className="h-4 w-4 mr-2" />
                {category.name}
              </Button>
            );
          })}
        </div>
      </div>

      {/* Transitions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTransitions.map((transition) => (
          <Card
            key={transition.id}
            className="bg-gradient-to-br from-slate-800/80 to-indigo-900/80 border border-indigo-500/30 hover:border-indigo-400/60 transition-all duration-300 hover:scale-105 cursor-pointer group"
            onMouseEnter={() => setHoveredTransition(transition.id)}
            onMouseLeave={() => setHoveredTransition(null)}
          >
            <CardContent className="p-0">
              {/* Preview Area */}
              <div className="relative h-40 bg-gradient-to-br from-indigo-600/20 to-purple-600/20 rounded-t-lg overflow-hidden">
                {/* Popular Badge */}
                {transition.isPopular && (
                  <div className="absolute top-3 left-3">
                    <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white border-0">
                      <Sparkles className="h-3 w-3 mr-1" />
                      Popular
                    </Badge>
                  </div>
                )}

                {/* Premium Badge */}
                {transition.isPremium && (
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0">
                      <Crown className="h-3 w-3 mr-1" />
                      Pro
                    </Badge>
                  </div>
                )}

                {/* Category Badge */}
                <div className="absolute bottom-3 left-3">
                  <Badge className={`${getCategoryColor(transition.category)} text-white border-0 capitalize`}>
                    {transition.category}
                  </Badge>
                </div>

                {/* Preview Animation */}
                <div className="absolute inset-0 flex items-center justify-center">
                  {previewMode === transition.id ? (
                    <div className="w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse">
                      <div className="w-full h-full flex items-center justify-center">
                        <div className="text-white font-bold">PREVIEW</div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-white/20 rounded border"></div>
                      <ArrowRight className="h-6 w-6 text-white animate-pulse" />
                      <div className="w-8 h-8 bg-white/20 rounded border"></div>
                    </div>
                  )}
                </div>

                {/* Hover Actions */}
                {hoveredTransition === transition.id && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center gap-3 transition-all duration-300">
                    <Button
                      onClick={() => startPreview(transition.id)}
                      variant="default"
                      size="sm"
                      className="bg-indigo-500 hover:bg-indigo-600"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Preview
                    </Button>
                    <Button
                      variant="default"
                      size="sm"
                      className="bg-purple-500 hover:bg-purple-600"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Gunakan
                    </Button>
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-4 space-y-3">
                <div className="space-y-2">
                  <h3 className="font-semibold text-white line-clamp-1 group-hover:text-indigo-300 transition-colors">
                    {transition.name}
                  </h3>
                  <p className="text-sm text-gray-400 line-clamp-2">
                    {transition.description}
                  </p>
                </div>

                {/* Technical Info */}
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-3 text-gray-400">
                    <div className="flex items-center gap-1">
                      <Timer className="h-4 w-4" />
                      <span>{transition.duration}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Eye className="h-4 w-4" />
                      <span>{transition.usageCount.toLocaleString()}</span>
                    </div>
                  </div>
                  
                  <Badge className={`${getComplexityColor(transition.complexity)} text-white border-0 text-xs`}>
                    {transition.complexity}
                  </Badge>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1">
                  {transition.tags.slice(0, 3).map((tag) => (
                    <Badge
                      key={tag}
                      variant="outline"
                      className="text-xs bg-indigo-500/10 border-indigo-500/30 text-indigo-300"
                    >
                      #{tag}
                    </Badge>
                  ))}
                  {transition.tags.length > 3 && (
                    <Badge
                      variant="outline"
                      className="text-xs bg-gray-500/10 border-gray-500/30 text-gray-400"
                    >
                      +{transition.tags.length - 3}
                    </Badge>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 border-indigo-500/30 hover:bg-indigo-500/20 text-indigo-300"
                  >
                    <Download className="h-3 w-3 mr-2" />
                    Tambahkan
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-purple-500/30 hover:bg-purple-500/20"
                  >
                    <Settings className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-purple-500/30 hover:bg-purple-500/20"
                  >
                    <Palette className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Cinematic Tools Info */}
      <Card className="bg-black/20 border-indigo-500/30">
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <h3 className="text-xl font-bold text-white flex items-center justify-center gap-2">
              <Film className="h-6 w-6 text-indigo-400" />
              Professional Cinematic Tools
            </h3>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Kumpulan transisi dan efek berkualitas Hollywood untuk mengangkat kualitas video Anda. 
              Setiap efek dirancang dengan teliti oleh profesional industry film.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
              <div className="text-center">
                <Sparkles className="h-8 w-8 mx-auto mb-2 text-indigo-400" />
                <div className="text-lg font-bold text-white">50+</div>
                <div className="text-sm text-gray-400">Efek Transisi</div>
              </div>
              <div className="text-center">
                <Timer className="h-8 w-8 mx-auto mb-2 text-purple-400" />
                <div className="text-lg font-bold text-white">0.2-5s</div>
                <div className="text-sm text-gray-400">Durasi Custom</div>
              </div>
              <div className="text-center">
                <Layers className="h-8 w-8 mx-auto mb-2 text-green-400" />
                <div className="text-lg font-bold text-white">4K</div>
                <div className="text-sm text-gray-400">Ultra HD Quality</div>
              </div>
              <div className="text-center">
                <Crown className="h-8 w-8 mx-auto mb-2 text-yellow-400" />
                <div className="text-lg font-bold text-white">Pro</div>
                <div className="text-sm text-gray-400">Cinema Grade</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}