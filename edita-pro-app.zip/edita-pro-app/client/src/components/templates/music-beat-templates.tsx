import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Music, 
  Play, 
  Pause, 
  Volume2, 
  Zap, 
  Radio, 
  RadioIcon,
  Headphones,
  Download,
  Settings,
  TrendingUp,
  Heart,
  Clock
} from 'lucide-react';

interface MusicTemplate {
  id: string;
  title: string;
  genre: string;
  bpm: number;
  key: string;
  duration: string;
  mood: string;
  energy: number; // 1-10
  isLooping: boolean;
  beatSyncAvailable: boolean;
  isPremium: boolean;
  downloadCount: number;
  rating: number;
  tags: string[];
}

export function MusicBeatTemplates() {
  const [selectedGenre, setSelectedGenre] = useState<string>('all');
  const [isPlaying, setIsPlaying] = useState<string | null>(null);
  const [bpmRange, setBpmRange] = useState([60, 180]);
  const [energyLevel, setEnergyLevel] = useState([1, 10]);

  const musicTemplates: MusicTemplate[] = [
    {
      id: 'music_1',
      title: 'Urban Hip Hop Beat',
      genre: 'hip-hop',
      bpm: 140,
      key: 'C Minor',
      duration: '3:30',
      mood: 'aggressive',
      energy: 8,
      isLooping: true,
      beatSyncAvailable: true,
      isPremium: false,
      downloadCount: 2400,
      rating: 4.8,
      tags: ['urban', 'trap', 'bass-heavy', 'modern']
    },
    {
      id: 'music_2',
      title: 'Electronic Dance Energy',
      genre: 'edm',
      bpm: 128,
      key: 'A Major',
      duration: '4:15',
      mood: 'energetic',
      energy: 9,
      isLooping: true,
      beatSyncAvailable: true,
      isPremium: true,
      downloadCount: 3200,
      rating: 4.9,
      tags: ['festival', 'drop', 'synth', 'party']
    },
    {
      id: 'music_3',
      title: 'Chill Lo-Fi Vibes',
      genre: 'lo-fi',
      bpm: 85,
      key: 'G Major',
      duration: '2:45',
      mood: 'relaxed',
      energy: 3,
      isLooping: true,
      beatSyncAvailable: true,
      isPremium: false,
      downloadCount: 1800,
      rating: 4.7,
      tags: ['study', 'chill', 'vinyl', 'nostalgic']
    },
    {
      id: 'music_4',
      title: 'Corporate Inspiring',
      genre: 'corporate',
      bpm: 120,
      key: 'C Major',
      duration: '3:00',
      mood: 'uplifting',
      energy: 6,
      isLooping: true,
      beatSyncAvailable: true,
      isPremium: true,
      downloadCount: 1500,
      rating: 4.6,
      tags: ['business', 'motivational', 'clean', 'professional']
    },
    {
      id: 'music_5',
      title: 'Trap Hard Hitting',
      genre: 'trap',
      bpm: 160,
      key: 'D Minor',
      duration: '2:30',
      mood: 'intense',
      energy: 10,
      isLooping: true,
      beatSyncAvailable: true,
      isPremium: false,
      downloadCount: 2800,
      rating: 4.8,
      tags: ['hard', '808', 'aggressive', 'street']
    },
    {
      id: 'music_6',
      title: 'Cinematic Epic Score',
      genre: 'cinematic',
      bpm: 110,
      key: 'E Minor',
      duration: '5:20',
      mood: 'dramatic',
      energy: 7,
      isLooping: false,
      beatSyncAvailable: true,
      isPremium: true,
      downloadCount: 950,
      rating: 4.9,
      tags: ['epic', 'orchestral', 'movie', 'dramatic']
    }
  ];

  const genres = [
    { id: 'all', name: 'Semua Genre', color: 'bg-purple-500' },
    { id: 'hip-hop', name: 'Hip Hop', color: 'bg-orange-500' },
    { id: 'edm', name: 'EDM', color: 'bg-blue-500' },
    { id: 'lo-fi', name: 'Lo-Fi', color: 'bg-green-500' },
    { id: 'corporate', name: 'Corporate', color: 'bg-gray-500' },
    { id: 'trap', name: 'Trap', color: 'bg-red-500' },
    { id: 'cinematic', name: 'Cinematic', color: 'bg-indigo-500' }
  ];

  const filteredTemplates = musicTemplates.filter(template => {
    const genreMatch = selectedGenre === 'all' || template.genre === selectedGenre;
    const bpmMatch = template.bpm >= bpmRange[0] && template.bpm <= bpmRange[1];
    const energyMatch = template.energy >= energyLevel[0] && template.energy <= energyLevel[1];
    return genreMatch && bpmMatch && energyMatch;
  });

  const getGenreColor = (genre: string) => {
    const genreObj = genres.find(g => g.id === genre);
    return genreObj?.color || 'bg-purple-500';
  };

  const getEnergyColor = (energy: number) => {
    if (energy <= 3) return 'bg-green-500';
    if (energy <= 6) return 'bg-yellow-500';
    if (energy <= 8) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const togglePlay = (musicId: string) => {
    if (isPlaying === musicId) {
      setIsPlaying(null);
    } else {
      setIsPlaying(musicId);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Music className="h-6 w-6 text-blue-400" />
              Template Musik Auto Beat Match
            </h2>
            <p className="text-gray-400">Musik berkualitas tinggi dengan sinkronisasi beat otomatis</p>
          </div>
          
          <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white border-0">
            <Zap className="h-3 w-3 mr-1" />
            Auto Sync
          </Badge>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Genre Filter */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white">Genre</label>
            <div className="flex flex-wrap gap-2">
              {genres.map((genre) => (
                <Button
                  key={genre.id}
                  onClick={() => setSelectedGenre(genre.id)}
                  variant={selectedGenre === genre.id ? "default" : "outline"}
                  size="sm"
                  className={selectedGenre === genre.id 
                    ? `${genre.color} text-white border-0` 
                    : "border-purple-500/30 hover:bg-purple-500/10"
                  }
                >
                  {genre.name}
                </Button>
              ))}
            </div>
          </div>

          {/* BPM Range */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white">BPM Range: {bpmRange[0]} - {bpmRange[1]}</label>
            <Slider
              value={bpmRange}
              onValueChange={setBpmRange}
              max={200}
              min={60}
              step={5}
              className="w-full"
            />
          </div>

          {/* Energy Level */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white">Energy Level: {energyLevel[0]} - {energyLevel[1]}</label>
            <Slider
              value={energyLevel}
              onValueChange={setEnergyLevel}
              max={10}
              min={1}
              step={1}
              className="w-full"
            />
          </div>
        </div>
      </div>

      {/* Music Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((template) => (
          <Card
            key={template.id}
            className="bg-gradient-to-br from-slate-800/80 to-blue-900/80 border border-blue-500/30 hover:border-blue-400/60 transition-all duration-300 hover:scale-105 cursor-pointer group"
          >
            <CardContent className="p-0">
              {/* Audio Visualizer Area */}
              <div className="relative h-40 bg-gradient-to-br from-blue-600/20 to-purple-600/20 rounded-t-lg overflow-hidden">
                {/* Beat Sync Badge */}
                {template.beatSyncAvailable && (
                  <div className="absolute top-3 left-3">
                    <Badge className="bg-gradient-to-r from-green-500 to-blue-500 text-white border-0">
                      <Zap className="h-3 w-3 mr-1" />
                      Auto Sync
                    </Badge>
                  </div>
                )}

                {/* Premium Badge */}
                {template.isPremium && (
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0">
                      Premium
                    </Badge>
                  </div>
                )}

                {/* Genre Badge */}
                <div className="absolute bottom-3 left-3">
                  <Badge className={`${getGenreColor(template.genre)} text-white border-0 capitalize`}>
                    {template.genre}
                  </Badge>
                </div>

                {/* Waveform Visualization */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 20 }).map((_, i) => (
                      <div
                        key={i}
                        className={`w-1 bg-blue-400 rounded-full transition-all duration-300 ${
                          isPlaying === template.id 
                            ? 'animate-pulse h-8' 
                            : `h-${Math.floor(Math.random() * 6) + 2}`
                        }`}
                        style={{ 
                          animationDelay: `${i * 50}ms`,
                          height: isPlaying === template.id ? `${Math.random() * 32 + 8}px` : `${Math.random() * 16 + 8}px`
                        }}
                      />
                    ))}
                  </div>
                </div>

                {/* Play Button */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <Button
                    onClick={() => togglePlay(template.id)}
                    variant="ghost"
                    size="lg"
                    className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-md hover:bg-white/30 transition-all duration-300"
                  >
                    {isPlaying === template.id ? (
                      <Pause className="h-8 w-8 text-white" />
                    ) : (
                      <Play className="h-8 w-8 text-white ml-1" />
                    )}
                  </Button>
                </div>
              </div>

              {/* Content */}
              <div className="p-4 space-y-3">
                <div className="space-y-2">
                  <h3 className="font-semibold text-white line-clamp-1 group-hover:text-blue-300 transition-colors">
                    {template.title}
                  </h3>
                  
                  <div className="flex items-center justify-between text-sm text-gray-400">
                    <span>{template.key}</span>
                    <span>{template.bpm} BPM</span>
                    <span>{template.duration}</span>
                  </div>
                </div>

                {/* Technical Info */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge className={`${getEnergyColor(template.energy)} text-white border-0 text-xs`}>
                      Energy {template.energy}/10
                    </Badge>
                    <Badge variant="outline" className="text-xs bg-purple-500/10 border-purple-500/30 text-purple-300">
                      {template.mood}
                    </Badge>
                  </div>
                  
                  {template.isLooping && (
                    <Badge variant="outline" className="text-xs bg-green-500/10 border-green-500/30 text-green-300">
                      Loop Ready
                    </Badge>
                  )}
                </div>

                {/* Rating & Downloads */}
                <div className="flex items-center justify-between text-sm text-gray-400">
                  <div className="flex items-center gap-1">
                    <Heart className="h-4 w-4 text-red-400" />
                    <span>{template.rating}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Download className="h-4 w-4" />
                    <span>{template.downloadCount.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{template.duration}</span>
                  </div>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1">
                  {template.tags.slice(0, 3).map((tag) => (
                    <Badge
                      key={tag}
                      variant="outline"
                      className="text-xs bg-blue-500/10 border-blue-500/30 text-blue-300"
                    >
                      #{tag}
                    </Badge>
                  ))}
                  {template.tags.length > 3 && (
                    <Badge
                      variant="outline"
                      className="text-xs bg-gray-500/10 border-gray-500/30 text-gray-400"
                    >
                      +{template.tags.length - 3}
                    </Badge>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 border-blue-500/30 hover:bg-blue-500/20 text-blue-300"
                  >
                    <Download className="h-3 w-3 mr-2" />
                    Gunakan
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-purple-500/30 hover:bg-purple-500/20"
                  >
                    <Settings className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-purple-500/30 hover:bg-purple-500/20"
                  >
                    <Heart className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Beat Match Info */}
      <Card className="bg-black/20 border-blue-500/30">
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <h3 className="text-xl font-bold text-white flex items-center justify-center gap-2">
              <Radio className="h-6 w-6 text-blue-400" />
              Auto Beat Match Technology
            </h3>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Teknologi AI canggih yang secara otomatis menyinkronkan beat musik dengan video Anda. 
              Analisis tempo real-time dan penyesuaian dinamis untuk hasil yang sempurna.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <div className="text-center">
                <TrendingUp className="h-8 w-8 mx-auto mb-2 text-blue-400" />
                <div className="text-lg font-bold text-white">99.9%</div>
                <div className="text-sm text-gray-400">Sync Accuracy</div>
              </div>
              <div className="text-center">
                <Headphones className="h-8 w-8 mx-auto mb-2 text-purple-400" />
                <div className="text-lg font-bold text-white">Studio</div>
                <div className="text-sm text-gray-400">Quality Audio</div>
              </div>
              <div className="text-center">
                <RadioIcon className="h-8 w-8 mx-auto mb-2 text-green-400" />
                <div className="text-lg font-bold text-white">Real-time</div>
                <div className="text-sm text-gray-400">Processing</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}