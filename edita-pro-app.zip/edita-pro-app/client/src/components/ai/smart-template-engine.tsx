import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Brain,
  Sparkles,
  Music,
  Scissors,
  Wand2,
  Clock,
  Zap,
  Target,
  Star,
  TrendingUp,
  Users,
  Heart,
  Volume2,
  Film,
  Image
} from 'lucide-react';

interface TransitionEffect {
  id: string;
  name: string;
  type: 'cut' | 'fade' | 'slide' | 'zoom' | 'wipe' | 'spin' | 'morph';
  duration: number;
  intensity: number;
  musicSync: boolean;
}

interface MusicTrack {
  id: string;
  name: string;
  genre: string;
  mood: string;
  bpm: number;
  duration: number;
  energy: number;
  preview: string;
}

interface SmartTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  popularity: number;
  effectiveness: number;
  musicTracks: MusicTrack[];
  transitions: TransitionEffect[];
  timing: {
    introLength: number;
    mainSegments: number;
    outroLength: number;
    beatDrops: number[];
  };
  aiSettings: {
    contentAnalysis: boolean;
    beatSync: boolean;
    autoColorGrade: boolean;
    smartCropping: boolean;
    emotionDetection: boolean;
  };
}

interface SmartTemplateEngineProps {
  onTemplateSelect?: (template: SmartTemplate) => void;
  onCustomize?: (template: SmartTemplate, customizations: any) => void;
}

export function SmartTemplateEngine({ onTemplateSelect, onCustomize }: SmartTemplateEngineProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [customizations, setCustomizations] = useState({
    musicIntensity: 70,
    transitionSpeed: 50,
    colorGrading: 60,
    beatSyncEnabled: true,
    autoEffects: true
  });

  const smartTemplates: SmartTemplate[] = [
    {
      id: 'viral_explosion',
      name: 'Viral Explosion',
      description: 'AI-optimized for maximum viral potential',
      category: 'Viral',
      popularity: 98,
      effectiveness: 95,
      musicTracks: [
        {
          id: 'electronic_hype',
          name: 'Electronic Hype',
          genre: 'Electronic Pop',
          mood: 'Energetic',
          bpm: 128,
          duration: 30,
          energy: 95,
          preview: 'electronic_hype.mp3'
        }
      ],
      transitions: [
        {
          id: 'zoom_punch',
          name: 'Zoom Punch',
          type: 'zoom',
          duration: 0.2,
          intensity: 90,
          musicSync: true
        },
        {
          id: 'quick_cut',
          name: 'Beat Cut',
          type: 'cut',
          duration: 0.1,
          intensity: 100,
          musicSync: true
        }
      ],
      timing: {
        introLength: 2,
        mainSegments: 8,
        outroLength: 2,
        beatDrops: [0.5, 1.0, 1.5, 2.0, 2.5]
      },
      aiSettings: {
        contentAnalysis: true,
        beatSync: true,
        autoColorGrade: true,
        smartCropping: true,
        emotionDetection: true
      }
    },
    {
      id: 'cinematic_story',
      name: 'Cinematic Storyteller',
      description: 'AI-crafted emotional narrative flow',
      category: 'Cinematic',
      popularity: 87,
      effectiveness: 92,
      musicTracks: [
        {
          id: 'orchestral_epic',
          name: 'Epic Orchestral',
          genre: 'Orchestral',
          mood: 'Epic',
          bpm: 90,
          duration: 60,
          energy: 85,
          preview: 'orchestral_epic.mp3'
        }
      ],
      transitions: [
        {
          id: 'smooth_fade',
          name: 'Emotional Fade',
          type: 'fade',
          duration: 1.5,
          intensity: 70,
          musicSync: false
        },
        {
          id: 'parallax_slide',
          name: 'Parallax Slide',
          type: 'slide',
          duration: 2.0,
          intensity: 80,
          musicSync: true
        }
      ],
      timing: {
        introLength: 5,
        mainSegments: 12,
        outroLength: 8,
        beatDrops: [0.8, 1.6, 2.4, 3.2]
      },
      aiSettings: {
        contentAnalysis: true,
        beatSync: false,
        autoColorGrade: true,
        smartCropping: false,
        emotionDetection: true
      }
    },
    {
      id: 'social_trendy',
      name: 'Social Media Trendy',
      description: 'Optimized for Instagram & TikTok algorithms',
      category: 'Social',
      popularity: 94,
      effectiveness: 89,
      musicTracks: [
        {
          id: 'indie_pop_vibe',
          name: 'Indie Pop Vibe',
          genre: 'Indie Pop',
          mood: 'Trendy',
          bpm: 110,
          duration: 25,
          energy: 80,
          preview: 'indie_pop.mp3'
        }
      ],
      transitions: [
        {
          id: 'slide_zoom',
          name: 'Slide Zoom',
          type: 'zoom',
          duration: 0.8,
          intensity: 85,
          musicSync: true
        },
        {
          id: 'color_pop',
          name: 'Color Pop',
          type: 'morph',
          duration: 0.5,
          intensity: 75,
          musicSync: false
        }
      ],
      timing: {
        introLength: 1,
        mainSegments: 6,
        outroLength: 1,
        beatDrops: [0.4, 0.8, 1.2, 1.6, 2.0]
      },
      aiSettings: {
        contentAnalysis: true,
        beatSync: true,
        autoColorGrade: false,
        smartCropping: true,
        emotionDetection: false
      }
    },
    {
      id: 'business_pro',
      name: 'Business Professional',
      description: 'AI-enhanced corporate communication',
      category: 'Business',
      popularity: 76,
      effectiveness: 88,
      musicTracks: [
        {
          id: 'corporate_upbeat',
          name: 'Corporate Upbeat',
          genre: 'Corporate',
          mood: 'Professional',
          bpm: 120,
          duration: 45,
          energy: 65,
          preview: 'corporate.mp3'
        }
      ],
      transitions: [
        {
          id: 'clean_fade',
          name: 'Clean Fade',
          type: 'fade',
          duration: 1.0,
          intensity: 60,
          musicSync: false
        },
        {
          id: 'slide_clean',
          name: 'Professional Slide',
          type: 'slide',
          duration: 0.8,
          intensity: 70,
          musicSync: true
        }
      ],
      timing: {
        introLength: 3,
        mainSegments: 10,
        outroLength: 5,
        beatDrops: [1.0, 2.0, 3.0, 4.0]
      },
      aiSettings: {
        contentAnalysis: false,
        beatSync: false,
        autoColorGrade: true,
        smartCropping: false,
        emotionDetection: false
      }
    },
    {
      id: 'adventure_dynamic',
      name: 'Adventure Dynamic',
      description: 'AI-powered high-energy storytelling',
      category: 'Adventure',
      popularity: 85,
      effectiveness: 91,
      musicTracks: [
        {
          id: 'adventure_rock',
          name: 'Adventure Rock',
          genre: 'Rock',
          mood: 'Exciting',
          bpm: 140,
          duration: 90,
          energy: 95,
          preview: 'adventure.mp3'
        }
      ],
      transitions: [
        {
          id: 'motion_blur',
          name: 'Motion Blur',
          type: 'wipe',
          duration: 0.6,
          intensity: 95,
          musicSync: true
        },
        {
          id: 'spin_dynamic',
          name: 'Dynamic Spin',
          type: 'spin',
          duration: 0.4,
          intensity: 90,
          musicSync: true
        }
      ],
      timing: {
        introLength: 4,
        mainSegments: 15,
        outroLength: 6,
        beatDrops: [0.5, 1.0, 1.5, 2.0, 2.5, 3.0]
      },
      aiSettings: {
        contentAnalysis: true,
        beatSync: true,
        autoColorGrade: true,
        smartCropping: true,
        emotionDetection: true
      }
    },
    {
      id: 'lifestyle_aesthetic',
      name: 'Lifestyle Aesthetic',
      description: 'AI-curated aesthetic vibes',
      category: 'Lifestyle',
      popularity: 82,
      effectiveness: 86,
      musicTracks: [
        {
          id: 'chill_indie',
          name: 'Chill Indie',
          genre: 'Indie',
          mood: 'Relaxed',
          bpm: 85,
          duration: 50,
          energy: 60,
          preview: 'chill_indie.mp3'
        }
      ],
      transitions: [
        {
          id: 'smooth_blend',
          name: 'Smooth Blend',
          type: 'morph',
          duration: 2.0,
          intensity: 50,
          musicSync: false
        },
        {
          id: 'dreamy_fade',
          name: 'Dreamy Fade',
          type: 'fade',
          duration: 1.8,
          intensity: 65,
          musicSync: true
        }
      ],
      timing: {
        introLength: 4,
        mainSegments: 8,
        outroLength: 6,
        beatDrops: [1.0, 2.0, 3.0]
      },
      aiSettings: {
        contentAnalysis: true,
        beatSync: false,
        autoColorGrade: true,
        smartCropping: false,
        emotionDetection: true
      }
    }
  ];

  const handleTemplateSelect = useCallback((templateId: string) => {
    setSelectedTemplate(templateId);
    const template = smartTemplates.find(t => t.id === templateId);
    if (template) {
      onTemplateSelect?.(template);
    }
  }, [onTemplateSelect, smartTemplates]);

  const handleCustomizationChange = useCallback((key: string, value: any) => {
    setCustomizations(prev => ({ ...prev, [key]: value }));
  }, []);

  const applyCustomizations = useCallback(() => {
    const template = smartTemplates.find(t => t.id === selectedTemplate);
    if (template) {
      onCustomize?.(template, customizations);
    }
  }, [selectedTemplate, customizations, onCustomize, smartTemplates]);

  const selectedTemplateData = smartTemplates.find(t => t.id === selectedTemplate);

  // Get category icon
  const getCategoryIcon = useCallback((category: string) => {
    switch (category.toLowerCase()) {
      case 'viral': return TrendingUp;
      case 'cinematic': return Film;
      case 'social': return Users;
      case 'business': return Target;
      case 'adventure': return Zap;
      case 'lifestyle': return Heart;
      default: return Star;
    }
  }, []);

  // Get popularity color
  const getPopularityColor = useCallback((popularity: number) => {
    if (popularity >= 90) return 'text-green-400';
    if (popularity >= 80) return 'text-yellow-400';
    if (popularity >= 70) return 'text-orange-400';
    return 'text-red-400';
  }, []);

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 text-white overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Brain className="h-6 w-6 text-indigo-400" />
              Smart Template Engine
              <Badge className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-0 ml-auto">
                <Sparkles className="h-3 w-3 mr-1" />
                AI Enhanced
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Template Library */}
          <div className="lg:col-span-2 space-y-4">
            <Card className="bg-slate-800/50 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Wand2 className="h-4 w-4 text-purple-400" />
                  AI-Powered Templates
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {smartTemplates.map((template) => {
                    const CategoryIcon = getCategoryIcon(template.category);
                    return (
                      <div
                        key={template.id}
                        className={`p-4 rounded-lg border cursor-pointer transition-all hover:scale-105 ${
                          selectedTemplate === template.id
                            ? 'bg-purple-500/20 border-purple-400 ring-2 ring-purple-400'
                            : 'bg-slate-700/50 border-slate-600 hover:border-purple-500/50'
                        }`}
                        onClick={() => handleTemplateSelect(template.id)}
                      >
                        {/* Header */}
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <CategoryIcon className="h-5 w-5 text-purple-400" />
                            <Badge className="bg-purple-500/20 text-purple-300 border-0 text-xs">
                              {template.category}
                            </Badge>
                          </div>
                          
                          <div className="flex items-center gap-1">
                            <TrendingUp className={`h-4 w-4 ${getPopularityColor(template.popularity)}`} />
                            <span className={`text-sm font-bold ${getPopularityColor(template.popularity)}`}>
                              {template.popularity}%
                            </span>
                          </div>
                        </div>

                        {/* Content */}
                        <div className="space-y-2">
                          <h3 className="font-semibold text-white">{template.name}</h3>
                          <p className="text-sm text-gray-400">{template.description}</p>
                          
                          {/* Stats */}
                          <div className="flex items-center gap-4 mt-3">
                            <div className="flex items-center gap-1">
                              <Star className="h-3 w-3 text-yellow-400" />
                              <span className="text-xs text-gray-300">{template.effectiveness}% effective</span>
                            </div>
                            
                            <div className="flex items-center gap-1">
                              <Music className="h-3 w-3 text-green-400" />
                              <span className="text-xs text-gray-300">{template.musicTracks.length} tracks</span>
                            </div>
                            
                            <div className="flex items-center gap-1">
                              <Scissors className="h-3 w-3 text-blue-400" />
                              <span className="text-xs text-gray-300">{template.transitions.length} transitions</span>
                            </div>
                          </div>

                          {/* AI Features */}
                          <div className="flex flex-wrap gap-1 mt-2">
                            {template.aiSettings.beatSync && (
                              <Badge className="bg-green-500/20 text-green-300 border-0 text-xs">Beat Sync</Badge>
                            )}
                            {template.aiSettings.autoColorGrade && (
                              <Badge className="bg-blue-500/20 text-blue-300 border-0 text-xs">Color AI</Badge>
                            )}
                            {template.aiSettings.emotionDetection && (
                              <Badge className="bg-pink-500/20 text-pink-300 border-0 text-xs">Emotion AI</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Customization Panel */}
          <div className="space-y-4">
            {/* Template Details */}
            {selectedTemplateData && (
              <Card className="bg-slate-800/50 border-indigo-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <Brain className="h-4 w-4 text-indigo-400" />
                    Template Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-white">{selectedTemplateData.name}</h3>
                    <p className="text-sm text-gray-400 mt-1">{selectedTemplateData.description}</p>
                  </div>

                  {/* Music Track */}
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-gray-300">Featured Music</label>
                    {selectedTemplateData.musicTracks.map((track) => (
                      <div key={track.id} className="p-2 bg-slate-700/50 rounded border border-slate-600">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-sm font-medium text-white">{track.name}</div>
                            <div className="text-xs text-gray-400">{track.genre} • {track.bpm} BPM</div>
                          </div>
                          <Badge className="bg-green-500/20 text-green-300 border-0 text-xs">
                            {track.energy}% Energy
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Timing Info */}
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-gray-300">Timing Structure</label>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div className="text-center p-2 bg-slate-700/50 rounded">
                        <div className="text-white font-medium">{selectedTemplateData.timing.introLength}s</div>
                        <div className="text-gray-400">Intro</div>
                      </div>
                      <div className="text-center p-2 bg-slate-700/50 rounded">
                        <div className="text-white font-medium">{selectedTemplateData.timing.mainSegments}</div>
                        <div className="text-gray-400">Segments</div>
                      </div>
                      <div className="text-center p-2 bg-slate-700/50 rounded">
                        <div className="text-white font-medium">{selectedTemplateData.timing.outroLength}s</div>
                        <div className="text-gray-400">Outro</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Customization Controls */}
            {selectedTemplateData && (
              <Card className="bg-slate-800/50 border-yellow-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-yellow-400" />
                    Customize Template
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Music Intensity */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs text-gray-300">Music Intensity</label>
                      <Badge className="bg-yellow-500/20 text-yellow-300 border-0 text-xs">
                        {customizations.musicIntensity}%
                      </Badge>
                    </div>
                    <Slider
                      value={[customizations.musicIntensity]}
                      onValueChange={([value]) => handleCustomizationChange('musicIntensity', value)}
                      max={100}
                      min={0}
                      step={5}
                      className="w-full"
                    />
                  </div>

                  {/* Transition Speed */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs text-gray-300">Transition Speed</label>
                      <Badge className="bg-blue-500/20 text-blue-300 border-0 text-xs">
                        {customizations.transitionSpeed}%
                      </Badge>
                    </div>
                    <Slider
                      value={[customizations.transitionSpeed]}
                      onValueChange={([value]) => handleCustomizationChange('transitionSpeed', value)}
                      max={100}
                      min={0}
                      step={5}
                      className="w-full"
                    />
                  </div>

                  {/* Color Grading */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs text-gray-300">AI Color Grading</label>
                      <Badge className="bg-purple-500/20 text-purple-300 border-0 text-xs">
                        {customizations.colorGrading}%
                      </Badge>
                    </div>
                    <Slider
                      value={[customizations.colorGrading]}
                      onValueChange={([value]) => handleCustomizationChange('colorGrading', value)}
                      max={100}
                      min={0}
                      step={5}
                      className="w-full"
                    />
                  </div>

                  {/* AI Features */}
                  <div className="space-y-3">
                    <label className="text-xs font-medium text-gray-300">AI Features</label>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-white">Beat Sync</span>
                      <button
                        onClick={() => handleCustomizationChange('beatSyncEnabled', !customizations.beatSyncEnabled)}
                        className={`w-10 h-5 rounded-full transition-colors ${
                          customizations.beatSyncEnabled ? 'bg-green-500' : 'bg-gray-600'
                        }`}
                      >
                        <div className={`w-4 h-4 bg-white rounded-full transition-transform ${
                          customizations.beatSyncEnabled ? 'translate-x-5' : 'translate-x-0.5'
                        }`} />
                      </button>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-white">Auto Effects</span>
                      <button
                        onClick={() => handleCustomizationChange('autoEffects', !customizations.autoEffects)}
                        className={`w-10 h-5 rounded-full transition-colors ${
                          customizations.autoEffects ? 'bg-green-500' : 'bg-gray-600'
                        }`}
                      >
                        <div className={`w-4 h-4 bg-white rounded-full transition-transform ${
                          customizations.autoEffects ? 'translate-x-5' : 'translate-x-0.5'
                        }`} />
                      </button>
                    </div>
                  </div>

                  {/* Apply Button */}
                  <Button
                    onClick={applyCustomizations}
                    className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
                  >
                    <Wand2 className="h-4 w-4 mr-2" />
                    Apply Customizations
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Template Stats */}
            <div className="grid grid-cols-2 gap-3">
              <Card className="bg-slate-800/50 border-green-500/30">
                <CardContent className="p-3 text-center">
                  <TrendingUp className="h-5 w-5 mx-auto mb-2 text-green-400" />
                  <div className="text-lg font-bold text-white">
                    {selectedTemplateData?.popularity || 0}%
                  </div>
                  <div className="text-xs text-gray-400">Popularity</div>
                </CardContent>
              </Card>
              
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardContent className="p-3 text-center">
                  <Star className="h-5 w-5 mx-auto mb-2 text-blue-400" />
                  <div className="text-lg font-bold text-white">
                    {selectedTemplateData?.effectiveness || 0}%
                  </div>
                  <div className="text-xs text-gray-400">Effectiveness</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}