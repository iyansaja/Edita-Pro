import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { 
  Wand2,
  Upload,
  Image,
  Video,
  Music,
  Sparkles,
  Play,
  Pause,
  Download,
  Settings,
  Zap,
  Clock,
  Target,
  Star,
  Heart,
  Smile,
  Coffee,
  Camera,
  Film,
  Volume2,
  Shuffle
} from 'lucide-react';

interface MediaAsset {
  id: string;
  type: 'image' | 'video' | 'audio';
  url: string;
  name: string;
  duration?: number;
  thumbnail?: string;
  size: number;
  selected: boolean;
}

interface VideoTemplate {
  id: string;
  name: string;
  description: string;
  category: 'viral' | 'cinematic' | 'social' | 'business' | 'travel' | 'lifestyle';
  duration: number;
  transitionStyle: string;
  musicGenre: string;
  pacing: 'slow' | 'medium' | 'fast' | 'dynamic';
  effects: string[];
  thumbnail: string;
}

interface AIVideoProject {
  id: string;
  name: string;
  template: VideoTemplate;
  assets: MediaAsset[];
  generatedVideo?: string;
  progress: number;
  status: 'idle' | 'analyzing' | 'generating' | 'processing' | 'completed' | 'error';
  aiInsights: {
    detectedMoods: string[];
    suggestedMusicGenre: string;
    recommendedPacing: string;
    qualityScore: number;
  };
}

interface AutoVideoGeneratorProps {
  onVideoGenerated?: (project: AIVideoProject) => void;
  onClose?: () => void;
}

export function AutoVideoGenerator({ onVideoGenerated, onClose }: AutoVideoGeneratorProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [project, setProject] = useState<AIVideoProject>({
    id: 'project_1',
    name: 'My AI Video',
    template: {} as VideoTemplate,
    assets: [],
    progress: 0,
    status: 'idle',
    aiInsights: {
      detectedMoods: [],
      suggestedMusicGenre: 'upbeat',
      recommendedPacing: 'medium',
      qualityScore: 0
    }
  });

  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);

  const videoTemplates: VideoTemplate[] = [
    {
      id: 'viral_tiktok',
      name: 'Viral TikTok Style',
      description: 'Fast-paced with trending transitions',
      category: 'viral',
      duration: 15,
      transitionStyle: 'quick_cuts',
      musicGenre: 'electronic_pop',
      pacing: 'fast',
      effects: ['zoom_punch', 'beat_sync', 'color_pop'],
      thumbnail: '🔥'
    },
    {
      id: 'cinematic_story',
      name: 'Cinematic Story',
      description: 'Smooth transitions with epic music',
      category: 'cinematic',
      duration: 60,
      transitionStyle: 'crossfade',
      musicGenre: 'orchestral',
      pacing: 'slow',
      effects: ['color_grade', 'lens_flare', 'parallax'],
      thumbnail: '🎬'
    },
    {
      id: 'instagram_reel',
      name: 'Instagram Reel',
      description: 'Trendy style for social media',
      category: 'social',
      duration: 30,
      transitionStyle: 'slide_zoom',
      musicGenre: 'indie_pop',
      pacing: 'medium',
      effects: ['beauty_filter', 'text_overlay', 'sticker_pop'],
      thumbnail: '📸'
    },
    {
      id: 'business_promo',
      name: 'Business Promo',
      description: 'Professional corporate style',
      category: 'business',
      duration: 45,
      transitionStyle: 'fade_clean',
      musicGenre: 'corporate',
      pacing: 'medium',
      effects: ['clean_titles', 'logo_reveal', 'stats_animation'],
      thumbnail: '💼'
    },
    {
      id: 'travel_vlog',
      name: 'Travel Adventure',
      description: 'Dynamic travel montage',
      category: 'travel',
      duration: 90,
      transitionStyle: 'motion_blur',
      musicGenre: 'adventure',
      pacing: 'dynamic',
      effects: ['map_animation', 'time_lapse', 'location_tags'],
      thumbnail: '✈️'
    },
    {
      id: 'lifestyle_mood',
      name: 'Lifestyle Mood',
      description: 'Aesthetic lifestyle vibes',
      category: 'lifestyle',
      duration: 45,
      transitionStyle: 'smooth_blend',
      musicGenre: 'chill_indie',
      pacing: 'slow',
      effects: ['film_grain', 'soft_glow', 'vintage_color'],
      thumbnail: '🌸'
    }
  ];

  const musicGenres = [
    { id: 'electronic_pop', name: 'Electronic Pop', mood: 'energetic', bpm: 128 },
    { id: 'orchestral', name: 'Cinematic Orchestral', mood: 'epic', bpm: 90 },
    { id: 'indie_pop', name: 'Indie Pop', mood: 'trendy', bpm: 110 },
    { id: 'corporate', name: 'Corporate Uplifting', mood: 'professional', bpm: 120 },
    { id: 'adventure', name: 'Adventure Rock', mood: 'exciting', bpm: 140 },
    { id: 'chill_indie', name: 'Chill Indie', mood: 'relaxed', bpm: 85 }
  ];

  const transitionStyles = [
    { id: 'quick_cuts', name: 'Quick Cuts', description: 'Fast-paced viral style' },
    { id: 'crossfade', name: 'Crossfade', description: 'Smooth cinematic blend' },
    { id: 'slide_zoom', name: 'Slide + Zoom', description: 'Dynamic social media' },
    { id: 'fade_clean', name: 'Clean Fade', description: 'Professional transition' },
    { id: 'motion_blur', name: 'Motion Blur', description: 'High-energy movement' },
    { id: 'smooth_blend', name: 'Smooth Blend', description: 'Aesthetic flow' }
  ];

  // Handle file upload
  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    const newAssets: MediaAsset[] = Array.from(files).map((file, index) => ({
      id: `asset_${Date.now()}_${index}`,
      type: file.type.startsWith('image/') ? 'image' : 
            file.type.startsWith('video/') ? 'video' : 'audio',
      url: URL.createObjectURL(file),
      name: file.name,
      size: file.size,
      selected: true,
      duration: file.type.startsWith('video/') ? Math.random() * 10 + 5 : undefined
    }));

    setProject(prev => ({
      ...prev,
      assets: [...prev.assets, ...newAssets]
    }));

    // Simulate AI analysis
    setTimeout(() => {
      analyzeAssets(newAssets);
    }, 1000);
  }, []);

  // AI Asset Analysis
  const analyzeAssets = useCallback((assets: MediaAsset[]) => {
    setProject(prev => ({ ...prev, status: 'analyzing' }));
    
    // Simulate AI analysis with progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setProject(prev => ({ ...prev, progress }));
      
      if (progress >= 100) {
        clearInterval(interval);
        
        // Generate AI insights
        const moods = ['happy', 'energetic', 'adventure', 'relaxed', 'professional'];
        const detectedMoods = moods.slice(0, Math.floor(Math.random() * 3) + 2);
        
        setProject(prev => ({
          ...prev,
          status: 'idle',
          progress: 0,
          aiInsights: {
            detectedMoods,
            suggestedMusicGenre: musicGenres[Math.floor(Math.random() * musicGenres.length)].id,
            recommendedPacing: ['slow', 'medium', 'fast'][Math.floor(Math.random() * 3)],
            qualityScore: Math.floor(Math.random() * 30) + 70
          }
        }));
      }
    }, 200);
  }, []);

  // Generate AI Video
  const generateVideo = useCallback(async () => {
    if (!selectedTemplate || project.assets.length === 0) return;

    const template = videoTemplates.find(t => t.id === selectedTemplate);
    if (!template) return;

    setIsGenerating(true);
    setProject(prev => ({ 
      ...prev, 
      status: 'generating',
      template,
      progress: 0
    }));

    // Simulate AI video generation process
    const steps = [
      'Analyzing media content...',
      'Selecting best clips...',
      'Applying AI transitions...',
      'Syncing to music beats...',
      'Adding effects & filters...',
      'Rendering final video...'
    ];

    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setProject(prev => ({ 
        ...prev, 
        progress: ((i + 1) / steps.length) * 100
      }));
      
      setCurrentStep(i + 1);
    }

    // Complete generation
    setProject(prev => ({
      ...prev,
      status: 'completed',
      generatedVideo: 'generated_video_url.mp4',
      progress: 100
    }));

    setIsGenerating(false);
    onVideoGenerated?.(project);
  }, [selectedTemplate, project, onVideoGenerated]);

  // Toggle asset selection
  const toggleAssetSelection = useCallback((assetId: string) => {
    setProject(prev => ({
      ...prev,
      assets: prev.assets.map(asset =>
        asset.id === assetId ? { ...asset, selected: !asset.selected } : asset
      )
    }));
  }, []);

  // Remove asset
  const removeAsset = useCallback((assetId: string) => {
    setProject(prev => ({
      ...prev,
      assets: prev.assets.filter(asset => asset.id !== assetId)
    }));
  }, []);

  // Format file size
  const formatFileSize = useCallback((bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }, []);

  const selectedAssets = project.assets.filter(asset => asset.selected);
  const selectedTemplateData = videoTemplates.find(t => t.id === selectedTemplate);

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-violet-900 to-slate-900 text-white overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-violet-900/80 to-fuchsia-900/80 border border-violet-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Wand2 className="h-6 w-6 text-violet-400" />
              AI Auto-Edit Video Generator
              <Badge className="bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white border-0 ml-auto">
                <Sparkles className="h-3 w-3 mr-1" />
                AI Powered
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        {/* Generation Progress */}
        {isGenerating && (
          <Card className="bg-gradient-to-r from-violet-800/50 to-purple-800/50 border border-violet-500/30">
            <CardContent className="p-6">
              <div className="text-center space-y-4">
                <div className="flex items-center justify-center gap-2">
                  <Zap className="h-5 w-5 text-violet-400 animate-pulse" />
                  <span className="text-lg font-semibold text-white">AI is creating your video...</span>
                </div>
                
                <Progress value={project.progress} className="w-full h-3" />
                
                <div className="text-sm text-gray-300">
                  Step {currentStep}/6: {
                    ['Analyzing media content...', 'Selecting best clips...', 'Applying AI transitions...', 
                     'Syncing to music beats...', 'Adding effects & filters...', 'Rendering final video...'][currentStep - 1]
                  }
                </div>
                
                <div className="text-2xl font-bold text-violet-400">
                  {project.progress.toFixed(0)}%
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Panel - Upload & Assets */}
          <div className="space-y-4">
            {/* Upload Media */}
            <Card className="bg-slate-800/50 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Upload className="h-4 w-4 text-green-400" />
                  Upload Media Assets
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="image/*,video/*,audio/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full bg-green-500 hover:bg-green-600 h-20 text-lg"
                  disabled={isGenerating}
                >
                  <Upload className="h-6 w-6 mr-2" />
                  Choose Photos & Videos
                </Button>

                <div className="text-xs text-gray-400 text-center">
                  Upload images, videos, or audio files
                </div>
              </CardContent>
            </Card>

            {/* AI Insights */}
            {project.aiInsights.detectedMoods.length > 0 && (
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-blue-400" />
                    AI Content Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <label className="text-xs text-gray-400">Detected Moods</label>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {project.aiInsights.detectedMoods.map((mood) => (
                        <Badge key={mood} className="bg-blue-500/20 text-blue-300 border-0 text-xs">
                          {mood}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-xs text-gray-400">Quality Score</label>
                    <div className="flex items-center gap-2 mt-1">
                      <Progress value={project.aiInsights.qualityScore} className="flex-1 h-2" />
                      <span className="text-sm text-white">{project.aiInsights.qualityScore}%</span>
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-xs text-gray-400">AI Recommendations</label>
                    <div className="text-sm text-white mt-1">
                      {project.aiInsights.suggestedMusicGenre} • {project.aiInsights.recommendedPacing} pacing
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Asset List */}
            {project.assets.length > 0 && (
              <Card className="bg-slate-800/50 border-yellow-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <Image className="h-4 w-4 text-yellow-400" />
                    Media Assets ({project.assets.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 max-h-64 overflow-y-auto">
                  {project.assets.map((asset) => (
                    <div
                      key={asset.id}
                      className={`p-2 rounded border transition-all cursor-pointer ${
                        asset.selected 
                          ? 'bg-yellow-500/20 border-yellow-400' 
                          : 'bg-slate-700/50 border-slate-600 hover:border-slate-500'
                      }`}
                      onClick={() => toggleAssetSelection(asset.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {asset.type === 'image' && <Image className="h-4 w-4 text-green-400" />}
                          {asset.type === 'video' && <Video className="h-4 w-4 text-blue-400" />}
                          {asset.type === 'audio' && <Music className="h-4 w-4 text-purple-400" />}
                          <span className="text-white text-sm truncate">{asset.name}</span>
                        </div>
                        
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            removeAsset(asset.id);
                          }}
                          variant="ghost"
                          size="sm"
                          className="p-1 h-6 w-6 text-red-400 hover:bg-red-500/20"
                        >
                          ✕
                        </Button>
                      </div>
                      
                      <div className="text-xs text-gray-400 mt-1">
                        {formatFileSize(asset.size)}
                        {asset.duration && ` • ${asset.duration.toFixed(1)}s`}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Center Panel - Template Selection */}
          <div className="space-y-4">
            <Card className="bg-slate-800/50 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Film className="h-4 w-4 text-purple-400" />
                  Video Templates
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 max-h-96 overflow-y-auto">
                {videoTemplates.map((template) => (
                  <div
                    key={template.id}
                    className={`p-4 rounded-lg border cursor-pointer transition-all ${
                      selectedTemplate === template.id
                        ? 'bg-purple-500/20 border-purple-400'
                        : 'bg-slate-700/50 border-slate-600 hover:border-slate-500'
                    }`}
                    onClick={() => setSelectedTemplate(template.id)}
                  >
                    <div className="flex items-start gap-3">
                      <div className="text-2xl">{template.thumbnail}</div>
                      <div className="flex-1">
                        <div className="font-medium text-white">{template.name}</div>
                        <div className="text-sm text-gray-400 mt-1">{template.description}</div>
                        
                        <div className="flex items-center gap-2 mt-2">
                          <Badge className="bg-slate-600/50 text-gray-300 border-0 text-xs">
                            <Clock className="h-3 w-3 mr-1" />
                            {template.duration}s
                          </Badge>
                          <Badge className="bg-slate-600/50 text-gray-300 border-0 text-xs">
                            {template.pacing}
                          </Badge>
                        </div>
                        
                        <div className="flex flex-wrap gap-1 mt-2">
                          {template.effects.slice(0, 2).map((effect) => (
                            <Badge key={effect} className="bg-purple-500/20 text-purple-300 border-0 text-xs">
                              {effect}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Generation Controls */}
          <div className="space-y-4">
            {/* Template Settings */}
            {selectedTemplateData && (
              <Card className="bg-slate-800/50 border-indigo-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <Settings className="h-4 w-4 text-indigo-400" />
                    Template Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-xs text-gray-400">Selected Template</label>
                    <div className="text-white font-medium">{selectedTemplateData.name}</div>
                  </div>
                  
                  <div>
                    <label className="text-xs text-gray-400">Music Genre</label>
                    <select className="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-white text-sm mt-1">
                      {musicGenres.map((genre) => (
                        <option key={genre.id} value={genre.id}>
                          {genre.name} ({genre.mood})
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="text-xs text-gray-400">Transition Style</label>
                    <select className="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-white text-sm mt-1">
                      {transitionStyles.map((style) => (
                        <option key={style.id} value={style.id}>
                          {style.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-xs text-gray-400">Video Duration</label>
                    <Slider
                      value={[selectedTemplateData.duration]}
                      max={120}
                      min={15}
                      step={5}
                      className="w-full"
                    />
                    <div className="text-center text-sm text-white">{selectedTemplateData.duration}s</div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Generation Button */}
            <Card className="bg-gradient-to-r from-violet-800/50 to-fuchsia-800/50 border border-violet-500/30">
              <CardContent className="p-4">
                <Button
                  onClick={generateVideo}
                  disabled={!selectedTemplate || selectedAssets.length === 0 || isGenerating}
                  className="w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-600 hover:to-fuchsia-600 h-16 text-lg font-semibold"
                >
                  {isGenerating ? (
                    <>
                      <Zap className="h-5 w-5 mr-2 animate-pulse" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Wand2 className="h-5 w-5 mr-2" />
                      Generate AI Video
                    </>
                  )}
                </Button>
                
                <div className="text-center mt-3 text-sm text-gray-300">
                  {selectedAssets.length} assets • {selectedTemplate ? 'Template selected' : 'Choose template'}
                </div>
              </CardContent>
            </Card>

            {/* Generation Stats */}
            <div className="grid grid-cols-2 gap-3">
              <Card className="bg-slate-800/50 border-green-500/30">
                <CardContent className="p-3 text-center">
                  <Target className="h-5 w-5 mx-auto mb-2 text-green-400" />
                  <div className="text-lg font-bold text-white">{selectedAssets.length}</div>
                  <div className="text-xs text-gray-400">Selected Assets</div>
                </CardContent>
              </Card>
              
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardContent className="p-3 text-center">
                  <Star className="h-5 w-5 mx-auto mb-2 text-blue-400" />
                  <div className="text-lg font-bold text-white">
                    {project.aiInsights.qualityScore || 0}%
                  </div>
                  <div className="text-xs text-gray-400">AI Quality</div>
                </CardContent>
              </Card>
            </div>

            {/* Generated Video Preview */}
            {project.status === 'completed' && project.generatedVideo && (
              <Card className="bg-gradient-to-r from-green-800/50 to-emerald-800/50 border border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <Play className="h-4 w-4 text-green-400" />
                    Generated Video
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="bg-slate-900 rounded-lg h-32 flex items-center justify-center">
                    <Play className="h-8 w-8 text-green-400" />
                  </div>
                  
                  <Button className="w-full bg-green-500 hover:bg-green-600">
                    <Download className="h-4 w-4 mr-2" />
                    Download Video
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}