import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  FileText,
  Video,
  Image,
  Music,
  Trash2,
  Edit,
  Copy,
  Star,
  Clock,
  Download,
  Share,
  MoreVertical,
  Plus,
  FolderOpen,
  Search,
  Filter,
  SortAsc,
  Grid,
  List,
  Sparkles,
  Zap,
  Crown,
  Heart
} from 'lucide-react';

interface Project {
  id: string;
  title: string;
  type: 'document' | 'video' | 'image' | 'audio' | 'template';
  description?: string;
  thumbnail?: string;
  lastModified: Date;
  createdAt: Date;
  size: string;
  status: 'draft' | 'completed' | 'in-progress';
  tags: string[];
  starred: boolean;
  shared: boolean;
  premium: boolean;
}

interface ProjectManagerProps {
  onProjectOpen?: (project: Project) => void;
  onProjectDelete?: (projectId: string) => void;
  onProjectEdit?: (project: Project) => void;
}

export function ProjectManager({ onProjectOpen, onProjectDelete, onProjectEdit }: ProjectManagerProps) {
  const [projects, setProjects] = useState<Project[]>([
    {
      id: '1',
      title: 'Video Viral TikTok',
      type: 'video',
      description: 'Video pendek dengan efek trending untuk TikTok',
      lastModified: new Date(Date.now() - 1000 * 60 * 30), // 30 mins ago
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
      size: '45.2 MB',
      status: 'completed',
      tags: ['viral', 'social media', 'trending'],
      starred: true,
      shared: false,
      premium: false
    },
    {
      id: '2',
      title: 'Presentasi Bisnis Q4',
      type: 'document',
      description: 'Laporan kinerja dan strategi untuk kuartal keempat',
      lastModified: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
      size: '8.7 MB',
      status: 'in-progress',
      tags: ['business', 'presentation', 'quarterly'],
      starred: false,
      shared: true,
      premium: true
    },
    {
      id: '3',
      title: 'Wedding Highlights',
      type: 'video',
      description: 'Montage pernikahan dengan musik romantis',
      lastModified: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 48), // 2 days ago
      size: '156.8 MB',
      status: 'completed',
      tags: ['wedding', 'romantic', 'highlight'],
      starred: true,
      shared: false,
      premium: false
    },
    {
      id: '4',
      title: 'Product Photography',
      type: 'image',
      description: 'Foto produk untuk e-commerce dengan editing profesional',
      lastModified: new Date(Date.now() - 1000 * 60 * 60 * 6), // 6 hours ago
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72), // 3 days ago
      size: '23.4 MB',
      status: 'draft',
      tags: ['product', 'photography', 'ecommerce'],
      starred: false,
      shared: false,
      premium: false
    },
    {
      id: '5',
      title: 'Podcast Intro Music',
      type: 'audio',
      description: 'Musik pembuka untuk podcast dengan sound effects',
      lastModified: new Date(Date.now() - 1000 * 60 * 60 * 12), // 12 hours ago
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 96), // 4 days ago
      size: '12.1 MB',
      status: 'completed',
      tags: ['podcast', 'intro', 'music'],
      starred: false,
      shared: true,
      premium: true
    }
  ]);

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'recent' | 'name' | 'type' | 'size'>('recent');
  const [filterType, setFilterType] = useState<'all' | 'document' | 'video' | 'image' | 'audio'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProjects, setSelectedProjects] = useState<string[]>([]);

  // Filter and sort projects
  const filteredAndSortedProjects = projects
    .filter(project => {
      const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           project.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           project.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesType = filterType === 'all' || project.type === filterType;
      return matchesSearch && matchesType;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.title.localeCompare(b.title);
        case 'type':
          return a.type.localeCompare(b.type);
        case 'size':
          return parseFloat(a.size) - parseFloat(b.size);
        case 'recent':
        default:
          return b.lastModified.getTime() - a.lastModified.getTime();
      }
    });

  // Delete project
  const handleDeleteProject = useCallback((projectId: string) => {
    setProjects(prev => prev.filter(p => p.id !== projectId));
    onProjectDelete?.(projectId);
  }, [onProjectDelete]);

  // Toggle star
  const toggleStar = useCallback((projectId: string) => {
    setProjects(prev => 
      prev.map(p => 
        p.id === projectId ? { ...p, starred: !p.starred } : p
      )
    );
  }, []);

  // Duplicate project
  const duplicateProject = useCallback((project: Project) => {
    const newProject: Project = {
      ...project,
      id: `${project.id}_copy_${Date.now()}`,
      title: `${project.title} (Copy)`,
      createdAt: new Date(),
      lastModified: new Date(),
      status: 'draft'
    };
    setProjects(prev => [newProject, ...prev]);
  }, []);

  // Get project type icon
  const getProjectIcon = useCallback((type: Project['type']) => {
    switch (type) {
      case 'video': return Video;
      case 'image': return Image;
      case 'audio': return Music;
      case 'template': return Sparkles;
      default: return FileText;
    }
  }, []);

  // Get status color
  const getStatusColor = useCallback((status: Project['status']) => {
    switch (status) {
      case 'completed': return 'bg-green-500/20 text-green-300';
      case 'in-progress': return 'bg-yellow-500/20 text-yellow-300';
      case 'draft': return 'bg-gray-500/20 text-gray-300';
      default: return 'bg-blue-500/20 text-blue-300';
    }
  }, []);

  // Format time ago
  const formatTimeAgo = useCallback((date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Baru saja';
    if (diffInHours < 24) return `${diffInHours} jam yang lalu`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays} hari yang lalu`;
    
    const diffInWeeks = Math.floor(diffInDays / 7);
    return `${diffInWeeks} minggu yang lalu`;
  }, []);

  return (
    <div className="w-full space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Clock className="h-6 w-6 text-purple-400" />
            Proyek Terakhir
          </h2>
          <p className="text-gray-400 mt-1">Kelola dan lanjutkan pekerjaan kreatif Anda</p>
        </div>
        
        <Button 
          className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
        >
          <Plus className="h-4 w-4 mr-2" />
          Buat Project Baru
        </Button>
      </div>

      {/* Search and Filters */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Cari proyek..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-gray-400 focus:border-purple-500"
              />
            </div>

            {/* Filters */}
            <div className="flex items-center gap-2">
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as any)}
                className="bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
              >
                <option value="all">Semua Tipe</option>
                <option value="document">Dokumen</option>
                <option value="video">Video</option>
                <option value="image">Gambar</option>
                <option value="audio">Audio</option>
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm"
              >
                <option value="recent">Terbaru</option>
                <option value="name">Nama</option>
                <option value="type">Tipe</option>
                <option value="size">Ukuran</option>
              </select>

              <div className="flex border border-slate-600 rounded-lg overflow-hidden">
                <Button
                  onClick={() => setViewMode('grid')}
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  className="rounded-none"
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  onClick={() => setViewMode('list')}
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  className="rounded-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Projects Grid/List */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAndSortedProjects.map((project) => {
            const Icon = getProjectIcon(project.type);
            return (
              <Card
                key={project.id}
                className="bg-slate-800/50 border-slate-700 hover:border-purple-500/50 transition-all duration-300 hover:scale-105 group cursor-pointer"
                onClick={() => onProjectOpen?.(project)}
              >
                <CardContent className="p-4">
                  {/* Project Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-purple-500/20 rounded-lg">
                        <Icon className="h-5 w-5 text-purple-400" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-white group-hover:text-purple-300 transition-colors line-clamp-1">
                          {project.title}
                        </h3>
                        <p className="text-sm text-gray-400 line-clamp-2 mt-1">
                          {project.description}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-1">
                      {project.premium && (
                        <Crown className="h-4 w-4 text-yellow-400" />
                      )}
                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleStar(project.id);
                        }}
                        variant="ghost"
                        size="sm"
                        className="p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Star className={`h-4 w-4 ${project.starred ? 'text-yellow-400 fill-current' : 'text-gray-400'}`} />
                      </Button>
                    </div>
                  </div>

                  {/* Project Info */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Badge className={getStatusColor(project.status)}>
                        {project.status === 'completed' ? 'Selesai' : 
                         project.status === 'in-progress' ? 'Sedang Dikerjakan' : 'Draft'}
                      </Badge>
                      <span className="text-xs text-gray-400">{project.size}</span>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {project.tags.slice(0, 3).map((tag) => (
                        <Badge key={tag} className="bg-slate-700 text-gray-300 text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {project.tags.length > 3 && (
                        <Badge className="bg-slate-700 text-gray-300 text-xs">
                          +{project.tags.length - 3}
                        </Badge>
                      )}
                    </div>

                    <div className="text-xs text-gray-400 flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {formatTimeAgo(project.lastModified)}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 mt-4 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        onProjectEdit?.(project);
                      }}
                      variant="outline"
                      size="sm"
                      className="flex-1 border-slate-600 hover:border-blue-500"
                    >
                      <Edit className="h-3 w-3 mr-1" />
                      Edit
                    </Button>
                    
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        duplicateProject(project);
                      }}
                      variant="outline"
                      size="sm"
                      className="border-slate-600 hover:border-green-500"
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                    
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteProject(project.id);
                      }}
                      variant="outline"
                      size="sm"
                      className="border-slate-600 hover:border-red-500 text-red-400 hover:text-red-300"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        /* List View */
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-0">
            <div className="divide-y divide-slate-700">
              {filteredAndSortedProjects.map((project) => {
                const Icon = getProjectIcon(project.type);
                return (
                  <div
                    key={project.id}
                    className="p-4 hover:bg-slate-700/50 cursor-pointer transition-colors group"
                    onClick={() => onProjectOpen?.(project)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <Icon className="h-5 w-5 text-purple-400" />
                        
                        <div className="flex-1">
                          <h3 className="font-medium text-white group-hover:text-purple-300 transition-colors">
                            {project.title}
                          </h3>
                          <p className="text-sm text-gray-400 mt-1">
                            {project.description}
                          </p>
                        </div>
                        
                        <div className="flex items-center gap-4 text-sm text-gray-400">
                          <Badge className={getStatusColor(project.status)}>
                            {project.status === 'completed' ? 'Selesai' : 
                             project.status === 'in-progress' ? 'Dikerjakan' : 'Draft'}
                          </Badge>
                          
                          <span>{project.size}</span>
                          <span>{formatTimeAgo(project.lastModified)}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        {project.starred && <Star className="h-4 w-4 text-yellow-400 fill-current" />}
                        {project.premium && <Crown className="h-4 w-4 text-yellow-400" />}
                        
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            onProjectEdit?.(project);
                          }}
                          variant="ghost"
                          size="sm"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            duplicateProject(project);
                          }}
                          variant="ghost"
                          size="sm"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteProject(project.id);
                          }}
                          variant="ghost"
                          size="sm"
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Empty State */}
      {filteredAndSortedProjects.length === 0 && (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="p-12 text-center">
            <FolderOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-white mb-2">Tidak ada proyek ditemukan</h3>
            <p className="text-gray-400 mb-4">
              {searchQuery || filterType !== 'all' 
                ? 'Coba ubah kriteria pencarian atau filter'
                : 'Mulai buat proyek kreatif pertama Anda'
              }
            </p>
            <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              <Plus className="h-4 w-4 mr-2" />
              Buat Project Baru
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}