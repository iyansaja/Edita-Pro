import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Grid3X3, 
  List, 
  Clock, 
  FileText, 
  Video, 
  Music, 
  Image,
  Play,
  Edit,
  Share,
  Download,
  MoreHorizontal,
  Calendar,
  Star,
  Eye
} from 'lucide-react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';

interface RecentProject {
  id: string;
  title: string;
  type: 'document' | 'video' | 'audio' | 'canvas' | 'image';
  thumbnail?: string;
  lastModified: Date;
  createdAt: Date;
  status: 'completed' | 'in-progress' | 'draft';
  size: string;
  duration?: string;
  progress?: number;
  tags: string[];
  isFavorite: boolean;
}

interface RecentProjectsViewProps {
  onProjectOpen?: (project: RecentProject) => void;
  onProjectEdit?: (project: RecentProject) => void;
}

export function RecentProjectsView({ onProjectOpen, onProjectEdit }: RecentProjectsViewProps) {
  const [, setLocation] = useLocation();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [hoveredProject, setHoveredProject] = useState<string | null>(null);

  // Fetch recent projects from database
  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['/api/projects/recent'],
    queryFn: async () => {
      const response = await fetch('/api/projects/recent');
      if (!response.ok) {
        throw new Error('Failed to fetch recent projects');
      }
      return response.json();
    }
  });

  const getTypeIcon = (type: RecentProject['type']) => {
    switch (type) {
      case 'document':
        return <FileText className="h-5 w-5" />;
      case 'video':
        return <Video className="h-5 w-5" />;
      case 'audio':
        return <Music className="h-5 w-5" />;
      case 'canvas':
        return <Image className="h-5 w-5" />;
      case 'image':
        return <Image className="h-5 w-5" />;
    }
  };

  const getStatusColor = (status: RecentProject['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500';
      case 'in-progress':
        return 'bg-yellow-500';
      case 'draft':
        return 'bg-gray-500';
    }
  };

  const getStatusText = (status: RecentProject['status']) => {
    switch (status) {
      case 'completed':
        return 'Selesai';
      case 'in-progress':
        return 'Sedang Dikerjakan';
      case 'draft':
        return 'Draft';
    }
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return 'Baru saja';
    } else if (diffInHours < 24) {
      return `${diffInHours} jam yang lalu`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays} hari yang lalu`;
    }
  };

  const handleProjectClick = (project: RecentProject) => {
    setLocation(`/editor?project=${project.id}&type=${project.type}`);
    onProjectOpen?.(project);
  };

  const handleEditProject = (project: RecentProject, e: React.MouseEvent) => {
    e.stopPropagation();
    setLocation(`/editor?project=${project.id}&mode=edit`);
    onProjectEdit?.(project);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Clock className="h-6 w-6 text-purple-400" />
              Proyek Terakhir
            </h2>
            <p className="text-gray-400">Memuat proyek terbaru...</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-64 bg-gray-800/50 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  // Grid View Component
  const GridView = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {projects.map((project: RecentProject) => (
        <Card
          key={project.id}
          className="bg-gradient-to-br from-slate-800/80 to-purple-900/80 border border-purple-500/30 hover:border-purple-400/60 transition-all duration-300 hover:scale-105 cursor-pointer group"
          onMouseEnter={() => setHoveredProject(project.id)}
          onMouseLeave={() => setHoveredProject(null)}
          onClick={() => handleProjectClick(project)}
        >
          <CardContent className="p-0">
            {/* Thumbnail */}
            <div className="relative h-40 bg-gradient-to-br from-purple-600/20 to-blue-600/20 rounded-t-lg overflow-hidden">
              <div className="w-full h-full flex items-center justify-center">
                <div className="text-6xl text-white/30">
                  {getTypeIcon(project.type)}
                </div>
              </div>

              {/* Favorite Star */}
              {project.isFavorite && (
                <div className="absolute top-3 left-3">
                  <Star className="h-5 w-5 text-yellow-400 fill-current" />
                </div>
              )}

              {/* Status Badge */}
              <div className="absolute top-3 right-3">
                <Badge className={`${getStatusColor(project.status)} text-white border-0 text-xs`}>
                  {getStatusText(project.status)}
                </Badge>
              </div>

              {/* Progress Bar */}
              {project.progress !== undefined && project.progress < 100 && (
                <div className="absolute bottom-0 left-0 w-full h-1 bg-black/30">
                  <div 
                    className="h-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-300"
                    style={{ width: `${project.progress}%` }}
                  />
                </div>
              )}

              {/* Hover Overlay */}
              {hoveredProject === project.id && (
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center gap-3 transition-all duration-300">
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleProjectClick(project);
                    }}
                    variant="default"
                    size="sm"
                    className="bg-purple-500 hover:bg-purple-600"
                  >
                    <Play className="h-4 w-4 mr-2" />
                    Buka
                  </Button>
                  <Button
                    onClick={(e) => handleEditProject(project, e)}
                    variant="default"
                    size="sm"
                    className="bg-blue-500 hover:bg-blue-600"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                </div>
              )}
            </div>

            {/* Content */}
            <div className="p-4 space-y-3">
              <div className="space-y-2">
                <h3 className="font-semibold text-white line-clamp-1 group-hover:text-purple-300 transition-colors">
                  {project.title}
                </h3>
                
                <div className="flex items-center justify-between text-sm text-gray-400">
                  <div className="flex items-center gap-1">
                    {getTypeIcon(project.type)}
                    <span className="capitalize">{project.type}</span>
                  </div>
                  {project.duration && (
                    <span>{project.duration}</span>
                  )}
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1">
                {project.tags.slice(0, 3).map((tag) => (
                  <Badge
                    key={tag}
                    variant="outline"
                    className="text-xs bg-purple-500/10 border-purple-500/30 text-purple-300"
                  >
                    {tag}
                  </Badge>
                ))}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between text-xs text-gray-500">
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {formatDate(new Date(project.lastModified))}
                </div>
                <span>{project.size}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  // List View Component
  const ListView = () => (
    <div className="space-y-3">
      {projects.map((project: RecentProject) => (
        <Card
          key={project.id}
          className="bg-gradient-to-r from-slate-800/80 to-purple-900/80 border border-purple-500/30 hover:border-purple-400/60 transition-all duration-300 cursor-pointer group"
          onClick={() => handleProjectClick(project)}
        >
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              {/* Icon */}
              <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-purple-600/20 to-blue-600/20 rounded-lg flex items-center justify-center">
                {getTypeIcon(project.type)}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-white truncate group-hover:text-purple-300 transition-colors">
                    {project.title}
                  </h3>
                  {project.isFavorite && (
                    <Star className="h-4 w-4 text-yellow-400 fill-current flex-shrink-0" />
                  )}
                </div>
                
                <div className="flex items-center gap-4 text-sm text-gray-400">
                  <span className="capitalize">{project.type}</span>
                  <span>{formatDate(new Date(project.lastModified))}</span>
                  <span>{project.size}</span>
                  {project.duration && <span>{project.duration}</span>}
                </div>

                {/* Progress */}
                {project.progress !== undefined && project.progress < 100 && (
                  <div className="mt-2 flex items-center gap-2">
                    <div className="flex-1 h-1 bg-gray-700 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-300"
                        style={{ width: `${project.progress}%` }}
                      />
                    </div>
                    <span className="text-xs text-gray-500">{project.progress}%</span>
                  </div>
                )}
              </div>

              {/* Status & Actions */}
              <div className="flex items-center gap-3">
                <Badge className={`${getStatusColor(project.status)} text-white border-0 text-xs`}>
                  {getStatusText(project.status)}
                </Badge>
                
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    onClick={(e) => handleEditProject(project, e)}
                    variant="ghost"
                    size="sm"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      console.log('Share project:', project.id);
                    }}
                    variant="ghost"
                    size="sm"
                  >
                    <Share className="h-4 w-4" />
                  </Button>
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      console.log('More options:', project.id);
                    }}
                    variant="ghost"
                    size="sm"
                  >
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Clock className="h-6 w-6 text-purple-400" />
            Proyek Terakhir
          </h2>
          <p className="text-gray-400">Lanjutkan pekerjaan dari sesi sebelumnya</p>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-2 bg-black/20 rounded-lg p-1">
          <Button
            onClick={() => setViewMode('grid')}
            variant={viewMode === 'grid' ? 'default' : 'ghost'}
            size="sm"
            className={viewMode === 'grid' ? 'bg-purple-500' : ''}
          >
            <Grid3X3 className="h-4 w-4" />
          </Button>
          <Button
            onClick={() => setViewMode('list')}
            variant={viewMode === 'list' ? 'default' : 'ghost'}
            size="sm"
            className={viewMode === 'list' ? 'bg-purple-500' : ''}
          >
            <List className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Projects Display */}
      {viewMode === 'grid' ? <GridView /> : <ListView />}

      {/* Empty State */}
      {projects.length === 0 && !isLoading && (
        <div className="text-center py-12">
          <Clock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">Belum ada proyek terbaru</h3>
          <p className="text-gray-400 mb-6">Mulai membuat proyek pertama Anda</p>
          <Button
            onClick={() => setLocation('/editor')}
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
          >
            <Edit className="h-4 w-4 mr-2" />
            Buat Proyek Baru
          </Button>
        </div>
      )}
    </div>
  );
}