import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Brain, 
  Eye, 
  EyeOff, 
  RotateCcw, 
  Download, 
  Upload,
  Zap,
  Layers,
  Target,
  Sparkles,
  Square,
  Circle,
  Settings,
  Play,
  Pause,
  User,
  Camera,
  Smartphone,
  Video,
  Wand2
} from 'lucide-react';

interface AISettings {
  precision: number;
  edgeSmoothing: number;
  confidence: number;
  noiseReduction: number;
  temporalConsistency: number;
  subjectFocus: 'person' | 'object' | 'auto';
  outputQuality: 'fast' | 'balanced' | 'precise';
}

interface AIBackgroundRemoverProps {
  videoUrl?: string;
  onProcessed?: (processedVideo: string) => void;
  onClose?: () => void;
}

export function AIBackgroundRemover({ videoUrl, onProcessed, onClose }: AIBackgroundRemoverProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [previewMode, setPreviewMode] = useState<'original' | 'processed' | 'mask'>('processed');
  const [activeTab, setActiveTab] = useState<'quick' | 'advanced' | 'preview'>('quick');
  const [isPlaying, setIsPlaying] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  
  const [aiSettings, setAiSettings] = useState<AISettings>({
    precision: 85,
    edgeSmoothing: 15,
    confidence: 80,
    noiseReduction: 20,
    temporalConsistency: 70,
    subjectFocus: 'person',
    outputQuality: 'balanced'
  });

  const [selectedVideo, setSelectedVideo] = useState<string>(videoUrl || '');
  const [detectedSubjects, setDetectedSubjects] = useState<Array<{
    id: string;
    type: 'person' | 'object';
    confidence: number;
    bbox: { x: number; y: number; width: number; height: number };
  }>>([]);

  // Quick presets for different content types
  const quickPresets = [
    {
      id: 'portrait',
      name: 'Portrait/Selfie',
      icon: User,
      description: 'Optimal untuk video selfie dan portrait',
      settings: { precision: 90, edgeSmoothing: 20, confidence: 85, subjectFocus: 'person' as const }
    },
    {
      id: 'vlog',
      name: 'Vlog/Talking',
      icon: Camera,
      description: 'Cocok untuk video vlog dan presentasi',
      settings: { precision: 85, edgeSmoothing: 15, confidence: 80, subjectFocus: 'person' as const }
    },
    {
      id: 'tiktok',
      name: 'TikTok/Social',
      icon: Smartphone,
      description: 'Disesuaikan untuk konten media sosial',
      settings: { precision: 80, edgeSmoothing: 25, confidence: 75, subjectFocus: 'auto' as const }
    },
    {
      id: 'product',
      name: 'Product Demo',
      icon: Square,
      description: 'Untuk video demo produk dan unboxing',
      settings: { precision: 95, edgeSmoothing: 10, confidence: 90, subjectFocus: 'object' as const }
    }
  ];

  // AI processing quality options
  const qualityOptions = [
    { id: 'fast', name: 'Fast', description: 'Cepat untuk preview', time: '~2 min' },
    { id: 'balanced', name: 'Balanced', description: 'Seimbang kualitas & kecepatan', time: '~5 min' },
    { id: 'precise', name: 'Precise', description: 'Kualitas maksimal', time: '~10 min' }
  ];

  // Handle file upload
  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setSelectedVideo(url);
    }
  }, []);

  // Update AI setting
  const updateSetting = useCallback((key: keyof AISettings, value: number | string) => {
    setAiSettings(prev => ({
      ...prev,
      [key]: value
    }));
  }, []);

  // Apply preset settings
  const applyPreset = useCallback((preset: typeof quickPresets[0]) => {
    setAiSettings(prev => ({
      ...prev,
      ...preset.settings
    }));
  }, []);

  // Simulate AI background removal (in real implementation, this would call an AI service)
  const processWithAI = useCallback(async () => {
    setIsProcessing(true);
    setProcessingProgress(0);
    
    try {
      // Simulate AI processing steps
      const steps = [
        'Analyzing video frames...',
        'Detecting subjects...',
        'Generating alpha masks...',
        'Applying temporal smoothing...',
        'Finalizing output...'
      ];
      
      for (let i = 0; i < steps.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        setProcessingProgress((i + 1) / steps.length * 100);
      }
      
      // Simulate subject detection
      setDetectedSubjects([
        {
          id: '1',
          type: 'person',
          confidence: 0.95,
          bbox: { x: 100, y: 50, width: 200, height: 300 }
        }
      ]);
      
      // In real implementation, this would be the processed video URL
      const processedUrl = selectedVideo; // Placeholder
      onProcessed?.(processedUrl);
      
    } catch (error) {
      console.error('AI processing failed:', error);
    } finally {
      setIsProcessing(false);
      setProcessingProgress(0);
    }
  }, [selectedVideo, aiSettings, onProcessed]);

  // Handle play/pause
  const handlePlayPause = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    
    if (isPlaying) {
      video.pause();
    } else {
      video.play();
    }
    setIsPlaying(!isPlaying);
  }, [isPlaying]);

  // Calculate quality score based on settings
  const qualityScore = Math.round(
    (aiSettings.precision + aiSettings.confidence + aiSettings.edgeSmoothing) / 3
  );

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-blue-900/80 to-purple-900/80 border border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Brain className="h-6 w-6 text-blue-400" />
              AI Background Remover
              <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white border-0 ml-auto">
                <Sparkles className="h-3 w-3 mr-1" />
                Powered by AI
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Video Preview */}
          <div className="lg:col-span-2 space-y-4">
            {/* Upload Section */}
            {!selectedVideo && (
              <Card className="bg-slate-800/50 border-dashed border-blue-500/30">
                <CardContent className="p-8 text-center">
                  <Upload className="h-12 w-12 mx-auto mb-4 text-blue-400" />
                  <h3 className="text-lg font-semibold text-white mb-2">Upload Video for AI Processing</h3>
                  <p className="text-gray-400 mb-4">AI akan mendeteksi dan menghapus background secara otomatis</p>
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Select Video File
                  </Button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="video/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </CardContent>
              </Card>
            )}

            {/* Video Player & Processing */}
            {selectedVideo && (
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardContent className="p-4">
                  <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                    {/* Original Video */}
                    <video
                      ref={videoRef}
                      src={selectedVideo}
                      className="w-full h-full object-contain"
                      loop
                      muted
                    />
                    
                    {/* AI Processing Overlay */}
                    {isProcessing && (
                      <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                        <div className="text-center space-y-4">
                          <div className="w-16 h-16 mx-auto">
                            <Brain className="w-full h-full text-blue-400 animate-pulse" />
                          </div>
                          <div className="text-white">
                            <div className="text-lg font-semibold mb-2">AI Processing...</div>
                            <div className="w-64 h-2 bg-gray-600 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-300"
                                style={{ width: `${processingProgress}%` }}
                              />
                            </div>
                            <div className="text-sm text-gray-400 mt-2">{processingProgress.toFixed(0)}% Complete</div>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {/* Subject Detection Overlay */}
                    {detectedSubjects.length > 0 && !isProcessing && (
                      <div className="absolute inset-0">
                        {detectedSubjects.map((subject) => (
                          <div
                            key={subject.id}
                            className="absolute border-2 border-green-400 rounded"
                            style={{
                              left: `${subject.bbox.x}px`,
                              top: `${subject.bbox.y}px`,
                              width: `${subject.bbox.width}px`,
                              height: `${subject.bbox.height}px`
                            }}
                          >
                            <Badge className="absolute -top-6 left-0 bg-green-500 text-white border-0">
                              {subject.type} ({(subject.confidence * 100).toFixed(0)}%)
                            </Badge>
                          </div>
                        ))}
                      </div>
                    )}
                    
                    {/* Overlay Controls */}
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Button
                          onClick={handlePlayPause}
                          variant="outline"
                          size="sm"
                          className="bg-black/60 border-white/20 hover:bg-white/20"
                        >
                          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Button
                          onClick={() => setPreviewMode(prev => 
                            prev === 'original' ? 'processed' : prev === 'processed' ? 'mask' : 'original'
                          )}
                          variant="outline"
                          size="sm"
                          className="bg-black/60 border-white/20 hover:bg-white/20"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          {previewMode}
                        </Button>
                        
                        <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                          {previewMode === 'original' ? 'Original' : 
                           previewMode === 'processed' ? 'AI Processed' : 'Alpha Mask'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Controls Panel */}
          <div className="space-y-4">
            <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
              <TabsList className="grid w-full grid-cols-3 bg-slate-700/50">
                <TabsTrigger value="quick" className="data-[state=active]:bg-blue-500">
                  <Zap className="h-4 w-4 mr-1" />
                  Quick
                </TabsTrigger>
                <TabsTrigger value="advanced" className="data-[state=active]:bg-blue-500">
                  <Settings className="h-4 w-4 mr-1" />
                  Advanced
                </TabsTrigger>
                <TabsTrigger value="preview" className="data-[state=active]:bg-blue-500">
                  <Eye className="h-4 w-4 mr-1" />
                  Preview
                </TabsTrigger>
              </TabsList>

              {/* Quick Presets */}
              <TabsContent value="quick" className="space-y-4">
                <Card className="bg-slate-800/50 border-blue-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Content Type Presets</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {quickPresets.map((preset) => {
                      const Icon = preset.icon;
                      return (
                        <Button
                          key={preset.id}
                          onClick={() => applyPreset(preset)}
                          variant="outline"
                          className="w-full h-auto p-4 border-blue-500/30 hover:bg-blue-500/20 text-left"
                        >
                          <div className="flex items-start gap-3 w-full">
                            <div className="p-2 bg-blue-500/20 rounded-lg">
                              <Icon className="h-5 w-5 text-blue-400" />
                            </div>
                            <div className="flex-1">
                              <div className="text-white font-medium">{preset.name}</div>
                              <div className="text-gray-400 text-sm">{preset.description}</div>
                            </div>
                          </div>
                        </Button>
                      );
                    })}
                  </CardContent>
                </Card>

                {/* Processing Quality */}
                <Card className="bg-slate-800/50 border-purple-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Processing Quality</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {qualityOptions.map((option) => (
                      <Button
                        key={option.id}
                        onClick={() => updateSetting('outputQuality', option.id)}
                        variant={aiSettings.outputQuality === option.id ? "default" : "outline"}
                        className={`w-full h-auto p-3 text-left ${
                          aiSettings.outputQuality === option.id 
                            ? "bg-purple-500 text-white" 
                            : "border-purple-500/30 hover:bg-purple-500/20"
                        }`}
                      >
                        <div className="w-full">
                          <div className="flex justify-between items-center mb-1">
                            <span className="font-medium">{option.name}</span>
                            <span className="text-xs opacity-70">{option.time}</span>
                          </div>
                          <div className="text-sm opacity-70">{option.description}</div>
                        </div>
                      </Button>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Advanced Controls */}
              <TabsContent value="advanced" className="space-y-4">
                <Card className="bg-slate-800/50 border-indigo-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">AI Fine-Tuning</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Precision */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">AI Precision</label>
                        <Badge className="bg-indigo-500/20 text-indigo-300 border-0">
                          {aiSettings.precision}%
                        </Badge>
                      </div>
                      <Slider
                        value={[aiSettings.precision]}
                        onValueChange={([value]) => updateSetting('precision', value)}
                        max={100}
                        min={50}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    {/* Edge Smoothing */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Edge Smoothing</label>
                        <Badge className="bg-blue-500/20 text-blue-300 border-0">
                          {aiSettings.edgeSmoothing}%
                        </Badge>
                      </div>
                      <Slider
                        value={[aiSettings.edgeSmoothing]}
                        onValueChange={([value]) => updateSetting('edgeSmoothing', value)}
                        max={50}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    {/* Confidence Threshold */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Confidence</label>
                        <Badge className="bg-green-500/20 text-green-300 border-0">
                          {aiSettings.confidence}%
                        </Badge>
                      </div>
                      <Slider
                        value={[aiSettings.confidence]}
                        onValueChange={([value]) => updateSetting('confidence', value)}
                        max={100}
                        min={50}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    {/* Temporal Consistency */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Temporal Smoothing</label>
                        <Badge className="bg-yellow-500/20 text-yellow-300 border-0">
                          {aiSettings.temporalConsistency}%
                        </Badge>
                      </div>
                      <Slider
                        value={[aiSettings.temporalConsistency]}
                        onValueChange={([value]) => updateSetting('temporalConsistency', value)}
                        max={100}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Preview & Export */}
              <TabsContent value="preview" className="space-y-4">
                <Card className="bg-slate-800/50 border-green-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">AI Processing</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Quality Score */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-300">Quality Score</span>
                        <Badge className={`border-0 ${
                          qualityScore >= 85 ? 'bg-green-500/20 text-green-300' :
                          qualityScore >= 70 ? 'bg-yellow-500/20 text-yellow-300' :
                          'bg-red-500/20 text-red-300'
                        }`}>
                          {qualityScore}%
                        </Badge>
                      </div>
                      <div className="w-full h-2 bg-gray-600 rounded-full overflow-hidden">
                        <div 
                          className={`h-full transition-all duration-300 ${
                            qualityScore >= 85 ? 'bg-green-500' :
                            qualityScore >= 70 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${qualityScore}%` }}
                        />
                      </div>
                    </div>

                    {/* Start Processing */}
                    <Button
                      onClick={processWithAI}
                      disabled={isProcessing || !selectedVideo}
                      className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                    >
                      {isProcessing ? (
                        <>
                          <Brain className="h-4 w-4 mr-2 animate-pulse" />
                          Processing with AI...
                        </>
                      ) : (
                        <>
                          <Wand2 className="h-4 w-4 mr-2" />
                          Start AI Processing
                        </>
                      )}
                    </Button>

                    <Button
                      onClick={() => {
                        setAiSettings({
                          precision: 85,
                          edgeSmoothing: 15,
                          confidence: 80,
                          noiseReduction: 20,
                          temporalConsistency: 70,
                          subjectFocus: 'person',
                          outputQuality: 'balanced'
                        });
                      }}
                      variant="outline"
                      className="w-full border-gray-500/30 hover:bg-gray-500/20"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset to Default
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}