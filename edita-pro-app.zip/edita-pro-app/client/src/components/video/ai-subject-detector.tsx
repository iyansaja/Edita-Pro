import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Brain, 
  Eye, 
  Target,
  User,
  Package,
  Zap,
  Settings,
  Layers,
  Sparkles,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface DetectedSubject {
  id: string;
  type: 'person' | 'object' | 'animal' | 'vehicle';
  confidence: number;
  bbox: { x: number; y: number; width: number; height: number };
  label: string;
  selected: boolean;
}

interface AISubjectDetectorProps {
  onSubjectsDetected?: (subjects: DetectedSubject[]) => void;
  onSelectionChange?: (selectedIds: string[]) => void;
}

export function AISubjectDetector({ onSubjectsDetected, onSelectionChange }: AISubjectDetectorProps) {
  const [isDetecting, setIsDetecting] = useState(false);
  const [detectionMode, setDetectionMode] = useState<'auto' | 'person' | 'object'>('auto');
  const [confidenceThreshold, setConfidenceThreshold] = useState(75);
  const [detectedSubjects, setDetectedSubjects] = useState<DetectedSubject[]>([]);

  // Mock subjects for demonstration
  const mockSubjects: DetectedSubject[] = [
    {
      id: '1',
      type: 'person',
      confidence: 0.96,
      bbox: { x: 150, y: 80, width: 200, height: 350 },
      label: 'Person',
      selected: true
    },
    {
      id: '2',
      type: 'object',
      confidence: 0.84,
      bbox: { x: 50, y: 200, width: 80, height: 120 },
      label: 'Chair',
      selected: false
    },
    {
      id: '3',
      type: 'object',
      confidence: 0.78,
      bbox: { x: 300, y: 150, width: 100, height: 180 },
      label: 'Table',
      selected: false
    }
  ];

  const startDetection = useCallback(async () => {
    setIsDetecting(true);
    
    // Simulate AI detection process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const filteredSubjects = mockSubjects.filter(
      subject => subject.confidence * 100 >= confidenceThreshold
    );
    
    setDetectedSubjects(filteredSubjects);
    setIsDetecting(false);
    onSubjectsDetected?.(filteredSubjects);
  }, [confidenceThreshold, onSubjectsDetected]);

  const toggleSubjectSelection = useCallback((subjectId: string) => {
    const updatedSubjects = detectedSubjects.map(subject =>
      subject.id === subjectId 
        ? { ...subject, selected: !subject.selected }
        : subject
    );
    
    setDetectedSubjects(updatedSubjects);
    
    const selectedIds = updatedSubjects
      .filter(subject => subject.selected)
      .map(subject => subject.id);
    
    onSelectionChange?.(selectedIds);
  }, [detectedSubjects, onSelectionChange]);

  const selectAllSubjects = useCallback(() => {
    const updatedSubjects = detectedSubjects.map(subject => ({
      ...subject,
      selected: true
    }));
    
    setDetectedSubjects(updatedSubjects);
    onSelectionChange?.(updatedSubjects.map(s => s.id));
  }, [detectedSubjects, onSelectionChange]);

  const deselectAllSubjects = useCallback(() => {
    const updatedSubjects = detectedSubjects.map(subject => ({
      ...subject,
      selected: false
    }));
    
    setDetectedSubjects(updatedSubjects);
    onSelectionChange?.([]);
  }, [detectedSubjects, onSelectionChange]);

  const getSubjectIcon = (type: DetectedSubject['type']) => {
    switch (type) {
      case 'person': return User;
      case 'object': return Package;
      case 'animal': return Target;
      case 'vehicle': return Target;
      default: return Target;
    }
  };

  const getSubjectColor = (type: DetectedSubject['type']) => {
    switch (type) {
      case 'person': return 'text-blue-400 border-blue-400';
      case 'object': return 'text-green-400 border-green-400';
      case 'animal': return 'text-yellow-400 border-yellow-400';
      case 'vehicle': return 'text-purple-400 border-purple-400';
      default: return 'text-gray-400 border-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-blue-900/80 to-indigo-900/80 border border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Brain className="h-5 w-5 text-blue-400" />
            AI Subject Detection
            <Badge className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white border-0 ml-auto">
              <Sparkles className="h-3 w-3 mr-1" />
              Neural Network
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Detection Controls */}
      <Card className="bg-slate-800/50 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Settings className="h-4 w-4 text-blue-400" />
            Detection Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Detection Mode */}
          <div className="space-y-2">
            <label className="text-sm text-gray-300">Detection Mode</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'auto', name: 'Auto Detect', icon: Zap },
                { id: 'person', name: 'Person Only', icon: User },
                { id: 'object', name: 'Objects Only', icon: Package }
              ].map(({ id, name, icon: Icon }) => (
                <Button
                  key={id}
                  onClick={() => setDetectionMode(id as any)}
                  variant={detectionMode === id ? "default" : "outline"}
                  size="sm"
                  className={detectionMode === id 
                    ? "bg-blue-500 text-white" 
                    : "border-blue-500/30 hover:bg-blue-500/20"
                  }
                >
                  <Icon className="h-4 w-4 mr-1" />
                  {name}
                </Button>
              ))}
            </div>
          </div>

          {/* Confidence Threshold */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-sm text-gray-300">Confidence Threshold</label>
              <Badge className="bg-indigo-500/20 text-indigo-300 border-0">
                {confidenceThreshold}%
              </Badge>
            </div>
            <Slider
              value={[confidenceThreshold]}
              onValueChange={([value]) => setConfidenceThreshold(value)}
              max={100}
              min={50}
              step={5}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>Less Accurate</span>
              <span>More Accurate</span>
            </div>
          </div>

          {/* Start Detection */}
          <Button
            onClick={startDetection}
            disabled={isDetecting}
            className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
          >
            {isDetecting ? (
              <>
                <Brain className="h-4 w-4 mr-2 animate-pulse" />
                Detecting Subjects...
              </>
            ) : (
              <>
                <Eye className="h-4 w-4 mr-2" />
                Start AI Detection
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Detected Subjects */}
      {detectedSubjects.length > 0 && (
        <Card className="bg-slate-800/50 border-green-500/30">
          <CardHeader>
            <CardTitle className="text-white text-sm flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-green-400" />
                Detected Subjects ({detectedSubjects.length})
              </div>
              <div className="flex items-center gap-2">
                <Button
                  onClick={selectAllSubjects}
                  variant="outline"
                  size="sm"
                  className="border-green-500/30 hover:bg-green-500/20 text-green-300"
                >
                  Select All
                </Button>
                <Button
                  onClick={deselectAllSubjects}
                  variant="outline"
                  size="sm"
                  className="border-gray-500/30 hover:bg-gray-500/20"
                >
                  Clear
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {detectedSubjects.map((subject) => {
              const Icon = getSubjectIcon(subject.type);
              const colorClass = getSubjectColor(subject.type);
              
              return (
                <div
                  key={subject.id}
                  className={`p-3 rounded-lg border transition-all cursor-pointer ${
                    subject.selected 
                      ? 'bg-blue-500/20 border-blue-400' 
                      : 'bg-slate-700/50 border-slate-600 hover:border-slate-500'
                  }`}
                  onClick={() => toggleSubjectSelection(subject.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded border ${colorClass}`}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-white font-medium">{subject.label}</div>
                        <div className="text-gray-400 text-sm">
                          Confidence: {(subject.confidence * 100).toFixed(0)}%
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Badge className={`border-0 ${
                        subject.confidence >= 0.9 ? 'bg-green-500/20 text-green-300' :
                        subject.confidence >= 0.75 ? 'bg-yellow-500/20 text-yellow-300' :
                        'bg-red-500/20 text-red-300'
                      }`}>
                        {subject.type}
                      </Badge>
                      
                      {subject.selected ? (
                        <CheckCircle className="h-5 w-5 text-blue-400" />
                      ) : (
                        <AlertCircle className="h-5 w-5 text-gray-500" />
                      )}
                    </div>
                  </div>
                  
                  {/* Bounding Box Info */}
                  <div className="mt-2 text-xs text-gray-500">
                    Position: ({subject.bbox.x}, {subject.bbox.y}) • 
                    Size: {subject.bbox.width}×{subject.bbox.height}
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Statistics */}
      {detectedSubjects.length > 0 && (
        <div className="grid grid-cols-2 gap-4">
          <Card className="bg-slate-800/50 border-blue-500/30">
            <CardContent className="p-4 text-center">
              <Eye className="h-6 w-6 mx-auto mb-2 text-blue-400" />
              <div className="text-lg font-bold text-white">
                {detectedSubjects.length}
              </div>
              <div className="text-xs text-gray-400">Total Detected</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardContent className="p-4 text-center">
              <CheckCircle className="h-6 w-6 mx-auto mb-2 text-green-400" />
              <div className="text-lg font-bold text-white">
                {detectedSubjects.filter(s => s.selected).length}
              </div>
              <div className="text-xs text-gray-400">Selected</div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}