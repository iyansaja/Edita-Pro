import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Layers, 
  Eye, 
  EyeOff, 
  Lock,
  Unlock,
  Move,
  Copy,
  Trash2,
  Volume2,
  VolumeX,
  Image,
  Video,
  Type,
  Music,
  Plus,
  Settings,
  ArrowUp,
  ArrowDown,
  Scissors,
  RotateCw,
  Palette,
  Blend,
  Circle
} from 'lucide-react';

interface TimelineLayer {
  id: string;
  name: string;
  type: 'video' | 'audio' | 'image' | 'text' | 'effect';
  visible: boolean;
  locked: boolean;
  opacity: number;
  blendMode: string;
  startTime: number;
  duration: number;
  position: { x: number; y: number };
  scale: number;
  rotation: number;
  color?: string;
  content?: string;
  src?: string;
  volume?: number;
}

interface MultilayerTimelineProps {
  onLayersChange?: (layers: TimelineLayer[]) => void;
  projectDuration?: number;
}

export function MultilayerTimeline({ onLayersChange, projectDuration = 60 }: MultilayerTimelineProps) {
  const timelineRef = useRef<HTMLDivElement>(null);
  const [layers, setLayers] = useState<TimelineLayer[]>([
    {
      id: 'layer_1',
      name: 'Background Video',
      type: 'video',
      visible: true,
      locked: false,
      opacity: 100,
      blendMode: 'normal',
      startTime: 0,
      duration: 30,
      position: { x: 0, y: 0 },
      scale: 1,
      rotation: 0,
      src: 'video1.mp4'
    },
    {
      id: 'layer_2',
      name: 'Overlay Image',
      type: 'image',
      visible: true,
      locked: false,
      opacity: 80,
      blendMode: 'multiply',
      startTime: 5,
      duration: 20,
      position: { x: 100, y: 50 },
      scale: 0.8,
      rotation: 0,
      src: 'overlay.png'
    },
    {
      id: 'layer_3',
      name: 'Title Text',
      type: 'text',
      visible: true,
      locked: false,
      opacity: 100,
      blendMode: 'normal',
      startTime: 2,
      duration: 8,
      position: { x: 200, y: 100 },
      scale: 1.2,
      rotation: 0,
      content: 'VIRAL VIDEO',
      color: '#ffffff'
    },
    {
      id: 'layer_4',
      name: 'Background Music',
      type: 'audio',
      visible: true,
      locked: false,
      opacity: 100,
      blendMode: 'normal',
      startTime: 0,
      duration: 30,
      position: { x: 0, y: 0 },
      scale: 1,
      rotation: 0,
      volume: 70,
      src: 'music.mp3'
    }
  ]);

  const [selectedLayer, setSelectedLayer] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [snapToGrid, setSnapToGrid] = useState(true);

  const blendModes = [
    'normal', 'multiply', 'screen', 'overlay', 'soft-light', 
    'hard-light', 'color-dodge', 'color-burn', 'darken', 
    'lighten', 'difference', 'exclusion'
  ];

  const layerTypes = [
    { id: 'video', name: 'Video', icon: Video, color: 'bg-blue-500' },
    { id: 'image', name: 'Image', icon: Image, color: 'bg-green-500' },
    { id: 'text', name: 'Text', icon: Type, color: 'bg-purple-500' },
    { id: 'audio', name: 'Audio', icon: Music, color: 'bg-orange-500' }
  ];

  // Add new layer
  const addLayer = useCallback((type: TimelineLayer['type']) => {
    const newLayer: TimelineLayer = {
      id: `layer_${Date.now()}`,
      name: `New ${type.charAt(0).toUpperCase() + type.slice(1)}`,
      type,
      visible: true,
      locked: false,
      opacity: 100,
      blendMode: 'normal',
      startTime: currentTime,
      duration: 10,
      position: { x: 0, y: 0 },
      scale: 1,
      rotation: 0,
      ...(type === 'text' && { content: 'Sample Text', color: '#ffffff' }),
      ...(type === 'audio' && { volume: 70 })
    };
    
    setLayers(prev => [...prev, newLayer]);
    setSelectedLayer(newLayer.id);
  }, [currentTime]);

  // Update layer property
  const updateLayer = useCallback((layerId: string, updates: Partial<TimelineLayer>) => {
    setLayers(prev => 
      prev.map(layer => 
        layer.id === layerId ? { ...layer, ...updates } : layer
      )
    );
  }, []);

  // Delete layer
  const deleteLayer = useCallback((layerId: string) => {
    setLayers(prev => prev.filter(layer => layer.id !== layerId));
    if (selectedLayer === layerId) {
      setSelectedLayer(null);
    }
  }, [selectedLayer]);

  // Duplicate layer
  const duplicateLayer = useCallback((layerId: string) => {
    const layer = layers.find(l => l.id === layerId);
    if (!layer) return;
    
    const duplicatedLayer: TimelineLayer = {
      ...layer,
      id: `layer_${Date.now()}`,
      name: `${layer.name} Copy`,
      startTime: layer.startTime + layer.duration
    };
    
    setLayers(prev => [...prev, duplicatedLayer]);
  }, [layers]);

  // Move layer up/down in stack
  const moveLayer = useCallback((layerId: string, direction: 'up' | 'down') => {
    setLayers(prev => {
      const index = prev.findIndex(l => l.id === layerId);
      if (index === -1) return prev;
      
      const newIndex = direction === 'up' ? index - 1 : index + 1;
      if (newIndex < 0 || newIndex >= prev.length) return prev;
      
      const newLayers = [...prev];
      [newLayers[index], newLayers[newIndex]] = [newLayers[newIndex], newLayers[index]];
      return newLayers;
    });
  }, []);

  // Get layer color based on type
  const getLayerColor = useCallback((type: TimelineLayer['type']) => {
    switch (type) {
      case 'video': return 'bg-blue-500';
      case 'image': return 'bg-green-500';
      case 'text': return 'bg-purple-500';
      case 'audio': return 'bg-orange-500';
      case 'effect': return 'bg-pink-500';
      default: return 'bg-gray-500';
    }
  }, []);

  // Calculate timeline position
  const getTimelinePosition = useCallback((time: number) => {
    return (time / projectDuration) * 100;
  }, [projectDuration]);

  // Handle timeline click
  const handleTimelineClick = useCallback((e: React.MouseEvent) => {
    if (!timelineRef.current) return;
    
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    const newTime = percentage * projectDuration;
    
    setCurrentTime(Math.max(0, Math.min(projectDuration, newTime)));
  }, [projectDuration]);

  // Format time
  const formatTime = useCallback((seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, []);

  // Update layers callback
  useEffect(() => {
    onLayersChange?.(layers);
  }, [layers, onLayersChange]);

  const selectedLayerData = selectedLayer ? layers.find(l => l.id === selectedLayer) : null;

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 text-white overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Layers className="h-6 w-6 text-indigo-400" />
              Multilayer Timeline Editor
              <Badge className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-0 ml-auto">
                <Layers className="h-3 w-3 mr-1" />
                Professional
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Timeline & Preview */}
          <div className="lg:col-span-3 space-y-4">
            {/* Timeline Controls */}
            <Card className="bg-slate-800/50 border-indigo-500/30">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Button
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="bg-indigo-500 hover:bg-indigo-600 w-12 h-12 rounded-full"
                    >
                      {isPlaying ? '⏸️' : '▶️'}
                    </Button>
                    
                    <div className="text-white font-mono">
                      {formatTime(currentTime)} / {formatTime(projectDuration)}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      onClick={() => setSnapToGrid(!snapToGrid)}
                      variant={snapToGrid ? "default" : "outline"}
                      size="sm"
                      className={snapToGrid ? "bg-purple-500" : "border-purple-500/30"}
                    >
                      Snap
                    </Button>
                    
                    <Slider
                      value={[zoomLevel]}
                      onValueChange={([value]) => setZoomLevel(value)}
                      max={3}
                      min={0.5}
                      step={0.1}
                      className="w-20"
                    />
                    
                    <span className="text-sm text-gray-400">{zoomLevel.toFixed(1)}x</span>
                  </div>
                </div>

                {/* Timeline Track */}
                <div 
                  ref={timelineRef}
                  className="relative h-64 bg-slate-700/50 rounded-lg cursor-pointer overflow-auto"
                  onClick={handleTimelineClick}
                >
                  {/* Time ruler */}
                  <div className="absolute top-0 left-0 right-0 h-8 bg-slate-600/50 border-b border-slate-500">
                    {Array.from({ length: Math.ceil(projectDuration / 5) + 1 }).map((_, i) => (
                      <div
                        key={i}
                        className="absolute text-xs text-gray-400 transform -translate-x-1/2"
                        style={{ left: `${(i * 5 / projectDuration) * 100}%`, top: '4px' }}
                      >
                        {formatTime(i * 5)}
                      </div>
                    ))}
                  </div>

                  {/* Layers */}
                  <div className="absolute top-8 left-0 right-0 bottom-0">
                    {layers.map((layer, index) => (
                      <div
                        key={layer.id}
                        className="relative h-12 border-b border-slate-600/50"
                        style={{ top: `${index * 48}px` }}
                      >
                        {/* Layer track */}
                        <div
                          className={`absolute h-10 rounded cursor-pointer transition-all duration-200 ${
                            getLayerColor(layer.type)
                          } ${
                            selectedLayer === layer.id ? 'ring-2 ring-yellow-400 scale-105' : ''
                          } ${
                            !layer.visible ? 'opacity-50' : ''
                          }`}
                          style={{
                            left: `${getTimelinePosition(layer.startTime)}%`,
                            width: `${(layer.duration / projectDuration) * 100}%`,
                            opacity: layer.opacity / 100
                          }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedLayer(layer.id);
                          }}
                        >
                          <div className="p-2 text-white text-xs font-medium truncate">
                            {layer.name}
                          </div>
                          
                          {/* Blend mode indicator */}
                          {layer.blendMode !== 'normal' && (
                            <Badge className="absolute top-0 right-1 text-xs bg-black/50 text-white border-0">
                              {layer.blendMode}
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Playhead */}
                  <div 
                    className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10"
                    style={{ left: `${getTimelinePosition(currentTime)}%` }}
                  >
                    <div className="absolute -top-2 -left-2 w-4 h-4 bg-red-500 rounded-full" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Layer Controls */}
          <div className="space-y-4">
            {/* Add Layer */}
            <Card className="bg-slate-800/50 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Plus className="h-4 w-4 text-green-400" />
                  Add Layer
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {layerTypes.map((type) => {
                  const Icon = type.icon;
                  return (
                    <Button
                      key={type.id}
                      onClick={() => addLayer(type.id as TimelineLayer['type'])}
                      variant="outline"
                      className="w-full justify-start border-green-500/30 hover:bg-green-500/20"
                    >
                      <Icon className="h-4 w-4 mr-2 text-green-400" />
                      {type.name}
                    </Button>
                  );
                })}
              </CardContent>
            </Card>

            {/* Layer List */}
            <Card className="bg-slate-800/50 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Layers className="h-4 w-4 text-purple-400" />
                  Layers ({layers.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-64 overflow-y-auto">
                {layers.map((layer, index) => (
                  <div
                    key={layer.id}
                    className={`p-2 rounded border transition-all cursor-pointer ${
                      selectedLayer === layer.id 
                        ? 'bg-purple-500/20 border-purple-400' 
                        : 'bg-slate-700/50 border-slate-600 hover:border-slate-500'
                    }`}
                    onClick={() => setSelectedLayer(layer.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded ${getLayerColor(layer.type)}`} />
                        <span className="text-white text-sm font-medium">{layer.name}</span>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            updateLayer(layer.id, { visible: !layer.visible });
                          }}
                          variant="ghost"
                          size="sm"
                          className="p-1 h-6 w-6"
                        >
                          {layer.visible ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                        </Button>
                        
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            updateLayer(layer.id, { locked: !layer.locked });
                          }}
                          variant="ghost"
                          size="sm"
                          className="p-1 h-6 w-6"
                        >
                          {layer.locked ? <Lock className="h-3 w-3" /> : <Unlock className="h-3 w-3" />}
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mt-1 text-xs text-gray-400">
                      <span>{layer.type}</span>
                      <span>{layer.opacity}%</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Selected Layer Properties */}
            {selectedLayerData && (
              <Card className="bg-slate-800/50 border-yellow-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <Settings className="h-4 w-4 text-yellow-400" />
                    Layer Properties
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Layer Name */}
                  <div>
                    <label className="text-xs text-gray-400">Name</label>
                    <input
                      type="text"
                      value={selectedLayerData.name}
                      onChange={(e) => updateLayer(selectedLayerData.id, { name: e.target.value })}
                      className="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-white text-sm"
                    />
                  </div>

                  {/* Opacity */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs text-gray-400">Opacity</label>
                      <Badge className="bg-yellow-500/20 text-yellow-300 border-0 text-xs">
                        {selectedLayerData.opacity}%
                      </Badge>
                    </div>
                    <Slider
                      value={[selectedLayerData.opacity]}
                      onValueChange={([value]) => updateLayer(selectedLayerData.id, { opacity: value })}
                      max={100}
                      min={0}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* Blend Mode */}
                  <div>
                    <label className="text-xs text-gray-400 mb-2 block">Blend Mode</label>
                    <select
                      value={selectedLayerData.blendMode}
                      onChange={(e) => updateLayer(selectedLayerData.id, { blendMode: e.target.value })}
                      className="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-white text-sm"
                    >
                      {blendModes.map((mode) => (
                        <option key={mode} value={mode}>
                          {mode.charAt(0).toUpperCase() + mode.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Duration */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs text-gray-400">Duration</label>
                      <Badge className="bg-blue-500/20 text-blue-300 border-0 text-xs">
                        {selectedLayerData.duration}s
                      </Badge>
                    </div>
                    <Slider
                      value={[selectedLayerData.duration]}
                      onValueChange={([value]) => updateLayer(selectedLayerData.id, { duration: value })}
                      max={60}
                      min={1}
                      step={0.5}
                      className="w-full"
                    />
                  </div>

                  {/* Audio Volume (for audio layers) */}
                  {selectedLayerData.type === 'audio' && (
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-xs text-gray-400">Volume</label>
                        <Badge className="bg-orange-500/20 text-orange-300 border-0 text-xs">
                          {selectedLayerData.volume}%
                        </Badge>
                      </div>
                      <Slider
                        value={[selectedLayerData.volume || 70]}
                        onValueChange={([value]) => updateLayer(selectedLayerData.id, { volume: value })}
                        max={100}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>
                  )}

                  {/* Layer Actions */}
                  <div className="grid grid-cols-2 gap-2 pt-2">
                    <Button
                      onClick={() => duplicateLayer(selectedLayerData.id)}
                      variant="outline"
                      size="sm"
                      className="border-green-500/30 hover:bg-green-500/20"
                    >
                      <Copy className="h-3 w-3 mr-1" />
                      Duplicate
                    </Button>
                    
                    <Button
                      onClick={() => deleteLayer(selectedLayerData.id)}
                      variant="outline"
                      size="sm"
                      className="border-red-500/30 hover:bg-red-500/20 text-red-300"
                    >
                      <Trash2 className="h-3 w-3 mr-1" />
                      Delete
                    </Button>
                  </div>

                  {/* Layer Order */}
                  <div className="flex items-center gap-2">
                    <Button
                      onClick={() => moveLayer(selectedLayerData.id, 'up')}
                      variant="outline"
                      size="sm"
                      className="flex-1 border-purple-500/30 hover:bg-purple-500/20"
                    >
                      <ArrowUp className="h-3 w-3 mr-1" />
                      Up
                    </Button>
                    
                    <Button
                      onClick={() => moveLayer(selectedLayerData.id, 'down')}
                      variant="outline"
                      size="sm"
                      className="flex-1 border-purple-500/30 hover:bg-purple-500/20"
                    >
                      <ArrowDown className="h-3 w-3 mr-1" />
                      Down
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Timeline Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-slate-800/50 border-blue-500/30">
            <CardContent className="p-4 text-center">
              <Layers className="h-6 w-6 mx-auto mb-2 text-blue-400" />
              <div className="text-lg font-bold text-white">{layers.length}</div>
              <div className="text-xs text-gray-400">Total Layers</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardContent className="p-4 text-center">
              <Eye className="h-6 w-6 mx-auto mb-2 text-green-400" />
              <div className="text-lg font-bold text-white">{layers.filter(l => l.visible).length}</div>
              <div className="text-xs text-gray-400">Visible</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-purple-500/30">
            <CardContent className="p-4 text-center">
              <Blend className="h-6 w-6 mx-auto mb-2 text-purple-400" />
              <div className="text-lg font-bold text-white">{layers.filter(l => l.blendMode !== 'normal').length}</div>
              <div className="text-xs text-gray-400">Blended</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-yellow-500/30">
            <CardContent className="p-4 text-center">
              <Circle className="h-6 w-6 mx-auto mb-2 text-yellow-400" />
              <div className="text-lg font-bold text-white">{Math.round(layers.reduce((sum, l) => sum + l.opacity, 0) / layers.length)}%</div>
              <div className="text-xs text-gray-400">Avg Opacity</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}