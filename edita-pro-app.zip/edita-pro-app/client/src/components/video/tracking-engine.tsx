import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Target, 
  Brain, 
  Eye,
  Zap,
  Settings,
  Crosshair,
  Move,
  RotateCcw,
  Activity,
  TrendingUp,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';

interface TrackingAnalytics {
  accuracy: number;
  stability: number;
  speed: number;
  confidence: number;
  framesProcesed: number;
  lostFrames: number;
}

interface TrackingEngineProps {
  onTrackingUpdate?: (data: any) => void;
}

export function TrackingEngine({ onTrackingUpdate }: TrackingEngineProps) {
  const [isActive, setIsActive] = useState(false);
  const [trackingMethod, setTrackingMethod] = useState<'optical' | 'feature' | 'hybrid'>('hybrid');
  const [analytics, setAnalytics] = useState<TrackingAnalytics>({
    accuracy: 94,
    stability: 88,
    speed: 60,
    confidence: 92,
    framesProcesed: 1240,
    lostFrames: 12
  });

  const [engineSettings, setEngineSettings] = useState({
    motionPrediction: 85,
    errorCorrection: 70,
    adaptiveTracking: 90,
    temporalSmoothing: 65,
    featureDetection: 80,
    noiseReduction: 75
  });

  const trackingMethods = [
    {
      id: 'optical',
      name: 'Optical Flow',
      description: 'Best for smooth motion',
      accuracy: 85,
      speed: 95,
      complexity: 'Low'
    },
    {
      id: 'feature',
      name: 'Feature Based',
      description: 'Best for detailed objects',
      accuracy: 95,
      speed: 70,
      complexity: 'High'
    },
    {
      id: 'hybrid',
      name: 'Hybrid AI',
      description: 'Best overall performance',
      accuracy: 92,
      speed: 80,
      complexity: 'Medium'
    }
  ];

  const updateSetting = useCallback((key: string, value: number) => {
    setEngineSettings(prev => ({
      ...prev,
      [key]: value
    }));
  }, []);

  const toggleTracking = useCallback(() => {
    setIsActive(!isActive);
    
    if (!isActive) {
      // Simulate real-time analytics updates
      const interval = setInterval(() => {
        setAnalytics(prev => ({
          ...prev,
          framesProcesed: prev.framesProcesed + Math.floor(Math.random() * 5) + 1,
          accuracy: Math.max(85, Math.min(98, prev.accuracy + (Math.random() - 0.5) * 2)),
          stability: Math.max(80, Math.min(95, prev.stability + (Math.random() - 0.5) * 3)),
          confidence: Math.max(85, Math.min(98, prev.confidence + (Math.random() - 0.5) * 2))
        }));
      }, 1000);
      
      // Clean up interval when stopping
      setTimeout(() => {
        if (isActive) clearInterval(interval);
      }, 100);
    }
  }, [isActive]);

  const resetTracking = useCallback(() => {
    setAnalytics({
      accuracy: 94,
      stability: 88,
      speed: 60,
      confidence: 92,
      framesProcesed: 0,
      lostFrames: 0
    });
  }, []);

  const getStatusColor = (value: number) => {
    if (value >= 90) return 'text-green-400 bg-green-500/20 border-green-500/30';
    if (value >= 75) return 'text-yellow-400 bg-yellow-500/20 border-yellow-500/30';
    return 'text-red-400 bg-red-500/20 border-red-500/30';
  };

  const getPerformanceRating = () => {
    const avgScore = (analytics.accuracy + analytics.stability + analytics.confidence) / 3;
    if (avgScore >= 90) return { label: 'Excellent', color: 'text-green-400' };
    if (avgScore >= 80) return { label: 'Good', color: 'text-yellow-400' };
    if (avgScore >= 70) return { label: 'Fair', color: 'text-orange-400' };
    return { label: 'Poor', color: 'text-red-400' };
  };

  const performance = getPerformanceRating();

  return (
    <div className="space-y-6">
      {/* Engine Status */}
      <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${isActive ? 'bg-green-500/20' : 'bg-gray-500/20'}`}>
                <Target className={`h-5 w-5 ${isActive ? 'text-green-400 animate-pulse' : 'text-gray-400'}`} />
              </div>
              <div>
                <h3 className="text-white font-semibold">Tracking Engine</h3>
                <p className="text-gray-400 text-sm">
                  {isActive ? 'Active - Real-time tracking' : 'Standby - Ready to track'}
                </p>
              </div>
            </div>
            
            <div className="text-right">
              <div className={`text-lg font-bold ${performance.color}`}>
                {performance.label}
              </div>
              <div className="text-xs text-gray-400">Performance</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tracking Method Selection */}
      <Card className="bg-slate-800/50 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Brain className="h-4 w-4 text-blue-400" />
            Tracking Algorithm
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {trackingMethods.map((method) => (
            <Button
              key={method.id}
              onClick={() => setTrackingMethod(method.id as any)}
              variant={trackingMethod === method.id ? "default" : "outline"}
              className={`w-full h-auto p-4 text-left ${
                trackingMethod === method.id 
                  ? "bg-blue-500 text-white" 
                  : "border-blue-500/30 hover:bg-blue-500/20"
              }`}
            >
              <div className="w-full">
                <div className="flex justify-between items-start mb-2">
                  <span className="font-medium">{method.name}</span>
                  <Badge className="bg-blue-500/20 text-blue-300 border-0 text-xs">
                    {method.complexity}
                  </Badge>
                </div>
                <div className="text-sm opacity-70 mb-2">{method.description}</div>
                <div className="flex justify-between text-xs">
                  <span>Accuracy: {method.accuracy}%</span>
                  <span>Speed: {method.speed}%</span>
                </div>
              </div>
            </Button>
          ))}
        </CardContent>
      </Card>

      {/* Real-time Analytics */}
      <Card className="bg-slate-800/50 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Activity className="h-4 w-4 text-green-400" />
            Real-time Analytics
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Key Metrics */}
          <div className="grid grid-cols-2 gap-3">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{analytics.accuracy}%</div>
              <div className="text-xs text-gray-400">Accuracy</div>
              <div className="w-full h-1 bg-gray-600 rounded-full mt-1">
                <div 
                  className="h-full bg-green-500 rounded-full transition-all duration-300"
                  style={{ width: `${analytics.accuracy}%` }}
                />
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{analytics.stability}%</div>
              <div className="text-xs text-gray-400">Stability</div>
              <div className="w-full h-1 bg-gray-600 rounded-full mt-1">
                <div 
                  className="h-full bg-blue-500 rounded-full transition-all duration-300"
                  style={{ width: `${analytics.stability}%` }}
                />
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{analytics.confidence}%</div>
              <div className="text-xs text-gray-400">Confidence</div>
              <div className="w-full h-1 bg-gray-600 rounded-full mt-1">
                <div 
                  className="h-full bg-purple-500 rounded-full transition-all duration-300"
                  style={{ width: `${analytics.confidence}%` }}
                />
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{analytics.framesProcesed}</div>
              <div className="text-xs text-gray-400">Frames</div>
              <div className="text-xs text-green-400">+{analytics.speed} fps</div>
            </div>
          </div>

          {/* Status Indicators */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Tracking Quality</span>
              <Badge className={getStatusColor(analytics.accuracy)}>
                {analytics.accuracy >= 90 ? 'Excellent' : analytics.accuracy >= 75 ? 'Good' : 'Fair'}
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Lost Frames</span>
              <Badge className={analytics.lostFrames < 20 ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}>
                {analytics.lostFrames}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Engine Settings */}
      <Card className="bg-slate-800/50 border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Settings className="h-4 w-4 text-purple-400" />
            Engine Fine-Tuning
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {Object.entries(engineSettings).map(([key, value]) => (
            <div key={key} className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm text-gray-300 capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </label>
                <Badge className="bg-purple-500/20 text-purple-300 border-0">
                  {value}%
                </Badge>
              </div>
              <Slider
                value={[value]}
                onValueChange={([newValue]) => updateSetting(key, newValue)}
                max={100}
                min={0}
                step={5}
                className="w-full"
              />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Control Actions */}
      <div className="grid grid-cols-2 gap-3">
        <Button
          onClick={toggleTracking}
          className={`w-full ${
            isActive 
              ? 'bg-red-500 hover:bg-red-600' 
              : 'bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600'
          }`}
        >
          {isActive ? (
            <>
              <Eye className="h-4 w-4 mr-2" />
              Stop Tracking
            </>
          ) : (
            <>
              <Crosshair className="h-4 w-4 mr-2" />
              Start Tracking
            </>
          )}
        </Button>
        
        <Button
          onClick={resetTracking}
          variant="outline"
          className="border-gray-500/30 hover:bg-gray-500/20"
        >
          <RotateCcw className="h-4 w-4 mr-2" />
          Reset
        </Button>
      </div>

      {/* Performance Insights */}
      <Card className="bg-gradient-to-r from-slate-800/50 to-indigo-900/20 border border-indigo-500/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-indigo-400" />
              <span className="text-sm text-white">Performance Insights</span>
            </div>
            <div className="flex items-center gap-4 text-xs text-gray-400">
              <div className="flex items-center gap-1">
                <CheckCircle className="h-3 w-3 text-green-400" />
                <span>Optimized</span>
              </div>
              {analytics.lostFrames > 10 && (
                <div className="flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3 text-yellow-400" />
                  <span>Adjustment Needed</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}