import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Sparkles, 
  Eye, 
  Heart,
  Palette,
  Smile,
  Star,
  Zap,
  Settings,
  RotateCcw,
  Download,
  Wand2
} from 'lucide-react';

interface MakeupSettings {
  foundation: number;
  concealer: number;
  blush: number;
  highlighter: number;
  bronzer: number;
  eyeshadow: number;
  eyeliner: number;
  mascara: number;
  eyebrows: number;
  lipstick: number;
  lipGloss: number;
  contour: number;
}

interface BeautyEngineProps {
  onSettingsChange?: (settings: any) => void;
}

export function BeautyEngine({ onSettingsChange }: BeautyEngineProps) {
  const [makeupSettings, setMakeupSettings] = useState<MakeupSettings>({
    foundation: 40,
    concealer: 30,
    blush: 25,
    highlighter: 20,
    bronzer: 15,
    eyeshadow: 35,
    eyeliner: 30,
    mascara: 40,
    eyebrows: 25,
    lipstick: 45,
    lipGloss: 20,
    contour: 15
  });

  const [selectedMakeupStyle, setSelectedMakeupStyle] = useState('natural');
  const [beautyMode, setBeautyMode] = useState<'auto' | 'manual'>('auto');

  const makeupStyles = [
    {
      id: 'natural',
      name: 'Natural',
      description: 'Everyday natural look',
      color: 'bg-green-500',
      settings: { foundation: 30, blush: 20, lipstick: 25, mascara: 30 }
    },
    {
      id: 'glam',
      name: 'Glamour',
      description: 'Bold evening look',
      color: 'bg-purple-500',
      settings: { foundation: 60, eyeshadow: 70, eyeliner: 60, lipstick: 80 }
    },
    {
      id: 'korean',
      name: 'K-Beauty',
      description: 'Korean beauty style',
      color: 'bg-pink-500',
      settings: { foundation: 50, blush: 40, highlighter: 45, lipstick: 35 }
    },
    {
      id: 'western',
      name: 'Western',
      description: 'Western makeup style',
      color: 'bg-orange-500',
      settings: { foundation: 45, contour: 40, bronzer: 35, lipstick: 60 }
    }
  ];

  const makeupCategories = [
    {
      name: 'Base Makeup',
      items: [
        { key: 'foundation', label: 'Foundation', icon: Palette, color: 'bg-orange-500/20 text-orange-300' },
        { key: 'concealer', label: 'Concealer', icon: Sparkles, color: 'bg-yellow-500/20 text-yellow-300' },
        { key: 'contour', label: 'Contour', icon: Settings, color: 'bg-brown-500/20 text-brown-300' },
        { key: 'highlighter', label: 'Highlighter', icon: Star, color: 'bg-white/20 text-white' }
      ]
    },
    {
      name: 'Eyes',
      items: [
        { key: 'eyeshadow', label: 'Eyeshadow', icon: Eye, color: 'bg-purple-500/20 text-purple-300' },
        { key: 'eyeliner', label: 'Eyeliner', icon: Eye, color: 'bg-black/20 text-gray-300' },
        { key: 'mascara', label: 'Mascara', icon: Eye, color: 'bg-gray-500/20 text-gray-300' },
        { key: 'eyebrows', label: 'Eyebrows', icon: Eye, color: 'bg-brown-500/20 text-brown-300' }
      ]
    },
    {
      name: 'Lips & Cheeks',
      items: [
        { key: 'blush', label: 'Blush', icon: Heart, color: 'bg-pink-500/20 text-pink-300' },
        { key: 'bronzer', label: 'Bronzer', icon: Sparkles, color: 'bg-amber-500/20 text-amber-300' },
        { key: 'lipstick', label: 'Lipstick', icon: Heart, color: 'bg-red-500/20 text-red-300' },
        { key: 'lipGloss', label: 'Lip Gloss', icon: Sparkles, color: 'bg-pink-500/20 text-pink-300' }
      ]
    }
  ];

  const updateMakeupSetting = useCallback((key: keyof MakeupSettings, value: number) => {
    const newSettings = { ...makeupSettings, [key]: value };
    setMakeupSettings(newSettings);
    onSettingsChange?.(newSettings);
  }, [makeupSettings, onSettingsChange]);

  const applyMakeupStyle = useCallback((style: typeof makeupStyles[0]) => {
    const newSettings = { ...makeupSettings, ...style.settings };
    setMakeupSettings(newSettings);
    setSelectedMakeupStyle(style.id);
    onSettingsChange?.(newSettings);
  }, [makeupSettings, onSettingsChange]);

  const resetMakeup = useCallback(() => {
    const resetSettings: MakeupSettings = {
      foundation: 0,
      concealer: 0,
      blush: 0,
      highlighter: 0,
      bronzer: 0,
      eyeshadow: 0,
      eyeliner: 0,
      mascara: 0,
      eyebrows: 0,
      lipstick: 0,
      lipGloss: 0,
      contour: 0
    };
    setMakeupSettings(resetSettings);
    onSettingsChange?.(resetSettings);
  }, [onSettingsChange]);

  const getMakeupIntensity = useCallback(() => {
    const total = Object.values(makeupSettings).reduce((sum, value) => sum + value, 0);
    return Math.round(total / Object.keys(makeupSettings).length);
  }, [makeupSettings]);

  return (
    <div className="space-y-6">
      {/* Beauty Engine Header */}
      <Card className="bg-gradient-to-r from-pink-900/80 to-purple-900/80 border border-pink-500/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-pink-500/20 rounded-lg">
                <Sparkles className="h-5 w-5 text-pink-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold">AI Beauty Engine</h3>
                <p className="text-gray-400 text-sm">Virtual makeup & beautification</p>
              </div>
            </div>
            
            <div className="text-right">
              <div className="text-2xl font-bold text-pink-400">{getMakeupIntensity()}%</div>
              <div className="text-xs text-gray-400">Makeup Intensity</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Makeup Styles */}
      <Card className="bg-slate-800/50 border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Palette className="h-4 w-4 text-purple-400" />
            Makeup Styles
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            {makeupStyles.map((style) => (
              <Button
                key={style.id}
                onClick={() => applyMakeupStyle(style)}
                variant={selectedMakeupStyle === style.id ? "default" : "outline"}
                className={`h-auto p-4 text-left ${
                  selectedMakeupStyle === style.id 
                    ? "bg-purple-500 text-white" 
                    : "border-purple-500/30 hover:bg-purple-500/20"
                }`}
              >
                <div className="w-full">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`w-3 h-3 rounded-full ${style.color}`} />
                    <span className="font-medium">{style.name}</span>
                  </div>
                  <div className="text-xs opacity-70">{style.description}</div>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Detailed Makeup Controls */}
      {makeupCategories.map((category) => (
        <Card key={category.name} className="bg-slate-800/50 border-pink-500/30">
          <CardHeader>
            <CardTitle className="text-white text-sm">{category.name}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {category.items.map((item) => {
              const Icon = item.icon;
              const value = makeupSettings[item.key as keyof MakeupSettings];
              
              return (
                <div key={item.key} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <Icon className="h-4 w-4 text-pink-400" />
                      <label className="text-sm text-gray-300">{item.label}</label>
                    </div>
                    <Badge className={`border-0 ${item.color}`}>
                      {value}%
                    </Badge>
                  </div>
                  <Slider
                    value={[value]}
                    onValueChange={([newValue]) => updateMakeupSetting(item.key as keyof MakeupSettings, newValue)}
                    max={100}
                    min={0}
                    step={1}
                    className="w-full"
                  />
                </div>
              );
            })}
          </CardContent>
        </Card>
      ))}

      {/* Beauty Mode Toggle */}
      <Card className="bg-slate-800/50 border-indigo-500/30">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Zap className="h-4 w-4 text-indigo-400" />
            Beauty Mode
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={() => setBeautyMode('auto')}
              variant={beautyMode === 'auto' ? "default" : "outline"}
              className={beautyMode === 'auto' 
                ? "bg-indigo-500 text-white" 
                : "border-indigo-500/30 hover:bg-indigo-500/20"
              }
            >
              <Wand2 className="h-4 w-4 mr-2" />
              Auto AI
            </Button>
            <Button
              onClick={() => setBeautyMode('manual')}
              variant={beautyMode === 'manual' ? "default" : "outline"}
              className={beautyMode === 'manual' 
                ? "bg-indigo-500 text-white" 
                : "border-indigo-500/30 hover:bg-indigo-500/20"
              }
            >
              <Settings className="h-4 w-4 mr-2" />
              Manual
            </Button>
          </div>
          
          <div className="text-xs text-gray-400 text-center">
            {beautyMode === 'auto' 
              ? 'AI automatically adjusts makeup based on face detection'
              : 'Manual control over each makeup element'
            }
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-3">
        <Button
          onClick={resetMakeup}
          variant="outline"
          className="border-gray-500/30 hover:bg-gray-500/20"
        >
          <RotateCcw className="h-4 w-4 mr-2" />
          Reset
        </Button>
        
        <Button
          className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
        >
          <Download className="h-4 w-4 mr-2" />
          Apply
        </Button>
      </div>

      {/* Makeup Analytics */}
      <Card className="bg-gradient-to-r from-slate-800/50 to-pink-900/20 border border-pink-500/20">
        <CardContent className="p-4">
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center gap-2">
              <Sparkles className="h-4 w-4 text-pink-400" />
              <span className="text-sm text-white">Makeup Analysis</span>
            </div>
            <div className="grid grid-cols-3 gap-4 text-xs text-gray-400">
              <div className="text-center">
                <div className="text-pink-400 font-bold">
                  {Object.values(makeupSettings).filter(v => v > 0).length}
                </div>
                <div>Active</div>
              </div>
              <div className="text-center">
                <div className="text-purple-400 font-bold">{getMakeupIntensity()}%</div>
                <div>Intensity</div>
              </div>
              <div className="text-center">
                <div className="text-blue-400 font-bold">
                  {selectedMakeupStyle.charAt(0).toUpperCase() + selectedMakeupStyle.slice(1)}
                </div>
                <div>Style</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}