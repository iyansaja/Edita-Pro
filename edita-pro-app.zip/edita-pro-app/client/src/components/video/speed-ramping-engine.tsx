import React, { useState, useCallback, useEffect } from 'react';
import { SpeedControl } from './speed-control';
import { VideoTimeline } from './video-timeline';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Film, 
  Zap, 
  Square, 
  Play, 
  Download, 
  Settings,
  TrendingUp,
  TrendingDown,
  RotateCcw,
  Sparkles,
  Clock,
  Gauge
} from 'lucide-react';

interface SpeedKeyframe {
  id: string;
  time: number;
  speed: number;
  easing: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out' | 'bounce';
}

interface FreezeFrame {
  id: string;
  time: number;
  duration: number;
}

interface TimelineMarker {
  id: string;
  time: number;
  type: 'speed' | 'freeze' | 'cut' | 'marker';
  value?: number;
  duration?: number;
  color: string;
}

interface SpeedRampingEngineProps {
  videoDuration: number;
  onExport?: (data: any) => void;
}

export function SpeedRampingEngine({ videoDuration = 60, onExport }: SpeedRampingEngineProps) {
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(75);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [speedKeyframes, setSpeedKeyframes] = useState<SpeedKeyframe[]>([
    { id: '1', time: 0, speed: 1, easing: 'linear' },
    { id: '2', time: videoDuration, speed: 1, easing: 'linear' }
  ]);
  const [freezeFrames, setFreezeFrames] = useState<FreezeFrame[]>([]);
  const [activeTab, setActiveTab] = useState<'timeline' | 'speed' | 'export'>('timeline');

  // Generate timeline markers from speed keyframes and freeze frames
  const timelineMarkers: TimelineMarker[] = [
    ...speedKeyframes.map(kf => ({
      id: `speed_${kf.id}`,
      time: kf.time,
      type: 'speed' as const,
      value: kf.speed,
      color: 'bg-blue-500'
    })),
    ...freezeFrames.map(ff => ({
      id: `freeze_${ff.id}`,
      time: ff.time,
      type: 'freeze' as const,
      duration: ff.duration,
      color: 'bg-indigo-500'
    }))
  ];

  // Calculate current speed based on keyframes
  const getCurrentSpeed = useCallback((time: number) => {
    for (let i = 0; i < speedKeyframes.length - 1; i++) {
      const current = speedKeyframes[i];
      const next = speedKeyframes[i + 1];
      
      if (time >= current.time && time <= next.time) {
        const progress = (time - current.time) / (next.time - current.time);
        
        // Apply easing
        let easedProgress = progress;
        switch (current.easing) {
          case 'ease-in':
            easedProgress = progress * progress;
            break;
          case 'ease-out':
            easedProgress = 1 - Math.pow(1 - progress, 2);
            break;
          case 'ease-in-out':
            easedProgress = progress < 0.5 
              ? 2 * progress * progress 
              : 1 - Math.pow(-2 * progress + 2, 2) / 2;
            break;
          case 'bounce':
            easedProgress = 1 - Math.pow(1 - progress, 3) * Math.cos(progress * Math.PI * 3);
            break;
          default:
            easedProgress = progress;
        }
        
        return current.speed + (next.speed - current.speed) * easedProgress;
      }
    }
    return speedKeyframes[speedKeyframes.length - 1]?.speed || 1;
  }, [speedKeyframes]);

  // Handle play/pause
  const handlePlayPause = useCallback(() => {
    setIsPlaying(!isPlaying);
  }, [isPlaying]);

  // Handle time change
  const handleTimeChange = useCallback((time: number) => {
    setCurrentTime(Math.max(0, Math.min(videoDuration, time)));
  }, [videoDuration]);

  // Handle speed keyframe changes
  const handleSpeedKeyframesChange = useCallback((keyframes: SpeedKeyframe[]) => {
    setSpeedKeyframes(keyframes);
  }, []);

  // Handle marker addition
  const handleMarkerAdd = useCallback((time: number, type: string) => {
    if (type === 'speed') {
      const newKeyframe: SpeedKeyframe = {
        id: `keyframe_${Date.now()}`,
        time,
        speed: getCurrentSpeed(time),
        easing: 'ease-in-out'
      };
      const newKeyframes = [...speedKeyframes, newKeyframe].sort((a, b) => a.time - b.time);
      setSpeedKeyframes(newKeyframes);
    } else if (type === 'freeze') {
      const newFreeze: FreezeFrame = {
        id: `freeze_${Date.now()}`,
        time,
        duration: 2
      };
      setFreezeFrames([...freezeFrames, newFreeze]);
    }
  }, [speedKeyframes, freezeFrames, getCurrentSpeed]);

  // Update playback speed based on current time
  useEffect(() => {
    const currentSpeed = getCurrentSpeed(currentTime);
    setPlaybackSpeed(currentSpeed);
  }, [currentTime, getCurrentSpeed]);

  // Simulate video playback
  useEffect(() => {
    if (!isPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentTime(prev => {
        const newTime = prev + 0.1 * playbackSpeed;
        if (newTime >= videoDuration) {
          setIsPlaying(false);
          return videoDuration;
        }
        return newTime;
      });
    }, 100);
    
    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed, videoDuration]);

  // Export functionality
  const handleExport = useCallback(() => {
    const exportData = {
      duration: videoDuration,
      speedKeyframes,
      freezeFrames,
      settings: {
        volume,
        playbackSpeed
      },
      metadata: {
        totalKeyframes: speedKeyframes.length,
        totalFreezeFrames: freezeFrames.length,
        avgSpeed: speedKeyframes.reduce((sum, kf) => sum + kf.speed, 0) / speedKeyframes.length,
        exportedAt: new Date().toISOString()
      }
    };
    
    onExport?.(exportData);
    
    // Create downloadable file
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `speed-ramping-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [videoDuration, speedKeyframes, freezeFrames, volume, playbackSpeed, onExport]);

  // Speed analysis
  const speedAnalysis = {
    totalSlowMotion: speedKeyframes.filter(kf => kf.speed < 1).length,
    totalFastMotion: speedKeyframes.filter(kf => kf.speed > 1).length,
    maxSpeed: Math.max(...speedKeyframes.map(kf => kf.speed)),
    minSpeed: Math.min(...speedKeyframes.map(kf => kf.speed)),
    totalFreezeTime: freezeFrames.reduce((sum, ff) => sum + ff.duration, 0)
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Film className="h-6 w-6 text-purple-400" />
            Advanced Speed Ramping Engine
            <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white border-0 ml-auto">
              <Sparkles className="h-3 w-3 mr-1" />
              Professional Grade
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Main Interface */}
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
        <TabsList className="grid w-full grid-cols-3 bg-slate-700/50">
          <TabsTrigger value="timeline" className="data-[state=active]:bg-purple-500">
            <Clock className="h-4 w-4 mr-2" />
            Timeline
          </TabsTrigger>
          <TabsTrigger value="speed" className="data-[state=active]:bg-purple-500">
            <Gauge className="h-4 w-4 mr-2" />
            Speed Control
          </TabsTrigger>
          <TabsTrigger value="export" className="data-[state=active]:bg-purple-500">
            <Download className="h-4 w-4 mr-2" />
            Export
          </TabsTrigger>
        </TabsList>

        {/* Timeline Tab */}
        <TabsContent value="timeline" className="space-y-4">
          <VideoTimeline
            duration={videoDuration}
            currentTime={currentTime}
            isPlaying={isPlaying}
            volume={volume}
            playbackSpeed={playbackSpeed}
            markers={timelineMarkers}
            onTimeChange={handleTimeChange}
            onPlayPause={handlePlayPause}
            onVolumeChange={setVolume}
            onSpeedChange={setPlaybackSpeed}
            onMarkerAdd={handleMarkerAdd}
          />
          
          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-slate-800/50 border-blue-500/30">
              <CardContent className="p-3 text-center">
                <TrendingDown className="h-6 w-6 mx-auto mb-1 text-orange-400" />
                <div className="text-lg font-bold text-white">{speedAnalysis.totalSlowMotion}</div>
                <div className="text-xs text-gray-400">Slow Motion</div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-800/50 border-green-500/30">
              <CardContent className="p-3 text-center">
                <TrendingUp className="h-6 w-6 mx-auto mb-1 text-blue-400" />
                <div className="text-lg font-bold text-white">{speedAnalysis.totalFastMotion}</div>
                <div className="text-xs text-gray-400">Fast Motion</div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-800/50 border-indigo-500/30">
              <CardContent className="p-3 text-center">
                <Square className="h-6 w-6 mx-auto mb-1 text-indigo-400" />
                <div className="text-lg font-bold text-white">{freezeFrames.length}</div>
                <div className="text-xs text-gray-400">Freeze Frames</div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-800/50 border-purple-500/30">
              <CardContent className="p-3 text-center">
                <Zap className="h-6 w-6 mx-auto mb-1 text-purple-400" />
                <div className="text-lg font-bold text-white">{speedAnalysis.maxSpeed.toFixed(1)}x</div>
                <div className="text-xs text-gray-400">Max Speed</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Speed Control Tab */}
        <TabsContent value="speed" className="space-y-4">
          <SpeedControl
            duration={videoDuration}
            currentTime={currentTime}
            isPlaying={isPlaying}
            onSpeedChange={handleSpeedKeyframesChange}
            onPlayPause={handlePlayPause}
          />
        </TabsContent>

        {/* Export Tab */}
        <TabsContent value="export" className="space-y-4">
          <Card className="bg-gradient-to-br from-slate-800/80 to-purple-900/80 border border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Download className="h-5 w-5 text-green-400" />
                Export Speed Ramping Project
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Project Summary */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h3 className="text-white font-medium">Project Overview</h3>
                  <div className="space-y-2 text-sm text-gray-300">
                    <div className="flex justify-between">
                      <span>Duration:</span>
                      <span>{(videoDuration / 60).toFixed(1)} minutes</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Speed Keyframes:</span>
                      <span>{speedKeyframes.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Freeze Frames:</span>
                      <span>{freezeFrames.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Speed Range:</span>
                      <span>{speedAnalysis.minSpeed.toFixed(1)}x - {speedAnalysis.maxSpeed.toFixed(1)}x</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h3 className="text-white font-medium">Export Options</h3>
                  <div className="space-y-2">
                    <Button
                      onClick={handleExport}
                      className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export JSON Project
                    </Button>
                    
                    <Button
                      variant="outline"
                      className="w-full border-purple-500/30 hover:bg-purple-500/20"
                    >
                      <Film className="h-4 w-4 mr-2" />
                      Render Video
                    </Button>
                    
                    <Button
                      variant="outline"
                      className="w-full border-gray-500/30 hover:bg-gray-500/20"
                    >
                      <Settings className="h-4 w-4 mr-2" />
                      Advanced Settings
                    </Button>
                  </div>
                </div>
              </div>

              {/* Effects Preview */}
              <div className="space-y-3">
                <h3 className="text-white font-medium">Applied Effects</h3>
                <div className="flex flex-wrap gap-2">
                  {speedAnalysis.totalSlowMotion > 0 && (
                    <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/30">
                      <TrendingDown className="h-3 w-3 mr-1" />
                      {speedAnalysis.totalSlowMotion} Slow Motion
                    </Badge>
                  )}
                  {speedAnalysis.totalFastMotion > 0 && (
                    <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {speedAnalysis.totalFastMotion} Fast Motion
                    </Badge>
                  )}
                  {freezeFrames.length > 0 && (
                    <Badge className="bg-indigo-500/20 text-indigo-300 border-indigo-500/30">
                      <Square className="h-3 w-3 mr-1" />
                      {freezeFrames.length} Freeze Frames
                    </Badge>
                  )}
                  {speedAnalysis.maxSpeed > 5 && (
                    <Badge className="bg-red-500/20 text-red-300 border-red-500/30">
                      <Zap className="h-3 w-3 mr-1" />
                      Extreme Speed
                    </Badge>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}