import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Zap, 
  Timer, 
  TrendingUp, 
  TrendingDown,
  Square,
  SkipBack,
  SkipForward,
  ChevronUp,
  ChevronDown,
  Gauge,
  Clock,
  Sparkles
} from 'lucide-react';

interface SpeedKeyframe {
  id: string;
  time: number; // dalam detik
  speed: number; // 0.1x - 10x
  easing: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out' | 'bounce';
}

interface SpeedControlProps {
  duration: number; // durasi video dalam detik
  onSpeedChange: (keyframes: SpeedKeyframe[]) => void;
  currentTime: number;
  isPlaying: boolean;
  onPlayPause: () => void;
}

export function SpeedControl({ 
  duration, 
  onSpeedChange, 
  currentTime, 
  isPlaying, 
  onPlayPause 
}: SpeedControlProps) {
  const [speedKeyframes, setSpeedKeyframes] = useState<SpeedKeyframe[]>([
    { id: '1', time: 0, speed: 1, easing: 'linear' },
    { id: '2', time: duration, speed: 1, easing: 'linear' }
  ]);
  
  const [selectedKeyframe, setSelectedKeyframe] = useState<string | null>(null);
  const [currentSpeed, setCurrentSpeed] = useState(1);
  const [freezeFrames, setFreezeFrames] = useState<Array<{id: string, time: number, duration: number}>>([]);
  const [activeTab, setActiveTab] = useState<'speed' | 'ramping' | 'freeze'>('speed');

  const speedPresets = [
    { label: '0.1x', value: 0.1, icon: TrendingDown, color: 'bg-red-500' },
    { label: '0.25x', value: 0.25, icon: TrendingDown, color: 'bg-orange-500' },
    { label: '0.5x', value: 0.5, icon: TrendingDown, color: 'bg-yellow-500' },
    { label: '1x', value: 1, icon: Play, color: 'bg-green-500' },
    { label: '2x', value: 2, icon: TrendingUp, color: 'bg-blue-500' },
    { label: '4x', value: 4, icon: TrendingUp, color: 'bg-purple-500' },
    { label: '8x', value: 8, icon: TrendingUp, color: 'bg-pink-500' },
    { label: '10x', value: 10, icon: Zap, color: 'bg-red-600' }
  ];

  const easingTypes = [
    { id: 'linear', name: 'Linear', description: 'Perubahan konstan' },
    { id: 'ease-in', name: 'Ease In', description: 'Mulai lambat' },
    { id: 'ease-out', name: 'Ease Out', description: 'Berakhir lambat' },
    { id: 'ease-in-out', name: 'Ease In-Out', description: 'Smooth transitions' },
    { id: 'bounce', name: 'Bounce', description: 'Efek bouncing' }
  ];

  const addSpeedKeyframe = useCallback(() => {
    const newKeyframe: SpeedKeyframe = {
      id: `keyframe_${Date.now()}`,
      time: currentTime,
      speed: currentSpeed,
      easing: 'ease-in-out'
    };
    
    const newKeyframes = [...speedKeyframes, newKeyframe].sort((a, b) => a.time - b.time);
    setSpeedKeyframes(newKeyframes);
    onSpeedChange(newKeyframes);
  }, [currentTime, currentSpeed, speedKeyframes, onSpeedChange]);

  const removeKeyframe = useCallback((keyframeId: string) => {
    if (speedKeyframes.length <= 2) return; // Keep at least start and end
    
    const newKeyframes = speedKeyframes.filter(k => k.id !== keyframeId);
    setSpeedKeyframes(newKeyframes);
    onSpeedChange(newKeyframes);
    setSelectedKeyframe(null);
  }, [speedKeyframes, onSpeedChange]);

  const updateKeyframe = useCallback((keyframeId: string, updates: Partial<SpeedKeyframe>) => {
    const newKeyframes = speedKeyframes.map(k => 
      k.id === keyframeId ? { ...k, ...updates } : k
    );
    setSpeedKeyframes(newKeyframes);
    onSpeedChange(newKeyframes);
  }, [speedKeyframes, onSpeedChange]);

  const addFreezeFrame = useCallback(() => {
    const newFreeze = {
      id: `freeze_${Date.now()}`,
      time: currentTime,
      duration: 2 // default 2 detik
    };
    setFreezeFrames([...freezeFrames, newFreeze]);
  }, [currentTime, freezeFrames]);

  const applySpeedPreset = useCallback((speed: number) => {
    setCurrentSpeed(speed);
    
    // Apply to entire video
    const newKeyframes = [
      { id: '1', time: 0, speed, easing: 'linear' as const },
      { id: '2', time: duration, speed, easing: 'linear' as const }
    ];
    
    setSpeedKeyframes(newKeyframes);
    onSpeedChange(newKeyframes);
  }, [duration, onSpeedChange]);

  const getSpeedAtTime = useCallback((time: number) => {
    for (let i = 0; i < speedKeyframes.length - 1; i++) {
      const current = speedKeyframes[i];
      const next = speedKeyframes[i + 1];
      
      if (time >= current.time && time <= next.time) {
        const progress = (time - current.time) / (next.time - current.time);
        return current.speed + (next.speed - current.speed) * progress;
      }
    }
    return speedKeyframes[speedKeyframes.length - 1]?.speed || 1;
  }, [speedKeyframes]);

  return (
    <Card className="bg-gradient-to-br from-slate-800/80 to-purple-900/80 border border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Gauge className="h-5 w-5 text-purple-400" />
          Speed Control & Ramping
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
          <TabsList className="grid w-full grid-cols-3 bg-slate-700/50">
            <TabsTrigger value="speed" className="data-[state=active]:bg-purple-500">
              <Gauge className="h-4 w-4 mr-2" />
              Speed Control
            </TabsTrigger>
            <TabsTrigger value="ramping" className="data-[state=active]:bg-purple-500">
              <TrendingUp className="h-4 w-4 mr-2" />
              Speed Ramping
            </TabsTrigger>
            <TabsTrigger value="freeze" className="data-[state=active]:bg-purple-500">
              <Square className="h-4 w-4 mr-2" />
              Freeze Frame
            </TabsTrigger>
          </TabsList>

          {/* Speed Control Tab */}
          <TabsContent value="speed" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium text-white">Quick Speed Presets</h3>
                <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                  Current: {currentSpeed.toFixed(1)}x
                </Badge>
              </div>
              
              <div className="grid grid-cols-4 gap-2">
                {speedPresets.map((preset) => {
                  const Icon = preset.icon;
                  return (
                    <Button
                      key={preset.value}
                      onClick={() => applySpeedPreset(preset.value)}
                      variant={currentSpeed === preset.value ? "default" : "outline"}
                      size="sm"
                      className={currentSpeed === preset.value 
                        ? `${preset.color} text-white border-0` 
                        : "border-purple-500/30 hover:bg-purple-500/20"
                      }
                    >
                      <Icon className="h-4 w-4 mr-1" />
                      {preset.label}
                    </Button>
                  );
                })}
              </div>

              {/* Custom Speed Slider */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-white">
                  Custom Speed: {currentSpeed.toFixed(1)}x
                </label>
                <Slider
                  value={[currentSpeed]}
                  onValueChange={([value]) => setCurrentSpeed(value)}
                  max={10}
                  min={0.1}
                  step={0.1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>0.1x (Super Slow)</span>
                  <span>1x (Normal)</span>
                  <span>10x (Ultra Fast)</span>
                </div>
              </div>

              <Button
                onClick={() => applySpeedPreset(currentSpeed)}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                <Zap className="h-4 w-4 mr-2" />
                Apply Speed to Video
              </Button>
            </div>
          </TabsContent>

          {/* Speed Ramping Tab */}
          <TabsContent value="ramping" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium text-white">Speed Keyframes</h3>
                <Button
                  onClick={addSpeedKeyframe}
                  size="sm"
                  className="bg-blue-500 hover:bg-blue-600"
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  Add Keyframe
                </Button>
              </div>

              {/* Timeline Visualization */}
              <div className="relative h-20 bg-slate-700/50 rounded-lg p-2">
                <div className="absolute top-2 left-2 right-2 h-1 bg-gray-600 rounded">
                  {/* Progress indicator */}
                  <div 
                    className="h-full bg-purple-400 rounded transition-all duration-300"
                    style={{ width: `${(currentTime / duration) * 100}%` }}
                  />
                  
                  {/* Keyframe markers */}
                  {speedKeyframes.map((keyframe) => (
                    <div
                      key={keyframe.id}
                      className={`absolute top-0 w-3 h-3 rounded-full cursor-pointer transform -translate-x-1/2 -translate-y-1 ${
                        selectedKeyframe === keyframe.id 
                          ? 'bg-pink-400 scale-125' 
                          : 'bg-blue-400 hover:bg-blue-300'
                      }`}
                      style={{ left: `${(keyframe.time / duration) * 100}%` }}
                      onClick={() => setSelectedKeyframe(keyframe.id)}
                    />
                  ))}
                </div>
                
                {/* Speed indicators */}
                <div className="mt-4 flex justify-between text-xs text-gray-400">
                  {speedKeyframes.map((keyframe, index) => (
                    <div key={keyframe.id} className="text-center">
                      <div className="text-white font-medium">{keyframe.speed}x</div>
                      <div>{(keyframe.time).toFixed(1)}s</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Keyframe Details */}
              {selectedKeyframe && (
                <Card className="bg-slate-700/50 border-blue-500/30">
                  <CardContent className="p-4 space-y-3">
                    {(() => {
                      const keyframe = speedKeyframes.find(k => k.id === selectedKeyframe);
                      if (!keyframe) return null;
                      
                      return (
                        <>
                          <h4 className="text-white font-medium">Edit Keyframe</h4>
                          
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="text-xs text-gray-400">Time (seconds)</label>
                              <Slider
                                value={[keyframe.time]}
                                onValueChange={([value]) => updateKeyframe(keyframe.id, { time: value })}
                                max={duration}
                                min={0}
                                step={0.1}
                                className="mt-1"
                              />
                              <div className="text-xs text-center text-gray-400 mt-1">
                                {keyframe.time.toFixed(1)}s
                              </div>
                            </div>
                            
                            <div>
                              <label className="text-xs text-gray-400">Speed</label>
                              <Slider
                                value={[keyframe.speed]}
                                onValueChange={([value]) => updateKeyframe(keyframe.id, { speed: value })}
                                max={10}
                                min={0.1}
                                step={0.1}
                                className="mt-1"
                              />
                              <div className="text-xs text-center text-gray-400 mt-1">
                                {keyframe.speed.toFixed(1)}x
                              </div>
                            </div>
                          </div>

                          <div>
                            <label className="text-xs text-gray-400 mb-2 block">Easing Type</label>
                            <div className="grid grid-cols-2 gap-2">
                              {easingTypes.map((easing) => (
                                <Button
                                  key={easing.id}
                                  onClick={() => updateKeyframe(keyframe.id, { easing: easing.id as any })}
                                  variant={keyframe.easing === easing.id ? "default" : "outline"}
                                  size="sm"
                                  className={keyframe.easing === easing.id 
                                    ? "bg-blue-500 text-white" 
                                    : "border-gray-500/30 hover:bg-gray-500/20"
                                  }
                                >
                                  <div className="text-center">
                                    <div className="text-xs font-medium">{easing.name}</div>
                                    <div className="text-xs opacity-70">{easing.description}</div>
                                  </div>
                                </Button>
                              ))}
                            </div>
                          </div>

                          <div className="flex gap-2">
                            <Button
                              onClick={() => removeKeyframe(keyframe.id)}
                              variant="outline"
                              size="sm"
                              className="flex-1 border-red-500/30 hover:bg-red-500/20 text-red-300"
                            >
                              Remove Keyframe
                            </Button>
                          </div>
                        </>
                      );
                    })()}
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Freeze Frame Tab */}
          <TabsContent value="freeze" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium text-white">Freeze Frames</h3>
                <Button
                  onClick={addFreezeFrame}
                  size="sm"
                  className="bg-indigo-500 hover:bg-indigo-600"
                >
                  <Square className="h-4 w-4 mr-2" />
                  Add Freeze
                </Button>
              </div>

              <div className="space-y-2">
                <div className="text-sm text-gray-400">
                  Current Time: {currentTime.toFixed(1)}s
                </div>
                <Button
                  onClick={addFreezeFrame}
                  className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600"
                >
                  <Square className="h-4 w-4 mr-2" />
                  Freeze Current Frame
                </Button>
              </div>

              {/* Freeze Frame List */}
              {freezeFrames.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-white">Active Freeze Frames</h4>
                  {freezeFrames.map((freeze) => (
                    <Card key={freeze.id} className="bg-slate-700/50 border-indigo-500/30">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-white font-medium">
                              Freeze at {freeze.time.toFixed(1)}s
                            </div>
                            <div className="text-gray-400 text-sm">
                              Duration: {freeze.duration}s
                            </div>
                          </div>
                          <Button
                            onClick={() => setFreezeFrames(freezeFrames.filter(f => f.id !== freeze.id))}
                            variant="outline"
                            size="sm"
                            className="border-red-500/30 hover:bg-red-500/20 text-red-300"
                          >
                            Remove
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Playback Controls */}
        <Card className="bg-slate-700/50 border-purple-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button
                  onClick={onPlayPause}
                  variant="outline"
                  size="sm"
                  className="border-purple-500/30 hover:bg-purple-500/20"
                >
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                
                <div className="text-white text-sm">
                  {currentTime.toFixed(1)}s / {duration.toFixed(1)}s
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                  Speed: {getSpeedAtTime(currentTime).toFixed(1)}x
                </Badge>
                
                <Button
                  variant="outline"
                  size="sm"
                  className="border-gray-500/30 hover:bg-gray-500/20"
                >
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </CardContent>
    </Card>
  );
}