import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Layers, 
  Palette,
  Blend,
  Circle,
  Settings2,
  Contrast,
  Sun,
  Settings,
  Eye,
  RotateCcw,
  Download
} from 'lucide-react';

interface BlendingSettings {
  mode: string;
  opacity: number;
  brightness: number;
  contrast: number;
  saturation: number;
  hue: number;
  shadows: number;
  highlights: number;
  exposure: number;
  vibrance: number;
}

interface LayerBlendingEngineProps {
  onBlendingChange?: (settings: BlendingSettings) => void;
}

export function LayerBlendingEngine({ onBlendingChange }: LayerBlendingEngineProps) {
  const [blendingSettings, setBlendingSettings] = useState<BlendingSettings>({
    mode: 'normal',
    opacity: 100,
    brightness: 0,
    contrast: 0,
    saturation: 0,
    hue: 0,
    shadows: 0,
    highlights: 0,
    exposure: 0,
    vibrance: 0
  });

  const [activeCategory, setActiveCategory] = useState<'blend' | 'color' | 'light'>('blend');

  const blendModes = [
    { id: 'normal', name: 'Normal', description: 'Default blending' },
    { id: 'multiply', name: 'Multiply', description: 'Darkens image' },
    { id: 'screen', name: 'Screen', description: 'Lightens image' },
    { id: 'overlay', name: 'Overlay', description: 'Combines multiply and screen' },
    { id: 'soft-light', name: 'Soft Light', description: 'Subtle overlay effect' },
    { id: 'hard-light', name: 'Hard Light', description: 'Strong overlay effect' },
    { id: 'color-dodge', name: 'Color Dodge', description: 'Brightens colors' },
    { id: 'color-burn', name: 'Color Burn', description: 'Darkens colors' },
    { id: 'darken', name: 'Darken', description: 'Keeps darkest pixels' },
    { id: 'lighten', name: 'Lighten', description: 'Keeps lightest pixels' },
    { id: 'difference', name: 'Difference', description: 'Subtracts colors' },
    { id: 'exclusion', name: 'Exclusion', description: 'Similar to difference' }
  ];

  const presetStyles = [
    {
      id: 'cinematic',
      name: 'Cinematic',
      description: 'Film-like color grading',
      settings: { brightness: -5, contrast: 15, saturation: 10, shadows: -10 }
    },
    {
      id: 'vintage',
      name: 'Vintage',
      description: 'Retro film look',
      settings: { brightness: 5, contrast: -5, saturation: -15, hue: 10 }
    },
    {
      id: 'vibrant',
      name: 'Vibrant',
      description: 'Enhanced colors',
      settings: { brightness: 10, contrast: 20, saturation: 25, vibrance: 30 }
    },
    {
      id: 'moody',
      name: 'Moody',
      description: 'Dark atmospheric look',
      settings: { brightness: -15, contrast: 25, shadows: -20, highlights: -10 }
    }
  ];

  const updateSetting = useCallback((key: keyof BlendingSettings, value: number | string) => {
    const newSettings = { ...blendingSettings, [key]: value };
    setBlendingSettings(newSettings);
    onBlendingChange?.(newSettings);
  }, [blendingSettings, onBlendingChange]);

  const applyPreset = useCallback((preset: typeof presetStyles[0]) => {
    const newSettings = { ...blendingSettings, ...preset.settings };
    setBlendingSettings(newSettings);
    onBlendingChange?.(newSettings);
  }, [blendingSettings, onBlendingChange]);

  const resetSettings = useCallback(() => {
    const resetSettings: BlendingSettings = {
      mode: 'normal',
      opacity: 100,
      brightness: 0,
      contrast: 0,
      saturation: 0,
      hue: 0,
      shadows: 0,
      highlights: 0,
      exposure: 0,
      vibrance: 0
    };
    setBlendingSettings(resetSettings);
    onBlendingChange?.(resetSettings);
  }, [onBlendingChange]);

  const getIntensityLevel = useCallback(() => {
    const adjustments = [
      Math.abs(blendingSettings.brightness),
      Math.abs(blendingSettings.contrast),
      Math.abs(blendingSettings.saturation),
      Math.abs(blendingSettings.hue),
      Math.abs(blendingSettings.shadows),
      Math.abs(blendingSettings.highlights)
    ];
    return Math.round(adjustments.reduce((sum, val) => sum + val, 0) / adjustments.length);
  }, [blendingSettings]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border border-purple-500/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <Blend className="h-5 w-5 text-purple-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold">Layer Blending Engine</h3>
                <p className="text-gray-400 text-sm">Professional color grading & blending</p>
              </div>
            </div>
            
            <div className="text-right">
              <div className="text-2xl font-bold text-purple-400">{getIntensityLevel()}%</div>
              <div className="text-xs text-gray-400">Effect Intensity</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Category Tabs */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { id: 'blend', name: 'Blending', icon: Blend },
          { id: 'color', name: 'Color', icon: Palette },
          { id: 'light', name: 'Lighting', icon: Sun }
        ].map(({ id, name, icon: Icon }) => (
          <Button
            key={id}
            onClick={() => setActiveCategory(id as any)}
            variant={activeCategory === id ? "default" : "outline"}
            className={activeCategory === id 
              ? "bg-purple-500 text-white" 
              : "border-purple-500/30 hover:bg-purple-500/20"
            }
          >
            <Icon className="h-4 w-4 mr-2" />
            {name}
          </Button>
        ))}
      </div>

      {/* Blend Mode Selection */}
      {activeCategory === 'blend' && (
        <Card className="bg-slate-800/50 border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-white text-sm">Blend Modes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto">
              {blendModes.map((mode) => (
                <Button
                  key={mode.id}
                  onClick={() => updateSetting('mode', mode.id)}
                  variant={blendingSettings.mode === mode.id ? "default" : "outline"}
                  className={`h-auto p-3 text-left ${
                    blendingSettings.mode === mode.id 
                      ? "bg-purple-500 text-white" 
                      : "border-purple-500/30 hover:bg-purple-500/20"
                  }`}
                >
                  <div className="w-full">
                    <div className="font-medium text-sm">{mode.name}</div>
                    <div className="text-xs opacity-70">{mode.description}</div>
                  </div>
                </Button>
              ))}
            </div>

            {/* Opacity Control */}
            <div className="space-y-2 pt-4 border-t border-slate-600">
              <div className="flex justify-between items-center">
                <label className="text-sm text-gray-300">Layer Opacity</label>
                <Badge className="bg-purple-500/20 text-purple-300 border-0">
                  {blendingSettings.opacity}%
                </Badge>
              </div>
              <Slider
                value={[blendingSettings.opacity]}
                onValueChange={([value]) => updateSetting('opacity', value)}
                max={100}
                min={0}
                step={1}
                className="w-full"
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Color Adjustments */}
      {activeCategory === 'color' && (
        <Card className="bg-slate-800/50 border-pink-500/30">
          <CardHeader>
            <CardTitle className="text-white text-sm">Color Grading</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Saturation */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm text-gray-300">Saturation</label>
                <Badge className="bg-pink-500/20 text-pink-300 border-0">
                  {blendingSettings.saturation > 0 ? '+' : ''}{blendingSettings.saturation}
                </Badge>
              </div>
              <Slider
                value={[blendingSettings.saturation]}
                onValueChange={([value]) => updateSetting('saturation', value)}
                max={100}
                min={-100}
                step={1}
                className="w-full"
              />
            </div>

            {/* Hue */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm text-gray-300">Hue Shift</label>
                <Badge className="bg-blue-500/20 text-blue-300 border-0">
                  {blendingSettings.hue > 0 ? '+' : ''}{blendingSettings.hue}°
                </Badge>
              </div>
              <Slider
                value={[blendingSettings.hue]}
                onValueChange={([value]) => updateSetting('hue', value)}
                max={180}
                min={-180}
                step={1}
                className="w-full"
              />
            </div>

            {/* Vibrance */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm text-gray-300">Vibrance</label>
                <Badge className="bg-orange-500/20 text-orange-300 border-0">
                  {blendingSettings.vibrance > 0 ? '+' : ''}{blendingSettings.vibrance}
                </Badge>
              </div>
              <Slider
                value={[blendingSettings.vibrance]}
                onValueChange={([value]) => updateSetting('vibrance', value)}
                max={100}
                min={-100}
                step={1}
                className="w-full"
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lighting Adjustments */}
      {activeCategory === 'light' && (
        <Card className="bg-slate-800/50 border-yellow-500/30">
          <CardHeader>
            <CardTitle className="text-white text-sm">Lighting & Exposure</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Brightness */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm text-gray-300">Brightness</label>
                <Badge className="bg-yellow-500/20 text-yellow-300 border-0">
                  {blendingSettings.brightness > 0 ? '+' : ''}{blendingSettings.brightness}
                </Badge>
              </div>
              <Slider
                value={[blendingSettings.brightness]}
                onValueChange={([value]) => updateSetting('brightness', value)}
                max={100}
                min={-100}
                step={1}
                className="w-full"
              />
            </div>

            {/* Contrast */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm text-gray-300">Contrast</label>
                <Badge className="bg-indigo-500/20 text-indigo-300 border-0">
                  {blendingSettings.contrast > 0 ? '+' : ''}{blendingSettings.contrast}
                </Badge>
              </div>
              <Slider
                value={[blendingSettings.contrast]}
                onValueChange={([value]) => updateSetting('contrast', value)}
                max={100}
                min={-100}
                step={1}
                className="w-full"
              />
            </div>

            {/* Shadows */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm text-gray-300">Shadows</label>
                <Badge className="bg-gray-500/20 text-gray-300 border-0">
                  {blendingSettings.shadows > 0 ? '+' : ''}{blendingSettings.shadows}
                </Badge>
              </div>
              <Slider
                value={[blendingSettings.shadows]}
                onValueChange={([value]) => updateSetting('shadows', value)}
                max={100}
                min={-100}
                step={1}
                className="w-full"
              />
            </div>

            {/* Highlights */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm text-gray-300">Highlights</label>
                <Badge className="bg-white/20 text-white border-0">
                  {blendingSettings.highlights > 0 ? '+' : ''}{blendingSettings.highlights}
                </Badge>
              </div>
              <Slider
                value={[blendingSettings.highlights]}
                onValueChange={([value]) => updateSetting('highlights', value)}
                max={100}
                min={-100}
                step={1}
                className="w-full"
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Preset Styles */}
      <Card className="bg-slate-800/50 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-white text-sm">Preset Styles</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            {presetStyles.map((preset) => (
              <Button
                key={preset.id}
                onClick={() => applyPreset(preset)}
                variant="outline"
                className="h-auto p-3 text-left border-green-500/30 hover:bg-green-500/20"
              >
                <div className="w-full">
                  <div className="font-medium text-sm text-white">{preset.name}</div>
                  <div className="text-xs text-gray-400">{preset.description}</div>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-3">
        <Button
          onClick={resetSettings}
          variant="outline"
          className="border-gray-500/30 hover:bg-gray-500/20"
        >
          <RotateCcw className="h-4 w-4 mr-2" />
          Reset All
        </Button>
        
        <Button
          className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
        >
          <Download className="h-4 w-4 mr-2" />
          Apply Changes
        </Button>
      </div>

      {/* Blending Analysis */}
      <Card className="bg-gradient-to-r from-slate-800/50 to-purple-900/20 border border-purple-500/20">
        <CardContent className="p-4">
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center gap-2">
              <Layers className="h-4 w-4 text-purple-400" />
              <span className="text-sm text-white">Blending Analysis</span>
            </div>
            <div className="grid grid-cols-3 gap-4 text-xs text-gray-400">
              <div className="text-center">
                <div className="text-purple-400 font-bold">
                  {blendingSettings.mode.charAt(0).toUpperCase() + blendingSettings.mode.slice(1)}
                </div>
                <div>Blend Mode</div>
              </div>
              <div className="text-center">
                <div className="text-pink-400 font-bold">{getIntensityLevel()}%</div>
                <div>Intensity</div>
              </div>
              <div className="text-center">
                <div className="text-blue-400 font-bold">{blendingSettings.opacity}%</div>
                <div>Opacity</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}