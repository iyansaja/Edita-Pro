import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Palette, 
  Eye, 
  EyeOff, 
  RotateCcw, 
  Download, 
  Upload,
  Zap,
  Layers,
  Settings2,
  Target,
  Sparkles,
  Square,
  Circle,
  Settings,
  Play,
  Pause
} from 'lucide-react';

interface ChromaKeySettings {
  keyColor: string;
  tolerance: number;
  softness: number;
  spill: number;
  edge: number;
  shadows: number;
  highlights: number;
  feathering: number;
  despill: number;
  alpha: number;
}

interface ChromaKeyEditorProps {
  videoUrl?: string;
  onProcessed?: (processedVideo: string) => void;
  onClose?: () => void;
}

export function ChromaKeyEditor({ videoUrl, onProcessed, onClose }: ChromaKeyEditorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [previewMode, setPreviewMode] = useState<'original' | 'keyed' | 'mask'>('keyed');
  const [activeTab, setActiveTab] = useState<'basic' | 'advanced' | 'preview'>('basic');
  const [isPlaying, setIsPlaying] = useState(false);
  
  const [chromaSettings, setChromaSettings] = useState<ChromaKeySettings>({
    keyColor: '#00ff00', // Default green
    tolerance: 0.3,
    softness: 0.1,
    spill: 0.1,
    edge: 0.1,
    shadows: 0.0,
    highlights: 0.0,
    feathering: 0.1,
    despill: 0.2,
    alpha: 1.0
  });

  const [selectedVideo, setSelectedVideo] = useState<string>(videoUrl || '');

  // Preset chroma key colors
  const chromaPresets = [
    { name: 'Classic Green', color: '#00ff00', icon: Square },
    { name: 'Blue Screen', color: '#0000ff', icon: Square },
    { name: 'Magenta', color: '#ff00ff', icon: Square },
    { name: 'Red', color: '#ff0000', icon: Square },
    { name: 'Custom', color: chromaSettings.keyColor, icon: Palette }
  ];

  // Handle file upload
  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setSelectedVideo(url);
    }
  }, []);

  // Update chroma setting
  const updateSetting = useCallback((key: keyof ChromaKeySettings, value: number | string) => {
    setChromaSettings(prev => ({
      ...prev,
      [key]: value
    }));
  }, []);

  // Apply chroma key effect
  const applyChromaKey = useCallback(() => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    
    if (!canvas || !video) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas size to match video
    canvas.width = video.videoWidth || 1920;
    canvas.height = video.videoHeight || 1080;
    
    // Draw current video frame
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Get image data for chroma key processing
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    
    // Parse key color
    const keyColor = hexToRgb(chromaSettings.keyColor);
    if (!keyColor) return;
    
    // Process each pixel
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      
      // Calculate color difference
      const distance = colorDistance(
        { r, g, b },
        keyColor
      );
      
      // Apply chroma key based on settings
      const normalizedDistance = distance / 441.67; // Max possible distance
      
      if (normalizedDistance <= chromaSettings.tolerance) {
        // Pixel is within tolerance - make transparent
        let alpha = 0;
        
        // Apply feathering for smooth edges
        if (normalizedDistance > chromaSettings.tolerance - chromaSettings.feathering) {
          const featherRange = chromaSettings.feathering;
          const featherPos = (normalizedDistance - (chromaSettings.tolerance - featherRange)) / featherRange;
          alpha = Math.floor(featherPos * 255);
        }
        
        data[i + 3] = alpha;
      } else {
        // Apply despill to remove color spill
        if (chromaSettings.despill > 0) {
          const spillAmount = Math.max(0, 1 - (normalizedDistance / chromaSettings.tolerance));
          const despillFactor = 1 - (spillAmount * chromaSettings.despill);
          
          if (keyColor.g > keyColor.r && keyColor.g > keyColor.b) {
            // Green key - reduce green channel
            data[i + 1] = Math.floor(data[i + 1] * despillFactor);
          } else if (keyColor.b > keyColor.r && keyColor.b > keyColor.g) {
            // Blue key - reduce blue channel
            data[i + 2] = Math.floor(data[i + 2] * despillFactor);
          }
        }
        
        // Apply alpha
        data[i + 3] = Math.floor(data[i + 3] * chromaSettings.alpha);
      }
    }
    
    // Apply processed image data back to canvas
    ctx.putImageData(imageData, 0, 0);
  }, [chromaSettings]);

  // Helper function to convert hex to RGB
  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };

  // Helper function to calculate color distance
  const colorDistance = (color1: {r: number, g: number, b: number}, color2: {r: number, g: number, b: number}) => {
    const dr = color1.r - color2.r;
    const dg = color1.g - color2.g;
    const db = color1.b - color2.b;
    return Math.sqrt(dr * dr + dg * dg + db * db);
  };

  // Handle play/pause
  const handlePlayPause = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    
    if (isPlaying) {
      video.pause();
    } else {
      video.play();
    }
    setIsPlaying(!isPlaying);
  }, [isPlaying]);

  // Process video frame by frame
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    
    const handleTimeUpdate = () => {
      applyChromaKey();
    };
    
    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('loadeddata', applyChromaKey);
    
    return () => {
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('loadeddata', applyChromaKey);
    };
  }, [applyChromaKey]);

  // Export processed video
  const handleExport = useCallback(async () => {
    setIsProcessing(true);
    
    try {
      const canvas = canvasRef.current;
      if (!canvas) return;
      
      // Convert canvas to blob
      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          onProcessed?.(url);
          
          // Download processed frame
          const a = document.createElement('a');
          a.href = url;
          a.download = `chroma-keyed-${Date.now()}.png`;
          a.click();
        }
      }, 'image/png');
      
    } catch (error) {
      console.error('Export failed:', error);
    } finally {
      setIsProcessing(false);
    }
  }, [onProcessed]);

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-green-900/80 to-blue-900/80 border border-green-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Palette className="h-6 w-6 text-green-400" />
              Green Screen / Chroma Key Editor
              <Badge className="bg-gradient-to-r from-green-500 to-blue-500 text-white border-0 ml-auto">
                <Sparkles className="h-3 w-3 mr-1" />
                Professional AI
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Video Preview */}
          <div className="lg:col-span-2 space-y-4">
            {/* Upload Section */}
            {!selectedVideo && (
              <Card className="bg-slate-800/50 border-dashed border-green-500/30">
                <CardContent className="p-8 text-center">
                  <Upload className="h-12 w-12 mx-auto mb-4 text-green-400" />
                  <h3 className="text-lg font-semibold text-white mb-2">Upload Video for Chroma Key</h3>
                  <p className="text-gray-400 mb-4">Select a video with green screen background</p>
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Select Video File
                  </Button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="video/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </CardContent>
              </Card>
            )}

            {/* Video Player & Canvas */}
            {selectedVideo && (
              <Card className="bg-slate-800/50 border-green-500/30">
                <CardContent className="p-4">
                  <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                    {/* Original Video (hidden) */}
                    <video
                      ref={videoRef}
                      src={selectedVideo}
                      className="absolute inset-0 w-full h-full object-contain opacity-0"
                      loop
                      muted
                    />
                    
                    {/* Processed Canvas */}
                    <canvas
                      ref={canvasRef}
                      className="w-full h-full object-contain"
                      style={{
                        background: previewMode === 'mask' ? '#ffffff' : 'transparent'
                      }}
                    />
                    
                    {/* Overlay Controls */}
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Button
                          onClick={handlePlayPause}
                          variant="outline"
                          size="sm"
                          className="bg-black/60 border-white/20 hover:bg-white/20"
                        >
                          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {/* Preview Mode Toggle */}
                        <Button
                          onClick={() => setPreviewMode(prev => 
                            prev === 'original' ? 'keyed' : prev === 'keyed' ? 'mask' : 'original'
                          )}
                          variant="outline"
                          size="sm"
                          className="bg-black/60 border-white/20 hover:bg-white/20"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          {previewMode}
                        </Button>
                        
                        <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                          {previewMode === 'original' ? 'Original' : 
                           previewMode === 'keyed' ? 'Chroma Keyed' : 'Alpha Mask'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Controls Panel */}
          <div className="space-y-4">
            <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
              <TabsList className="grid w-full grid-cols-3 bg-slate-700/50">
                <TabsTrigger value="basic" className="data-[state=active]:bg-green-500">
                  <Target className="h-4 w-4 mr-1" />
                  Basic
                </TabsTrigger>
                <TabsTrigger value="advanced" className="data-[state=active]:bg-green-500">
                  <Settings className="h-4 w-4 mr-1" />
                  Advanced
                </TabsTrigger>
                <TabsTrigger value="preview" className="data-[state=active]:bg-green-500">
                  <Eye className="h-4 w-4 mr-1" />
                  Preview
                </TabsTrigger>
              </TabsList>

              {/* Basic Controls */}
              <TabsContent value="basic" className="space-y-4">
                <Card className="bg-slate-800/50 border-green-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Key Color Selection</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Color Presets */}
                    <div className="grid grid-cols-2 gap-2">
                      {chromaPresets.map((preset) => {
                        const Icon = preset.icon;
                        return (
                          <Button
                            key={preset.name}
                            onClick={() => updateSetting('keyColor', preset.color)}
                            variant={chromaSettings.keyColor === preset.color ? "default" : "outline"}
                            size="sm"
                            className={chromaSettings.keyColor === preset.color 
                              ? "bg-green-500 text-white border-0" 
                              : "border-green-500/30 hover:bg-green-500/20"
                            }
                          >
                            <div 
                              className="w-3 h-3 rounded mr-2 border border-white/30"
                              style={{ backgroundColor: preset.color }}
                            />
                            {preset.name}
                          </Button>
                        );
                      })}
                    </div>

                    {/* Custom Color Picker */}
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">Custom Color</label>
                      <input
                        type="color"
                        value={chromaSettings.keyColor}
                        onChange={(e) => updateSetting('keyColor', e.target.value)}
                        className="w-full h-10 rounded border border-green-500/30 bg-transparent"
                      />
                    </div>

                    {/* Tolerance */}
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">
                        Tolerance: {(chromaSettings.tolerance * 100).toFixed(0)}%
                      </label>
                      <Slider
                        value={[chromaSettings.tolerance]}
                        onValueChange={([value]) => updateSetting('tolerance', value)}
                        max={1}
                        min={0}
                        step={0.01}
                        className="w-full"
                      />
                    </div>

                    {/* Feathering */}
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">
                        Feathering: {(chromaSettings.feathering * 100).toFixed(0)}%
                      </label>
                      <Slider
                        value={[chromaSettings.feathering]}
                        onValueChange={([value]) => updateSetting('feathering', value)}
                        max={0.5}
                        min={0}
                        step={0.01}
                        className="w-full"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Advanced Controls */}
              <TabsContent value="advanced" className="space-y-4">
                <Card className="bg-slate-800/50 border-blue-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Fine-Tuning Controls</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Spill Suppression */}
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">
                        Spill Suppression: {(chromaSettings.spill * 100).toFixed(0)}%
                      </label>
                      <Slider
                        value={[chromaSettings.spill]}
                        onValueChange={([value]) => updateSetting('spill', value)}
                        max={1}
                        min={0}
                        step={0.01}
                        className="w-full"
                      />
                    </div>

                    {/* Despill */}
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">
                        Despill: {(chromaSettings.despill * 100).toFixed(0)}%
                      </label>
                      <Slider
                        value={[chromaSettings.despill]}
                        onValueChange={([value]) => updateSetting('despill', value)}
                        max={1}
                        min={0}
                        step={0.01}
                        className="w-full"
                      />
                    </div>

                    {/* Edge Softness */}
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">
                        Edge Softness: {(chromaSettings.edge * 100).toFixed(0)}%
                      </label>
                      <Slider
                        value={[chromaSettings.edge]}
                        onValueChange={([value]) => updateSetting('edge', value)}
                        max={1}
                        min={0}
                        step={0.01}
                        className="w-full"
                      />
                    </div>

                    {/* Shadows */}
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">
                        Shadow Adjustment: {(chromaSettings.shadows * 100).toFixed(0)}%
                      </label>
                      <Slider
                        value={[chromaSettings.shadows]}
                        onValueChange={([value]) => updateSetting('shadows', value)}
                        max={1}
                        min={-1}
                        step={0.01}
                        className="w-full"
                      />
                    </div>

                    {/* Highlights */}
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">
                        Highlight Adjustment: {(chromaSettings.highlights * 100).toFixed(0)}%
                      </label>
                      <Slider
                        value={[chromaSettings.highlights]}
                        onValueChange={([value]) => updateSetting('highlights', value)}
                        max={1}
                        min={-1}
                        step={0.01}
                        className="w-full"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Preview Controls */}
              <TabsContent value="preview" className="space-y-4">
                <Card className="bg-slate-800/50 border-purple-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Preview & Export</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Preview Modes */}
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">Preview Mode</label>
                      <div className="grid grid-cols-1 gap-2">
                        {[
                          { mode: 'original', label: 'Original Video', icon: Eye },
                          { mode: 'keyed', label: 'Chroma Keyed', icon: Layers },
                          { mode: 'mask', label: 'Alpha Mask', icon: Circle }
                        ].map(({ mode, label, icon: Icon }) => (
                          <Button
                            key={mode}
                            onClick={() => setPreviewMode(mode as any)}
                            variant={previewMode === mode ? "default" : "outline"}
                            size="sm"
                            className={previewMode === mode 
                              ? "bg-purple-500 text-white" 
                              : "border-purple-500/30 hover:bg-purple-500/20"
                            }
                          >
                            <Icon className="h-4 w-4 mr-2" />
                            {label}
                          </Button>
                        ))}
                      </div>
                    </div>

                    {/* Export Options */}
                    <div className="space-y-2">
                      <Button
                        onClick={handleExport}
                        disabled={isProcessing || !selectedVideo}
                        className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
                      >
                        {isProcessing ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <Download className="h-4 w-4 mr-2" />
                            Export Frame
                          </>
                        )}
                      </Button>

                      <Button
                        onClick={() => {
                          setChromaSettings({
                            keyColor: '#00ff00',
                            tolerance: 0.3,
                            softness: 0.1,
                            spill: 0.1,
                            edge: 0.1,
                            shadows: 0.0,
                            highlights: 0.0,
                            feathering: 0.1,
                            despill: 0.2,
                            alpha: 1.0
                          });
                        }}
                        variant="outline"
                        className="w-full border-gray-500/30 hover:bg-gray-500/20"
                      >
                        <RotateCcw className="h-4 w-4 mr-2" />
                        Reset Settings
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}