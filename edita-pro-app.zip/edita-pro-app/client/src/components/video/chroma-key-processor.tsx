import React, { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Palette, 
  Zap, 
  Eye, 
  Layers, 
  Target,
  Sparkles,
  Download,
  RotateCcw,
  Settings2,
  Lightbulb,
  Square
} from 'lucide-react';

interface ChromaKeySettings {
  tolerance: number;
  feathering: number;
  spill: number;
  shadows: number;
  highlights: number;
  despill: number;
}

interface ChromaKeyProcessorProps {
  onSettingsChange?: (settings: ChromaKeySettings) => void;
}

export function ChromaKeyProcessor({ onSettingsChange }: ChromaKeyProcessorProps) {
  const [activeColor, setActiveColor] = useState('#00ff00');
  const [isProcessing, setIsProcessing] = useState(false);
  const [previewMode, setPreviewMode] = useState<'original' | 'keyed' | 'mask'>('keyed');
  
  const [settings, setSettings] = useState<ChromaKeySettings>({
    tolerance: 30,
    feathering: 10,
    spill: 10,
    shadows: 0,
    highlights: 0,
    despill: 20
  });

  const colorPresets = [
    { name: 'Classic Green', color: '#00ff00', usage: '85%' },
    { name: 'Blue Screen', color: '#0000ff', usage: '12%' },
    { name: 'Magenta', color: '#ff00ff', usage: '2%' },
    { name: 'Custom Red', color: '#ff0000', usage: '1%' }
  ];

  const updateSetting = useCallback((key: keyof ChromaKeySettings, value: number) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    onSettingsChange?.(newSettings);
  }, [settings, onSettingsChange]);

  const applyPreset = useCallback((presetName: string) => {
    let presetSettings: Partial<ChromaKeySettings> = {};
    
    switch (presetName) {
      case 'studio':
        presetSettings = { tolerance: 25, feathering: 15, spill: 8, despill: 25 };
        break;
      case 'outdoor':
        presetSettings = { tolerance: 35, feathering: 20, spill: 15, despill: 30 };
        break;
      case 'lowlight':
        presetSettings = { tolerance: 40, feathering: 25, spill: 20, shadows: -10 };
        break;
      case 'precise':
        presetSettings = { tolerance: 15, feathering: 5, spill: 5, despill: 15 };
        break;
    }
    
    const newSettings = { ...settings, ...presetSettings };
    setSettings(newSettings);
    onSettingsChange?.(newSettings);
  }, [settings, onSettingsChange]);

  const resetSettings = useCallback(() => {
    const defaultSettings: ChromaKeySettings = {
      tolerance: 30,
      feathering: 10,
      spill: 10,
      shadows: 0,
      highlights: 0,
      despill: 20
    };
    setSettings(defaultSettings);
    onSettingsChange?.(defaultSettings);
  }, [onSettingsChange]);

  const qualityScore = Math.round(
    (100 - settings.tolerance + settings.feathering + settings.despill) / 3
  );

  return (
    <div className="space-y-6">
      {/* Header with Quality Score */}
      <Card className="bg-gradient-to-r from-green-900/80 to-blue-900/80 border border-green-500/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <Palette className="h-5 w-5 text-green-400" />
              </div>
              <div>
                <h3 className="text-white font-semibold">Chroma Key Processor</h3>
                <p className="text-gray-400 text-sm">Real-time green screen removal</p>
              </div>
            </div>
            
            <div className="text-right">
              <div className="text-2xl font-bold text-white">{qualityScore}%</div>
              <div className="text-xs text-gray-400">Quality Score</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Color Selection */}
      <Card className="bg-slate-800/50 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Target className="h-4 w-4 text-green-400" />
            Key Color Selection
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            {colorPresets.map((preset) => (
              <Button
                key={preset.name}
                onClick={() => setActiveColor(preset.color)}
                variant={activeColor === preset.color ? "default" : "outline"}
                size="sm"
                className={`h-auto p-3 ${
                  activeColor === preset.color 
                    ? "bg-green-500 text-white border-0" 
                    : "border-green-500/30 hover:bg-green-500/20"
                }`}
              >
                <div className="flex items-center gap-2 w-full">
                  <div 
                    className="w-4 h-4 rounded border border-white/30"
                    style={{ backgroundColor: preset.color }}
                  />
                  <div className="text-left flex-1">
                    <div className="text-xs font-medium">{preset.name}</div>
                    <div className="text-xs opacity-70">{preset.usage} usage</div>
                  </div>
                </div>
              </Button>
            ))}
          </div>
          
          <div className="space-y-2">
            <label className="text-xs text-gray-400">Custom Color</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={activeColor}
                onChange={(e) => setActiveColor(e.target.value)}
                className="w-12 h-8 rounded border border-green-500/30 bg-transparent"
              />
              <span className="text-sm text-gray-300 font-mono">{activeColor}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Primary Controls */}
      <Card className="bg-slate-800/50 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Settings2 className="h-4 w-4 text-blue-400" />
            Primary Controls
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Tolerance */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-sm text-gray-300">Tolerance</label>
              <Badge className={`${
                settings.tolerance < 20 ? 'bg-green-500/20 text-green-300' :
                settings.tolerance < 35 ? 'bg-yellow-500/20 text-yellow-300' :
                'bg-red-500/20 text-red-300'
              } border-0`}>
                {settings.tolerance}%
              </Badge>
            </div>
            <Slider
              value={[settings.tolerance]}
              onValueChange={([value]) => updateSetting('tolerance', value)}
              max={100}
              min={1}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>Precise</span>
              <span>Aggressive</span>
            </div>
          </div>

          {/* Feathering */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-sm text-gray-300">Edge Feathering</label>
              <Badge className="bg-blue-500/20 text-blue-300 border-0">
                {settings.feathering}%
              </Badge>
            </div>
            <Slider
              value={[settings.feathering]}
              onValueChange={([value]) => updateSetting('feathering', value)}
              max={50}
              min={0}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>Sharp</span>
              <span>Soft</span>
            </div>
          </div>

          {/* Spill Suppression */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-sm text-gray-300">Spill Suppression</label>
              <Badge className="bg-purple-500/20 text-purple-300 border-0">
                {settings.spill}%
              </Badge>
            </div>
            <Slider
              value={[settings.spill]}
              onValueChange={([value]) => updateSetting('spill', value)}
              max={100}
              min={0}
              step={1}
              className="w-full"
            />
          </div>
        </CardContent>
      </Card>

      {/* Advanced Controls */}
      <Card className="bg-slate-800/50 border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Lightbulb className="h-4 w-4 text-purple-400" />
            Advanced Fine-Tuning
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Despill */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-sm text-gray-300">Despill Amount</label>
              <Badge className="bg-indigo-500/20 text-indigo-300 border-0">
                {settings.despill}%
              </Badge>
            </div>
            <Slider
              value={[settings.despill]}
              onValueChange={([value]) => updateSetting('despill', value)}
              max={100}
              min={0}
              step={1}
              className="w-full"
            />
          </div>

          {/* Shadows */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-sm text-gray-300">Shadow Adjust</label>
              <Badge className="bg-gray-500/20 text-gray-300 border-0">
                {settings.shadows > 0 ? '+' : ''}{settings.shadows}%
              </Badge>
            </div>
            <Slider
              value={[settings.shadows]}
              onValueChange={([value]) => updateSetting('shadows', value)}
              max={50}
              min={-50}
              step={1}
              className="w-full"
            />
          </div>

          {/* Highlights */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-sm text-gray-300">Highlight Adjust</label>
              <Badge className="bg-yellow-500/20 text-yellow-300 border-0">
                {settings.highlights > 0 ? '+' : ''}{settings.highlights}%
              </Badge>
            </div>
            <Slider
              value={[settings.highlights]}
              onValueChange={([value]) => updateSetting('highlights', value)}
              max={50}
              min={-50}
              step={1}
              className="w-full"
            />
          </div>
        </CardContent>
      </Card>

      {/* Quick Presets */}
      <Card className="bg-slate-800/50 border-orange-500/30">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Zap className="h-4 w-4 text-orange-400" />
            Quick Presets
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'studio', name: 'Studio Setup', desc: 'Professional lighting' },
              { id: 'outdoor', name: 'Outdoor Shot', desc: 'Natural lighting' },
              { id: 'lowlight', name: 'Low Light', desc: 'Dim conditions' },
              { id: 'precise', name: 'Precise Cut', desc: 'Maximum accuracy' }
            ].map((preset) => (
              <Button
                key={preset.id}
                onClick={() => applyPreset(preset.id)}
                variant="outline"
                size="sm"
                className="h-auto p-3 border-orange-500/30 hover:bg-orange-500/20 text-left"
              >
                <div>
                  <div className="text-xs font-medium text-white">{preset.name}</div>
                  <div className="text-xs text-gray-400">{preset.desc}</div>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex items-center gap-3">
        <Button
          onClick={resetSettings}
          variant="outline"
          className="flex-1 border-gray-500/30 hover:bg-gray-500/20"
        >
          <RotateCcw className="h-4 w-4 mr-2" />
          Reset
        </Button>
        
        <Button
          className="flex-1 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
        >
          <Download className="h-4 w-4 mr-2" />
          Apply
        </Button>
      </div>

      {/* Quality Indicator */}
      <Card className="bg-gradient-to-r from-slate-800/50 to-green-900/20 border border-green-500/20">
        <CardContent className="p-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-green-400" />
              <span className="text-sm text-white">Processing Quality</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-20 h-2 bg-gray-600 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-300 ${
                    qualityScore >= 80 ? 'bg-green-500' :
                    qualityScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${qualityScore}%` }}
                />
              </div>
              <span className="text-sm font-bold text-white">{qualityScore}%</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}