import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { 
  Palette, 
  Zap, 
  Sparkles, 
  Wand2, 
  Film, 
  Camera,
  Eye,
  Brush,
  Rainbow,
  Sun,
  Moon,
  Snowflake,
  Clock
} from 'lucide-react';

interface VisualEffect {
  id: string;
  name: string;
  type: 'filter' | 'transition' | 'trending' | 'ai';
  intensity: number;
  enabled: boolean;
  startTime?: number;
  duration?: number;
  params?: Record<string, any>;
}

interface VisualEffectsPanelProps {
  onAddEffect: (effect: VisualEffect) => void;
  activeEffects: VisualEffect[];
  onUpdateEffect: (id: string, updates: Partial<VisualEffect>) => void;
  onRemoveEffect: (id: string) => void;
  videoDuration: number;
}

const colorFilters = [
  { id: 'cinematic', name: 'Cinematic', icon: Film, color: '#FF6B35' },
  { id: 'vintage', name: 'Vintage', icon: Camera, color: '#8B4513' },
  { id: 'blackwhite', name: 'Black & White', icon: Eye, color: '#666666' },
  { id: 'warm', name: 'Warm', icon: Sun, color: '#FFA500' },
  { id: 'cold', name: 'Cold', icon: Snowflake, color: '#87CEEB' },
  { id: 'sepia', name: 'Sepia', icon: Clock, color: '#DEB887' },
  { id: 'neon', name: 'Neon', icon: Rainbow, color: '#FF1493' },
  { id: 'retro', name: 'Retro', icon: Moon, color: '#800080' }
];

const transitionEffects = [
  { id: 'zoom', name: 'Zoom In/Out', description: 'Efek zoom dinamis' },
  { id: 'blur', name: 'Motion Blur', description: 'Blur bergerak' },
  { id: 'glitch', name: 'Glitch', description: 'Efek digital glitch' },
  { id: 'lightleak', name: 'Light Leak', description: 'Bocoran cahaya' },
  { id: 'dissolve', name: 'Dissolve', description: 'Transisi larut' },
  { id: 'swipe', name: 'Swipe', description: 'Geser layar' },
  { id: 'fade', name: 'Fade', description: 'Fade in/out' },
  { id: 'slide', name: 'Slide', description: 'Slide transisi' }
];

const trendingEffects = [
  { id: '3dzoom', name: '3D Zoom', description: 'Zoom 3D trending' },
  { id: 'shake', name: 'Camera Shake', description: 'Guncangan kamera' },
  { id: 'flashbeat', name: 'Flash Beat', description: 'Flash mengikuti beat' },
  { id: 'dreamyglow', name: 'Dreamy Glow', description: 'Cahaya bermimpi' },
  { id: 'parallax', name: 'Parallax', description: 'Efek parallax' },
  { id: 'datamosh', name: 'Datamosh', description: 'Digital datamosh' },
  { id: 'vhs', name: 'VHS Aesthetic', description: 'Aesthetic VHS' },
  { id: 'cyberpunk', name: 'Cyberpunk', description: 'Efek cyberpunk' }
];

const aiEffects = [
  { id: 'sketch', name: 'Sketsa', description: 'Konversi ke sketsa pensil' },
  { id: 'cartoon', name: 'Kartun', description: 'Style kartun/animasi' },
  { id: 'anime', name: 'Anime', description: 'Style anime Jepang' },
  { id: 'painting', name: 'Lukisan', description: 'Efek lukisan cat minyak' },
  { id: 'watercolor', name: 'Cat Air', description: 'Efek cat air' },
  { id: 'aging', name: 'Aging', description: 'Efek video tua/rusak' },
  { id: 'artistic', name: 'Artistic', description: 'Filter artistik AI' },
  { id: 'stylize', name: 'Stylize', description: 'Stylisasi AI' }
];

export function VisualEffectsPanel({
  onAddEffect,
  activeEffects,
  onUpdateEffect,
  onRemoveEffect,
  videoDuration
}: VisualEffectsPanelProps) {
  const [selectedEffect, setSelectedEffect] = useState<string | null>(null);

  const addColorFilter = (filterId: string) => {
    const filter = colorFilters.find(f => f.id === filterId);
    if (filter) {
      const effect: VisualEffect = {
        id: `${filterId}_${Date.now()}`,
        name: filter.name,
        type: 'filter',
        intensity: 50,
        enabled: true,
        startTime: 0,
        duration: videoDuration,
        params: { filterId }
      };
      onAddEffect(effect);
    }
  };

  const addTransitionEffect = (transitionId: string) => {
    const transition = transitionEffects.find(t => t.id === transitionId);
    if (transition) {
      const effect: VisualEffect = {
        id: `${transitionId}_${Date.now()}`,
        name: transition.name,
        type: 'transition',
        intensity: 70,
        enabled: true,
        startTime: 0,
        duration: 2,
        params: { transitionId }
      };
      onAddEffect(effect);
    }
  };

  const addTrendingEffect = (effectId: string) => {
    const trending = trendingEffects.find(t => t.id === effectId);
    if (trending) {
      const effect: VisualEffect = {
        id: `${effectId}_${Date.now()}`,
        name: trending.name,
        type: 'trending',
        intensity: 60,
        enabled: true,
        startTime: 0,
        duration: videoDuration,
        params: { effectId }
      };
      onAddEffect(effect);
    }
  };

  const addAIEffect = (aiId: string) => {
    const ai = aiEffects.find(a => a.id === aiId);
    if (ai) {
      const effect: VisualEffect = {
        id: `${aiId}_${Date.now()}`,
        name: ai.name,
        type: 'ai',
        intensity: 80,
        enabled: true,
        startTime: 0,
        duration: videoDuration,
        params: { aiId }
      };
      onAddEffect(effect);
    }
  };

  const getEffectsByType = (type: string) => {
    return activeEffects.filter(effect => effect.type === type);
  };

  return (
    <div className="space-y-4">
      <Tabs defaultValue="filters" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="filters">Filter</TabsTrigger>
          <TabsTrigger value="transitions">Transisi</TabsTrigger>
          <TabsTrigger value="trending">Trending</TabsTrigger>
          <TabsTrigger value="ai">AI</TabsTrigger>
        </TabsList>

        <TabsContent value="filters" className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium flex items-center">
              <Palette className="w-4 h-4 mr-2" />
              Filter Warna
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {colorFilters.map((filter) => {
                const Icon = filter.icon;
                return (
                  <Button
                    key={filter.id}
                    variant="outline"
                    size="sm"
                    onClick={() => addColorFilter(filter.id)}
                    className="justify-start"
                  >
                    <Icon className="w-4 h-4 mr-2" style={{ color: filter.color }} />
                    {filter.name}
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Active Color Filters */}
          <div className="space-y-2">
            <h4 className="font-medium">Filter Aktif ({getEffectsByType('filter').length})</h4>
            <div className="max-h-32 overflow-y-auto space-y-2">
              {getEffectsByType('filter').map((effect) => (
                <div key={effect.id} className="p-2 border rounded space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{effect.name}</span>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={effect.enabled}
                        onCheckedChange={(checked) => onUpdateEffect(effect.id, { enabled: checked })}
                        size="sm"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onRemoveEffect(effect.id)}
                      >
                        ×
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Intensitas: {effect.intensity}%</Label>
                    <Slider
                      value={[effect.intensity]}
                      onValueChange={([value]) => onUpdateEffect(effect.id, { intensity: value })}
                      max={100}
                      step={5}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="transitions" className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium flex items-center">
              <Zap className="w-4 h-4 mr-2" />
              Efek Transisi
            </h4>
            <div className="space-y-2">
              {transitionEffects.map((transition) => (
                <Button
                  key={transition.id}
                  variant="outline"
                  size="sm"
                  onClick={() => addTransitionEffect(transition.id)}
                  className="w-full justify-start"
                >
                  <div className="text-left">
                    <div className="font-medium">{transition.name}</div>
                    <div className="text-xs text-muted-foreground">{transition.description}</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Active Transitions */}
          <div className="space-y-2">
            <h4 className="font-medium">Transisi Aktif ({getEffectsByType('transition').length})</h4>
            <div className="max-h-32 overflow-y-auto space-y-2">
              {getEffectsByType('transition').map((effect) => (
                <div key={effect.id} className="p-2 border rounded space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{effect.name}</span>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={effect.enabled}
                        onCheckedChange={(checked) => onUpdateEffect(effect.id, { enabled: checked })}
                        size="sm"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onRemoveEffect(effect.id)}
                      >
                        ×
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <Label className="text-xs">Mulai: {effect.startTime}s</Label>
                      <Slider
                        value={[effect.startTime || 0]}
                        onValueChange={([value]) => onUpdateEffect(effect.id, { startTime: value })}
                        max={videoDuration}
                        step={0.1}
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Durasi: {effect.duration}s</Label>
                      <Slider
                        value={[effect.duration || 2]}
                        onValueChange={([value]) => onUpdateEffect(effect.id, { duration: value })}
                        min={0.1}
                        max={10}
                        step={0.1}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="trending" className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium flex items-center">
              <Sparkles className="w-4 h-4 mr-2" />
              Efek Trending
            </h4>
            <div className="space-y-2">
              {trendingEffects.map((effect) => (
                <Button
                  key={effect.id}
                  variant="outline"
                  size="sm"
                  onClick={() => addTrendingEffect(effect.id)}
                  className="w-full justify-start"
                >
                  <div className="text-left">
                    <div className="font-medium">{effect.name}</div>
                    <div className="text-xs text-muted-foreground">{effect.description}</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Active Trending Effects */}
          <div className="space-y-2">
            <h4 className="font-medium">Efek Trending Aktif ({getEffectsByType('trending').length})</h4>
            <div className="max-h-32 overflow-y-auto space-y-2">
              {getEffectsByType('trending').map((effect) => (
                <div key={effect.id} className="p-2 border rounded space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{effect.name}</span>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={effect.enabled}
                        onCheckedChange={(checked) => onUpdateEffect(effect.id, { enabled: checked })}
                        size="sm"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onRemoveEffect(effect.id)}
                      >
                        ×
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Intensitas: {effect.intensity}%</Label>
                    <Slider
                      value={[effect.intensity]}
                      onValueChange={([value]) => onUpdateEffect(effect.id, { intensity: value })}
                      max={100}
                      step={5}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="ai" className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium flex items-center">
              <Wand2 className="w-4 h-4 mr-2" />
              Efek AI
            </h4>
            <div className="space-y-2">
              {aiEffects.map((effect) => (
                <Button
                  key={effect.id}
                  variant="outline"
                  size="sm"
                  onClick={() => addAIEffect(effect.id)}
                  className="w-full justify-start"
                  disabled={effect.id !== 'sketch' && effect.id !== 'cartoon'} // Enable some for demo
                >
                  <div className="text-left">
                    <div className="font-medium">{effect.name}</div>
                    <div className="text-xs text-muted-foreground">{effect.description}</div>
                  </div>
                </Button>
              ))}
            </div>
            <div className="text-xs text-muted-foreground p-2 bg-muted rounded">
              💡 Efek AI memerlukan processing yang lebih lama dan koneksi internet
            </div>
          </div>

          {/* Active AI Effects */}
          <div className="space-y-2">
            <h4 className="font-medium">Efek AI Aktif ({getEffectsByType('ai').length})</h4>
            <div className="max-h-32 overflow-y-auto space-y-2">
              {getEffectsByType('ai').map((effect) => (
                <div key={effect.id} className="p-2 border rounded space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{effect.name}</span>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={effect.enabled}
                        onCheckedChange={(checked) => onUpdateEffect(effect.id, { enabled: checked })}
                        size="sm"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onRemoveEffect(effect.id)}
                      >
                        ×
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Intensitas: {effect.intensity}%</Label>
                    <Slider
                      value={[effect.intensity]}
                      onValueChange={([value]) => onUpdateEffect(effect.id, { intensity: value })}
                      max={100}
                      step={10}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Quick Actions */}
      <div className="pt-4 border-t">
        <div className="grid grid-cols-2 gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              activeEffects.forEach(effect => onRemoveEffect(effect.id));
            }}
          >
            Clear All
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              activeEffects.forEach(effect => 
                onUpdateEffect(effect.id, { enabled: !effect.enabled })
              );
            }}
          >
            Toggle All
          </Button>
        </div>
      </div>
    </div>
  );
}