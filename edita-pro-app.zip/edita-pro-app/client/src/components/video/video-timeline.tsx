import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX,
  Maximize2,
  Clock,
  Gauge,
  Square,
  Zap
} from 'lucide-react';

interface TimelineMarker {
  id: string;
  time: number;
  type: 'speed' | 'freeze' | 'cut' | 'marker';
  value?: number;
  duration?: number;
  color: string;
}

interface VideoTimelineProps {
  duration: number;
  currentTime: number;
  isPlaying: boolean;
  volume: number;
  playbackSpeed: number;
  markers: TimelineMarker[];
  onTimeChange: (time: number) => void;
  onPlayPause: () => void;
  onVolumeChange: (volume: number) => void;
  onSpeedChange: (speed: number) => void;
  onMarkerAdd: (time: number, type: string) => void;
}

export function VideoTimeline({
  duration,
  currentTime,
  isPlaying,
  volume,
  playbackSpeed,
  markers,
  onTimeChange,
  onPlayPause,
  onVolumeChange,
  onSpeedChange,
  onMarkerAdd
}: VideoTimelineProps) {
  const timelineRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isVolumeVisible, setIsVolumeVisible] = useState(false);
  const [hoveredTime, setHoveredTime] = useState<number | null>(null);

  const formatTime = useCallback((seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 100);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
  }, []);

  const handleTimelineClick = useCallback((e: React.MouseEvent) => {
    if (!timelineRef.current) return;
    
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, x / rect.width));
    const newTime = percentage * duration;
    
    onTimeChange(newTime);
  }, [duration, onTimeChange]);

  const handleTimelineDrag = useCallback((e: React.MouseEvent) => {
    if (!isDragging) return;
    handleTimelineClick(e);
  }, [isDragging, handleTimelineClick]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!timelineRef.current) return;
    
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, x / rect.width));
    const time = percentage * duration;
    
    setHoveredTime(time);
  }, [duration]);

  const getMarkerPosition = useCallback((time: number) => {
    return (time / duration) * 100;
  }, [duration]);

  const speedPresets = [0.25, 0.5, 1, 1.5, 2, 4];

  return (
    <Card className="bg-gradient-to-r from-slate-800/90 to-slate-900/90 border border-purple-500/30">
      <CardContent className="p-4 space-y-4">
        {/* Main Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Playback Controls */}
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                className="border-purple-500/30 hover:bg-purple-500/20"
                onClick={() => onTimeChange(Math.max(0, currentTime - 10))}
              >
                <SkipBack className="h-4 w-4" />
              </Button>
              
              <Button
                onClick={onPlayPause}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 w-12 h-12 rounded-full"
              >
                {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 ml-0.5" />}
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className="border-purple-500/30 hover:bg-purple-500/20"
                onClick={() => onTimeChange(Math.min(duration, currentTime + 10))}
              >
                <SkipForward className="h-4 w-4" />
              </Button>
            </div>

            {/* Time Display */}
            <div className="flex items-center gap-2 text-white">
              <Clock className="h-4 w-4 text-purple-400" />
              <span className="font-mono text-sm">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Speed Control */}
            <div className="flex items-center gap-2">
              <Gauge className="h-4 w-4 text-blue-400" />
              <div className="flex items-center gap-1">
                {speedPresets.map((speed) => (
                  <Button
                    key={speed}
                    onClick={() => onSpeedChange(speed)}
                    variant={playbackSpeed === speed ? "default" : "outline"}
                    size="sm"
                    className={playbackSpeed === speed 
                      ? "bg-blue-500 text-white h-6 px-2 text-xs" 
                      : "border-blue-500/30 hover:bg-blue-500/20 h-6 px-2 text-xs"
                    }
                  >
                    {speed}x
                  </Button>
                ))}
              </div>
            </div>

            {/* Volume Control */}
            <div className="relative">
              <Button
                variant="outline"
                size="sm"
                className="border-purple-500/30 hover:bg-purple-500/20"
                onClick={() => setIsVolumeVisible(!isVolumeVisible)}
              >
                {volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </Button>
              
              {isVolumeVisible && (
                <div className="absolute right-0 bottom-full mb-2 p-2 bg-slate-800 border border-purple-500/30 rounded-lg">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={volume}
                    onChange={(e) => onVolumeChange(parseInt(e.target.value))}
                    className="w-20 h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              )}
            </div>

            {/* Fullscreen */}
            <Button
              variant="outline"
              size="sm"
              className="border-purple-500/30 hover:bg-purple-500/20"
            >
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Timeline */}
        <div className="space-y-2">
          {/* Timeline Track */}
          <div
            ref={timelineRef}
            className="relative h-12 bg-slate-700/50 rounded-lg cursor-pointer overflow-hidden"
            onClick={handleTimelineClick}
            onMouseDown={() => setIsDragging(true)}
            onMouseUp={() => setIsDragging(false)}
            onMouseMove={handleMouseMove}
            onMouseLeave={() => {
              setHoveredTime(null);
              setIsDragging(false);
            }}
          >
            {/* Background gradient */}
            <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 via-blue-900/20 to-purple-900/20" />
            
            {/* Waveform visualization (simplified) */}
            <div className="absolute inset-0 flex items-center px-2">
              {Array.from({ length: 50 }).map((_, i) => (
                <div
                  key={i}
                  className="flex-1 mx-px bg-gradient-to-t from-purple-400/40 to-blue-400/40 rounded-sm"
                  style={{ 
                    height: `${Math.random() * 60 + 20}%`,
                    opacity: currentTime / duration > i / 50 ? 1 : 0.3
                  }}
                />
              ))}
            </div>

            {/* Progress bar */}
            <div 
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-100 ease-out"
              style={{ width: `${(currentTime / duration) * 100}%` }}
            />

            {/* Markers */}
            {markers.map((marker) => (
              <div
                key={marker.id}
                className={`absolute top-0 w-1 h-full ${marker.color} opacity-80 hover:opacity-100 cursor-pointer`}
                style={{ left: `${getMarkerPosition(marker.time)}%` }}
                title={`${marker.type} at ${formatTime(marker.time)}`}
              >
                {marker.type === 'freeze' && (
                  <Square className="h-3 w-3 text-white absolute -top-1 -left-1" />
                )}
                {marker.type === 'speed' && (
                  <Zap className="h-3 w-3 text-white absolute -top-1 -left-1" />
                )}
              </div>
            ))}

            {/* Playhead */}
            <div 
              className="absolute top-0 w-0.5 h-full bg-white shadow-lg z-10"
              style={{ left: `${(currentTime / duration) * 100}%` }}
            >
              <div className="absolute -top-2 -left-2 w-4 h-4 bg-white rounded-full shadow-lg" />
            </div>

            {/* Hover indicator */}
            {hoveredTime !== null && (
              <div 
                className="absolute top-0 w-0.5 h-full bg-yellow-400/60"
                style={{ left: `${(hoveredTime / duration) * 100}%` }}
              >
                <div className="absolute -top-8 -left-8 bg-black/80 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                  {formatTime(hoveredTime)}
                </div>
              </div>
            )}
          </div>

          {/* Timeline Labels */}
          <div className="flex justify-between text-xs text-gray-400 px-1">
            <span>0:00</span>
            <span>{formatTime(duration / 4)}</span>
            <span>{formatTime(duration / 2)}</span>
            <span>{formatTime(duration * 3/4)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center gap-2">
          <Button
            onClick={() => onMarkerAdd(currentTime, 'speed')}
            variant="outline"
            size="sm"
            className="border-blue-500/30 hover:bg-blue-500/20 text-blue-300"
          >
            <Gauge className="h-3 w-3 mr-1" />
            Speed Point
          </Button>
          
          <Button
            onClick={() => onMarkerAdd(currentTime, 'freeze')}
            variant="outline"
            size="sm"
            className="border-indigo-500/30 hover:bg-indigo-500/20 text-indigo-300"
          >
            <Square className="h-3 w-3 mr-1" />
            Freeze Frame
          </Button>
          
          <div className="flex-1" />
          
          <Badge 
            className={`${
              playbackSpeed === 1 
                ? 'bg-green-500/20 text-green-300 border-green-500/30' 
                : playbackSpeed < 1
                ? 'bg-orange-500/20 text-orange-300 border-orange-500/30'
                : 'bg-blue-500/20 text-blue-300 border-blue-500/30'
            }`}
          >
            {playbackSpeed < 1 ? 'Slow Motion' : playbackSpeed > 1 ? 'Fast Motion' : 'Normal Speed'} 
            ({playbackSpeed}x)
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}