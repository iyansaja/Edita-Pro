import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Sparkles, 
  Eye, 
  RotateCcw, 
  Download, 
  Upload,
  Zap,
  Palette,
  Settings,
  Smile,
  User,
  Camera,
  Heart,
  Star,
  Wand2,
  Baby,
  Users,
  Layers,
  Aperture,
  Focus,
  Airplay
} from 'lucide-react';

interface FaceEffectSettings {
  skinSmoothing: number;
  eyeEnlargement: number;
  faceSlimming: number;
  lipsTint: number;
  eyebrowDarkening: number;
  teethWhitening: number;
  glowEffect: number;
  makeupIntensity: number;
}

interface FaceTransformSettings {
  cartoonLevel: number;
  ageShift: number; // -50 to +50 years
  genderBalance: number; // 0-100 (0=male, 100=female)
  artStyle: 'realistic' | 'cartoon' | 'anime' | 'oil-painting' | 'sketch';
}

interface BackgroundSettings {
  blur: number;
  brightness: number;
  saturation: number;
  virtualBg: string;
  bokehIntensity: number;
  depthOfField: number;
}

interface AIFaceEffectsProps {
  videoUrl?: string;
  onProcessed?: (processedVideo: string) => void;
  onClose?: () => void;
}

export function AIFaceEffects({ videoUrl, onProcessed, onClose }: AIFaceEffectsProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState<'beautify' | 'transform' | 'background'>('beautify');
  const [previewMode, setPreviewMode] = useState<'original' | 'processed'>('processed');
  const [isPlaying, setIsPlaying] = useState(false);
  const [faceDetected, setFaceDetected] = useState(true);
  
  const [beautifySettings, setBeautifySettings] = useState<FaceEffectSettings>({
    skinSmoothing: 30,
    eyeEnlargement: 15,
    faceSlimming: 10,
    lipsTint: 20,
    eyebrowDarkening: 15,
    teethWhitening: 25,
    glowEffect: 20,
    makeupIntensity: 40
  });
  
  const [transformSettings, setTransformSettings] = useState<FaceTransformSettings>({
    cartoonLevel: 0,
    ageShift: 0,
    genderBalance: 50,
    artStyle: 'realistic'
  });
  
  const [backgroundSettings, setBackgroundSettings] = useState<BackgroundSettings>({
    blur: 0,
    brightness: 0,
    saturation: 0,
    virtualBg: 'none',
    bokehIntensity: 0,
    depthOfField: 50
  });

  const [selectedVideo, setSelectedVideo] = useState<string>(videoUrl || '');

  // Beautify presets
  const beautifyPresets = [
    {
      id: 'natural',
      name: 'Natural',
      icon: Smile,
      description: 'Subtle enhancement',
      settings: { skinSmoothing: 20, eyeEnlargement: 10, faceSlimming: 5, makeupIntensity: 20 }
    },
    {
      id: 'instagram',
      name: 'Instagram',
      icon: Camera,
      description: 'Social media ready',
      settings: { skinSmoothing: 40, eyeEnlargement: 20, faceSlimming: 15, makeupIntensity: 50 }
    },
    {
      id: 'glamour',
      name: 'Glamour',
      icon: Star,
      description: 'Full makeup look',
      settings: { skinSmoothing: 60, eyeEnlargement: 30, faceSlimming: 20, makeupIntensity: 80 }
    },
    {
      id: 'professional',
      name: 'Professional',
      icon: User,
      description: 'Business appropriate',
      settings: { skinSmoothing: 25, eyeEnlargement: 5, faceSlimming: 8, makeupIntensity: 30 }
    }
  ];

  // Transform effects
  const transformEffects = [
    { id: 'cartoon', name: 'Cartoon', icon: Smile, description: 'Disney-style cartoon' },
    { id: 'anime', name: 'Anime', icon: Star, description: 'Japanese anime style' },
    { id: 'baby', name: 'Baby Face', icon: Baby, description: 'Younger appearance' },
    { id: 'aged', name: 'Aged', icon: User, description: 'Older appearance' },
    { id: 'gender', name: 'Gender Swap', icon: Users, description: 'Gender transformation' },
    { id: 'artistic', name: 'Art Style', icon: Palette, description: 'Artistic rendering' }
  ];

  // Virtual backgrounds
  const virtualBackgrounds = [
    { id: 'none', name: 'Original', preview: '', color: 'bg-gray-500' },
    { id: 'office', name: 'Office', preview: '', color: 'bg-blue-500' },
    { id: 'beach', name: 'Beach', preview: '', color: 'bg-cyan-500' },
    { id: 'space', name: 'Space', preview: '', color: 'bg-purple-900' },
    { id: 'nature', name: 'Nature', preview: '', color: 'bg-green-500' },
    { id: 'city', name: 'City', preview: '', color: 'bg-orange-500' }
  ];

  // Handle file upload
  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setSelectedVideo(url);
    }
  }, []);

  // Update beautify settings
  const updateBeautifySettings = useCallback((key: keyof FaceEffectSettings, value: number) => {
    setBeautifySettings(prev => ({
      ...prev,
      [key]: value
    }));
  }, []);

  // Update transform settings
  const updateTransformSettings = useCallback((key: keyof FaceTransformSettings, value: number | string) => {
    setTransformSettings(prev => ({
      ...prev,
      [key]: value
    }));
  }, []);

  // Update background settings
  const updateBackgroundSettings = useCallback((key: keyof BackgroundSettings, value: number | string) => {
    setBackgroundSettings(prev => ({
      ...prev,
      [key]: value
    }));
  }, []);

  // Apply beautify preset
  const applyBeautifyPreset = useCallback((preset: typeof beautifyPresets[0]) => {
    setBeautifySettings(prev => ({
      ...prev,
      ...preset.settings
    }));
  }, []);

  // Process with AI
  const processWithAI = useCallback(async () => {
    setIsProcessing(true);
    
    // Simulate AI processing
    const steps = [
      'Detecting facial features...',
      'Analyzing skin texture...',
      'Applying beauty filters...',
      'Processing background...',
      'Finalizing effects...'
    ];
    
    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    setIsProcessing(false);
  }, []);

  // Handle play/pause
  const handlePlayPause = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    
    if (isPlaying) {
      video.pause();
    } else {
      video.play();
    }
    setIsPlaying(!isPlaying);
  }, [isPlaying]);

  // Calculate overall effect intensity
  const getEffectIntensity = useCallback(() => {
    const beautifyIntensity = Object.values(beautifySettings).reduce((a, b) => a + b, 0) / Object.keys(beautifySettings).length;
    const transformIntensity = Math.abs(transformSettings.ageShift) + transformSettings.cartoonLevel;
    const backgroundIntensity = backgroundSettings.blur + backgroundSettings.bokehIntensity;
    
    return Math.round((beautifyIntensity + transformIntensity + backgroundIntensity) / 3);
  }, [beautifySettings, transformSettings, backgroundSettings]);

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-pink-900 to-slate-900 text-white overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-pink-900/80 to-purple-900/80 border border-pink-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-pink-400" />
              AI Face Effects & Beautify
              <Badge className="bg-gradient-to-r from-pink-500 to-purple-500 text-white border-0 ml-auto">
                <Wand2 className="h-3 w-3 mr-1" />
                AI Powered
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Video Preview */}
          <div className="lg:col-span-2 space-y-4">
            {/* Upload Section */}
            {!selectedVideo && (
              <Card className="bg-slate-800/50 border-dashed border-pink-500/30">
                <CardContent className="p-8 text-center">
                  <Upload className="h-12 w-12 mx-auto mb-4 text-pink-400" />
                  <h3 className="text-lg font-semibold text-white mb-2">Upload Video for AI Face Effects</h3>
                  <p className="text-gray-400 mb-4">AI akan mendeteksi wajah dan menerapkan efek beautify</p>
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Select Video File
                  </Button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="video/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </CardContent>
              </Card>
            )}

            {/* Video Player & Effects */}
            {selectedVideo && (
              <Card className="bg-slate-800/50 border-pink-500/30">
                <CardContent className="p-4">
                  <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                    {/* Original Video */}
                    <video
                      ref={videoRef}
                      src={selectedVideo}
                      className="w-full h-full object-contain"
                      loop
                      muted
                    />
                    
                    {/* Face Detection Overlay */}
                    {faceDetected && (
                      <div className="absolute top-20 left-1/2 transform -translate-x-1/2">
                        <div className="w-40 h-50 border-2 border-pink-400 rounded-lg">
                          <Badge className="absolute -top-6 left-0 bg-pink-500 text-white border-0">
                            Face Detected (96%)
                          </Badge>
                        </div>
                      </div>
                    )}
                    
                    {/* Processing Overlay */}
                    {isProcessing && (
                      <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                        <div className="text-center space-y-4">
                          <Sparkles className="w-16 h-16 mx-auto text-pink-400 animate-pulse" />
                          <div className="text-white">
                            <div className="text-lg font-semibold">AI Processing Face Effects...</div>
                            <div className="text-sm text-gray-400">Applying beautify & transformations</div>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {/* Controls */}
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Button
                          onClick={handlePlayPause}
                          variant="outline"
                          size="sm"
                          className="bg-black/60 border-white/20 hover:bg-white/20"
                        >
                          {isPlaying ? '⏸️' : '▶️'}
                        </Button>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Button
                          onClick={() => setPreviewMode(prev => prev === 'original' ? 'processed' : 'original')}
                          variant="outline"
                          size="sm"
                          className="bg-black/60 border-white/20 hover:bg-white/20"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          {previewMode}
                        </Button>
                        
                        <Badge className="bg-pink-500/20 text-pink-300 border-pink-500/30">
                          Effect: {getEffectIntensity()}%
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Controls Panel */}
          <div className="space-y-4">
            <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
              <TabsList className="grid w-full grid-cols-3 bg-slate-700/50">
                <TabsTrigger value="beautify" className="data-[state=active]:bg-pink-500">
                  <Sparkles className="h-4 w-4 mr-1" />
                  Beautify
                </TabsTrigger>
                <TabsTrigger value="transform" className="data-[state=active]:bg-pink-500">
                  <Wand2 className="h-4 w-4 mr-1" />
                  Transform
                </TabsTrigger>
                <TabsTrigger value="background" className="data-[state=active]:bg-pink-500">
                  <Layers className="h-4 w-4 mr-1" />
                  Background
                </TabsTrigger>
              </TabsList>

              {/* Beautify Tab */}
              <TabsContent value="beautify" className="space-y-4">
                {/* Presets */}
                <Card className="bg-slate-800/50 border-pink-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Beauty Presets</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      {beautifyPresets.map((preset) => {
                        const Icon = preset.icon;
                        return (
                          <Button
                            key={preset.id}
                            onClick={() => applyBeautifyPreset(preset)}
                            variant="outline"
                            className="h-auto p-3 border-pink-500/30 hover:bg-pink-500/20 text-left"
                          >
                            <div className="flex items-center gap-2 w-full">
                              <Icon className="h-4 w-4 text-pink-400" />
                              <div className="flex-1">
                                <div className="text-white text-sm font-medium">{preset.name}</div>
                                <div className="text-gray-400 text-xs">{preset.description}</div>
                              </div>
                            </div>
                          </Button>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>

                {/* Beautify Controls */}
                <Card className="bg-slate-800/50 border-purple-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Fine-Tuning</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Skin Smoothing */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Skin Smoothing</label>
                        <Badge className="bg-pink-500/20 text-pink-300 border-0">
                          {beautifySettings.skinSmoothing}%
                        </Badge>
                      </div>
                      <Slider
                        value={[beautifySettings.skinSmoothing]}
                        onValueChange={([value]) => updateBeautifySettings('skinSmoothing', value)}
                        max={100}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    {/* Eye Enlargement */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Eye Enlargement</label>
                        <Badge className="bg-blue-500/20 text-blue-300 border-0">
                          {beautifySettings.eyeEnlargement}%
                        </Badge>
                      </div>
                      <Slider
                        value={[beautifySettings.eyeEnlargement]}
                        onValueChange={([value]) => updateBeautifySettings('eyeEnlargement', value)}
                        max={50}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    {/* Face Slimming */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Face Slimming</label>
                        <Badge className="bg-green-500/20 text-green-300 border-0">
                          {beautifySettings.faceSlimming}%
                        </Badge>
                      </div>
                      <Slider
                        value={[beautifySettings.faceSlimming]}
                        onValueChange={([value]) => updateBeautifySettings('faceSlimming', value)}
                        max={30}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    {/* Makeup Intensity */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Makeup Intensity</label>
                        <Badge className="bg-purple-500/20 text-purple-300 border-0">
                          {beautifySettings.makeupIntensity}%
                        </Badge>
                      </div>
                      <Slider
                        value={[beautifySettings.makeupIntensity]}
                        onValueChange={([value]) => updateBeautifySettings('makeupIntensity', value)}
                        max={100}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Transform Tab */}
              <TabsContent value="transform" className="space-y-4">
                <Card className="bg-slate-800/50 border-yellow-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Face Transformation</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Age Transformation */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Age Shift</label>
                        <Badge className="bg-yellow-500/20 text-yellow-300 border-0">
                          {transformSettings.ageShift > 0 ? '+' : ''}{transformSettings.ageShift} years
                        </Badge>
                      </div>
                      <Slider
                        value={[transformSettings.ageShift]}
                        onValueChange={([value]) => updateTransformSettings('ageShift', value)}
                        max={50}
                        min={-50}
                        step={1}
                        className="w-full"
                      />
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>Younger</span>
                        <span>Older</span>
                      </div>
                    </div>

                    {/* Cartoon Level */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Cartoon Effect</label>
                        <Badge className="bg-orange-500/20 text-orange-300 border-0">
                          {transformSettings.cartoonLevel}%
                        </Badge>
                      </div>
                      <Slider
                        value={[transformSettings.cartoonLevel]}
                        onValueChange={([value]) => updateTransformSettings('cartoonLevel', value)}
                        max={100}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    {/* Art Style */}
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">Art Style</label>
                      <div className="grid grid-cols-2 gap-2">
                        {['realistic', 'cartoon', 'anime', 'sketch'].map((style) => (
                          <Button
                            key={style}
                            onClick={() => updateTransformSettings('artStyle', style)}
                            variant={transformSettings.artStyle === style ? "default" : "outline"}
                            size="sm"
                            className={transformSettings.artStyle === style 
                              ? "bg-yellow-500 text-white" 
                              : "border-yellow-500/30 hover:bg-yellow-500/20"
                            }
                          >
                            {style.charAt(0).toUpperCase() + style.slice(1)}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Background Tab */}
              <TabsContent value="background" className="space-y-4">
                <Card className="bg-slate-800/50 border-indigo-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Virtual Background</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Virtual Backgrounds */}
                    <div className="grid grid-cols-3 gap-2">
                      {virtualBackgrounds.map((bg) => (
                        <Button
                          key={bg.id}
                          onClick={() => updateBackgroundSettings('virtualBg', bg.id)}
                          variant={backgroundSettings.virtualBg === bg.id ? "default" : "outline"}
                          className={`h-16 ${
                            backgroundSettings.virtualBg === bg.id 
                              ? "border-indigo-400" 
                              : "border-indigo-500/30 hover:bg-indigo-500/20"
                          }`}
                        >
                          <div className={`w-full h-full rounded ${bg.color} flex items-center justify-center`}>
                            <span className="text-white text-xs font-medium">{bg.name}</span>
                          </div>
                        </Button>
                      ))}
                    </div>

                    {/* Bokeh Effect */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Bokeh Intensity</label>
                        <Badge className="bg-indigo-500/20 text-indigo-300 border-0">
                          {backgroundSettings.bokehIntensity}%
                        </Badge>
                      </div>
                      <Slider
                        value={[backgroundSettings.bokehIntensity]}
                        onValueChange={([value]) => updateBackgroundSettings('bokehIntensity', value)}
                        max={100}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    {/* Background Blur */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Background Blur</label>
                        <Badge className="bg-blue-500/20 text-blue-300 border-0">
                          {backgroundSettings.blur}%
                        </Badge>
                      </div>
                      <Slider
                        value={[backgroundSettings.blur]}
                        onValueChange={([value]) => updateBackgroundSettings('blur', value)}
                        max={100}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Process Button */}
            <Button
              onClick={processWithAI}
              disabled={isProcessing || !selectedVideo}
              className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
            >
              {isProcessing ? (
                <>
                  <Sparkles className="h-4 w-4 mr-2 animate-pulse" />
                  Processing AI Effects...
                </>
              ) : (
                <>
                  <Wand2 className="h-4 w-4 mr-2" />
                  Apply AI Face Effects
                </>
              )}
            </Button>

            {/* Reset Button */}
            <Button
              onClick={() => {
                setBeautifySettings({
                  skinSmoothing: 30,
                  eyeEnlargement: 15,
                  faceSlimming: 10,
                  lipsTint: 20,
                  eyebrowDarkening: 15,
                  teethWhitening: 25,
                  glowEffect: 20,
                  makeupIntensity: 40
                });
                setTransformSettings({
                  cartoonLevel: 0,
                  ageShift: 0,
                  genderBalance: 50,
                  artStyle: 'realistic'
                });
              }}
              variant="outline"
              className="w-full border-gray-500/30 hover:bg-gray-500/20"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset All Effects
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}