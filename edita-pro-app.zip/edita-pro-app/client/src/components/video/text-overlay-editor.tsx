import React, { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { 
  Type, 
  Bold, 
  Italic, 
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Palette,
  Move,
  RotateCw,
  Zap,
  Eye,
  Plus,
  Trash2
} from 'lucide-react';

interface TextOverlay {
  id: string;
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
  fontSize: number;
  fontFamily: string;
  color: string;
  backgroundColor: string;
  bold: boolean;
  italic: boolean;
  underline: boolean;
  alignment: 'left' | 'center' | 'right';
  animation: string;
  duration: number;
  startTime: number;
  endTime: number;
  rotation: number;
  opacity: number;
  // 3D & Effects
  shadow: boolean;
  shadowColor: string;
  shadowBlur: number;
  outline: boolean;
  outlineColor: string;
  outlineWidth: number;
  highlight: boolean;
  highlightColor: string;
  effect3D: boolean;
}

interface TextOverlayEditorProps {
  open: boolean;
  onClose: () => void;
  videoDuration: number;
  onAddTextOverlay: (overlay: TextOverlay) => void;
  existingOverlays: TextOverlay[];
  onUpdateOverlay: (id: string, overlay: Partial<TextOverlay>) => void;
  onDeleteOverlay: (id: string) => void;
}

const fontFamilies = [
  'Arial', 'Helvetica', 'Times New Roman', 'Georgia', 'Verdana', 
  'Tahoma', 'Impact', 'Comic Sans MS', 'Trebuchet MS', 'Lucida Console',
  'Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Poppins',
  'Oswald', 'Playfair Display', 'Dancing Script', 'Pacifico'
];

const animations = [
  { value: 'none', label: 'Tidak Ada' },
  { value: 'fadeIn', label: 'Fade In' },
  { value: 'fadeOut', label: 'Fade Out' },
  { value: 'slideInLeft', label: 'Slide In Kiri' },
  { value: 'slideInRight', label: 'Slide In Kanan' },
  { value: 'slideInTop', label: 'Slide In Atas' },
  { value: 'slideInBottom', label: 'Slide In Bawah' },
  { value: 'bounceIn', label: 'Bounce In' },
  { value: 'zoomIn', label: 'Zoom In' },
  { value: 'typewriter', label: 'Efek Ketik' },
  { value: 'shake', label: 'Bergoyang' },
  { value: 'pulse', label: 'Berkedip' },
  { value: 'rotate', label: 'Berputar' },
  { value: 'flip', label: 'Flip' }
];

const presetColors = [
  '#FFFFFF', '#000000', '#FF0000', '#00FF00', '#0000FF',
  '#FFFF00', '#FF00FF', '#00FFFF', '#FFA500', '#800080',
  '#FFC0CB', '#A52A2A', '#808080', '#FFD700', '#32CD32'
];

export function TextOverlayEditor({ 
  open, 
  onClose, 
  videoDuration, 
  onAddTextOverlay,
  existingOverlays,
  onUpdateOverlay,
  onDeleteOverlay
}: TextOverlayEditorProps) {
  const [selectedOverlay, setSelectedOverlay] = useState<string | null>(null);
  const [newOverlay, setNewOverlay] = useState<Omit<TextOverlay, 'id'>>({
    text: 'Teks Baru',
    x: 50,
    y: 50,
    width: 200,
    height: 50,
    fontSize: 24,
    fontFamily: 'Arial',
    color: '#FFFFFF',
    backgroundColor: 'transparent',
    bold: false,
    italic: false,
    underline: false,
    alignment: 'center',
    animation: 'fadeIn',
    duration: 1,
    startTime: 0,
    endTime: Math.min(5, videoDuration),
    rotation: 0,
    opacity: 100,
    shadow: true,
    shadowColor: '#000000',
    shadowBlur: 4,
    outline: false,
    outlineColor: '#000000',
    outlineWidth: 2,
    highlight: false,
    highlightColor: '#FFFF00',
    effect3D: false
  });

  const handleAddOverlay = () => {
    const overlay: TextOverlay = {
      ...newOverlay,
      id: Date.now().toString()
    };
    onAddTextOverlay(overlay);
    
    // Reset form
    setNewOverlay({
      ...newOverlay,
      text: 'Teks Baru',
      y: newOverlay.y + 60, // Offset untuk teks berikutnya
      startTime: newOverlay.endTime,
      endTime: Math.min(newOverlay.endTime + 5, videoDuration)
    });
  };

  const handleUpdateOverlay = (field: keyof TextOverlay, value: any) => {
    if (selectedOverlay) {
      onUpdateOverlay(selectedOverlay, { [field]: value });
    } else {
      setNewOverlay(prev => ({ ...prev, [field]: value }));
    }
  };

  const getCurrentOverlay = () => {
    if (selectedOverlay) {
      return existingOverlays.find(o => o.id === selectedOverlay);
    }
    return newOverlay;
  };

  const currentOverlay = getCurrentOverlay();

  const renderTextPreview = () => {
    if (!currentOverlay) return null;

    const textStyle: React.CSSProperties = {
      fontFamily: currentOverlay.fontFamily,
      fontSize: `${currentOverlay.fontSize}px`,
      color: currentOverlay.color,
      fontWeight: currentOverlay.bold ? 'bold' : 'normal',
      fontStyle: currentOverlay.italic ? 'italic' : 'normal',
      textDecoration: currentOverlay.underline ? 'underline' : 'none',
      textAlign: currentOverlay.alignment,
      transform: `rotate(${currentOverlay.rotation}deg) ${currentOverlay.effect3D ? 'perspective(1000px) rotateX(15deg)' : ''}`,
      opacity: currentOverlay.opacity / 100,
      padding: '8px 12px',
      borderRadius: '4px',
      position: 'relative' as const,
      display: 'inline-block',
      minWidth: '100px',
      textShadow: currentOverlay.shadow ? `2px 2px ${currentOverlay.shadowBlur}px ${currentOverlay.shadowColor}` : 'none',
      WebkitTextStroke: currentOverlay.outline ? `${currentOverlay.outlineWidth}px ${currentOverlay.outlineColor}` : 'none',
      background: currentOverlay.highlight ? currentOverlay.highlightColor : (currentOverlay.backgroundColor === 'transparent' ? 'transparent' : currentOverlay.backgroundColor)
    };

    return (
      <div className="bg-gray-900 p-6 rounded-lg flex items-center justify-center min-h-32">
        <div style={textStyle}>
          {currentOverlay.text}
        </div>
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editor Teks & Subtitle</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Preview */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Preview Teks</h3>
            {renderTextPreview()}
            
            {/* Existing Overlays List */}
            <div className="space-y-2">
              <h4 className="font-medium">Teks yang Ada</h4>
              <div className="max-h-32 overflow-y-auto space-y-1">
                {existingOverlays.length === 0 ? (
                  <div className="text-sm text-muted-foreground">Belum ada teks</div>
                ) : (
                  existingOverlays.map((overlay) => (
                    <div
                      key={overlay.id}
                      className={`flex items-center justify-between p-2 rounded border cursor-pointer ${
                        selectedOverlay === overlay.id ? 'border-primary bg-primary/10' : 'border-border'
                      }`}
                      onClick={() => setSelectedOverlay(overlay.id)}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">{overlay.text}</div>
                        <div className="text-xs text-muted-foreground">
                          {overlay.startTime}s - {overlay.endTime}s
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteOverlay(overlay.id);
                          if (selectedOverlay === overlay.id) {
                            setSelectedOverlay(null);
                          }
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Editor */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">
                {selectedOverlay ? 'Edit Teks' : 'Tambah Teks Baru'}
              </h3>
              {selectedOverlay && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedOverlay(null)}
                >
                  Buat Baru
                </Button>
              )}
            </div>

            <Tabs defaultValue="content" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="content">Konten</TabsTrigger>
                <TabsTrigger value="style">Style</TabsTrigger>
                <TabsTrigger value="effects">Efek</TabsTrigger>
                <TabsTrigger value="timing">Waktu</TabsTrigger>
              </TabsList>

              <TabsContent value="content" className="space-y-4">
                {/* Text Content */}
                <div className="space-y-2">
                  <Label>Teks</Label>
                  <Textarea
                    value={currentOverlay?.text || ''}
                    onChange={(e) => handleUpdateOverlay('text', e.target.value)}
                    placeholder="Masukkan teks..."
                    rows={3}
                  />
                </div>

                {/* Font Family */}
                <div className="space-y-2">
                  <Label>Font</Label>
                  <Select 
                    value={currentOverlay?.fontFamily || 'Arial'} 
                    onValueChange={(value) => handleUpdateOverlay('fontFamily', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {fontFamilies.map((font) => (
                        <SelectItem key={font} value={font} style={{ fontFamily: font }}>
                          {font}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Font Size */}
                <div className="space-y-2">
                  <Label>Ukuran Font: {currentOverlay?.fontSize}px</Label>
                  <Slider
                    value={[currentOverlay?.fontSize || 24]}
                    onValueChange={([value]) => handleUpdateOverlay('fontSize', value)}
                    min={12}
                    max={120}
                    step={2}
                  />
                </div>
              </TabsContent>

              <TabsContent value="style" className="space-y-4">
                {/* Text Formatting */}
                <div className="space-y-2">
                  <Label>Format Teks</Label>
                  <div className="flex space-x-2">
                    <Button
                      variant={currentOverlay?.bold ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleUpdateOverlay('bold', !currentOverlay?.bold)}
                    >
                      <Bold className="w-4 h-4" />
                    </Button>
                    <Button
                      variant={currentOverlay?.italic ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleUpdateOverlay('italic', !currentOverlay?.italic)}
                    >
                      <Italic className="w-4 h-4" />
                    </Button>
                    <Button
                      variant={currentOverlay?.underline ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleUpdateOverlay('underline', !currentOverlay?.underline)}
                    >
                      <Underline className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Text Alignment */}
                <div className="space-y-2">
                  <Label>Perataan</Label>
                  <div className="flex space-x-2">
                    <Button
                      variant={currentOverlay?.alignment === 'left' ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleUpdateOverlay('alignment', 'left')}
                    >
                      <AlignLeft className="w-4 h-4" />
                    </Button>
                    <Button
                      variant={currentOverlay?.alignment === 'center' ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleUpdateOverlay('alignment', 'center')}
                    >
                      <AlignCenter className="w-4 h-4" />
                    </Button>
                    <Button
                      variant={currentOverlay?.alignment === 'right' ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleUpdateOverlay('alignment', 'right')}
                    >
                      <AlignRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Colors */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Warna Teks</Label>
                    <div className="flex flex-wrap gap-1">
                      {presetColors.map((color) => (
                        <button
                          key={color}
                          className="w-6 h-6 rounded border border-gray-300"
                          style={{ backgroundColor: color }}
                          onClick={() => handleUpdateOverlay('color', color)}
                        />
                      ))}
                    </div>
                    <Input
                      type="color"
                      value={currentOverlay?.color || '#FFFFFF'}
                      onChange={(e) => handleUpdateOverlay('color', e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Background</Label>
                    <div className="flex flex-wrap gap-1">
                      <button
                        className="w-6 h-6 rounded border border-gray-300 bg-transparent"
                        onClick={() => handleUpdateOverlay('backgroundColor', 'transparent')}
                        title="Transparan"
                      >
                        <div className="w-full h-full bg-gradient-to-br from-gray-200 to-gray-400"></div>
                      </button>
                      {presetColors.map((color) => (
                        <button
                          key={color}
                          className="w-6 h-6 rounded border border-gray-300"
                          style={{ backgroundColor: color }}
                          onClick={() => handleUpdateOverlay('backgroundColor', color)}
                        />
                      ))}
                    </div>
                    <Input
                      type="color"
                      value={currentOverlay?.backgroundColor === 'transparent' ? '#000000' : currentOverlay?.backgroundColor || '#000000'}
                      onChange={(e) => handleUpdateOverlay('backgroundColor', e.target.value)}
                    />
                  </div>
                </div>

                {/* Opacity */}
                <div className="space-y-2">
                  <Label>Opacity: {currentOverlay?.opacity}%</Label>
                  <Slider
                    value={[currentOverlay?.opacity || 100]}
                    onValueChange={([value]) => handleUpdateOverlay('opacity', value)}
                    min={0}
                    max={100}
                    step={5}
                  />
                </div>

                {/* Rotation */}
                <div className="space-y-2">
                  <Label>Rotasi: {currentOverlay?.rotation}°</Label>
                  <Slider
                    value={[currentOverlay?.rotation || 0]}
                    onValueChange={([value]) => handleUpdateOverlay('rotation', value)}
                    min={-180}
                    max={180}
                    step={5}
                  />
                </div>
              </TabsContent>

              <TabsContent value="effects" className="space-y-4">
                {/* Animation */}
                <div className="space-y-2">
                  <Label>Animasi</Label>
                  <Select 
                    value={currentOverlay?.animation || 'fadeIn'} 
                    onValueChange={(value) => handleUpdateOverlay('animation', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {animations.map((anim) => (
                        <SelectItem key={anim.value} value={anim.value}>
                          {anim.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Shadow */}
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={currentOverlay?.shadow}
                      onCheckedChange={(checked) => handleUpdateOverlay('shadow', checked)}
                    />
                    <Label>Bayangan</Label>
                  </div>
                  {currentOverlay?.shadow && (
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        type="color"
                        value={currentOverlay?.shadowColor || '#000000'}
                        onChange={(e) => handleUpdateOverlay('shadowColor', e.target.value)}
                      />
                      <div className="space-y-1">
                        <Label className="text-xs">Blur: {currentOverlay?.shadowBlur}px</Label>
                        <Slider
                          value={[currentOverlay?.shadowBlur || 4]}
                          onValueChange={([value]) => handleUpdateOverlay('shadowBlur', value)}
                          min={0}
                          max={20}
                          step={1}
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Outline */}
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={currentOverlay?.outline}
                      onCheckedChange={(checked) => handleUpdateOverlay('outline', checked)}
                    />
                    <Label>Outline</Label>
                  </div>
                  {currentOverlay?.outline && (
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        type="color"
                        value={currentOverlay?.outlineColor || '#000000'}
                        onChange={(e) => handleUpdateOverlay('outlineColor', e.target.value)}
                      />
                      <div className="space-y-1">
                        <Label className="text-xs">Lebar: {currentOverlay?.outlineWidth}px</Label>
                        <Slider
                          value={[currentOverlay?.outlineWidth || 2]}
                          onValueChange={([value]) => handleUpdateOverlay('outlineWidth', value)}
                          min={1}
                          max={10}
                          step={1}
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Highlight */}
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={currentOverlay?.highlight}
                      onCheckedChange={(checked) => handleUpdateOverlay('highlight', checked)}
                    />
                    <Label>Highlight</Label>
                  </div>
                  {currentOverlay?.highlight && (
                    <Input
                      type="color"
                      value={currentOverlay?.highlightColor || '#FFFF00'}
                      onChange={(e) => handleUpdateOverlay('highlightColor', e.target.value)}
                    />
                  )}
                </div>

                {/* 3D Effect */}
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={currentOverlay?.effect3D}
                    onCheckedChange={(checked) => handleUpdateOverlay('effect3D', checked)}
                  />
                  <Label>Efek 3D</Label>
                </div>
              </TabsContent>

              <TabsContent value="timing" className="space-y-4">
                {/* Duration */}
                <div className="space-y-2">
                  <Label>Durasi Animasi: {currentOverlay?.duration}s</Label>
                  <Slider
                    value={[currentOverlay?.duration || 1]}
                    onValueChange={([value]) => handleUpdateOverlay('duration', value)}
                    min={0.1}
                    max={5}
                    step={0.1}
                  />
                </div>

                {/* Start Time */}
                <div className="space-y-2">
                  <Label>Waktu Mulai: {currentOverlay?.startTime}s</Label>
                  <Slider
                    value={[currentOverlay?.startTime || 0]}
                    onValueChange={([value]) => handleUpdateOverlay('startTime', value)}
                    min={0}
                    max={videoDuration}
                    step={0.1}
                  />
                </div>

                {/* End Time */}
                <div className="space-y-2">
                  <Label>Waktu Selesai: {currentOverlay?.endTime}s</Label>
                  <Slider
                    value={[currentOverlay?.endTime || 5]}
                    onValueChange={([value]) => handleUpdateOverlay('endTime', value)}
                    min={0}
                    max={videoDuration}
                    step={0.1}
                  />
                </div>

                {/* Position */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Posisi X: {currentOverlay?.x}%</Label>
                    <Slider
                      value={[currentOverlay?.x || 50]}
                      onValueChange={([value]) => handleUpdateOverlay('x', value)}
                      min={0}
                      max={100}
                      step={1}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Posisi Y: {currentOverlay?.y}%</Label>
                    <Slider
                      value={[currentOverlay?.y || 50]}
                      onValueChange={([value]) => handleUpdateOverlay('y', value)}
                      min={0}
                      max={100}
                      step={1}
                    />
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            {/* Action Buttons */}
            <div className="flex space-x-2 pt-4 border-t">
              {!selectedOverlay && (
                <Button onClick={handleAddOverlay} className="flex-1">
                  <Plus className="w-4 h-4 mr-2" />
                  Tambah Teks
                </Button>
              )}
              <Button variant="outline" onClick={onClose}>
                Selesai
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}