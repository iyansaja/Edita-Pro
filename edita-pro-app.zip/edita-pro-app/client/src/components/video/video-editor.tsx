import React, { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TextOverlayEditor } from './text-overlay-editor';
import { VisualEffectsPanel } from './visual-effects-panel-fixed';
import { StickerOverlayPanel } from './sticker-overlay-panel';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Scissors, 
  Copy, 
  RotateCw, 
  FlipHorizontal, 
  FlipVertical, 
  Undo, 
  Redo,
  Download,
  Upload,
  Type,
  Subtitles
} from 'lucide-react';

interface VideoEditorProps {
  open: boolean;
  onClose: () => void;
  videoUrl?: string;
  onSaveVideo: (editedVideoUrl: string) => void;
}

interface TextOverlay {
  id: string;
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
  fontSize: number;
  fontFamily: string;
  color: string;
  backgroundColor: string;
  bold: boolean;
  italic: boolean;
  underline: boolean;
  alignment: 'left' | 'center' | 'right';
  animation: string;
  duration: number;
  startTime: number;
  endTime: number;
  rotation: number;
  opacity: number;
  shadow: boolean;
  shadowColor: string;
  shadowBlur: number;
  outline: boolean;
  outlineColor: string;
  outlineWidth: number;
  highlight: boolean;
  highlightColor: string;
  effect3D: boolean;
}

interface StickerOverlay {
  id: string;
  type: 'sticker' | 'emoji' | 'gif' | 'overlay';
  content: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  opacity: number;
  startTime: number;
  endTime: number;
  blendMode: string;
  animation?: string;
  scale: number;
}

interface VisualEffect {
  id: string;
  name: string;
  type: 'filter' | 'transition' | 'trending' | 'ai';
  intensity: number;
  enabled: boolean;
  startTime?: number;
  duration?: number;
  params?: Record<string, any>;
}

interface VideoEdit {
  type: 'cut' | 'copy' | 'rotate' | 'flip' | 'reverse' | 'crop';
  startTime?: number;
  endTime?: number;
  angle?: number;
  direction?: 'horizontal' | 'vertical';
  aspectRatio?: string;
  timestamp: number;
}

const aspectRatios = [
  { value: '16:9', label: '16:9 (Landscape)' },
  { value: '9:16', label: '9:16 (Portrait)' },
  { value: '1:1', label: '1:1 (Square)' },
  { value: '4:3', label: '4:3 (Classic)' },
  { value: '21:9', label: '21:9 (Cinematic)' },
  { value: 'original', label: 'Original' }
];

export function VideoEditor({ open, onClose, videoUrl, onSaveVideo }: VideoEditorProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [selectedAspectRatio, setSelectedAspectRatio] = useState('original');
  const [rotation, setRotation] = useState(0);
  const [flipHorizontal, setFlipHorizontal] = useState(false);
  const [flipVertical, setFlipVertical] = useState(false);
  const [editHistory, setEditHistory] = useState<VideoEdit[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Segment selection for cutting
  const [selectionStart, setSelectionStart] = useState(0);
  const [selectionEnd, setSelectionEnd] = useState(0);
  const [isSelectingSegment, setIsSelectingSegment] = useState(false);

  // Text overlay states
  const [textOverlayEditorOpen, setTextOverlayEditorOpen] = useState(false);
  const [textOverlays, setTextOverlays] = useState<TextOverlay[]>([]);

  // Visual effects states
  const [visualEffects, setVisualEffects] = useState<VisualEffect[]>([]);

  // Sticker overlay states
  const [stickerOverlays, setStickerOverlays] = useState<StickerOverlay[]>([]);

  useEffect(() => {
    if (videoRef.current && videoUrl) {
      videoRef.current.src = videoUrl;
    }
  }, [videoUrl]);

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
      setSelectionEnd(videoRef.current.duration);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const seekTo = (time: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const addEdit = (edit: Omit<VideoEdit, 'timestamp'>) => {
    const newEdit: VideoEdit = {
      ...edit,
      timestamp: Date.now()
    };
    
    const newHistory = editHistory.slice(0, historyIndex + 1);
    newHistory.push(newEdit);
    setEditHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };

  const undo = () => {
    if (historyIndex > -1) {
      setHistoryIndex(historyIndex - 1);
      applyEditsUpToIndex(historyIndex - 1);
    }
  };

  const redo = () => {
    if (historyIndex < editHistory.length - 1) {
      setHistoryIndex(historyIndex + 1);
      applyEditsUpToIndex(historyIndex + 1);
    }
  };

  const applyEditsUpToIndex = (index: number) => {
    // Reset transformations
    setRotation(0);
    setFlipHorizontal(false);
    setFlipVertical(false);
    setSelectedAspectRatio('original');

    // Apply edits in sequence
    for (let i = 0; i <= index; i++) {
      const edit = editHistory[i];
      switch (edit.type) {
        case 'rotate':
          setRotation(prev => (prev + (edit.angle || 90)) % 360);
          break;
        case 'flip':
          if (edit.direction === 'horizontal') {
            setFlipHorizontal(prev => !prev);
          } else {
            setFlipVertical(prev => !prev);
          }
          break;
        case 'crop':
          setSelectedAspectRatio(edit.aspectRatio || 'original');
          break;
      }
    }
  };

  const handleRotate = () => {
    setRotation(prev => (prev + 90) % 360);
    addEdit({ type: 'rotate', angle: 90 });
  };

  const handleFlipHorizontal = () => {
    setFlipHorizontal(prev => !prev);
    addEdit({ type: 'flip', direction: 'horizontal' });
  };

  const handleFlipVertical = () => {
    setFlipVertical(prev => !prev);
    addEdit({ type: 'flip', direction: 'vertical' });
  };

  const handleAspectRatioChange = (ratio: string) => {
    setSelectedAspectRatio(ratio);
    addEdit({ type: 'crop', aspectRatio: ratio });
  };

  const handleCutSegment = () => {
    if (selectionStart < selectionEnd) {
      addEdit({ 
        type: 'cut', 
        startTime: selectionStart, 
        endTime: selectionEnd 
      });
      setIsSelectingSegment(false);
    }
  };

  const handleCopySegment = () => {
    if (selectionStart < selectionEnd) {
      addEdit({ 
        type: 'copy', 
        startTime: selectionStart, 
        endTime: selectionEnd 
      });
    }
  };

  const handleReverseVideo = () => {
    addEdit({ type: 'reverse' });
  };

  // Text overlay handlers
  const handleAddTextOverlay = (overlay: TextOverlay) => {
    setTextOverlays(prev => [...prev, overlay]);
  };

  const handleUpdateTextOverlay = (id: string, updates: Partial<TextOverlay>) => {
    setTextOverlays(prev => prev.map(overlay => 
      overlay.id === id ? { ...overlay, ...updates } : overlay
    ));
  };

  const handleDeleteTextOverlay = (id: string) => {
    setTextOverlays(prev => prev.filter(overlay => overlay.id !== id));
  };

  // Visual effects handlers
  const handleAddVisualEffect = (effect: VisualEffect) => {
    setVisualEffects(prev => [...prev, effect]);
  };

  const handleUpdateVisualEffect = (id: string, updates: Partial<VisualEffect>) => {
    setVisualEffects(prev => prev.map(effect => 
      effect.id === id ? { ...effect, ...updates } : effect
    ));
  };

  const handleRemoveVisualEffect = (id: string) => {
    setVisualEffects(prev => prev.filter(effect => effect.id !== id));
  };

  // Sticker overlay handlers
  const handleAddStickerOverlay = (sticker: StickerOverlay) => {
    setStickerOverlays(prev => [...prev, sticker]);
  };

  const handleUpdateStickerOverlay = (id: string, updates: Partial<StickerOverlay>) => {
    setStickerOverlays(prev => prev.map(sticker => 
      sticker.id === id ? { ...sticker, ...updates } : sticker
    ));
  };

  const handleRemoveStickerOverlay = (id: string) => {
    setStickerOverlays(prev => prev.filter(sticker => sticker.id !== id));
  };

  const renderVideoWithEffects = () => {
    const transform = `rotate(${rotation}deg) ${flipHorizontal ? 'scaleX(-1)' : ''} ${flipVertical ? 'scaleY(-1)' : ''}`;
    
    return (
      <div className="relative bg-black rounded-lg overflow-hidden">
        <video
          ref={videoRef}
          className="w-full h-auto max-h-96 object-contain"
          style={{ transform }}
          onLoadedMetadata={handleLoadedMetadata}
          onTimeUpdate={handleTimeUpdate}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
        >
          <source src={videoUrl} type="video/mp4" />
        </video>
        
        {/* Selection overlay for cutting */}
        {isSelectingSegment && (
          <div className="absolute bottom-0 left-0 right-0 h-2 bg-blue-500/20">
            <div 
              className="h-full bg-blue-500"
              style={{
                marginLeft: `${(selectionStart / duration) * 100}%`,
                width: `${((selectionEnd - selectionStart) / duration) * 100}%`
              }}
            />
          </div>
        )}
      </div>
    );
  };

  const exportVideo = async () => {
    setIsProcessing(true);
    try {
      // In a real implementation, this would process the video with all edits
      // For demo purposes, we'll simulate processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      onSaveVideo(videoUrl || '');
      onClose();
    } catch (error) {
      console.error('Error exporting video:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  if (!videoUrl) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Video Editor</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Video Preview */}
          <div className="lg:col-span-2 space-y-4">
            {renderVideoWithEffects()}
            
            {/* Video Controls */}
            <div className="space-y-4">
              <div className="flex items-center justify-center space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => seekTo(Math.max(0, currentTime - 10))}
                >
                  <SkipBack className="w-4 h-4" />
                </Button>
                
                <Button onClick={togglePlayPause}>
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => seekTo(Math.min(duration, currentTime + 10))}
                >
                  <SkipForward className="w-4 h-4" />
                </Button>
              </div>

              {/* Timeline */}
              <div className="space-y-2">
                <Slider
                  value={[currentTime]}
                  max={duration}
                  step={0.1}
                  onValueChange={([value]) => seekTo(value)}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{formatTime(currentTime)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>

              {/* Selection Range for Cutting */}
              {isSelectingSegment && (
                <div className="space-y-2">
                  <div className="text-sm font-medium">Select segment to cut:</div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs text-muted-foreground">Start</label>
                      <Slider
                        value={[selectionStart]}
                        max={duration}
                        step={0.1}
                        onValueChange={([value]) => setSelectionStart(value)}
                      />
                      <span className="text-xs">{formatTime(selectionStart)}</span>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground">End</label>
                      <Slider
                        value={[selectionEnd]}
                        max={duration}
                        step={0.1}
                        onValueChange={([value]) => setSelectionEnd(value)}
                      />
                      <span className="text-xs">{formatTime(selectionEnd)}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Editing Tools */}
          <div className="space-y-4">
            {/* History Controls */}
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={undo}
                disabled={historyIndex <= -1}
              >
                <Undo className="w-4 h-4 mr-2" />
                Undo
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={redo}
                disabled={historyIndex >= editHistory.length - 1}
              >
                <Redo className="w-4 h-4 mr-2" />
                Redo
              </Button>
            </div>

            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="basic">Basic</TabsTrigger>
                <TabsTrigger value="transform">Transform</TabsTrigger>
                <TabsTrigger value="text">Teks</TabsTrigger>
                <TabsTrigger value="effects">Efek</TabsTrigger>
                <TabsTrigger value="stickers">Stiker</TabsTrigger>
                <TabsTrigger value="advanced">Advanced</TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-4">
                {/* Cut & Copy */}
                <div className="space-y-2">
                  <h4 className="font-medium">Cut & Copy</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setIsSelectingSegment(!isSelectingSegment)}
                    >
                      <Scissors className="w-4 h-4 mr-2" />
                      {isSelectingSegment ? 'Cancel' : 'Cut'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCopySegment}
                      disabled={!isSelectingSegment}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy
                    </Button>
                  </div>
                  {isSelectingSegment && (
                    <Button
                      size="sm"
                      onClick={handleCutSegment}
                      className="w-full"
                    >
                      Apply Cut
                    </Button>
                  )}
                </div>

                {/* Aspect Ratio */}
                <div className="space-y-2">
                  <h4 className="font-medium">Aspect Ratio</h4>
                  <Select value={selectedAspectRatio} onValueChange={handleAspectRatioChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {aspectRatios.map((ratio) => (
                        <SelectItem key={ratio.value} value={ratio.value}>
                          {ratio.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </TabsContent>

              <TabsContent value="transform" className="space-y-4">
                {/* Rotation & Flip */}
                <div className="space-y-2">
                  <h4 className="font-medium">Transform</h4>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleRotate}
                    >
                      <RotateCw className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleFlipHorizontal}
                    >
                      <FlipHorizontal className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleFlipVertical}
                    >
                      <FlipVertical className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Rotation: {rotation}° | H-Flip: {flipHorizontal ? 'On' : 'Off'} | V-Flip: {flipVertical ? 'On' : 'Off'}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="text" className="space-y-4">
                {/* Text & Subtitle Tools */}
                <div className="space-y-2">
                  <h4 className="font-medium">Teks & Subtitle</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setTextOverlayEditorOpen(true)}
                    >
                      <Type className="w-4 h-4 mr-2" />
                      Tambah Teks
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled
                      title="Memerlukan OpenAI API Key"
                    >
                      <Subtitles className="w-4 h-4 mr-2" />
                      Auto Subtitle
                    </Button>
                  </div>
                </div>

                {/* Text Overlays List */}
                <div className="space-y-2">
                  <h4 className="font-medium">Teks pada Video ({textOverlays.length})</h4>
                  <div className="max-h-32 overflow-y-auto space-y-1">
                    {textOverlays.length === 0 ? (
                      <div className="text-xs text-muted-foreground">Belum ada teks</div>
                    ) : (
                      textOverlays.map((overlay) => (
                        <div
                          key={overlay.id}
                          className="flex items-center justify-between p-2 rounded border text-xs"
                        >
                          <div className="flex-1 min-w-0">
                            <div className="font-medium truncate">{overlay.text}</div>
                            <div className="text-muted-foreground">
                              {overlay.startTime}s - {overlay.endTime}s
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteTextOverlay(overlay.id)}
                          >
                            <Type className="w-3 h-3" />
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="effects" className="space-y-4">
                {/* Visual Effects Panel */}
                <VisualEffectsPanel
                  onAddEffect={handleAddVisualEffect}
                  activeEffects={visualEffects}
                  onUpdateEffect={handleUpdateVisualEffect}
                  onRemoveEffect={handleRemoveVisualEffect}
                  videoDuration={duration}
                />
              </TabsContent>

              <TabsContent value="stickers" className="space-y-4">
                {/* Sticker Overlay Panel */}
                <StickerOverlayPanel
                  onAddSticker={handleAddStickerOverlay}
                  activeStickers={stickerOverlays}
                  onUpdateSticker={handleUpdateStickerOverlay}
                  onRemoveSticker={handleRemoveStickerOverlay}
                  videoDuration={duration}
                />
              </TabsContent>

              <TabsContent value="advanced" className="space-y-4">
                {/* Advanced Effects */}
                <div className="space-y-2">
                  <h4 className="font-medium">Advanced</h4>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleReverseVideo}
                    className="w-full"
                  >
                    Reverse Video
                  </Button>
                </div>

                {/* Edit History */}
                <div className="space-y-2">
                  <h4 className="font-medium">Edit History</h4>
                  <div className="max-h-32 overflow-y-auto space-y-1">
                    {editHistory.length === 0 ? (
                      <div className="text-xs text-muted-foreground">No edits yet</div>
                    ) : (
                      editHistory.map((edit, index) => (
                        <div
                          key={edit.timestamp}
                          className={`text-xs p-2 rounded ${
                            index <= historyIndex
                              ? 'bg-primary/10 text-primary'
                              : 'bg-muted text-muted-foreground'
                          }`}
                        >
                          {edit.type} {edit.angle && `(${edit.angle}°)`} 
                          {edit.direction && `(${edit.direction})`}
                          {edit.aspectRatio && `(${edit.aspectRatio})`}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            {/* Export */}
            <div className="pt-4 border-t">
              <Button
                onClick={exportVideo}
                disabled={isProcessing}
                className="w-full"
              >
                <Download className="w-4 h-4 mr-2" />
                {isProcessing ? 'Processing...' : 'Export Video'}
              </Button>
            </div>
          </div>
        </div>

        {/* Text Overlay Editor */}
        <TextOverlayEditor
          open={textOverlayEditorOpen}
          onClose={() => setTextOverlayEditorOpen(false)}
          videoDuration={duration}
          onAddTextOverlay={handleAddTextOverlay}
          existingOverlays={textOverlays}
          onUpdateOverlay={handleUpdateTextOverlay}
          onDeleteOverlay={handleDeleteTextOverlay}
        />
      </DialogContent>
    </Dialog>
  );
}