import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Smile, 
  Heart, 
  Star, 
  Zap, 
  Crown,
  Camera,
  Gift,
  Sparkles,
  Sun,
  Moon,
  Rainbow,
  Flower,
  Leaf,
  Snowflake
} from 'lucide-react';

interface StickerOverlay {
  id: string;
  type: 'sticker' | 'emoji' | 'gif' | 'overlay';
  content: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  opacity: number;
  startTime: number;
  endTime: number;
  blendMode: string;
  animation?: string;
  scale: number;
}

interface StickerOverlayPanelProps {
  onAddSticker: (sticker: StickerOverlay) => void;
  activeStickers: StickerOverlay[];
  onUpdateSticker: (id: string, updates: Partial<StickerOverlay>) => void;
  onRemoveSticker: (id: string) => void;
  videoDuration: number;
}

const stickerCategories = {
  emotions: {
    name: 'Emosi',
    icon: Smile,
    stickers: ['😀', '😂', '🥰', '😎', '🤩', '😭', '😱', '🤔', '😴', '🤪', '😍', '🥳']
  },
  hearts: {
    name: 'Hati',
    icon: Heart,
    stickers: ['❤️', '💕', '💖', '💗', '💝', '💘', '💞', '💟', '♥️', '🧡', '💛', '💚']
  },
  celebrations: {
    name: 'Perayaan',
    icon: Star,
    stickers: ['🎉', '🎊', '🎈', '🎁', '🎂', '🎄', '🎃', '🎆', '🎇', '✨', '🎯', '🏆']
  },
  animals: {
    name: 'Hewan',
    icon: Gift,
    stickers: ['🐶', '🐱', '🐭', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐸', '🐙']
  },
  nature: {
    name: 'Alam',
    icon: Leaf,
    stickers: ['🌸', '🌺', '🌻', '🌷', '🌹', '🌿', '🍀', '🌳', '🌲', '🍃', '🌾', '🌵']
  },
  weather: {
    name: 'Cuaca',
    icon: Sun,
    stickers: ['☀️', '🌙', '⭐', '🌟', '💫', '⚡', '🌈', '☁️', '⛅', '🌦️', '❄️', '🔥']
  }
};

const animatedStickers = [
  { id: 'bounce-heart', name: 'Hati Bouncing', emoji: '💖', animation: 'bounce' },
  { id: 'spin-star', name: 'Bintang Berputar', emoji: '⭐', animation: 'spin' },
  { id: 'pulse-fire', name: 'Api Berkedip', emoji: '🔥', animation: 'pulse' },
  { id: 'shake-lightning', name: 'Petir Bergetar', emoji: '⚡', animation: 'shake' },
  { id: 'float-cloud', name: 'Awan Melayang', emoji: '☁️', animation: 'float' },
  { id: 'twinkle-sparkle', name: 'Kilauan Berkelip', emoji: '✨', animation: 'twinkle' }
];

const gifStickers = [
  { id: 'dancing-cat', name: 'Kucing Dansa', url: '🐱‍💻', category: 'fun' },
  { id: 'party-parrot', name: 'Burung Pesta', url: '🦜', category: 'party' },
  { id: 'rainbow-loading', name: 'Pelangi Loading', url: '🌈', category: 'effects' },
  { id: 'fireworks', name: 'Kembang Api', url: '🎆', category: 'celebration' },
  { id: 'hearts-floating', name: 'Hati Melayang', url: '💕', category: 'love' },
  { id: 'stars-twinkling', name: 'Bintang Berkelip', url: '⭐', category: 'magic' }
];

const blendModes = [
  { value: 'normal', label: 'Normal' },
  { value: 'multiply', label: 'Multiply (Gelap)' },
  { value: 'screen', label: 'Screen (Terang)' },
  { value: 'overlay', label: 'Overlay (Kontras)' },
  { value: 'soft-light', label: 'Soft Light' },
  { value: 'hard-light', label: 'Hard Light' },
  { value: 'color-dodge', label: 'Color Dodge' },
  { value: 'color-burn', label: 'Color Burn' },
  { value: 'darken', label: 'Darken' },
  { value: 'lighten', label: 'Lighten' },
  { value: 'difference', label: 'Difference' },
  { value: 'exclusion', label: 'Exclusion' }
];

const overlayTemplates = [
  { id: 'film-grain', name: 'Film Grain', description: 'Butiran film vintage' },
  { id: 'light-leak', name: 'Light Leak', description: 'Bocoran cahaya' },
  { id: 'dust-particles', name: 'Debu Melayang', description: 'Partikel debu' },
  { id: 'bokeh-lights', name: 'Bokeh Lights', description: 'Lampu bokeh' },
  { id: 'paper-texture', name: 'Tekstur Kertas', description: 'Overlay kertas' },
  { id: 'fabric-texture', name: 'Tekstur Kain', description: 'Overlay kain' }
];

export function StickerOverlayPanel({
  onAddSticker,
  activeStickers,
  onUpdateSticker,
  onRemoveSticker,
  videoDuration
}: StickerOverlayPanelProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('emotions');

  const addEmojiSticker = (emoji: string) => {
    const sticker: StickerOverlay = {
      id: `emoji_${Date.now()}`,
      type: 'emoji',
      content: emoji,
      x: 50,
      y: 50,
      width: 60,
      height: 60,
      rotation: 0,
      opacity: 100,
      startTime: 0,
      endTime: Math.min(5, videoDuration),
      blendMode: 'normal',
      scale: 1
    };
    onAddSticker(sticker);
  };

  const addAnimatedSticker = (sticker: typeof animatedStickers[0]) => {
    const animatedSticker: StickerOverlay = {
      id: `animated_${Date.now()}`,
      type: 'sticker',
      content: sticker.emoji,
      x: 50,
      y: 50,
      width: 80,
      height: 80,
      rotation: 0,
      opacity: 100,
      startTime: 0,
      endTime: Math.min(3, videoDuration),
      blendMode: 'normal',
      animation: sticker.animation,
      scale: 1
    };
    onAddSticker(animatedSticker);
  };

  const addGifSticker = (gif: typeof gifStickers[0]) => {
    const gifSticker: StickerOverlay = {
      id: `gif_${Date.now()}`,
      type: 'gif',
      content: gif.url,
      x: 50,
      y: 50,
      width: 100,
      height: 100,
      rotation: 0,
      opacity: 100,
      startTime: 0,
      endTime: videoDuration,
      blendMode: 'normal',
      scale: 1
    };
    onAddSticker(gifSticker);
  };

  const addOverlayTemplate = (template: typeof overlayTemplates[0]) => {
    const overlay: StickerOverlay = {
      id: `overlay_${Date.now()}`,
      type: 'overlay',
      content: template.id,
      x: 0,
      y: 0,
      width: 100,
      height: 100,
      rotation: 0,
      opacity: 30,
      startTime: 0,
      endTime: videoDuration,
      blendMode: 'overlay',
      scale: 1
    };
    onAddSticker(overlay);
  };

  const getStickersByType = (type: string) => {
    return activeStickers.filter(sticker => sticker.type === type);
  };

  const filteredStickers = searchTerm 
    ? Object.values(stickerCategories).flatMap(cat => 
        cat.stickers.filter(sticker => 
          sticker.toLowerCase().includes(searchTerm.toLowerCase())
        )
      )
    : stickerCategories[selectedCategory as keyof typeof stickerCategories]?.stickers || [];

  return (
    <div className="space-y-4">
      <Tabs defaultValue="emoji" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="emoji">Emoji</TabsTrigger>
          <TabsTrigger value="animated">Animasi</TabsTrigger>
          <TabsTrigger value="gif">GIF</TabsTrigger>
          <TabsTrigger value="overlay">Overlay</TabsTrigger>
        </TabsList>

        <TabsContent value="emoji" className="space-y-4">
          {/* Search & Category */}
          <div className="space-y-2">
            <Input
              placeholder="Cari emoji..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="text-sm"
            />
            
            {!searchTerm && (
              <div className="flex flex-wrap gap-1">
                {Object.entries(stickerCategories).map(([key, category]) => {
                  const Icon = category.icon;
                  return (
                    <Button
                      key={key}
                      variant={selectedCategory === key ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedCategory(key)}
                      className="text-xs"
                    >
                      <Icon className="w-3 h-3 mr-1" />
                      {category.name}
                    </Button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Emoji Grid */}
          <div className="grid grid-cols-6 gap-2 max-h-48 overflow-y-auto">
            {filteredStickers.map((emoji, index) => (
              <Button
                key={index}
                variant="outline"
                className="aspect-square p-0 text-2xl hover:scale-110 transition-transform"
                onClick={() => addEmojiSticker(emoji)}
                title="Klik untuk menambah ke video"
              >
                {emoji}
              </Button>
            ))}
          </div>

          {/* Active Emoji Stickers */}
          <div className="space-y-2">
            <h4 className="font-medium">Emoji Aktif ({getStickersByType('emoji').length})</h4>
            <div className="max-h-32 overflow-y-auto space-y-1">
              {getStickersByType('emoji').map((sticker) => (
                <div key={sticker.id} className="flex items-center justify-between p-2 border rounded text-sm">
                  <div className="flex items-center space-x-2">
                    <span className="text-lg">{sticker.content}</span>
                    <div>
                      <div className="font-medium">Scale: {Math.round(sticker.scale * 100)}%</div>
                      <div className="text-xs text-muted-foreground">
                        {sticker.startTime}s - {sticker.endTime}s
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onRemoveSticker(sticker.id)}
                  >
                    ×
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="animated" className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium flex items-center">
              <Sparkles className="w-4 h-4 mr-2" />
              Stiker Animasi
            </h4>
            <div className="space-y-2">
              {animatedStickers.map((sticker) => (
                <Button
                  key={sticker.id}
                  variant="outline"
                  size="sm"
                  onClick={() => addAnimatedSticker(sticker)}
                  className="w-full justify-start"
                >
                  <span className="text-lg mr-2">{sticker.emoji}</span>
                  <div className="text-left">
                    <div className="font-medium">{sticker.name}</div>
                    <div className="text-xs text-muted-foreground">{sticker.animation}</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Active Animated Stickers */}
          <div className="space-y-2">
            <h4 className="font-medium">Animasi Aktif ({getStickersByType('sticker').length})</h4>
            <div className="max-h-32 overflow-y-auto space-y-1">
              {getStickersByType('sticker').map((sticker) => (
                <div key={sticker.id} className="p-2 border rounded space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{sticker.content}</span>
                      <span className="text-sm font-medium">{sticker.animation}</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onRemoveSticker(sticker.id)}
                    >
                      ×
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <Label className="text-xs">Scale: {Math.round(sticker.scale * 100)}%</Label>
                      <Slider
                        value={[sticker.scale * 100]}
                        onValueChange={([value]) => onUpdateSticker(sticker.id, { scale: value / 100 })}
                        min={10}
                        max={300}
                        step={10}
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Opacity: {sticker.opacity}%</Label>
                      <Slider
                        value={[sticker.opacity]}
                        onValueChange={([value]) => onUpdateSticker(sticker.id, { opacity: value })}
                        max={100}
                        step={5}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="gif" className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium flex items-center">
              <Zap className="w-4 h-4 mr-2" />
              GIF Stickers
            </h4>
            <div className="space-y-2">
              {gifStickers.map((gif) => (
                <Button
                  key={gif.id}
                  variant="outline"
                  size="sm"
                  onClick={() => addGifSticker(gif)}
                  className="w-full justify-start"
                >
                  <span className="text-lg mr-2">{gif.url}</span>
                  <div className="text-left">
                    <div className="font-medium">{gif.name}</div>
                    <div className="text-xs text-muted-foreground">{gif.category}</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Active GIF Stickers */}
          <div className="space-y-2">
            <h4 className="font-medium">GIF Aktif ({getStickersByType('gif').length})</h4>
            <div className="max-h-32 overflow-y-auto space-y-1">
              {getStickersByType('gif').map((sticker) => (
                <div key={sticker.id} className="p-2 border rounded">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg">{sticker.content}</span>
                      <div className="text-sm">
                        <div>Scale: {Math.round(sticker.scale * 100)}%</div>
                        <div className="text-xs text-muted-foreground">
                          {sticker.startTime}s - {sticker.endTime}s
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onRemoveSticker(sticker.id)}
                    >
                      ×
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="overlay" className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium flex items-center">
              <Camera className="w-4 h-4 mr-2" />
              Video Overlays
            </h4>
            <div className="space-y-2">
              {overlayTemplates.map((template) => (
                <Button
                  key={template.id}
                  variant="outline"
                  size="sm"
                  onClick={() => addOverlayTemplate(template)}
                  className="w-full justify-start"
                >
                  <div className="text-left">
                    <div className="font-medium">{template.name}</div>
                    <div className="text-xs text-muted-foreground">{template.description}</div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Active Overlays */}
          <div className="space-y-2">
            <h4 className="font-medium">Overlay Aktif ({getStickersByType('overlay').length})</h4>
            <div className="max-h-32 overflow-y-auto space-y-2">
              {getStickersByType('overlay').map((overlay) => (
                <div key={overlay.id} className="p-2 border rounded space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{overlay.content}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onRemoveSticker(overlay.id)}
                    >
                      ×
                    </Button>
                  </div>
                  <div className="space-y-2">
                    <div className="space-y-1">
                      <Label className="text-xs">Blend Mode</Label>
                      <Select
                        value={overlay.blendMode}
                        onValueChange={(value) => onUpdateSticker(overlay.id, { blendMode: value })}
                      >
                        <SelectTrigger className="h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {blendModes.map((mode) => (
                            <SelectItem key={mode.value} value={mode.value}>
                              {mode.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Opacity: {overlay.opacity}%</Label>
                      <Slider
                        value={[overlay.opacity]}
                        onValueChange={([value]) => onUpdateSticker(overlay.id, { opacity: value })}
                        max={100}
                        step={5}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Quick Actions */}
      <div className="pt-4 border-t">
        <div className="grid grid-cols-2 gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              activeStickers.forEach(sticker => onRemoveSticker(sticker.id));
            }}
          >
            Clear All
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => {
              // Add random popular emoji
              const popularEmojis = ['😍', '🔥', '✨', '💯', '🎉', '❤️'];
              const randomEmoji = popularEmojis[Math.floor(Math.random() * popularEmojis.length)];
              addEmojiSticker(randomEmoji);
            }}
          >
            Random Emoji
          </Button>
        </div>
      </div>
    </div>
  );
}