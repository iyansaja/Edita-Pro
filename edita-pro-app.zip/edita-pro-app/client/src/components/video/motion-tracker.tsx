import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Target, 
  Eye, 
  Crosshair, 
  RotateCcw, 
  Download, 
  Upload,
  Zap,
  Layers,
  Settings,
  Sparkles,
  Square,
  Circle,
  Play,
  Pause,
  User,
  Smile,
  Camera,
  MousePointer,
  Move,
  Lock,
  Unlock,
  Filter
} from 'lucide-react';

interface TrackingPoint {
  id: string;
  x: number;
  y: number;
  confidence: number;
  timestamp: number;
}

interface TrackingObject {
  id: string;
  type: 'face' | 'object' | 'custom';
  label: string;
  points: TrackingPoint[];
  active: boolean;
  color: string;
  boundingBox?: { x: number; y: number; width: number; height: number };
}

interface AttachedElement {
  id: string;
  type: 'sticker' | 'text' | 'blur' | 'frame';
  content: string;
  trackingObjectId: string;
  offsetX: number;
  offsetY: number;
  scale: number;
  rotation: number;
  opacity: number;
  locked: boolean;
}

interface MotionTrackerProps {
  videoUrl?: string;
  onTracked?: (trackingData: any) => void;
  onClose?: () => void;
}

export function MotionTracker({ videoUrl, onTracked, onClose }: MotionTrackerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isTracking, setIsTracking] = useState(false);
  const [trackingMode, setTrackingMode] = useState<'auto' | 'manual' | 'face'>('face');
  const [activeTab, setActiveTab] = useState<'setup' | 'track' | 'elements'>('setup');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentFrame, setCurrentFrame] = useState(0);
  
  const [trackingObjects, setTrackingObjects] = useState<TrackingObject[]>([]);
  const [attachedElements, setAttachedElements] = useState<AttachedElement[]>([]);
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  
  const [trackingSettings, setTrackingSettings] = useState({
    sensitivity: 85,
    smoothing: 15,
    accuracy: 90,
    faceDetection: true,
    objectDetection: true,
    motionPrediction: true
  });

  const [selectedVideo, setSelectedVideo] = useState<string>(videoUrl || '');

  // Predefined tracking presets
  const trackingPresets = [
    {
      id: 'face',
      name: 'Face Tracking',
      icon: Smile,
      description: 'Track facial features automatically',
      settings: { sensitivity: 90, smoothing: 20, accuracy: 95 }
    },
    {
      id: 'object',
      name: 'Object Tracking',
      icon: Target,
      description: 'Track any object manually',
      settings: { sensitivity: 80, smoothing: 10, accuracy: 85 }
    },
    {
      id: 'motion',
      name: 'Motion Tracking',
      icon: Move,
      description: 'Track movement and gestures',
      settings: { sensitivity: 75, smoothing: 25, accuracy: 80 }
    }
  ];

  // Available elements to attach
  const elementTypes = [
    {
      id: 'sticker',
      name: 'Sticker',
      icon: Sparkles,
      options: ['😀', '❤️', '⭐', '🔥', '👍', '🎉']
    },
    {
      id: 'text',
      name: 'Text',
      icon: Square,
      options: ['SUBSCRIBE', 'LIKE', 'FOLLOW', 'VIRAL']
    },
    {
      id: 'blur',
      name: 'Blur Effect',
      icon: Filter,
      options: ['Face Blur', 'Object Blur', 'Background Blur']
    },
    {
      id: 'frame',
      name: 'Frame',
      icon: Square,
      options: ['Circle', 'Square', 'Heart', 'Star']
    }
  ];

  // Handle file upload
  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setSelectedVideo(url);
    }
  }, []);

  // Start tracking
  const startTracking = useCallback(async () => {
    setIsTracking(true);
    
    // Simulate AI tracking process
    const mockFaceTracking: TrackingObject = {
      id: 'face_1',
      type: 'face',
      label: 'Face',
      points: [
        { id: '1', x: 200, y: 150, confidence: 0.95, timestamp: 0 },
        { id: '2', x: 205, y: 152, confidence: 0.93, timestamp: 100 },
        { id: '3', x: 210, y: 155, confidence: 0.94, timestamp: 200 }
      ],
      active: true,
      color: '#00ff00',
      boundingBox: { x: 180, y: 130, width: 60, height: 80 }
    };
    
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setTrackingObjects([mockFaceTracking]);
    setIsTracking(false);
  }, []);

  // Add tracking point manually
  const addTrackingPoint = useCallback((x: number, y: number) => {
    if (trackingMode !== 'manual') return;
    
    const newObject: TrackingObject = {
      id: `custom_${Date.now()}`,
      type: 'custom',
      label: `Point ${trackingObjects.length + 1}`,
      points: [{ id: '1', x, y, confidence: 1.0, timestamp: currentFrame }],
      active: true,
      color: '#ff0000'
    };
    
    setTrackingObjects(prev => [...prev, newObject]);
  }, [trackingMode, trackingObjects.length, currentFrame]);

  // Attach element to tracking object
  const attachElement = useCallback((elementType: string, content: string, trackingObjectId: string) => {
    const newElement: AttachedElement = {
      id: `element_${Date.now()}`,
      type: elementType as any,
      content,
      trackingObjectId,
      offsetX: 0,
      offsetY: -30,
      scale: 1,
      rotation: 0,
      opacity: 1,
      locked: false
    };
    
    setAttachedElements(prev => [...prev, newElement]);
  }, []);

  // Update element properties
  const updateElement = useCallback((elementId: string, updates: Partial<AttachedElement>) => {
    setAttachedElements(prev => 
      prev.map(el => el.id === elementId ? { ...el, ...updates } : el)
    );
  }, []);

  // Remove element
  const removeElement = useCallback((elementId: string) => {
    setAttachedElements(prev => prev.filter(el => el.id !== elementId));
    if (selectedElement === elementId) {
      setSelectedElement(null);
    }
  }, [selectedElement]);

  // Handle canvas click for manual tracking
  const handleCanvasClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    addTrackingPoint(x, y);
  }, [addTrackingPoint]);

  // Handle play/pause
  const handlePlayPause = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    
    if (isPlaying) {
      video.pause();
    } else {
      video.play();
    }
    setIsPlaying(!isPlaying);
  }, [isPlaying]);

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 text-white overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Target className="h-6 w-6 text-indigo-400" />
              Motion Tracking Studio
              <Badge className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-0 ml-auto">
                <Sparkles className="h-3 w-3 mr-1" />
                AI Powered
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Video Preview & Tracking */}
          <div className="lg:col-span-2 space-y-4">
            {/* Upload Section */}
            {!selectedVideo && (
              <Card className="bg-slate-800/50 border-dashed border-indigo-500/30">
                <CardContent className="p-8 text-center">
                  <Upload className="h-12 w-12 mx-auto mb-4 text-indigo-400" />
                  <h3 className="text-lg font-semibold text-white mb-2">Upload Video for Motion Tracking</h3>
                  <p className="text-gray-400 mb-4">AI akan melacak gerakan objek secara real-time</p>
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Select Video File
                  </Button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="video/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </CardContent>
              </Card>
            )}

            {/* Video Player & Tracking Canvas */}
            {selectedVideo && (
              <Card className="bg-slate-800/50 border-indigo-500/30">
                <CardContent className="p-4">
                  <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                    {/* Original Video */}
                    <video
                      ref={videoRef}
                      src={selectedVideo}
                      className="w-full h-full object-contain"
                      loop
                      muted
                    />
                    
                    {/* Tracking Overlay Canvas */}
                    <canvas
                      ref={canvasRef}
                      className="absolute inset-0 w-full h-full cursor-crosshair"
                      onClick={handleCanvasClick}
                    />
                    
                    {/* Tracking Objects Visualization */}
                    {trackingObjects.map((obj) => (
                      <div key={obj.id} className="absolute">
                        {/* Bounding Box */}
                        {obj.boundingBox && (
                          <div
                            className="absolute border-2 rounded"
                            style={{
                              left: `${obj.boundingBox.x}px`,
                              top: `${obj.boundingBox.y}px`,
                              width: `${obj.boundingBox.width}px`,
                              height: `${obj.boundingBox.height}px`,
                              borderColor: obj.color
                            }}
                          >
                            <Badge 
                              className="absolute -top-6 left-0 text-white border-0"
                              style={{ backgroundColor: obj.color }}
                            >
                              {obj.label}
                            </Badge>
                          </div>
                        )}
                        
                        {/* Tracking Points */}
                        {obj.points.map((point) => (
                          <div
                            key={point.id}
                            className="absolute w-2 h-2 rounded-full"
                            style={{
                              left: `${point.x}px`,
                              top: `${point.y}px`,
                              backgroundColor: obj.color,
                              transform: 'translate(-50%, -50%)'
                            }}
                          />
                        ))}
                      </div>
                    ))}
                    
                    {/* Attached Elements */}
                    {attachedElements.map((element) => {
                      const trackingObj = trackingObjects.find(obj => obj.id === element.trackingObjectId);
                      if (!trackingObj || trackingObj.points.length === 0) return null;
                      
                      const lastPoint = trackingObj.points[trackingObj.points.length - 1];
                      
                      return (
                        <div
                          key={element.id}
                          className={`absolute pointer-events-none ${
                            selectedElement === element.id ? 'ring-2 ring-yellow-400' : ''
                          }`}
                          style={{
                            left: `${lastPoint.x + element.offsetX}px`,
                            top: `${lastPoint.y + element.offsetY}px`,
                            transform: `translate(-50%, -50%) scale(${element.scale}) rotate(${element.rotation}deg)`,
                            opacity: element.opacity
                          }}
                        >
                          {element.type === 'sticker' && (
                            <div className="text-3xl">{element.content}</div>
                          )}
                          {element.type === 'text' && (
                            <div className="text-white font-bold text-lg bg-black/50 px-2 py-1 rounded">
                              {element.content}
                            </div>
                          )}
                          {element.type === 'blur' && (
                            <div className="w-16 h-16 bg-white/30 backdrop-blur-md rounded-full" />
                          )}
                          {element.type === 'frame' && (
                            <div className="w-20 h-20 border-4 border-white rounded-full" />
                          )}
                        </div>
                      );
                    })}
                    
                    {/* Tracking Status Overlay */}
                    {isTracking && (
                      <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                        <div className="text-center space-y-4">
                          <Target className="w-16 h-16 mx-auto text-indigo-400 animate-spin" />
                          <div className="text-white">
                            <div className="text-lg font-semibold">AI Tracking in Progress...</div>
                            <div className="text-sm text-gray-400">Analyzing motion patterns</div>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {/* Controls */}
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Button
                          onClick={handlePlayPause}
                          variant="outline"
                          size="sm"
                          className="bg-black/60 border-white/20 hover:bg-white/20"
                        >
                          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                        
                        <Badge className="bg-indigo-500/20 text-indigo-300 border-indigo-500/30">
                          {trackingObjects.length} Objects Tracked
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                          {attachedElements.length} Elements Attached
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Controls Panel */}
          <div className="space-y-4">
            <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
              <TabsList className="grid w-full grid-cols-3 bg-slate-700/50">
                <TabsTrigger value="setup" className="data-[state=active]:bg-indigo-500">
                  <Settings className="h-4 w-4 mr-1" />
                  Setup
                </TabsTrigger>
                <TabsTrigger value="track" className="data-[state=active]:bg-indigo-500">
                  <Target className="h-4 w-4 mr-1" />
                  Track
                </TabsTrigger>
                <TabsTrigger value="elements" className="data-[state=active]:bg-indigo-500">
                  <Layers className="h-4 w-4 mr-1" />
                  Elements
                </TabsTrigger>
              </TabsList>

              {/* Setup Tab */}
              <TabsContent value="setup" className="space-y-4">
                <Card className="bg-slate-800/50 border-indigo-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Tracking Presets</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {trackingPresets.map((preset) => {
                      const Icon = preset.icon;
                      return (
                        <Button
                          key={preset.id}
                          onClick={() => setTrackingMode(preset.id as any)}
                          variant={trackingMode === preset.id ? "default" : "outline"}
                          className={`w-full h-auto p-4 text-left ${
                            trackingMode === preset.id 
                              ? "bg-indigo-500 text-white" 
                              : "border-indigo-500/30 hover:bg-indigo-500/20"
                          }`}
                        >
                          <div className="flex items-start gap-3 w-full">
                            <Icon className="h-5 w-5 text-indigo-400 mt-1" />
                            <div className="flex-1">
                              <div className="font-medium">{preset.name}</div>
                              <div className="text-sm opacity-70">{preset.description}</div>
                            </div>
                          </div>
                        </Button>
                      );
                    })}
                  </CardContent>
                </Card>

                {/* Tracking Settings */}
                <Card className="bg-slate-800/50 border-purple-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Tracking Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Sensitivity */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Sensitivity</label>
                        <Badge className="bg-purple-500/20 text-purple-300 border-0">
                          {trackingSettings.sensitivity}%
                        </Badge>
                      </div>
                      <Slider
                        value={[trackingSettings.sensitivity]}
                        onValueChange={([value]) => setTrackingSettings(prev => ({ ...prev, sensitivity: value }))}
                        max={100}
                        min={50}
                        step={5}
                        className="w-full"
                      />
                    </div>

                    {/* Smoothing */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-gray-300">Smoothing</label>
                        <Badge className="bg-blue-500/20 text-blue-300 border-0">
                          {trackingSettings.smoothing}%
                        </Badge>
                      </div>
                      <Slider
                        value={[trackingSettings.smoothing]}
                        onValueChange={([value]) => setTrackingSettings(prev => ({ ...prev, smoothing: value }))}
                        max={50}
                        min={0}
                        step={5}
                        className="w-full"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Track Tab */}
              <TabsContent value="track" className="space-y-4">
                <Card className="bg-slate-800/50 border-green-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Start Tracking</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button
                      onClick={startTracking}
                      disabled={isTracking || !selectedVideo}
                      className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600"
                    >
                      {isTracking ? (
                        <>
                          <Target className="h-4 w-4 mr-2 animate-spin" />
                          Tracking...
                        </>
                      ) : (
                        <>
                          <Crosshair className="h-4 w-4 mr-2" />
                          Start AI Tracking
                        </>
                      )}
                    </Button>

                    {trackingMode === 'manual' && (
                      <div className="text-center text-sm text-gray-400">
                        Click on the video to add tracking points manually
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Tracked Objects */}
                {trackingObjects.length > 0 && (
                  <Card className="bg-slate-800/50 border-yellow-500/30">
                    <CardHeader>
                      <CardTitle className="text-white text-sm">Tracked Objects</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {trackingObjects.map((obj) => (
                        <div
                          key={obj.id}
                          className="flex items-center justify-between p-2 bg-slate-700/50 rounded"
                        >
                          <div className="flex items-center gap-2">
                            <div 
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: obj.color }}
                            />
                            <span className="text-white text-sm">{obj.label}</span>
                          </div>
                          <Badge className="bg-green-500/20 text-green-300 border-0 text-xs">
                            {obj.points.length} points
                          </Badge>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              {/* Elements Tab */}
              <TabsContent value="elements" className="space-y-4">
                <Card className="bg-slate-800/50 border-orange-500/30">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">Add Elements</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {elementTypes.map((elementType) => {
                      const Icon = elementType.icon;
                      return (
                        <div key={elementType.id} className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Icon className="h-4 w-4 text-orange-400" />
                            <span className="text-white text-sm font-medium">{elementType.name}</span>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            {elementType.options.map((option) => (
                              <Button
                                key={option}
                                onClick={() => {
                                  if (trackingObjects.length > 0) {
                                    attachElement(elementType.id, option, trackingObjects[0].id);
                                  }
                                }}
                                variant="outline"
                                size="sm"
                                className="border-orange-500/30 hover:bg-orange-500/20 text-xs"
                                disabled={trackingObjects.length === 0}
                              >
                                {elementType.id === 'sticker' ? option : option}
                              </Button>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </CardContent>
                </Card>

                {/* Attached Elements */}
                {attachedElements.length > 0 && (
                  <Card className="bg-slate-800/50 border-pink-500/30">
                    <CardHeader>
                      <CardTitle className="text-white text-sm">Attached Elements</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {attachedElements.map((element) => (
                        <div
                          key={element.id}
                          className={`p-3 rounded border transition-all cursor-pointer ${
                            selectedElement === element.id 
                              ? 'bg-pink-500/20 border-pink-400' 
                              : 'bg-slate-700/50 border-slate-600 hover:border-slate-500'
                          }`}
                          onClick={() => setSelectedElement(element.id)}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="text-white text-sm font-medium">
                                {element.type} - {element.content}
                              </div>
                              <div className="text-gray-400 text-xs">
                                Offset: ({element.offsetX}, {element.offsetY})
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  updateElement(element.id, { locked: !element.locked });
                                }}
                                variant="outline"
                                size="sm"
                                className="border-gray-500/30 hover:bg-gray-500/20 p-1"
                              >
                                {element.locked ? <Lock className="h-3 w-3" /> : <Unlock className="h-3 w-3" />}
                              </Button>
                              <Button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  removeElement(element.id);
                                }}
                                variant="outline"
                                size="sm"
                                className="border-red-500/30 hover:bg-red-500/20 p-1 text-red-300"
                              >
                                ✕
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}