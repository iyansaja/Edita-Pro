import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Palette,
  Sparkles,
  Sun,
  Moon,
  Heart,
  Zap,
  Music,
  Smile,
  Eye,
  Target,
  Wand2,
  Filter,
  Adjust,
  Camera,
  Video,
  Image as ImageIcon,
  TrendingUp,
  Users,
  Clock
} from 'lucide-react';

interface MoodFilter {
  id: string;
  name: string;
  icon: any;
  color: string;
  description: string;
  platforms: string[];
  adjustments: {
    brightness: number;
    contrast: number;
    saturation: number;
    warmth: number;
    vibrance: number;
    clarity: number;
  };
  effects: string[];
  popularity: number;
}

interface PlatformProfile {
  id: string;
  name: string;
  icon: string;
  primaryMoods: string[];
  colorScheme: string;
  preferredAdjustments: {
    brightness: number;
    contrast: number;
    saturation: number;
  };
}

interface MoodFilterEngineProps {
  onFilterApply?: (filter: MoodFilter, platform: string) => void;
  onPresetSave?: (preset: any) => void;
  selectedPlatform?: string;
}

export function MoodFilterEngine({ onFilterApply, onPresetSave, selectedPlatform = 'tiktok' }: MoodFilterEngineProps) {
  const [activeFilter, setActiveFilter] = useState<string>('');
  const [customAdjustments, setCustomAdjustments] = useState({
    brightness: 0,
    contrast: 0,
    saturation: 0,
    warmth: 0,
    vibrance: 0,
    clarity: 0
  });

  const [selectedCategory, setSelectedCategory] = useState<string>('trending');
  const [isProcessing, setIsProcessing] = useState(false);

  const platformProfiles: PlatformProfile[] = [
    {
      id: 'tiktok',
      name: 'TikTok',
      icon: '🎵',
      primaryMoods: ['energetic', 'fun', 'viral', 'trendy'],
      colorScheme: 'high-contrast',
      preferredAdjustments: {
        brightness: 10,
        contrast: 15,
        saturation: 20
      }
    },
    {
      id: 'instagram',
      name: 'Instagram',
      icon: '📸',
      primaryMoods: ['aesthetic', 'lifestyle', 'artistic', 'beautiful'],
      colorScheme: 'balanced',
      preferredAdjustments: {
        brightness: 5,
        contrast: 10,
        saturation: 15
      }
    },
    {
      id: 'youtube',
      name: 'YouTube',
      icon: '📺',
      primaryMoods: ['cinematic', 'professional', 'engaging', 'story'],
      colorScheme: 'cinematic',
      preferredAdjustments: {
        brightness: 0,
        contrast: 8,
        saturation: 5
      }
    },
    {
      id: 'facebook',
      name: 'Facebook',
      icon: '👥',
      primaryMoods: ['friendly', 'social', 'family', 'warm'],
      colorScheme: 'warm',
      preferredAdjustments: {
        brightness: 8,
        contrast: 5,
        saturation: 10
      }
    }
  ];

  const moodFilters: MoodFilter[] = [
    {
      id: 'aesthetic_vibes',
      name: 'Aesthetic Vibes',
      icon: Sparkles,
      color: 'from-pink-500 to-purple-500',
      description: 'Soft, dreamy aesthetic perfect for lifestyle content',
      platforms: ['tiktok', 'instagram'],
      adjustments: {
        brightness: 15,
        contrast: -5,
        saturation: 25,
        warmth: 20,
        vibrance: 30,
        clarity: -10
      },
      effects: ['soft_glow', 'vintage_fade', 'dreamy_blur'],
      popularity: 95
    },
    {
      id: 'viral_energy',
      name: 'Viral Energy',
      icon: Zap,
      color: 'from-yellow-500 to-red-500',
      description: 'High-energy, punchy look for trending content',
      platforms: ['tiktok', 'youtube'],
      adjustments: {
        brightness: 20,
        contrast: 30,
        saturation: 40,
        warmth: -10,
        vibrance: 50,
        clarity: 25
      },
      effects: ['sharp_pop', 'color_boost', 'dynamic_contrast'],
      popularity: 92
    },
    {
      id: 'cinematic_mood',
      name: 'Cinematic',
      icon: Video,
      color: 'from-blue-600 to-indigo-600',
      description: 'Professional cinematic grade for storytelling',
      platforms: ['youtube', 'facebook'],
      adjustments: {
        brightness: -5,
        contrast: 20,
        saturation: -15,
        warmth: 10,
        vibrance: -20,
        clarity: 15
      },
      effects: ['film_grain', 'color_grade', 'vignette'],
      popularity: 88
    },
    {
      id: 'golden_hour',
      name: 'Golden Hour',
      icon: Sun,
      color: 'from-yellow-400 to-orange-500',
      description: 'Warm, golden sunlight effect',
      platforms: ['instagram', 'facebook'],
      adjustments: {
        brightness: 25,
        contrast: 10,
        saturation: 20,
        warmth: 40,
        vibrance: 25,
        clarity: 10
      },
      effects: ['golden_glow', 'warm_highlights', 'soft_shadows'],
      popularity: 90
    },
    {
      id: 'moody_dark',
      name: 'Moody Dark',
      icon: Moon,
      color: 'from-gray-700 to-black',
      description: 'Dark, dramatic atmosphere',
      platforms: ['tiktok', 'youtube'],
      adjustments: {
        brightness: -20,
        contrast: 35,
        saturation: 15,
        warmth: -15,
        vibrance: 20,
        clarity: 20
      },
      effects: ['dark_shadows', 'mood_lighting', 'selective_color'],
      popularity: 85
    },
    {
      id: 'fresh_natural',
      name: 'Fresh & Natural',
      icon: Heart,
      color: 'from-green-400 to-blue-400',
      description: 'Clean, natural look for authentic content',
      platforms: ['instagram', 'facebook'],
      adjustments: {
        brightness: 10,
        contrast: 5,
        saturation: -5,
        warmth: 5,
        vibrance: 10,
        clarity: 15
      },
      effects: ['natural_enhance', 'skin_smooth', 'clarity_boost'],
      popularity: 87
    }
  ];

  const currentPlatform = platformProfiles.find(p => p.id === selectedPlatform) || platformProfiles[0];
  const recommendedFilters = moodFilters
    .filter(filter => filter.platforms.includes(selectedPlatform))
    .sort((a, b) => b.popularity - a.popularity);

  const applyFilter = async (filter: MoodFilter) => {
    setActiveFilter(filter.id);
    setIsProcessing(true);
    
    // Apply platform-specific adjustments
    const platformAdjustments = currentPlatform.preferredAdjustments;
    const combinedAdjustments = {
      brightness: filter.adjustments.brightness + platformAdjustments.brightness,
      contrast: filter.adjustments.contrast + platformAdjustments.contrast,
      saturation: filter.adjustments.saturation + platformAdjustments.saturation,
      warmth: filter.adjustments.warmth,
      vibrance: filter.adjustments.vibrance,
      clarity: filter.adjustments.clarity
    };
    
    setCustomAdjustments(combinedAdjustments);
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsProcessing(false);
    onFilterApply?.(filter, selectedPlatform);
  };

  const handleAdjustmentChange = (key: string, value: number[]) => {
    setCustomAdjustments(prev => ({
      ...prev,
      [key]: value[0]
    }));
  };

  const resetFilters = () => {
    setActiveFilter('');
    setCustomAdjustments({
      brightness: 0,
      contrast: 0,
      saturation: 0,
      warmth: 0,
      vibrance: 0,
      clarity: 0
    });
  };

  return (
    <div className="w-full space-y-6">
      {/* Header with Platform Selection */}
      <Card className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Palette className="h-6 w-6 text-purple-400" />
            Platform Mood Filters
            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 ml-auto">
              <Target className="h-3 w-3 mr-1" />
              {currentPlatform.name} Optimized
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-3">
            {platformProfiles.map((platform) => (
              <Button
                key={platform.id}
                onClick={() => {/* Platform switching will be handled by parent */}}
                className={`p-4 h-auto flex flex-col gap-2 ${
                  platform.id === selectedPlatform 
                    ? 'bg-indigo-600 hover:bg-indigo-700' 
                    : 'bg-slate-700 hover:bg-slate-600'
                }`}
              >
                <span className="text-2xl">{platform.icon}</span>
                <span className="text-sm font-medium">{platform.name}</span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Processing Indicator */}
      {isProcessing && (
        <Card className="bg-gradient-to-r from-indigo-800/50 to-purple-800/50 border border-indigo-500/30">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <Wand2 className="h-8 w-8 text-indigo-400 mx-auto animate-pulse" />
              <div className="text-white">
                Applying {currentPlatform.name}-optimized mood filter...
              </div>
              <div className="flex justify-center">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-indigo-400"></div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recommended Filters */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-400" />
                Trending for {currentPlatform.name}
                <Badge className="bg-green-500/20 text-green-300 border-green-500/30 ml-auto">
                  {recommendedFilters.length} Filters
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {recommendedFilters.map((filter) => {
                  const IconComponent = filter.icon;
                  return (
                    <div
                      key={filter.id}
                      className={`p-4 rounded-lg cursor-pointer transition-all hover:scale-105 ${
                        activeFilter === filter.id
                          ? 'bg-gradient-to-r from-indigo-600/50 to-purple-600/50 border border-indigo-400'
                          : 'bg-slate-700/50 hover:bg-slate-700/70'
                      }`}
                      onClick={() => applyFilter(filter)}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`p-3 rounded-lg bg-gradient-to-r ${filter.color}`}>
                          <IconComponent className="h-5 w-5 text-white" />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-medium text-white">{filter.name}</h3>
                            <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 text-xs">
                              {filter.popularity}%
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-400 mb-2">{filter.description}</p>
                          
                          <div className="flex flex-wrap gap-1">
                            {filter.effects.slice(0, 2).map((effect, index) => (
                              <Badge
                                key={index}
                                className="bg-purple-500/20 text-purple-300 border-purple-500/30 text-xs"
                              >
                                {effect.replace('_', ' ')}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Manual Adjustments */}
        <div className="space-y-4">
          <Card className="bg-slate-800/50 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Adjust className="h-4 w-4 text-blue-400" />
                Fine Tune
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(customAdjustments).map(([key, value]) => (
                <div key={key} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="text-sm text-gray-300 capitalize">{key}</label>
                    <Badge className="bg-indigo-500/20 text-indigo-300 border-0 text-xs">
                      {value > 0 ? '+' : ''}{value}
                    </Badge>
                  </div>
                  <Slider
                    value={[value]}
                    onValueChange={(val) => handleAdjustmentChange(key, val)}
                    max={50}
                    min={-50}
                    step={1}
                    className="w-full"
                  />
                </div>
              ))}
              
              <div className="flex gap-2 mt-4">
                <Button 
                  onClick={resetFilters}
                  variant="outline" 
                  className="flex-1 border-gray-500 text-gray-300"
                >
                  Reset
                </Button>
                <Button 
                  onClick={() => onPresetSave?.(customAdjustments)}
                  className="flex-1 bg-indigo-500 hover:bg-indigo-600"
                >
                  Save Preset
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Platform Insights */}
          <Card className="bg-slate-800/50 border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Eye className="h-4 w-4 text-yellow-400" />
                {currentPlatform.name} Insights
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2 text-sm">
                <div className="text-gray-300">
                  <strong>Primary Moods:</strong>
                </div>
                <div className="flex flex-wrap gap-1">
                  {currentPlatform.primaryMoods.map((mood, index) => (
                    <Badge
                      key={index}
                      className="bg-green-500/20 text-green-300 border-green-500/30 text-xs"
                    >
                      {mood}
                    </Badge>
                  ))}
                </div>
                
                <div className="mt-3 text-gray-300">
                  <strong>Color Scheme:</strong> {currentPlatform.colorScheme}
                </div>
                
                <div className="text-xs text-gray-400 mt-2">
                  Filters are automatically optimized for {currentPlatform.name}'s algorithm and audience preferences.
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}