import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Play,
  Pause,
  RotateCw,
  ZoomIn,
  ZoomOut,
  Move,
  Eye,
  Settings,
  Zap,
  Sparkles,
  Target,
  Timer,
  BarChart3,
  Circle,
  Square,
  Triangle,
  Star,
  Heart
} from 'lucide-react';

interface TweenAnimation {
  id: string;
  name: string;
  type: 'zoom_in' | 'zoom_out' | 'slide_left' | 'slide_right' | 'slide_up' | 'slide_down' | 'rotate_cw' | 'rotate_ccw' | 'fade_in' | 'fade_out' | 'bounce' | 'elastic' | 'pulse';
  duration: number;
  easing: string;
  delay: number;
  repeat: number;
  yoyo: boolean;
  enabled: boolean;
}

interface AnimatedObject {
  id: string;
  name: string;
  type: 'text' | 'shape' | 'image' | 'icon';
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  scale: number;
  opacity: number;
  color: string;
  content?: string;
  animations: TweenAnimation[];
  visible: boolean;
}

interface MotionGraphicsEngineProps {
  onAnimationUpdate?: (objects: AnimatedObject[]) => void;
  canvasWidth?: number;
  canvasHeight?: number;
}

export function MotionGraphicsEngine({ 
  onAnimationUpdate, 
  canvasWidth = 1920, 
  canvasHeight = 1080 
}: MotionGraphicsEngineProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [animatedObjects, setAnimatedObjects] = useState<AnimatedObject[]>([
    {
      id: 'obj_1',
      name: 'Hero Title',
      type: 'text',
      x: 960,
      y: 300,
      width: 600,
      height: 100,
      rotation: 0,
      scale: 1,
      opacity: 100,
      color: '#ffffff',
      content: 'VIRAL VIDEO',
      visible: true,
      animations: [
        {
          id: 'anim_1',
          name: 'Zoom In',
          type: 'zoom_in',
          duration: 1.5,
          easing: 'elastic.out(1, 0.3)',
          delay: 0,
          repeat: 0,
          yoyo: false,
          enabled: true
        },
        {
          id: 'anim_2',
          name: 'Pulse',
          type: 'pulse',
          duration: 2,
          easing: 'power2.inOut',
          delay: 2,
          repeat: -1,
          yoyo: true,
          enabled: true
        }
      ]
    },
    {
      id: 'obj_2',
      name: 'Background Circle',
      type: 'shape',
      x: 960,
      y: 540,
      width: 200,
      height: 200,
      rotation: 0,
      scale: 1,
      opacity: 30,
      color: '#ff6b6b',
      visible: true,
      animations: [
        {
          id: 'anim_3',
          name: 'Rotate 360',
          type: 'rotate_cw',
          duration: 10,
          easing: 'none',
          delay: 0,
          repeat: -1,
          yoyo: false,
          enabled: true
        },
        {
          id: 'anim_4',
          name: 'Scale Pulse',
          type: 'bounce',
          duration: 3,
          easing: 'bounce.out',
          delay: 1,
          repeat: -1,
          yoyo: true,
          enabled: true
        }
      ]
    }
  ]);

  const [selectedObject, setSelectedObject] = useState<string>('obj_1');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [zoomLevel, setZoomLevel] = useState(0.5);

  const animationPresets = [
    {
      id: 'zoom_in',
      name: 'Zoom In',
      description: 'Scale from 0 to normal size',
      icon: ZoomIn,
      color: 'bg-blue-500',
      keyframes: { scale: [0, 1], opacity: [0, 1] }
    },
    {
      id: 'zoom_out',
      name: 'Zoom Out',
      description: 'Scale from normal to 0',
      icon: ZoomOut,
      color: 'bg-red-500',
      keyframes: { scale: [1, 0], opacity: [1, 0] }
    },
    {
      id: 'slide_left',
      name: 'Slide Left',
      description: 'Enter from right side',
      icon: Move,
      color: 'bg-green-500',
      keyframes: { x: ['+300', '0'] }
    },
    {
      id: 'slide_right',
      name: 'Slide Right',
      description: 'Enter from left side',
      icon: Move,
      color: 'bg-yellow-500',
      keyframes: { x: ['-300', '0'] }
    },
    {
      id: 'fade_in',
      name: 'Fade In',
      description: 'Opacity 0 to 100',
      icon: Eye,
      color: 'bg-purple-500',
      keyframes: { opacity: [0, 1] }
    },
    {
      id: 'rotate_cw',
      name: 'Rotate CW',
      description: 'Clockwise rotation',
      icon: RotateCw,
      color: 'bg-indigo-500',
      keyframes: { rotation: [0, 360] }
    },
    {
      id: 'bounce',
      name: 'Bounce',
      description: 'Bouncy scale effect',
      icon: Target,
      color: 'bg-pink-500',
      keyframes: { scale: [0.8, 1.2, 1] }
    },
    {
      id: 'pulse',
      name: 'Pulse',
      description: 'Rhythmic scale pulse',
      icon: Heart,
      color: 'bg-rose-500',
      keyframes: { scale: [1, 1.1, 1] }
    }
  ];

  const easingOptions = [
    'none',
    'power1.out',
    'power2.out',
    'power3.out',
    'power4.out',
    'back.out(1.7)',
    'elastic.out(1, 0.3)',
    'bounce.out',
    'circ.out',
    'expo.out'
  ];

  const shapeTypes = [
    { id: 'circle', name: 'Circle', icon: Circle },
    { id: 'square', name: 'Square', icon: Square },
    { id: 'triangle', name: 'Triangle', icon: Triangle },
    { id: 'star', name: 'Star', icon: Star }
  ];

  // Get selected object
  const selectedObjectData = animatedObjects.find(obj => obj.id === selectedObject);

  // Add new object
  const addObject = useCallback((type: AnimatedObject['type']) => {
    const newObject: AnimatedObject = {
      id: `obj_${Date.now()}`,
      name: `New ${type.charAt(0).toUpperCase() + type.slice(1)}`,
      type,
      x: canvasWidth / 2,
      y: canvasHeight / 2,
      width: type === 'text' ? 400 : 150,
      height: type === 'text' ? 80 : 150,
      rotation: 0,
      scale: 1,
      opacity: 100,
      color: '#ffffff',
      visible: true,
      animations: [],
      ...(type === 'text' && { content: 'Sample Text' })
    };
    
    setAnimatedObjects(prev => [...prev, newObject]);
    setSelectedObject(newObject.id);
  }, [canvasWidth, canvasHeight]);

  // Add animation to object
  const addAnimation = useCallback((objectId: string, animationType: TweenAnimation['type']) => {
    const preset = animationPresets.find(p => p.id === animationType);
    if (!preset) return;

    const newAnimation: TweenAnimation = {
      id: `anim_${Date.now()}`,
      name: preset.name,
      type: animationType,
      duration: 1,
      easing: 'power2.out',
      delay: 0,
      repeat: 0,
      yoyo: false,
      enabled: true
    };

    setAnimatedObjects(prev =>
      prev.map(obj =>
        obj.id === objectId
          ? { ...obj, animations: [...obj.animations, newAnimation] }
          : obj
      )
    );
  }, [animationPresets]);

  // Update object property
  const updateObject = useCallback((objectId: string, updates: Partial<AnimatedObject>) => {
    setAnimatedObjects(prev =>
      prev.map(obj =>
        obj.id === objectId ? { ...obj, ...updates } : obj
      )
    );
  }, []);

  // Update animation
  const updateAnimation = useCallback((objectId: string, animationId: string, updates: Partial<TweenAnimation>) => {
    setAnimatedObjects(prev =>
      prev.map(obj =>
        obj.id === objectId
          ? {
              ...obj,
              animations: obj.animations.map(anim =>
                anim.id === animationId ? { ...anim, ...updates } : anim
              )
            }
          : obj
      )
    );
  }, []);

  // Delete animation
  const deleteAnimation = useCallback((objectId: string, animationId: string) => {
    setAnimatedObjects(prev =>
      prev.map(obj =>
        obj.id === objectId
          ? {
              ...obj,
              animations: obj.animations.filter(anim => anim.id !== animationId)
            }
          : obj
      )
    );
  }, []);

  // Canvas rendering
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 1;
    const gridSize = 50;
    
    for (let x = 0; x <= canvas.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    
    for (let y = 0; y <= canvas.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Render objects
    animatedObjects.forEach(obj => {
      if (!obj.visible) return;

      ctx.save();
      
      // Apply transformations
      ctx.translate(obj.x, obj.y);
      ctx.rotate((obj.rotation * Math.PI) / 180);
      ctx.scale(obj.scale, obj.scale);
      ctx.globalAlpha = obj.opacity / 100;

      // Set color
      ctx.fillStyle = obj.color;
      ctx.strokeStyle = obj.color;

      // Draw based on type
      switch (obj.type) {
        case 'text':
          ctx.font = `bold ${Math.max(24, obj.height / 2)}px Arial`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(obj.content || 'Text', 0, 0);
          break;

        case 'shape':
          ctx.beginPath();
          ctx.arc(0, 0, obj.width / 2, 0, Math.PI * 2);
          ctx.fill();
          break;

        case 'image':
          ctx.fillRect(-obj.width / 2, -obj.height / 2, obj.width, obj.height);
          break;

        case 'icon':
          ctx.beginPath();
          ctx.arc(0, 0, obj.width / 2, 0, Math.PI * 2);
          ctx.fill();
          break;
      }

      // Selection indicator
      if (selectedObject === obj.id) {
        ctx.strokeStyle = '#ff6b6b';
        ctx.lineWidth = 2;
        ctx.strokeRect(-obj.width / 2 - 5, -obj.height / 2 - 5, obj.width + 10, obj.height + 10);
      }

      ctx.restore();
    });
  }, [animatedObjects, selectedObject]);

  // Animation loop
  useEffect(() => {
    let animationFrame: number;
    
    if (isPlaying) {
      const animate = () => {
        setCurrentTime(prev => prev + 0.016); // ~60fps
        renderCanvas();
        animationFrame = requestAnimationFrame(animate);
      };
      animationFrame = requestAnimationFrame(animate);
    } else {
      renderCanvas();
    }

    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, [isPlaying, renderCanvas]);

  // Update callback
  useEffect(() => {
    onAnimationUpdate?.(animatedObjects);
  }, [animatedObjects, onAnimationUpdate]);

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 text-white overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Zap className="h-6 w-6 text-indigo-400" />
              Motion Graphics & Animation Engine
              <Badge className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-0 ml-auto">
                <Sparkles className="h-3 w-3 mr-1" />
                Professional
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Canvas Area */}
          <div className="lg:col-span-3 space-y-4">
            {/* Controls */}
            <Card className="bg-slate-800/50 border-indigo-500/30">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Button
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="bg-indigo-500 hover:bg-indigo-600 w-12 h-12 rounded-full"
                    >
                      {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                    </Button>
                    
                    <div className="text-white font-mono text-sm">
                      {currentTime.toFixed(1)}s
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-gray-400">Zoom:</span>
                    <Slider
                      value={[zoomLevel]}
                      onValueChange={([value]) => setZoomLevel(value)}
                      max={2}
                      min={0.1}
                      step={0.1}
                      className="w-32"
                    />
                    <span className="text-sm text-white">{(zoomLevel * 100).toFixed(0)}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Canvas */}
            <Card className="bg-slate-800/50 border-purple-500/30">
              <CardContent className="p-4">
                <div className="relative bg-slate-900 rounded-lg overflow-hidden">
                  <canvas
                    ref={canvasRef}
                    width={canvasWidth * zoomLevel}
                    height={canvasHeight * zoomLevel}
                    className="border border-slate-600 cursor-crosshair"
                    style={{
                      maxWidth: '100%',
                      maxHeight: '60vh'
                    }}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Side Panel */}
          <div className="space-y-4">
            {/* Add Objects */}
            <Card className="bg-slate-800/50 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Target className="h-4 w-4 text-green-400" />
                  Add Objects
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  onClick={() => addObject('text')}
                  className="w-full bg-green-500 hover:bg-green-600"
                >
                  Text Element
                </Button>
                <Button
                  onClick={() => addObject('shape')}
                  className="w-full bg-blue-500 hover:bg-blue-600"
                >
                  Shape
                </Button>
                <Button
                  onClick={() => addObject('image')}
                  className="w-full bg-purple-500 hover:bg-purple-600"
                >
                  Image
                </Button>
              </CardContent>
            </Card>

            {/* Object List */}
            <Card className="bg-slate-800/50 border-yellow-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Settings className="h-4 w-4 text-yellow-400" />
                  Objects ({animatedObjects.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-48 overflow-y-auto">
                {animatedObjects.map((obj) => (
                  <div
                    key={obj.id}
                    className={`p-2 rounded border cursor-pointer transition-all ${
                      selectedObject === obj.id 
                        ? 'bg-yellow-500/20 border-yellow-400' 
                        : 'bg-slate-700/50 border-slate-600 hover:border-slate-500'
                    }`}
                    onClick={() => setSelectedObject(obj.id)}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-white text-sm font-medium">{obj.name}</span>
                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          updateObject(obj.id, { visible: !obj.visible });
                        }}
                        variant="ghost"
                        size="sm"
                        className="p-1 h-6 w-6"
                      >
                        <Eye className={`h-3 w-3 ${obj.visible ? 'text-green-400' : 'text-gray-400'}`} />
                      </Button>
                    </div>
                    <div className="text-xs text-gray-400 mt-1">
                      {obj.animations.length} animations
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Animation Presets */}
            {selectedObjectData && (
              <Card className="bg-slate-800/50 border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-purple-400" />
                    Animation Presets
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 max-h-64 overflow-y-auto">
                  <div className="grid grid-cols-2 gap-2">
                    {animationPresets.map((preset) => {
                      const Icon = preset.icon;
                      return (
                        <Button
                          key={preset.id}
                          onClick={() => addAnimation(selectedObjectData.id, preset.id as TweenAnimation['type'])}
                          variant="outline"
                          className="h-auto p-2 text-left border-purple-500/30 hover:bg-purple-500/20"
                        >
                          <div className="w-full text-center">
                            <Icon className="h-4 w-4 mx-auto mb-1 text-purple-400" />
                            <div className="text-xs text-white">{preset.name}</div>
                          </div>
                        </Button>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Object Properties */}
            {selectedObjectData && (
              <Card className="bg-slate-800/50 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <Settings className="h-4 w-4 text-blue-400" />
                    Object Properties
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Object Name */}
                  <div>
                    <label className="text-xs text-gray-400">Name</label>
                    <input
                      type="text"
                      value={selectedObjectData.name}
                      onChange={(e) => updateObject(selectedObjectData.id, { name: e.target.value })}
                      className="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-white text-sm"
                    />
                  </div>

                  {/* Position */}
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs text-gray-400">X</label>
                      <input
                        type="number"
                        value={selectedObjectData.x}
                        onChange={(e) => updateObject(selectedObjectData.id, { x: Number(e.target.value) })}
                        className="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-white text-sm"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400">Y</label>
                      <input
                        type="number"
                        value={selectedObjectData.y}
                        onChange={(e) => updateObject(selectedObjectData.id, { y: Number(e.target.value) })}
                        className="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-white text-sm"
                      />
                    </div>
                  </div>

                  {/* Scale & Rotation */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs text-gray-400">Scale</label>
                      <Badge className="bg-blue-500/20 text-blue-300 border-0 text-xs">
                        {selectedObjectData.scale.toFixed(2)}x
                      </Badge>
                    </div>
                    <Slider
                      value={[selectedObjectData.scale]}
                      onValueChange={([value]) => updateObject(selectedObjectData.id, { scale: value })}
                      max={3}
                      min={0.1}
                      step={0.1}
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs text-gray-400">Rotation</label>
                      <Badge className="bg-green-500/20 text-green-300 border-0 text-xs">
                        {selectedObjectData.rotation}°
                      </Badge>
                    </div>
                    <Slider
                      value={[selectedObjectData.rotation]}
                      onValueChange={([value]) => updateObject(selectedObjectData.id, { rotation: value })}
                      max={360}
                      min={-360}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* Text Content */}
                  {selectedObjectData.type === 'text' && (
                    <div>
                      <label className="text-xs text-gray-400">Text Content</label>
                      <input
                        type="text"
                        value={selectedObjectData.content || ''}
                        onChange={(e) => updateObject(selectedObjectData.id, { content: e.target.value })}
                        className="w-full bg-slate-700 border border-slate-600 rounded px-2 py-1 text-white text-sm"
                      />
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Animation Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-slate-800/50 border-indigo-500/30">
            <CardContent className="p-4 text-center">
              <Target className="h-6 w-6 mx-auto mb-2 text-indigo-400" />
              <div className="text-lg font-bold text-white">{animatedObjects.length}</div>
              <div className="text-xs text-gray-400">Objects</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-purple-500/30">
            <CardContent className="p-4 text-center">
              <Sparkles className="h-6 w-6 mx-auto mb-2 text-purple-400" />
              <div className="text-lg font-bold text-white">
                {animatedObjects.reduce((sum, obj) => sum + obj.animations.length, 0)}
              </div>
              <div className="text-xs text-gray-400">Animations</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardContent className="p-4 text-center">
              <Timer className="h-6 w-6 mx-auto mb-2 text-green-400" />
              <div className="text-lg font-bold text-white">{currentTime.toFixed(1)}s</div>
              <div className="text-xs text-gray-400">Timeline</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-yellow-500/30">
            <CardContent className="p-4 text-center">
              <BarChart3 className="h-6 w-6 mx-auto mb-2 text-yellow-400" />
              <div className="text-lg font-bold text-white">{(zoomLevel * 100).toFixed(0)}%</div>
              <div className="text-xs text-gray-400">Canvas Zoom</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}