import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Play,
  Pause,
  Square,
  SkipBack,
  SkipForward,
  FastForward,
  Rewind,
  Plus,
  Trash2,
  Copy,
  Move,
  RotateCw,
  ZoomIn,
  Eye,
  Settings,
  Target,
  Timer,
  Zap,
  Layers,
  Sparkles,
  BarChart3,
  Circle
} from 'lucide-react';

interface AnimationKeyframe {
  id: string;
  time: number; // 0-1 (percentage of animation duration)
  value: number | { x: number; y: number } | { r: number; g: number; b: number; a: number };
  easing: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out' | 'bounce' | 'elastic' | 'back';
}

interface AnimationProperty {
  id: string;
  name: string;
  type: 'position' | 'rotation' | 'scale' | 'opacity' | 'color';
  keyframes: AnimationKeyframe[];
  enabled: boolean;
  min: number;
  max: number;
  unit: string;
}

interface AnimationLayer {
  id: string;
  name: string;
  type: 'object' | 'text' | 'image' | 'effect';
  properties: AnimationProperty[];
  duration: number; // in seconds
  enabled: boolean;
  locked: boolean;
}

interface KeyframeEditorProps {
  onAnimationUpdate?: (layers: AnimationLayer[]) => void;
  projectDuration?: number;
}

export function KeyframeEditor({ onAnimationUpdate, projectDuration = 10 }: KeyframeEditorProps) {
  const timelineRef = useRef<HTMLDivElement>(null);
  const [animationLayers, setAnimationLayers] = useState<AnimationLayer[]>([
    {
      id: 'layer_1',
      name: 'Hero Text',
      type: 'text',
      duration: 8,
      enabled: true,
      locked: false,
      properties: [
        {
          id: 'pos_1',
          name: 'Position',
          type: 'position',
          min: -500,
          max: 500,
          unit: 'px',
          enabled: true,
          keyframes: [
            { id: 'kf_1', time: 0, value: { x: -200, y: 0 }, easing: 'ease-out' },
            { id: 'kf_2', time: 0.3, value: { x: 0, y: 0 }, easing: 'bounce' },
            { id: 'kf_3', time: 0.8, value: { x: 0, y: 0 }, easing: 'ease-in' },
            { id: 'kf_4', time: 1, value: { x: 200, y: 0 }, easing: 'linear' }
          ]
        },
        {
          id: 'scale_1',
          name: 'Scale',
          type: 'scale',
          min: 0,
          max: 3,
          unit: 'x',
          enabled: true,
          keyframes: [
            { id: 'kf_5', time: 0, value: 0.5, easing: 'elastic' },
            { id: 'kf_6', time: 0.2, value: 1.2, easing: 'bounce' },
            { id: 'kf_7', time: 0.4, value: 1, easing: 'ease-out' }
          ]
        },
        {
          id: 'opacity_1',
          name: 'Opacity',
          type: 'opacity',
          min: 0,
          max: 100,
          unit: '%',
          enabled: true,
          keyframes: [
            { id: 'kf_8', time: 0, value: 0, easing: 'ease-in' },
            { id: 'kf_9', time: 0.2, value: 100, easing: 'linear' },
            { id: 'kf_10', time: 0.9, value: 100, easing: 'ease-out' },
            { id: 'kf_11', time: 1, value: 0, easing: 'ease-in' }
          ]
        }
      ]
    },
    {
      id: 'layer_2',
      name: 'Background Logo',
      type: 'image',
      duration: 10,
      enabled: true,
      locked: false,
      properties: [
        {
          id: 'rotation_1',
          name: 'Rotation',
          type: 'rotation',
          min: -360,
          max: 360,
          unit: '°',
          enabled: true,
          keyframes: [
            { id: 'kf_12', time: 0, value: 0, easing: 'linear' },
            { id: 'kf_13', time: 1, value: 360, easing: 'linear' }
          ]
        },
        {
          id: 'scale_2',
          name: 'Scale',
          type: 'scale',
          min: 0.5,
          max: 2,
          unit: 'x',
          enabled: true,
          keyframes: [
            { id: 'kf_14', time: 0, value: 1, easing: 'ease-in-out' },
            { id: 'kf_15', time: 0.5, value: 1.5, easing: 'ease-in-out' },
            { id: 'kf_16', time: 1, value: 1, easing: 'ease-in-out' }
          ]
        }
      ]
    }
  ]);

  const [selectedLayer, setSelectedLayer] = useState<string>('layer_1');
  const [selectedProperty, setSelectedProperty] = useState<string>('pos_1');
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);

  const easingTypes = [
    { id: 'linear', name: 'Linear', curve: 'ease-linear' },
    { id: 'ease-in', name: 'Ease In', curve: 'ease-in' },
    { id: 'ease-out', name: 'Ease Out', curve: 'ease-out' },
    { id: 'ease-in-out', name: 'Ease In Out', curve: 'ease-in-out' },
    { id: 'bounce', name: 'Bounce', curve: 'cubic-bezier(0.68, -0.55, 0.265, 1.55)' },
    { id: 'elastic', name: 'Elastic', curve: 'cubic-bezier(0.175, 0.885, 0.32, 1.275)' },
    { id: 'back', name: 'Back', curve: 'cubic-bezier(0.175, 0.885, 0.32, 1.275)' }
  ];

  const animationPresets = [
    {
      id: 'fade_in',
      name: 'Fade In',
      description: 'Smooth opacity transition',
      properties: ['opacity'],
      keyframes: [
        { time: 0, value: 0, easing: 'ease-out' },
        { time: 1, value: 100, easing: 'linear' }
      ]
    },
    {
      id: 'slide_left',
      name: 'Slide From Left',
      description: 'Enter from left side',
      properties: ['position'],
      keyframes: [
        { time: 0, value: { x: -300, y: 0 }, easing: 'ease-out' },
        { time: 1, value: { x: 0, y: 0 }, easing: 'bounce' }
      ]
    },
    {
      id: 'zoom_bounce',
      name: 'Zoom Bounce',
      description: 'Scale with bounce effect',
      properties: ['scale'],
      keyframes: [
        { time: 0, value: 0, easing: 'elastic' },
        { time: 0.6, value: 1.2, easing: 'bounce' },
        { time: 1, value: 1, easing: 'ease-out' }
      ]
    },
    {
      id: 'rotate_360',
      name: 'Full Rotation',
      description: 'Complete 360° rotation',
      properties: ['rotation'],
      keyframes: [
        { time: 0, value: 0, easing: 'linear' },
        { time: 1, value: 360, easing: 'linear' }
      ]
    }
  ];

  // Get selected layer and property
  const selectedLayerData = animationLayers.find(l => l.id === selectedLayer);
  const selectedPropertyData = selectedLayerData?.properties.find(p => p.id === selectedProperty);

  // Add keyframe
  const addKeyframe = useCallback((propertyId: string, time: number) => {
    setAnimationLayers(prev => 
      prev.map(layer => ({
        ...layer,
        properties: layer.properties.map(prop => {
          if (prop.id === propertyId) {
            const newKeyframe: AnimationKeyframe = {
              id: `kf_${Date.now()}`,
              time,
              value: prop.type === 'position' ? { x: 0, y: 0 } : 
                     prop.type === 'color' ? { r: 255, g: 255, b: 255, a: 1 } : 50,
              easing: 'ease-out'
            };
            return {
              ...prop,
              keyframes: [...prop.keyframes, newKeyframe].sort((a, b) => a.time - b.time)
            };
          }
          return prop;
        })
      }))
    );
  }, []);

  // Update keyframe
  const updateKeyframe = useCallback((propertyId: string, keyframeId: string, updates: Partial<AnimationKeyframe>) => {
    setAnimationLayers(prev => 
      prev.map(layer => ({
        ...layer,
        properties: layer.properties.map(prop => {
          if (prop.id === propertyId) {
            return {
              ...prop,
              keyframes: prop.keyframes.map(kf => 
                kf.id === keyframeId ? { ...kf, ...updates } : kf
              )
            };
          }
          return prop;
        })
      }))
    );
  }, []);

  // Delete keyframe
  const deleteKeyframe = useCallback((propertyId: string, keyframeId: string) => {
    setAnimationLayers(prev => 
      prev.map(layer => ({
        ...layer,
        properties: layer.properties.map(prop => {
          if (prop.id === propertyId) {
            return {
              ...prop,
              keyframes: prop.keyframes.filter(kf => kf.id !== keyframeId)
            };
          }
          return prop;
        })
      }))
    );
  }, []);

  // Timeline position calculation
  const getTimelinePosition = useCallback((time: number) => {
    return (time / projectDuration) * 100;
  }, [projectDuration]);

  // Handle timeline click
  const handleTimelineClick = useCallback((e: React.MouseEvent) => {
    if (!timelineRef.current) return;
    
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    const newTime = percentage * projectDuration;
    
    setCurrentTime(Math.max(0, Math.min(projectDuration, newTime)));
  }, [projectDuration]);

  // Format time
  const formatTime = useCallback((seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = (seconds % 60).toFixed(1);
    return `${mins}:${secs.padStart(4, '0')}`;
  }, []);

  // Get property icon
  const getPropertyIcon = useCallback((type: AnimationProperty['type']) => {
    switch (type) {
      case 'position': return Move;
      case 'rotation': return RotateCw;
      case 'scale': return ZoomIn;
      case 'opacity': return Eye;
      case 'color': return Circle;
      default: return Settings;
    }
  }, []);

  // Animation playback
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime(prev => {
          const newTime = prev + (0.1 * playbackSpeed);
          if (newTime >= projectDuration) {
            setIsPlaying(false);
            return 0;
          }
          return newTime;
        });
      }, 100);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, playbackSpeed, projectDuration]);

  // Update callback
  useEffect(() => {
    onAnimationUpdate?.(animationLayers);
  }, [animationLayers, onAnimationUpdate]);

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-purple-900/80 to-pink-900/80 border border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Zap className="h-6 w-6 text-purple-400" />
              Keyframe Animation Editor
              <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 ml-auto">
                <Sparkles className="h-3 w-3 mr-1" />
                Professional
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Timeline */}
          <div className="lg:col-span-3 space-y-4">
            {/* Playback Controls */}
            <Card className="bg-slate-800/50 border-indigo-500/30">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Button
                      onClick={() => setCurrentTime(0)}
                      variant="outline"
                      size="sm"
                      className="border-indigo-500/30 hover:bg-indigo-500/20"
                    >
                      <SkipBack className="h-4 w-4" />
                    </Button>
                    
                    <Button
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="bg-indigo-500 hover:bg-indigo-600 w-12 h-12 rounded-full"
                    >
                      {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                    </Button>
                    
                    <Button
                      onClick={() => {
                        setIsPlaying(false);
                        setCurrentTime(0);
                      }}
                      variant="outline"
                      size="sm"
                      className="border-indigo-500/30 hover:bg-indigo-500/20"
                    >
                      <Square className="h-4 w-4" />
                    </Button>
                    
                    <Button
                      onClick={() => setCurrentTime(projectDuration)}
                      variant="outline"
                      size="sm"
                      className="border-indigo-500/30 hover:bg-indigo-500/20"
                    >
                      <SkipForward className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="text-white font-mono text-sm">
                      {formatTime(currentTime)} / {formatTime(projectDuration)}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-400">Speed:</span>
                      <Slider
                        value={[playbackSpeed]}
                        onValueChange={([value]) => setPlaybackSpeed(value)}
                        max={3}
                        min={0.1}
                        step={0.1}
                        className="w-20"
                      />
                      <span className="text-xs text-white">{playbackSpeed}x</span>
                    </div>
                  </div>
                </div>

                {/* Timeline */}
                <div 
                  ref={timelineRef}
                  className="relative h-48 bg-slate-700/50 rounded-lg cursor-crosshair overflow-auto"
                  onClick={handleTimelineClick}
                >
                  {/* Time ruler */}
                  <div className="absolute top-0 left-0 right-0 h-8 bg-slate-600/50 border-b border-slate-500">
                    {Array.from({ length: Math.ceil(projectDuration) + 1 }).map((_, i) => (
                      <div
                        key={i}
                        className="absolute text-xs text-gray-400 transform -translate-x-1/2"
                        style={{ left: `${(i / projectDuration) * 100}%`, top: '4px' }}
                      >
                        {i}s
                      </div>
                    ))}
                  </div>

                  {/* Property tracks */}
                  <div className="absolute top-8 left-0 right-0 bottom-0">
                    {selectedLayerData?.properties.map((property, index) => {
                      const Icon = getPropertyIcon(property.type);
                      return (
                        <div
                          key={property.id}
                          className={`relative h-10 border-b border-slate-600/50 ${
                            selectedProperty === property.id ? 'bg-purple-500/20' : ''
                          }`}
                          style={{ top: `${index * 40}px` }}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedProperty(property.id);
                          }}
                        >
                          {/* Property label */}
                          <div className="absolute left-2 top-2 flex items-center gap-2 text-xs">
                            <Icon className="h-3 w-3 text-purple-400" />
                            <span className="text-white">{property.name}</span>
                          </div>

                          {/* Keyframes */}
                          {property.keyframes.map((keyframe) => (
                            <div
                              key={keyframe.id}
                              className="absolute w-3 h-3 bg-purple-500 rounded-full cursor-pointer hover:bg-purple-400 transition-colors border border-white shadow-lg"
                              style={{
                                left: `${(keyframe.time / projectDuration) * 100}%`,
                                top: '50%',
                                transform: 'translateY(-50%)'
                              }}
                              onClick={(e) => {
                                e.stopPropagation();
                                // Select keyframe
                              }}
                            />
                          ))}

                          {/* Animation curve visualization */}
                          <svg 
                            className="absolute inset-0 w-full h-full pointer-events-none"
                            style={{ zIndex: 1 }}
                          >
                            {property.keyframes.map((keyframe, i) => {
                              if (i === property.keyframes.length - 1) return null;
                              const nextKeyframe = property.keyframes[i + 1];
                              const startX = (keyframe.time / projectDuration) * 100;
                              const endX = (nextKeyframe.time / projectDuration) * 100;
                              
                              return (
                                <line
                                  key={`${keyframe.id}-${nextKeyframe.id}`}
                                  x1={`${startX}%`}
                                  y1="50%"
                                  x2={`${endX}%`}
                                  y2="50%"
                                  stroke="rgba(168, 85, 247, 0.5)"
                                  strokeWidth="2"
                                  strokeDasharray={keyframe.easing === 'linear' ? '0' : '3,3'}
                                />
                              );
                            })}
                          </svg>
                        </div>
                      );
                    })}
                  </div>

                  {/* Playhead */}
                  <div 
                    className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10"
                    style={{ left: `${(currentTime / projectDuration) * 100}%` }}
                  >
                    <div className="absolute -top-1 -left-2 w-4 h-4 bg-red-500 rounded-full" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Side Panel */}
          <div className="space-y-4">
            {/* Layer Selection */}
            <Card className="bg-slate-800/50 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Layers className="h-4 w-4 text-green-400" />
                  Animation Layers
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {animationLayers.map((layer) => (
                  <Button
                    key={layer.id}
                    onClick={() => setSelectedLayer(layer.id)}
                    variant={selectedLayer === layer.id ? "default" : "outline"}
                    className={`w-full justify-start ${
                      selectedLayer === layer.id 
                        ? "bg-green-500 text-white" 
                        : "border-green-500/30 hover:bg-green-500/20"
                    }`}
                  >
                    <Target className="h-4 w-4 mr-2" />
                    {layer.name}
                  </Button>
                ))}
              </CardContent>
            </Card>

            {/* Property Controls */}
            {selectedPropertyData && (
              <Card className="bg-slate-800/50 border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-white text-sm flex items-center gap-2">
                    <Settings className="h-4 w-4 text-purple-400" />
                    Property Controls
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Add Keyframe */}
                  <Button
                    onClick={() => addKeyframe(selectedPropertyData.id, currentTime / projectDuration)}
                    className="w-full bg-purple-500 hover:bg-purple-600"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Keyframe
                  </Button>

                  {/* Keyframe List */}
                  <div className="space-y-2 max-h-32 overflow-y-auto">
                    {selectedPropertyData.keyframes.map((keyframe, index) => (
                      <div
                        key={keyframe.id}
                        className="p-2 bg-slate-700/50 rounded border border-slate-600"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-white">#{index + 1}</span>
                          <Button
                            onClick={() => deleteKeyframe(selectedPropertyData.id, keyframe.id)}
                            variant="ghost"
                            size="sm"
                            className="p-1 h-6 w-6 text-red-400 hover:bg-red-500/20"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                        
                        <div className="text-xs text-gray-400">
                          Time: {(keyframe.time * projectDuration).toFixed(1)}s
                        </div>
                        
                        <select
                          value={keyframe.easing}
                          onChange={(e) => updateKeyframe(
                            selectedPropertyData.id, 
                            keyframe.id, 
                            { easing: e.target.value as AnimationKeyframe['easing'] }
                          )}
                          className="w-full mt-1 bg-slate-600 border border-slate-500 rounded px-1 py-0.5 text-xs text-white"
                        >
                          {easingTypes.map((easing) => (
                            <option key={easing.id} value={easing.id}>
                              {easing.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Animation Presets */}
            <Card className="bg-slate-800/50 border-yellow-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-yellow-400" />
                  Animation Presets
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {animationPresets.map((preset) => (
                  <Button
                    key={preset.id}
                    variant="outline"
                    className="w-full h-auto p-3 text-left border-yellow-500/30 hover:bg-yellow-500/20"
                  >
                    <div className="w-full">
                      <div className="font-medium text-sm text-white">{preset.name}</div>
                      <div className="text-xs text-gray-400">{preset.description}</div>
                    </div>
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Animation Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-slate-800/50 border-purple-500/30">
            <CardContent className="p-4 text-center">
              <Layers className="h-6 w-6 mx-auto mb-2 text-purple-400" />
              <div className="text-lg font-bold text-white">{animationLayers.length}</div>
              <div className="text-xs text-gray-400">Animation Layers</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardContent className="p-4 text-center">
              <Target className="h-6 w-6 mx-auto mb-2 text-green-400" />
              <div className="text-lg font-bold text-white">
                {selectedLayerData?.properties.reduce((sum, p) => sum + p.keyframes.length, 0) || 0}
              </div>
              <div className="text-xs text-gray-400">Total Keyframes</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-blue-500/30">
            <CardContent className="p-4 text-center">
              <Timer className="h-6 w-6 mx-auto mb-2 text-blue-400" />
              <div className="text-lg font-bold text-white">{projectDuration}s</div>
              <div className="text-xs text-gray-400">Duration</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-pink-500/30">
            <CardContent className="p-4 text-center">
              <BarChart3 className="h-6 w-6 mx-auto mb-2 text-pink-400" />
              <div className="text-lg font-bold text-white">{playbackSpeed}x</div>
              <div className="text-xs text-gray-400">Playback Speed</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}