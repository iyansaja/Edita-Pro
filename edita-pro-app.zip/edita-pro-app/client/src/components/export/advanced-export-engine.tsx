import React, { useState, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { 
  Download,
  Settings,
  Film,
  Image,
  FileVideo,
  Zap,
  Crown,
  Gauge,
  HardDrive,
  Clock,
  Eye,
  Sparkles,
  CheckCircle,
  AlertCircle,
  Users,
  Shield,
  Layers,
  Target
} from 'lucide-react';

interface ExportSettings {
  format: 'MP4' | 'MOV' | 'GIF' | 'WEBM';
  resolution: '480p' | '720p' | '1080p' | '1440p' | '4K';
  fps: 24 | 30 | 60 | 120;
  quality: 'low' | 'medium' | 'high' | 'ultra';
  compression: number; // 0-100
  watermark: boolean;
  bitrate: number;
  codec: 'H.264' | 'H.265' | 'VP9' | 'AV1';
}

interface ExportProfile {
  id: string;
  name: string;
  description: string;
  settings: ExportSettings;
  category: 'social' | 'professional' | 'web' | 'archive';
  premium: boolean;
  fileSize: string;
  uploadTime: string;
}

interface AdvancedExportEngineProps {
  onExport?: (settings: ExportSettings) => void;
  onClose?: () => void;
  isLoggedIn?: boolean;
}

export function AdvancedExportEngine({ onExport, onClose, isLoggedIn = false }: AdvancedExportEngineProps) {
  const [exportSettings, setExportSettings] = useState<ExportSettings>({
    format: 'MP4',
    resolution: '1080p',
    fps: 30,
    quality: 'high',
    compression: 70,
    watermark: !isLoggedIn,
    bitrate: 8000,
    codec: 'H.264'
  });

  const [selectedProfile, setSelectedProfile] = useState<string>('custom');
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [estimatedSize, setEstimatedSize] = useState('0 MB');
  const [estimatedTime, setEstimatedTime] = useState('0s');

  const exportProfiles: ExportProfile[] = [
    {
      id: 'tiktok_instagram',
      name: 'TikTok & Instagram',
      description: 'Optimal untuk social media vertikal',
      category: 'social',
      premium: false,
      fileSize: '15-25 MB',
      uploadTime: '2-3 min',
      settings: {
        format: 'MP4',
        resolution: '1080p',
        fps: 30,
        quality: 'high',
        compression: 75,
        watermark: !isLoggedIn,
        bitrate: 6000,
        codec: 'H.264'
      }
    },
    {
      id: 'youtube_4k',
      name: 'YouTube 4K Ultra',
      description: 'Kualitas maksimal untuk YouTube',
      category: 'professional',
      premium: true,
      fileSize: '200-400 MB',
      uploadTime: '10-15 min',
      settings: {
        format: 'MP4',
        resolution: '4K',
        fps: 60,
        quality: 'ultra',
        compression: 50,
        watermark: false,
        bitrate: 25000,
        codec: 'H.265'
      }
    },
    {
      id: 'web_optimized',
      name: 'Web Optimized',
      description: 'Ringan untuk website dan email',
      category: 'web',
      premium: false,
      fileSize: '5-10 MB',
      uploadTime: '1-2 min',
      settings: {
        format: 'MP4',
        resolution: '720p',
        fps: 30,
        quality: 'medium',
        compression: 85,
        watermark: !isLoggedIn,
        bitrate: 3000,
        codec: 'H.264'
      }
    },
    {
      id: 'gif_animation',
      name: 'GIF Animation',
      description: 'Format GIF untuk meme dan preview',
      category: 'web',
      premium: false,
      fileSize: '2-8 MB',
      uploadTime: '1 min',
      settings: {
        format: 'GIF',
        resolution: '720p',
        fps: 24,
        quality: 'medium',
        compression: 80,
        watermark: !isLoggedIn,
        bitrate: 2000,
        codec: 'H.264'
      }
    }
  ];

  const resolutionSpecs = {
    '480p': { width: 854, height: 480, pixels: '0.4M' },
    '720p': { width: 1280, height: 720, pixels: '0.9M' },
    '1080p': { width: 1920, height: 1080, pixels: '2.1M' },
    '1440p': { width: 2560, height: 1440, pixels: '3.7M' },
    '4K': { width: 3840, height: 2160, pixels: '8.3M' }
  };

  // Calculate estimated file size and export time
  const calculateEstimates = useCallback(() => {
    const { resolution, fps, quality, compression, format } = exportSettings;
    const resSpec = resolutionSpecs[resolution];
    
    // Base calculation (simplified)
    let baseSizeMB = (parseInt(resSpec.pixels) * fps * 10) / 1000000;
    
    // Quality multiplier
    const qualityMultiplier = {
      'low': 0.3,
      'medium': 0.6,
      'high': 1.0,
      'ultra': 1.5
    }[quality];
    
    // Compression effect
    const compressionMultiplier = (100 - compression) / 100;
    
    // Format multiplier
    const formatMultiplier = {
      'MP4': 1.0,
      'MOV': 1.2,
      'GIF': 0.4,
      'WEBM': 0.8
    }[format];
    
    const estimatedSizeMB = baseSizeMB * qualityMultiplier * compressionMultiplier * formatMultiplier;
    const estimatedTimeSeconds = estimatedSizeMB * 2; // 2 seconds per MB (simplified)
    
    setEstimatedSize(`${estimatedSizeMB.toFixed(1)} MB`);
    setEstimatedTime(`${Math.ceil(estimatedTimeSeconds)}s`);
  }, [exportSettings]);

  useEffect(() => {
    calculateEstimates();
  }, [calculateEstimates]);

  // Apply export profile
  const applyProfile = useCallback((profile: ExportProfile) => {
    setExportSettings(profile.settings);
    setSelectedProfile(profile.id);
  }, []);

  // Update setting
  const updateSetting = useCallback(<K extends keyof ExportSettings>(
    key: K, 
    value: ExportSettings[K]
  ) => {
    setExportSettings(prev => ({ ...prev, [key]: value }));
    setSelectedProfile('custom');
  }, []);

  // Start export
  const startExport = useCallback(async () => {
    setIsExporting(true);
    setExportProgress(0);
    
    // Simulate export progress
    const totalSteps = 100;
    for (let i = 0; i <= totalSteps; i++) {
      await new Promise(resolve => setTimeout(resolve, 50));
      setExportProgress(i);
    }
    
    setIsExporting(false);
    onExport?.(exportSettings);
  }, [exportSettings, onExport]);

  // Get quality color
  const getQualityColor = (quality: string) => {
    switch (quality) {
      case 'ultra': return 'text-purple-400';
      case 'high': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'low': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  // Get format icon
  const getFormatIcon = (format: string) => {
    switch (format) {
      case 'MP4': return FileVideo;
      case 'MOV': return Film;
      case 'GIF': return Image;
      default: return FileVideo;
    }
  };

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 text-white overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Download className="h-6 w-6 text-indigo-400" />
              Advanced Export Engine
              <Badge className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white border-0 ml-auto">
                <Sparkles className="h-3 w-3 mr-1" />
                Professional
              </Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        {/* Export Progress */}
        {isExporting && (
          <Card className="bg-gradient-to-r from-green-800/50 to-emerald-800/50 border border-green-500/30">
            <CardContent className="p-6">
              <div className="text-center space-y-4">
                <div className="flex items-center justify-center gap-2">
                  <Download className="h-5 w-5 text-green-400 animate-pulse" />
                  <span className="text-lg font-semibold text-white">Exporting your video...</span>
                </div>
                
                <Progress value={exportProgress} className="w-full h-3" />
                
                <div className="text-sm text-gray-300">
                  {exportProgress < 30 ? 'Processing video layers...' :
                   exportProgress < 60 ? 'Applying effects and transitions...' :
                   exportProgress < 90 ? 'Encoding video...' : 'Finalizing export...'}
                </div>
                
                <div className="text-2xl font-bold text-green-400">
                  {exportProgress}%
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Export Profiles */}
          <div className="lg:col-span-2 space-y-4">
            {/* Quick Profiles */}
            <Card className="bg-slate-800/50 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Target className="h-4 w-4 text-green-400" />
                  Export Profiles
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {exportProfiles.map((profile) => {
                    const FormatIcon = getFormatIcon(profile.settings.format);
                    return (
                      <div
                        key={profile.id}
                        className={`p-4 rounded-lg border cursor-pointer transition-all hover:scale-105 ${
                          selectedProfile === profile.id
                            ? 'bg-green-500/20 border-green-400 ring-2 ring-green-400'
                            : 'bg-slate-700/50 border-slate-600 hover:border-green-500/50'
                        }`}
                        onClick={() => applyProfile(profile)}
                      >
                        <div className="flex items-start gap-3">
                          <div className="p-2 bg-green-500/20 rounded-lg">
                            <FormatIcon className="h-5 w-5 text-green-400" />
                          </div>
                          
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h3 className="font-medium text-white">{profile.name}</h3>
                              {profile.premium && (
                                <Crown className="h-4 w-4 text-yellow-400" />
                              )}
                            </div>
                            <p className="text-xs text-gray-400 mt-1">{profile.description}</p>
                            
                            <div className="flex items-center gap-4 mt-2 text-xs text-gray-300">
                              <span>{profile.settings.resolution} • {profile.settings.fps}fps</span>
                              <span>{profile.fileSize}</span>
                              <span>{profile.uploadTime}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Custom Settings */}
            <Card className="bg-slate-800/50 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Settings className="h-4 w-4 text-purple-400" />
                  Custom Export Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Format & Resolution */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-gray-300 mb-2 block">Format</label>
                    <select
                      value={exportSettings.format}
                      onChange={(e) => updateSetting('format', e.target.value as ExportSettings['format'])}
                      className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white"
                    >
                      <option value="MP4">MP4 (Universal)</option>
                      <option value="MOV">MOV (Professional)</option>
                      <option value="GIF">GIF (Animation)</option>
                      <option value="WEBM">WEBM (Web)</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="text-sm text-gray-300 mb-2 block">Resolution</label>
                    <select
                      value={exportSettings.resolution}
                      onChange={(e) => updateSetting('resolution', e.target.value as ExportSettings['resolution'])}
                      className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white"
                    >
                      <option value="480p">480p (854×480)</option>
                      <option value="720p">720p HD (1280×720)</option>
                      <option value="1080p">1080p FHD (1920×1080)</option>
                      <option value="1440p">1440p QHD (2560×1440)</option>
                      <option value="4K">4K UHD (3840×2160)</option>
                    </select>
                  </div>
                </div>

                {/* FPS & Quality */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-gray-300 mb-2 block">Frame Rate</label>
                    <select
                      value={exportSettings.fps}
                      onChange={(e) => updateSetting('fps', parseInt(e.target.value) as ExportSettings['fps'])}
                      className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white"
                    >
                      <option value={24}>24 FPS (Cinema)</option>
                      <option value={30}>30 FPS (Standard)</option>
                      <option value={60}>60 FPS (Smooth)</option>
                      <option value={120}>120 FPS (Ultra Smooth)</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="text-sm text-gray-300 mb-2 block">Quality</label>
                    <select
                      value={exportSettings.quality}
                      onChange={(e) => updateSetting('quality', e.target.value as ExportSettings['quality'])}
                      className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white"
                    >
                      <option value="low">Low (Fast)</option>
                      <option value="medium">Medium (Balanced)</option>
                      <option value="high">High (Quality)</option>
                      <option value="ultra">Ultra (Max Quality)</option>
                    </select>
                  </div>
                </div>

                {/* Compression */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="text-sm text-gray-300">Compression Level</label>
                    <Badge className="bg-blue-500/20 text-blue-300 border-0 text-xs">
                      {exportSettings.compression}% compressed
                    </Badge>
                  </div>
                  <Slider
                    value={[exportSettings.compression]}
                    onValueChange={([value]) => updateSetting('compression', value)}
                    max={95}
                    min={10}
                    step={5}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-400">
                    <span>Large File • High Quality</span>
                    <span>Small File • Lower Quality</span>
                  </div>
                </div>

                {/* Watermark */}
                <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Shield className="h-5 w-5 text-blue-400" />
                    <div>
                      <div className="text-white font-medium">Watermark</div>
                      <div className="text-xs text-gray-400">
                        {isLoggedIn ? 'Login users get watermark-free exports' : 'Login to remove watermark'}
                      </div>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => updateSetting('watermark', !exportSettings.watermark)}
                    disabled={!isLoggedIn}
                    className={`w-12 h-6 rounded-full transition-colors ${
                      exportSettings.watermark ? 'bg-red-500' : 'bg-green-500'
                    } ${!isLoggedIn ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                      exportSettings.watermark ? 'translate-x-0.5' : 'translate-x-6'
                    }`} />
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Export Summary & Controls */}
          <div className="space-y-4">
            {/* Export Summary */}
            <Card className="bg-slate-800/50 border-yellow-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Eye className="h-4 w-4 text-yellow-400" />
                  Export Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Format:</span>
                    <Badge className="bg-blue-500/20 text-blue-300 border-0">
                      {exportSettings.format}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-400">Resolution:</span>
                    <span className="text-white">{exportSettings.resolution}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-400">Frame Rate:</span>
                    <span className="text-white">{exportSettings.fps} FPS</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-400">Quality:</span>
                    <span className={`font-medium ${getQualityColor(exportSettings.quality)}`}>
                      {exportSettings.quality.toUpperCase()}
                    </span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-400">Watermark:</span>
                    <span className={exportSettings.watermark ? 'text-red-400' : 'text-green-400'}>
                      {exportSettings.watermark ? 'Yes' : 'No'}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* File Estimates */}
            <Card className="bg-slate-800/50 border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Gauge className="h-4 w-4 text-blue-400" />
                  File Estimates
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-slate-700/50 rounded-lg">
                    <HardDrive className="h-5 w-5 mx-auto mb-2 text-blue-400" />
                    <div className="text-lg font-bold text-white">{estimatedSize}</div>
                    <div className="text-xs text-gray-400">File Size</div>
                  </div>
                  
                  <div className="text-center p-3 bg-slate-700/50 rounded-lg">
                    <Clock className="h-5 w-5 mx-auto mb-2 text-green-400" />
                    <div className="text-lg font-bold text-white">{estimatedTime}</div>
                    <div className="text-xs text-gray-400">Export Time</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Export Button */}
            <Card className="bg-gradient-to-r from-indigo-800/50 to-purple-800/50 border border-indigo-500/30">
              <CardContent className="p-4">
                <Button
                  onClick={startExport}
                  disabled={isExporting}
                  className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 h-14 text-lg font-semibold"
                >
                  {isExporting ? (
                    <>
                      <Gauge className="h-5 w-5 mr-2 animate-spin" />
                      Exporting... {exportProgress}%
                    </>
                  ) : (
                    <>
                      <Download className="h-5 w-5 mr-2" />
                      Export Video
                    </>
                  )}
                </Button>
                
                <div className="text-center mt-3 text-sm text-gray-300">
                  {exportSettings.format} • {exportSettings.resolution} • {estimatedSize}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}