import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Download,
  Film,
  Image,
  FileVideo,
  Crown,
  Smartphone,
  Monitor,
  Wifi,
  Archive,
  Clock,
  HardDrive,
  CheckCircle,
  Zap
} from 'lucide-react';

interface QuickExportProfile {
  id: string;
  name: string;
  description: string;
  format: 'MP4' | 'MOV' | 'GIF' | 'WEBM';
  resolution: string;
  fps: number;
  quality: string;
  fileSize: string;
  exportTime: string;
  category: 'social' | 'professional' | 'web' | 'archive';
  premium: boolean;
  icon: any;
  color: string;
  features: string[];
}

interface QuickExportProfilesProps {
  onExportStart?: (profileId: string) => void;
  isLoggedIn?: boolean;
}

export function QuickExportProfiles({ onExportStart, isLoggedIn = false }: QuickExportProfilesProps) {
  const [selectedProfile, setSelectedProfile] = useState<string>('');
  const [isExporting, setIsExporting] = useState(false);

  const exportProfiles: QuickExportProfile[] = [
    {
      id: 'social_media',
      name: 'Social Media',
      description: 'Perfect untuk TikTok, Instagram, dan Facebook',
      format: 'MP4',
      resolution: '1080p',
      fps: 30,
      quality: 'High',
      fileSize: '15-25 MB',
      exportTime: '2-3 min',
      category: 'social',
      premium: false,
      icon: Smartphone,
      color: 'from-pink-500 to-rose-500',
      features: ['Square & Vertical format', 'Auto compression', 'Fast upload']
    },
    {
      id: 'youtube_4k',
      name: 'YouTube 4K',
      description: 'Kualitas ultra HD untuk konten premium',
      format: 'MP4',
      resolution: '4K',
      fps: 60,
      quality: 'Ultra',
      fileSize: '200-400 MB',
      exportTime: '10-15 min',
      category: 'professional',
      premium: true,
      icon: Monitor,
      color: 'from-red-500 to-orange-500',
      features: ['4K Ultra HD', 'H.265 codec', 'HDR support']
    },
    {
      id: 'web_optimized',
      name: 'Web Optimized',
      description: 'Ringan dan cepat untuk website',
      format: 'MP4',
      resolution: '720p',
      fps: 30,
      quality: 'Medium',
      fileSize: '5-10 MB',
      exportTime: '1-2 min',
      category: 'web',
      premium: false,
      icon: Wifi,
      color: 'from-blue-500 to-cyan-500',
      features: ['Small file size', 'Fast loading', 'Web compatible']
    },
    {
      id: 'gif_animation',
      name: 'GIF Animation',
      description: 'Format GIF untuk meme dan preview',
      format: 'GIF',
      resolution: '720p',
      fps: 24,
      quality: 'Medium',
      fileSize: '2-8 MB',
      exportTime: '1 min',
      category: 'web',
      premium: false,
      icon: Image,
      color: 'from-green-500 to-emerald-500',
      features: ['Loop animation', 'Universal support', 'No audio']
    },
    {
      id: 'professional_mov',
      name: 'Professional MOV',
      description: 'Format profesional untuk editing lanjutan',
      format: 'MOV',
      resolution: '1080p',
      fps: 60,
      quality: 'Ultra',
      fileSize: '100-200 MB',
      exportTime: '5-8 min',
      category: 'professional',
      premium: true,
      icon: Film,
      color: 'from-purple-500 to-indigo-500',
      features: ['ProRes codec', 'Color grading ready', 'High bitrate']
    },
    {
      id: 'archive_master',
      name: 'Archive Master',
      description: 'Kualitas tertinggi untuk penyimpanan',
      format: 'MOV',
      resolution: '4K',
      fps: 60,
      quality: 'Ultra',
      fileSize: '500-1000 MB',
      exportTime: '20-30 min',
      category: 'archive',
      premium: true,
      icon: Archive,
      color: 'from-gray-600 to-slate-600',
      features: ['Lossless quality', 'Future-proof', 'Max preservation']
    }
  ];

  const handleExport = async (profileId: string) => {
    setSelectedProfile(profileId);
    setIsExporting(true);
    
    // Simulate export process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsExporting(false);
    onExportStart?.(profileId);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'social': return Smartphone;
      case 'professional': return Film;
      case 'web': return Wifi;
      case 'archive': return Archive;
      default: return FileVideo;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'social': return 'bg-pink-500/20 text-pink-300 border-pink-500/30';
      case 'professional': return 'bg-purple-500/20 text-purple-300 border-purple-500/30';
      case 'web': return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 'archive': return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Zap className="h-6 w-6 text-yellow-400" />
            Quick Export Profiles
            <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0 ml-auto">
              One-Click Export
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Export Profiles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {exportProfiles.map((profile) => {
          const IconComponent = profile.icon;
          const CategoryIcon = getCategoryIcon(profile.category);
          const isSelected = selectedProfile === profile.id;
          
          return (
            <Card
              key={profile.id}
              className={`relative overflow-hidden cursor-pointer transition-all duration-300 hover:scale-105 ${
                isSelected 
                  ? 'bg-gradient-to-br from-green-800/50 to-emerald-800/50 border-green-400 ring-2 ring-green-400' 
                  : 'bg-slate-800/50 border-slate-600 hover:border-indigo-500/50'
              }`}
              onClick={() => !isExporting && handleExport(profile.id)}
            >
              {/* Background Gradient */}
              <div className={`absolute inset-0 bg-gradient-to-br ${profile.color} opacity-10`} />
              
              <CardContent className="relative p-6 space-y-4">
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className={`p-3 rounded-lg bg-gradient-to-br ${profile.color}`}>
                    <IconComponent className="h-6 w-6 text-white" />
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {profile.premium && (
                      <Crown className="h-4 w-4 text-yellow-400" />
                    )}
                    <Badge className={getCategoryColor(profile.category)}>
                      <CategoryIcon className="h-3 w-3 mr-1" />
                      {profile.category}
                    </Badge>
                  </div>
                </div>

                {/* Title & Description */}
                <div>
                  <h3 className="text-lg font-semibold text-white">{profile.name}</h3>
                  <p className="text-sm text-gray-400 mt-1">{profile.description}</p>
                </div>

                {/* Specs */}
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center gap-2">
                    <FileVideo className="h-4 w-4 text-blue-400" />
                    <span className="text-gray-300">{profile.format} • {profile.resolution}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Zap className="h-4 w-4 text-green-400" />
                    <span className="text-gray-300">{profile.fps} FPS</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <HardDrive className="h-4 w-4 text-purple-400" />
                    <span className="text-gray-300">{profile.fileSize}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-orange-400" />
                    <span className="text-gray-300">{profile.exportTime}</span>
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-2">
                  {profile.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2 text-xs text-gray-400">
                      <CheckCircle className="h-3 w-3 text-green-400" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Export Button */}
                <Button
                  disabled={isExporting || (profile.premium && !isLoggedIn)}
                  className={`w-full h-12 ${
                    isSelected && isExporting
                      ? 'bg-green-500 hover:bg-green-600'
                      : `bg-gradient-to-r ${profile.color} hover:opacity-90`
                  } transition-all duration-300`}
                >
                  {isSelected && isExporting ? (
                    <>
                      <Download className="h-4 w-4 mr-2 animate-pulse" />
                      Exporting...
                    </>
                  ) : profile.premium && !isLoggedIn ? (
                    <>
                      <Crown className="h-4 w-4 mr-2" />
                      Premium Required
                    </>
                  ) : (
                    <>
                      <Download className="h-4 w-4 mr-2" />
                      Export {profile.format}
                    </>
                  )}
                </Button>

                {/* Watermark Notice */}
                {!isLoggedIn && (
                  <div className="text-xs text-yellow-400 text-center">
                    ⚠️ Watermark will be added • Login to remove
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Premium Notice */}
      {!isLoggedIn && (
        <Card className="bg-gradient-to-r from-yellow-800/50 to-orange-800/50 border border-yellow-500/30">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Crown className="h-8 w-8 text-yellow-400" />
              <div>
                <h3 className="text-white font-semibold">Unlock Premium Exports</h3>
                <p className="text-yellow-200 text-sm mt-1">
                  Login untuk akses 4K exports, remove watermarks, dan format profesional
                </p>
              </div>
              <Button className="ml-auto bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                Login Now
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}