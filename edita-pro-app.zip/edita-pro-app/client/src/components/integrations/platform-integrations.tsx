import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Youtube, 
  Instagram, 
  Facebook, 
  Twitter, 
  Linkedin, 
  Twitch, 
  Music, 
  Camera, 
  Cloud, 
  Zap, 
  CheckCircle, 
  AlertCircle, 
  Settings, 
  Link, 
  Upload, 
  Download, 
  Sparkles, 
  Shield, 
  Globe,
  Smartphone,
  Video,
  Image,
  Users,
  TrendingUp
} from 'lucide-react';

interface PlatformIntegration {
  id: string;
  name: string;
  icon: any;
  color: string;
  connected: boolean;
  features: string[];
  description: string;
  category: 'social' | 'cloud' | 'music' | 'ai' | 'productivity';
  premium: boolean;
  lastSync?: Date;
}

interface IntegrationAction {
  id: string;
  name: string;
  description: string;
  type: 'upload' | 'download' | 'sync' | 'analyze';
  platform: string;
  enabled: boolean;
}

interface PlatformIntegrationsProps {
  onConnect?: (platform: string) => void;
  onDisconnect?: (platform: string) => void;
  onSync?: (platform: string) => void;
}

export function PlatformIntegrations({ onConnect, onDisconnect, onSync }: PlatformIntegrationsProps) {
  const [integrations, setIntegrations] = useState<PlatformIntegration[]>([
    {
      id: 'youtube',
      name: 'YouTube',
      icon: Youtube,
      color: 'from-red-500 to-red-600',
      connected: false,
      category: 'social',
      premium: false,
      description: 'Upload videos langsung ke channel YouTube Anda',
      features: ['Auto upload', 'Metadata sync', 'Thumbnail generation', 'Analytics tracking']
    },
    {
      id: 'instagram',
      name: 'Instagram',
      icon: Instagram,
      color: 'from-pink-500 to-purple-600',
      connected: false,
      category: 'social',
      premium: false,
      description: 'Share ke Instagram Feed, Stories, dan Reels',
      features: ['Multi-format posts', 'Story scheduling', 'Reels optimization', 'Hashtag suggestions']
    },
    {
      id: 'tiktok',
      name: 'TikTok',
      icon: Music,
      color: 'from-black to-pink-500',
      connected: false,
      category: 'social',
      premium: false,
      description: 'Upload video viral ke TikTok dengan optimal format',
      features: ['Vertical video optimization', 'Trending audio', 'Hashtag trends', 'Best time posting']
    },
    {
      id: 'facebook',
      name: 'Facebook',
      icon: Facebook,
      color: 'from-blue-500 to-blue-600',
      connected: false,
      category: 'social',
      premium: false,
      description: 'Share ke Facebook Pages dan personal profile',
      features: ['Page management', 'Video scheduling', 'Audience insights', 'Cross-posting']
    },
    {
      id: 'drive',
      name: 'Google Drive',
      icon: Cloud,
      color: 'from-blue-400 to-green-500',
      connected: false,
      category: 'cloud',
      premium: false,
      description: 'Sync files otomatis dengan Google Drive',
      features: ['Auto backup', 'File sync', 'Folder organization', 'Version control']
    },
    {
      id: 'dropbox',
      name: 'Dropbox',
      icon: Cloud,
      color: 'from-blue-600 to-blue-700',
      connected: false,
      category: 'cloud',
      premium: false,
      description: 'Backup dan sync dengan Dropbox storage',
      features: ['Smart sync', 'File sharing', 'Team folders', 'Offline access']
    },
    {
      id: 'spotify',
      name: 'Spotify',
      icon: Music,
      color: 'from-green-500 to-green-600',
      connected: false,
      category: 'music',
      premium: true,
      description: 'Access Spotify music library untuk video background',
      features: ['Music library', 'Playlist import', 'Audio sync', 'Copyright safe']
    },
    {
      id: 'unsplash',
      name: 'Unsplash',
      icon: Image,
      color: 'from-gray-700 to-gray-800',
      connected: false,
      category: 'ai',
      premium: false,
      description: 'Millions of high-quality stock photos gratis',
      features: ['HD photos', 'Commercial use', 'Search by keyword', 'Auto attribution']
    },
    {
      id: 'openai',
      name: 'OpenAI',
      icon: Sparkles,
      color: 'from-purple-500 to-indigo-600',
      connected: false,
      category: 'ai',
      premium: true,
      description: 'AI-powered content generation dan enhancement',
      features: ['Text generation', 'Image analysis', 'Smart suggestions', 'Content optimization']
    },
    {
      id: 'slack',
      name: 'Slack',
      icon: Users,
      color: 'from-purple-600 to-pink-500',
      connected: false,
      category: 'productivity',
      premium: false,
      description: 'Team collaboration dan project notifications',
      features: ['Project updates', 'Team sharing', 'Review requests', 'Status notifications']
    }
  ]);

  const [automationActions, setAutomationActions] = useState<IntegrationAction[]>([
    {
      id: 'auto_youtube_upload',
      name: 'Auto YouTube Upload',
      description: 'Upload completed videos ke YouTube otomatis',
      type: 'upload',
      platform: 'youtube',
      enabled: false
    },
    {
      id: 'instagram_stories_sync',
      name: 'Instagram Stories Sync',
      description: 'Auto-post ke Instagram Stories dengan optimal timing',
      type: 'upload',
      platform: 'instagram',
      enabled: false
    },
    {
      id: 'drive_backup',
      name: 'Google Drive Backup',
      description: 'Backup semua project files ke Google Drive',
      type: 'sync',
      platform: 'drive',
      enabled: false
    },
    {
      id: 'spotify_music_import',
      name: 'Spotify Music Import',
      description: 'Import musik dari Spotify playlist',
      type: 'download',
      platform: 'spotify',
      enabled: false
    }
  ]);

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isConnecting, setIsConnecting] = useState<string>('');

  const categories = [
    { id: 'all', name: 'All Integrations', icon: Globe },
    { id: 'social', name: 'Social Media', icon: Users },
    { id: 'cloud', name: 'Cloud Storage', icon: Cloud },
    { id: 'music', name: 'Music Services', icon: Music },
    { id: 'ai', name: 'AI Services', icon: Sparkles },
    { id: 'productivity', name: 'Productivity', icon: TrendingUp }
  ];

  const handleConnect = async (platform: string) => {
    setIsConnecting(platform);
    
    // This would require actual API keys from the user
    // For now, we'll show the connection process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIntegrations(prev => prev.map(integration => 
      integration.id === platform 
        ? { ...integration, connected: true, lastSync: new Date() }
        : integration
    ));
    
    setIsConnecting('');
    onConnect?.(platform);
  };

  const handleDisconnect = (platform: string) => {
    setIntegrations(prev => prev.map(integration => 
      integration.id === platform 
        ? { ...integration, connected: false, lastSync: undefined }
        : integration
    ));
    
    onDisconnect?.(platform);
  };

  const handleSync = async (platform: string) => {
    setIntegrations(prev => prev.map(integration => 
      integration.id === platform 
        ? { ...integration, lastSync: new Date() }
        : integration
    ));
    
    onSync?.(platform);
  };

  const toggleAutomation = (actionId: string) => {
    setAutomationActions(prev => prev.map(action => 
      action.id === actionId 
        ? { ...action, enabled: !action.enabled }
        : action
    ));
  };

  const filteredIntegrations = selectedCategory === 'all' 
    ? integrations 
    : integrations.filter(integration => integration.category === selectedCategory);

  const connectedCount = integrations.filter(i => i.connected).length;
  const activeAutomations = automationActions.filter(a => a.enabled).length;

  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-indigo-900/80 to-purple-900/80 border border-indigo-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Link className="h-6 w-6 text-indigo-400" />
            Platform Integrations
            <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white border-0 ml-auto">
              <CheckCircle className="h-3 w-3 mr-1" />
              {connectedCount} Connected
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="p-3 bg-slate-700/50 rounded-lg">
              <div className="text-2xl font-bold text-white">{connectedCount}</div>
              <div className="text-sm text-gray-300">Connected Platforms</div>
            </div>
            <div className="p-3 bg-slate-700/50 rounded-lg">
              <div className="text-2xl font-bold text-white">{activeAutomations}</div>
              <div className="text-sm text-gray-300">Active Automations</div>
            </div>
            <div className="p-3 bg-slate-700/50 rounded-lg">
              <div className="text-2xl font-bold text-white">24/7</div>
              <div className="text-sm text-gray-300">Auto Sync</div>
            </div>
            <div className="p-3 bg-slate-700/50 rounded-lg">
              <div className="text-2xl font-bold text-white">99.9%</div>
              <div className="text-sm text-gray-300">Uptime</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Category Filter */}
      <Card className="bg-slate-800/50 border-blue-500/30">
        <CardContent className="p-4">
          <div className="flex gap-2 flex-wrap">
            {categories.map(category => {
              const CategoryIcon = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                    selectedCategory === category.id
                      ? 'bg-blue-500 text-white'
                      : 'bg-slate-700/50 text-gray-300 hover:bg-slate-700'
                  }`}
                >
                  <CategoryIcon className="h-4 w-4" />
                  {category.name}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Available Integrations */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="bg-slate-800/50 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Globe className="h-4 w-4 text-green-400" />
                Available Integrations
                <Badge className="bg-green-500/20 text-green-300 border-green-500/30 ml-auto">
                  {filteredIntegrations.length} Services
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {filteredIntegrations.map((integration) => {
                const IconComponent = integration.icon;
                return (
                  <div
                    key={integration.id}
                    className="flex items-center gap-4 p-4 bg-slate-700/50 rounded-lg hover:bg-slate-700/70 transition-colors"
                  >
                    <div className={`p-3 rounded-lg bg-gradient-to-r ${integration.color}`}>
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-white">{integration.name}</h3>
                        {integration.premium && (
                          <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 text-xs">
                            Premium
                          </Badge>
                        )}
                        {integration.connected && (
                          <Badge className="bg-green-500/20 text-green-300 border-green-500/30 text-xs">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Connected
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-400 mt-1">{integration.description}</p>
                      
                      <div className="flex flex-wrap gap-1 mt-2">
                        {integration.features.slice(0, 3).map((feature) => (
                          <Badge key={feature} className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs">
                            {feature}
                          </Badge>
                        ))}
                        {integration.features.length > 3 && (
                          <Badge className="bg-gray-500/20 text-gray-300 border-gray-500/30 text-xs">
                            +{integration.features.length - 3} more
                          </Badge>
                        )}
                      </div>

                      {integration.lastSync && (
                        <div className="text-xs text-gray-500 mt-1">
                          Last sync: {Math.floor((Date.now() - integration.lastSync.getTime()) / 60000)}m ago
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {integration.connected ? (
                        <>
                          <Button
                            size="sm"
                            onClick={() => handleSync(integration.id)}
                            className="bg-blue-500 hover:bg-blue-600"
                          >
                            <Zap className="h-3 w-3 mr-1" />
                            Sync
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDisconnect(integration.id)}
                            className="border-red-500 text-red-400 hover:bg-red-500/20"
                          >
                            Disconnect
                          </Button>
                        </>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => handleConnect(integration.id)}
                          disabled={isConnecting === integration.id}
                          className={`bg-gradient-to-r ${integration.color} hover:opacity-90`}
                        >
                          {isConnecting === integration.id ? (
                            <>
                              <Settings className="h-3 w-3 mr-1 animate-spin" />
                              Connecting...
                            </>
                          ) : (
                            <>
                              <Link className="h-3 w-3 mr-1" />
                              Connect
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </div>

        {/* Automation Settings */}
        <div className="space-y-4">
          <Card className="bg-slate-800/50 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Zap className="h-4 w-4 text-purple-400" />
                Automation Rules
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {automationActions.map((action) => (
                <div key={action.id} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                  <div className="flex-1">
                    <div className="font-medium text-white text-sm">{action.name}</div>
                    <div className="text-xs text-gray-400">{action.description}</div>
                  </div>
                  <button
                    onClick={() => toggleAutomation(action.id)}
                    className={`w-12 h-6 rounded-full transition-colors ${
                      action.enabled ? 'bg-green-500' : 'bg-gray-600'
                    }`}
                  >
                    <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                      action.enabled ? 'translate-x-6' : 'translate-x-0.5'
                    }`} />
                  </button>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Shield className="h-4 w-4 text-yellow-400" />
                Security & Privacy
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>OAuth 2.0 Authentication</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>Encrypted token storage</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>Minimal permission requests</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span>Data privacy compliance</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-orange-500/30">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-orange-400" />
                Setup Required
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-sm text-gray-300">
                <p className="mb-2">To enable integrations, you'll need to provide API keys and credentials for each service.</p>
                <p className="text-orange-300">Ready to connect? We'll guide you through the setup process for each platform.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}