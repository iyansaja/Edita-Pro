import React, { useState } from 'react';
import { TemplateCarousel } from './template-carousel';
import { RecentProjectsView } from '@/components/projects/recent-projects-view';
import { ViralVideoTemplates } from '@/components/templates/viral-video-templates';
import { MusicBeatTemplates } from '@/components/templates/music-beat-templates';
import { CinematicTransitions } from '@/components/templates/cinematic-transitions';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  Filter, 
  Plus, 
  TrendingUp, 
  Clock, 
  Zap,
  FileText,
  Video,
  Music,
  Image,
  Sparkles,
  Users,
  Award
} from 'lucide-react';

interface Template {
  id: string;
  title: string;
  description: string;
  category: 'document' | 'video' | 'audio' | 'presentation' | 'design';
  thumbnail: string;
  tags: string[];
  rating: number;
  downloads: number;
  isPremium: boolean;
  author: string;
  duration?: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

interface LobbyDashboardProps {
  onCreateNew?: () => void;
  onSelectTemplate?: (template: Template) => void;
}

export function LobbyDashboard({ onCreateNew, onSelectTemplate }: LobbyDashboardProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Template data berbagai kategori
  const featuredTemplates: Template[] = [
    {
      id: '1',
      title: 'Modern Business Presentation',
      description: 'Professional slides untuk meeting dan presentasi corporate',
      category: 'presentation',
      thumbnail: '',
      tags: ['business', 'corporate', 'modern', 'slides'],
      rating: 4.8,
      downloads: 1250,
      isPremium: true,
      author: 'DesignPro',
      difficulty: 'intermediate'
    },
    {
      id: '2',
      title: 'Social Media Video Template',
      description: 'Template video trendy untuk konten Instagram dan TikTok',
      category: 'video',
      thumbnail: '',
      tags: ['social', 'trendy', 'instagram', 'viral'],
      rating: 4.9,
      downloads: 2100,
      isPremium: false,
      author: 'VideoMaster',
      duration: '15s',
      difficulty: 'beginner'
    },
    {
      id: '3',
      title: 'Podcast Intro Music',
      description: 'Musik intro profesional untuk podcast dan konten audio',
      category: 'audio',
      thumbnail: '',
      tags: ['podcast', 'intro', 'professional', 'music'],
      rating: 4.7,
      downloads: 890,
      isPremium: true,
      author: 'AudioCraft',
      duration: '30s',
      difficulty: 'beginner'
    },
    {
      id: '4',
      title: 'Creative Document Layout',
      description: 'Template dokumen cantik dengan typography modern',
      category: 'document',
      thumbnail: '',
      tags: ['creative', 'typography', 'layout', 'modern'],
      rating: 4.6,
      downloads: 670,
      isPremium: false,
      author: 'TypeDesign',
      difficulty: 'intermediate'
    }
  ];

  const trendingTemplates: Template[] = [
    {
      id: '5',
      title: 'Animated Logo Reveal',
      description: 'Logo reveal animasi stunning untuk brand introduction',
      category: 'video',
      thumbnail: '',
      tags: ['logo', 'animation', 'brand', 'intro'],
      rating: 4.9,
      downloads: 3200,
      isPremium: true,
      author: 'AnimationStudio',
      duration: '5s',
      difficulty: 'advanced'
    },
    {
      id: '6',
      title: 'Minimalist Portfolio',
      description: 'Design clean dan minimalist perfect untuk portfolio',
      category: 'design',
      thumbnail: '',
      tags: ['minimalist', 'portfolio', 'clean', 'professional'],
      rating: 4.8,
      downloads: 1500,
      isPremium: false,
      author: 'MinimalDesign',
      difficulty: 'intermediate'
    },
    {
      id: '7',
      title: 'Corporate Video Intro',
      description: 'Video intro corporate dengan animasi profesional',
      category: 'video',
      thumbnail: '',
      tags: ['corporate', 'intro', 'professional', 'business'],
      rating: 4.7,
      downloads: 980,
      isPremium: true,
      author: 'CorpVideo',
      duration: '10s',
      difficulty: 'intermediate'
    }
  ];

  const recentTemplates: Template[] = [
    {
      id: '8',
      title: 'Creative Report Template',
      description: 'Template laporan kreatif dengan visualisasi data',
      category: 'document',
      thumbnail: '',
      tags: ['report', 'data', 'creative', 'business'],
      rating: 4.5,
      downloads: 420,
      isPremium: false,
      author: 'DataDesign',
      difficulty: 'beginner'
    },
    {
      id: '9',
      title: 'YouTube Thumbnail Pack',
      description: 'Pack thumbnail YouTube dengan design eye-catching',
      category: 'design',
      thumbnail: '',
      tags: ['youtube', 'thumbnail', 'social', 'engaging'],
      rating: 4.6,
      downloads: 750,
      isPremium: true,
      author: 'ThumbCraft',
      difficulty: 'beginner'
    }
  ];

  const categories = [
    { id: 'all', name: 'Semua', icon: Sparkles },
    { id: 'document', name: 'Dokumen', icon: FileText },
    { id: 'video', name: 'Video', icon: Video },
    { id: 'audio', name: 'Audio', icon: Music },
    { id: 'presentation', name: 'Presentasi', icon: Image },
    { id: 'design', name: 'Design', icon: Sparkles }
  ];

  const stats = [
    { label: 'Total Templates', value: '500+', icon: FileText, color: 'text-blue-400' },
    { label: 'Active Users', value: '10K+', icon: Users, color: 'text-green-400' },
    { label: 'Pro Templates', value: '200+', icon: Award, color: 'text-yellow-400' },
    { label: 'Downloads', value: '50K+', icon: TrendingUp, color: 'text-purple-400' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-white flex items-center justify-center gap-3">
            <Sparkles className="h-8 w-8 text-purple-400" />
            Edita Pro Template Gallery
          </h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Temukan template profesional untuk semua kebutuhan creative Anda. 
            Dari video editing hingga document design, semuanya tersedia di sini.
          </p>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center justify-center gap-4">
          <Button
            onClick={onCreateNew}
            size="lg"
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <Plus className="h-5 w-5 mr-2" />
            Buat Project Baru
          </Button>
          
          <Button
            variant="outline"
            size="lg"
            className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
          >
            <Zap className="h-5 w-5 mr-2" />
            Quick Start
          </Button>
        </div>

        {/* Search & Filter */}
        <div className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Cari template..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-black/20 border-purple-500/30 text-white placeholder-gray-400"
            />
          </div>
          
          <div className="flex items-center gap-2">
            {categories.map((category) => {
              const Icon = category.icon;
              return (
                <Button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  size="sm"
                  className={selectedCategory === category.id 
                    ? "bg-purple-500 hover:bg-purple-600" 
                    : "border-purple-500/30 hover:bg-purple-500/10"
                  }
                >
                  <Icon className="h-4 w-4 mr-2" />
                  {category.name}
                </Button>
              );
            })}
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card key={stat.label} className="bg-black/20 border-purple-500/30">
                <CardContent className="p-4 text-center">
                  <Icon className={`h-8 w-8 mx-auto mb-2 ${stat.color}`} />
                  <div className="text-2xl font-bold text-white">{stat.value}</div>
                  <div className="text-sm text-gray-400">{stat.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Recent Projects Section */}
        <RecentProjectsView 
          onProjectOpen={(project) => console.log('Opening project:', project)}
          onProjectEdit={(project) => console.log('Editing project:', project)}
        />

        {/* Featured Templates */}
        <TemplateCarousel
          title="Template Unggulan"
          templates={featuredTemplates}
          onSelectTemplate={onSelectTemplate}
          onPreviewTemplate={(template) => console.log('Preview:', template)}
        />

        {/* Trending Templates */}
        <TemplateCarousel
          title="Trending Sekarang"
          templates={trendingTemplates}
          onSelectTemplate={onSelectTemplate}
          onPreviewTemplate={(template) => console.log('Preview:', template)}
        />

        {/* Recent Templates */}
        <TemplateCarousel
          title="Template Terbaru"
          templates={recentTemplates}
          onSelectTemplate={onSelectTemplate}
          onPreviewTemplate={(template) => console.log('Preview:', template)}
        />

        {/* Call to Action */}
        <Card className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 border-purple-500/30">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-white mb-4">
              Upgrade ke Edita Pro Premium
            </h3>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
              Dapatkan akses unlimited ke semua template premium, fitur AI advanced, 
              dan export kualitas 4K tanpa watermark.
            </p>
            <Button
              size="lg"
              className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Award className="h-5 w-5 mr-2" />
              Upgrade Sekarang
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}