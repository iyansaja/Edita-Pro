import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  FileText, 
  Video, 
  Music, 
  Image, 
  Sparkles, 
  Crown,
  Eye,
  Download,
  Star
} from 'lucide-react';

interface Template {
  id: string;
  title: string;
  description: string;
  category: 'document' | 'video' | 'audio' | 'presentation' | 'design';
  thumbnail: string;
  tags: string[];
  rating: number;
  downloads: number;
  isPremium: boolean;
  author: string;
  duration?: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

interface TemplateCarouselProps {
  templates: Template[];
  title: string;
  onSelectTemplate?: (template: Template) => void;
  onPreviewTemplate?: (template: Template) => void;
}

export function TemplateCarousel({ templates, title, onSelectTemplate, onPreviewTemplate }: TemplateCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [hoveredTemplate, setHoveredTemplate] = useState<string | null>(null);

  const scrollLeft = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: -320, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: 320, behavior: 'smooth' });
    }
  };

  const getCategoryIcon = (category: Template['category']) => {
    switch (category) {
      case 'document':
        return <FileText className="h-4 w-4" />;
      case 'video':
        return <Video className="h-4 w-4" />;
      case 'audio':
        return <Music className="h-4 w-4" />;
      case 'presentation':
        return <Image className="h-4 w-4" />;
      case 'design':
        return <Sparkles className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getDifficultyColor = (difficulty: Template['difficulty']) => {
    switch (difficulty) {
      case 'beginner':
        return 'bg-green-500';
      case 'intermediate':
        return 'bg-yellow-500';
      case 'advanced':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="w-full space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Sparkles className="h-6 w-6 text-purple-400" />
          {title}
        </h2>
        
        <div className="flex items-center gap-2">
          <Button
            onClick={scrollLeft}
            variant="outline"
            size="sm"
            className="rounded-full bg-black/20 border-purple-500/30 hover:bg-purple-500/20"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            onClick={scrollRight}
            variant="outline"
            size="sm"
            className="rounded-full bg-black/20 border-purple-500/30 hover:bg-purple-500/20"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Carousel */}
      <div className="relative">
        <div 
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide pb-4"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {templates.map((template) => (
            <Card
              key={template.id}
              className="flex-shrink-0 w-80 bg-gradient-to-br from-slate-800/80 to-purple-900/80 border border-purple-500/30 hover:border-purple-400/60 transition-all duration-300 hover:scale-105 cursor-pointer group backdrop-blur-md"
              onMouseEnter={() => setHoveredTemplate(template.id)}
              onMouseLeave={() => setHoveredTemplate(null)}
              onClick={() => onSelectTemplate?.(template)}
            >
              <CardContent className="p-0">
                {/* Thumbnail */}
                <div className="relative h-48 bg-gradient-to-br from-purple-600/20 to-blue-600/20 rounded-t-lg overflow-hidden">
                  {/* Thumbnail Image Placeholder */}
                  <div className="w-full h-full bg-gradient-to-br from-indigo-500/30 to-purple-600/30 flex items-center justify-center">
                    <div className="text-6xl text-white/30">
                      {getCategoryIcon(template.category)}
                    </div>
                  </div>
                  
                  {/* Premium Badge */}
                  {template.isPremium && (
                    <div className="absolute top-3 left-3">
                      <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0">
                        <Crown className="h-3 w-3 mr-1" />
                        Pro
                      </Badge>
                    </div>
                  )}
                  
                  {/* Category Badge */}
                  <div className="absolute top-3 right-3">
                    <Badge variant="secondary" className="bg-black/50 text-white border-0 capitalize">
                      {getCategoryIcon(template.category)}
                      <span className="ml-1">{template.category}</span>
                    </Badge>
                  </div>

                  {/* Hover Overlay */}
                  {hoveredTemplate === template.id && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center gap-3 transition-all duration-300">
                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          onPreviewTemplate?.(template);
                        }}
                        variant="default"
                        size="sm"
                        className="bg-purple-500 hover:bg-purple-600"
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Preview
                      </Button>
                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectTemplate?.(template);
                        }}
                        variant="default"
                        size="sm"
                        className="bg-blue-500 hover:bg-blue-600"
                      >
                        <Play className="h-4 w-4 mr-2" />
                        Use Template
                      </Button>
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-4 space-y-3">
                  {/* Title & Rating */}
                  <div className="space-y-2">
                    <h3 className="font-semibold text-white line-clamp-1">
                      {template.title}
                    </h3>
                    <p className="text-sm text-gray-400 line-clamp-2">
                      {template.description}
                    </p>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1">
                    {template.tags.slice(0, 3).map((tag) => (
                      <Badge
                        key={tag}
                        variant="outline"
                        className="text-xs bg-purple-500/10 border-purple-500/30 text-purple-300"
                      >
                        {tag}
                      </Badge>
                    ))}
                    {template.tags.length > 3 && (
                      <Badge
                        variant="outline"
                        className="text-xs bg-gray-500/10 border-gray-500/30 text-gray-400"
                      >
                        +{template.tags.length - 3}
                      </Badge>
                    )}
                  </div>

                  {/* Stats */}
                  <div className="flex items-center justify-between text-sm text-gray-400">
                    <div className="flex items-center gap-3">
                      {/* Rating */}
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 text-yellow-400 fill-current" />
                        <span>{template.rating}</span>
                      </div>
                      
                      {/* Downloads */}
                      <div className="flex items-center gap-1">
                        <Download className="h-4 w-4" />
                        <span>{template.downloads}</span>
                      </div>
                    </div>

                    {/* Difficulty */}
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${getDifficultyColor(template.difficulty)}`} />
                      <span className="capitalize text-xs">{template.difficulty}</span>
                    </div>
                  </div>

                  {/* Author & Duration */}
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>by {template.author}</span>
                    {template.duration && <span>{template.duration}</span>}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}