import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
  Play, 
  Pause, 
  Square, 
  Volume2, 
  Upload, 
  Mic, 
  Music, 
  Waves,
  Settings,
  Download,
  FileAudio,
  Headphones,
  Radio,
  Zap,
  VolumeX,
  RotateCcw,
  Shuffle,
  SkipBack,
  SkipForward
} from 'lucide-react';

interface AudioTrack {
  id: string;
  name: string;
  type: 'music' | 'sfx' | 'voiceover' | 'ambient';
  url: string;
  duration: number;
  volume: number;
  startTime: number;
  endTime: number;
  effects: string[];
}

interface AudioEditorProps {
  open: boolean;
  onClose: () => void;
  onAudioAdded: (audioUrl: string, type: string) => void;
}

const MUSIC_LIBRARY = [
  { id: '1', name: 'Cinematic Epic', genre: 'Cinematic', duration: 180, url: '/audio/music/cinematic-epic.mp3' },
  { id: '2', name: 'Upbeat Pop', genre: 'Pop', duration: 120, url: '/audio/music/upbeat-pop.mp3' },
  { id: '3', name: 'Chill Lofi', genre: 'Lofi', duration: 240, url: '/audio/music/chill-lofi.mp3' },
  { id: '4', name: 'Corporate Inspiring', genre: 'Corporate', duration: 150, url: '/audio/music/corporate.mp3' },
  { id: '5', name: 'Electronic Dance', genre: 'EDM', duration: 200, url: '/audio/music/edm-dance.mp3' },
  { id: '6', name: 'Acoustic Guitar', genre: 'Acoustic', duration: 160, url: '/audio/music/acoustic.mp3' },
];

const SOUND_FX_LIBRARY = [
  { id: '1', name: 'Whoosh', category: 'Transitions', duration: 2, url: '/audio/sfx/whoosh.mp3' },
  { id: '2', name: 'Pop', category: 'UI', duration: 1, url: '/audio/sfx/pop.mp3' },
  { id: '3', name: 'Thunder', category: 'Nature', duration: 5, url: '/audio/sfx/thunder.mp3' },
  { id: '4', name: 'Applause', category: 'Crowd', duration: 8, url: '/audio/sfx/applause.mp3' },
  { id: '5', name: 'Typing', category: 'Office', duration: 10, url: '/audio/sfx/typing.mp3' },
  { id: '6', name: 'Cinematic Hit', category: 'Cinematic', duration: 3, url: '/audio/sfx/cinematic-hit.mp3' },
  { id: '7', name: 'Ocean Waves', category: 'Ambience', duration: 300, url: '/audio/sfx/ocean-waves.mp3' },
  { id: '8', name: 'Forest Birds', category: 'Ambience', duration: 180, url: '/audio/sfx/forest-birds.mp3' },
];

const VOICE_EFFECTS = [
  { id: 'normal', name: 'Normal', icon: '🎤' },
  { id: 'robot', name: 'Robot', icon: '🤖' },
  { id: 'chipmunk', name: 'Chipmunk', icon: '🐿️' },
  { id: 'deep', name: 'Deep Voice', icon: '👹' },
  { id: 'funny', name: 'Funny', icon: '🤡' },
  { id: 'echo', name: 'Echo', icon: '🔊' },
  { id: 'reverb', name: 'Reverb', icon: '🎭' },
  { id: 'whisper', name: 'Whisper', icon: '🤫' },
];

export function AudioEditor({ open, onClose, onAudioAdded }: AudioEditorProps) {
  const [activeTab, setActiveTab] = useState('music');
  const [audioTracks, setAudioTracks] = useState<AudioTrack[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [selectedVoiceEffect, setSelectedVoiceEffect] = useState('normal');
  const [masterVolume, setMasterVolume] = useState([80]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [autoBeatMatch, setAutoBeatMatch] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    if (!open) return;
    
    // Initialize audio context
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, [open]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      
      const chunks: BlobPart[] = [];
      
      mediaRecorderRef.current.ondataavailable = (e) => {
        chunks.push(e.data);
      };
      
      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        const url = URL.createObjectURL(blob);
        const newTrack: AudioTrack = {
          id: Date.now().toString(),
          name: `Voice Recording ${recordingTime}s`,
          type: 'voiceover',
          url,
          duration: recordingTime,
          volume: 80,
          startTime: 0,
          endTime: recordingTime,
          effects: [selectedVoiceEffect]
        };
        setAudioTracks(prev => [...prev, newTrack]);
        onAudioAdded(url, 'voiceover');
      };
      
      mediaRecorderRef.current.start();
      setIsRecording(true);
      setRecordingTime(0);
      
      recordingTimerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      
    } catch (error) {
      console.error('Error accessing microphone:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      const newTrack: AudioTrack = {
        id: Date.now().toString(),
        name: file.name,
        type: 'music',
        url,
        duration: 0, // Will be updated when audio loads
        volume: 80,
        startTime: 0,
        endTime: 0,
        effects: []
      };
      setAudioTracks(prev => [...prev, newTrack]);
      onAudioAdded(url, 'music');
    }
  };

  const addLibraryMusic = (music: any) => {
    const newTrack: AudioTrack = {
      id: Date.now().toString(),
      name: music.name,
      type: 'music',
      url: music.url,
      duration: music.duration,
      volume: 80,
      startTime: 0,
      endTime: music.duration,
      effects: []
    };
    setAudioTracks(prev => [...prev, newTrack]);
    onAudioAdded(music.url, 'music');
  };

  const addSoundFX = (sfx: any) => {
    const newTrack: AudioTrack = {
      id: Date.now().toString(),
      name: sfx.name,
      type: 'sfx',
      url: sfx.url,
      duration: sfx.duration,
      volume: 80,
      startTime: 0,
      endTime: sfx.duration,
      effects: []
    };
    setAudioTracks(prev => [...prev, newTrack]);
    onAudioAdded(sfx.url, 'sfx');
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-900 rounded-xl w-full max-w-6xl h-[90vh] flex flex-col glass-morphism modern-card">
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-4">
            <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg">
              <Headphones className="h-6 w-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold gradient-text">Audio & Musik Editor</h2>
              <p className="text-gray-600 dark:text-gray-400">Tambah musik, efek suara, dan voice-over professional</p>
            </div>
          </div>
          <Button onClick={onClose} variant="outline" size="sm">
            ✕
          </Button>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* Left Panel - Audio Library */}
          <div className="w-1/2 border-r border-gray-200 dark:border-gray-700 flex flex-col">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
              <TabsList className="grid w-full grid-cols-4 m-4">
                <TabsTrigger value="music" className="flex items-center space-x-2">
                  <Music className="h-4 w-4" />
                  <span>Musik</span>
                </TabsTrigger>
                <TabsTrigger value="sfx" className="flex items-center space-x-2">
                  <Zap className="h-4 w-4" />
                  <span>SFX</span>
                </TabsTrigger>
                <TabsTrigger value="voice" className="flex items-center space-x-2">
                  <Mic className="h-4 w-4" />
                  <span>Voice</span>
                </TabsTrigger>
                <TabsTrigger value="upload" className="flex items-center space-x-2">
                  <Upload className="h-4 w-4" />
                  <span>Upload</span>
                </TabsTrigger>
              </TabsList>

              <div className="flex-1 overflow-auto px-4 pb-4">
                <TabsContent value="music" className="mt-0">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold">Library Musik</h3>
                      <Badge variant="secondary">{MUSIC_LIBRARY.length} tracks</Badge>
                    </div>
                    {MUSIC_LIBRARY.map((music) => (
                      <Card key={music.id} className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <h4 className="font-medium">{music.name}</h4>
                              <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                                <Badge variant="outline" className="text-xs">{music.genre}</Badge>
                                <span>{formatTime(music.duration)}</span>
                              </div>
                            </div>
                            <Button 
                              onClick={() => addLibraryMusic(music)}
                              size="sm"
                              className="ml-2"
                            >
                              <Play className="h-4 w-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="sfx" className="mt-0">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold">Sound Effects</h3>
                      <Badge variant="secondary">{SOUND_FX_LIBRARY.length} sounds</Badge>
                    </div>
                    {SOUND_FX_LIBRARY.map((sfx) => (
                      <Card key={sfx.id} className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <h4 className="font-medium">{sfx.name}</h4>
                              <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                                <Badge variant="outline" className="text-xs">{sfx.category}</Badge>
                                <span>{formatTime(sfx.duration)}</span>
                              </div>
                            </div>
                            <Button 
                              onClick={() => addSoundFX(sfx)}
                              size="sm"
                              className="ml-2"
                            >
                              <Play className="h-4 w-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="voice" className="mt-0">
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <Mic className="h-5 w-5" />
                          <span>Voice Recording</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="flex items-center justify-center space-x-4">
                          {!isRecording ? (
                            <Button onClick={startRecording} className="bg-red-500 hover:bg-red-600">
                              <Mic className="h-4 w-4 mr-2" />
                              Start Recording
                            </Button>
                          ) : (
                            <Button onClick={stopRecording} variant="outline">
                              <Square className="h-4 w-4 mr-2" />
                              Stop ({formatTime(recordingTime)})
                            </Button>
                          )}
                        </div>
                        
                        <Separator />
                        
                        <div>
                          <Label className="text-sm font-medium">Voice Effects</Label>
                          <div className="grid grid-cols-2 gap-2 mt-2">
                            {VOICE_EFFECTS.map((effect) => (
                              <Button
                                key={effect.id}
                                variant={selectedVoiceEffect === effect.id ? "default" : "outline"}
                                size="sm"
                                onClick={() => setSelectedVoiceEffect(effect.id)}
                                className="justify-start"
                              >
                                <span className="mr-2">{effect.icon}</span>
                                {effect.name}
                              </Button>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="upload" className="mt-0">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Upload className="h-5 w-5" />
                        <span>Upload Audio File</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div 
                        className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center cursor-pointer hover:border-blue-400 transition-colors"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        <FileAudio className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                        <p className="text-lg font-medium mb-2">Drop your audio file here</p>
                        <p className="text-gray-600 dark:text-gray-400 mb-4">
                          Support: MP3, WAV, AAC, M4A
                        </p>
                        <Button>
                          <Upload className="h-4 w-4 mr-2" />
                          Browse Files
                        </Button>
                      </div>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="audio/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </CardContent>
                  </Card>
                </TabsContent>
              </div>
            </Tabs>
          </div>

          {/* Right Panel - Audio Timeline */}
          <div className="w-1/2 flex flex-col">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Audio Timeline</h3>
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="outline">
                    <SkipBack className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant={isPlaying ? "default" : "outline"}>
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                  <Button size="sm" variant="outline">
                    <SkipForward className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline">
                    <Square className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-4">
                  <Label className="text-sm font-medium">Master Volume</Label>
                  <div className="flex-1">
                    <Slider
                      value={masterVolume}
                      onValueChange={setMasterVolume}
                      max={100}
                      step={1}
                      className="w-full"
                    />
                  </div>
                  <span className="text-sm text-gray-600 dark:text-gray-400 min-w-[3rem]">
                    {masterVolume[0]}%
                  </span>
                </div>

                <div className="flex items-center space-x-4">
                  <Label className="text-sm font-medium">Auto Beat Match</Label>
                  <Button
                    size="sm"
                    variant={autoBeatMatch ? "default" : "outline"}
                    onClick={() => setAutoBeatMatch(!autoBeatMatch)}
                  >
                    <Shuffle className="h-4 w-4 mr-2" />
                    {autoBeatMatch ? 'ON' : 'OFF'}
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-auto p-4">
              <div className="space-y-3">
                {audioTracks.length === 0 ? (
                  <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                    <Waves className="h-12 w-12 mx-auto mb-4" />
                    <p>Belum ada audio track</p>
                    <p className="text-sm">Tambahkan musik atau efek suara dari library</p>
                  </div>
                ) : (
                  audioTracks.map((track) => (
                    <Card key={track.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded">
                              {track.type === 'music' && <Music className="h-4 w-4 text-blue-600" />}
                              {track.type === 'sfx' && <Zap className="h-4 w-4 text-green-600" />}
                              {track.type === 'voiceover' && <Mic className="h-4 w-4 text-purple-600" />}
                              {track.type === 'ambient' && <Radio className="h-4 w-4 text-orange-600" />}
                            </div>
                            <div>
                              <h4 className="font-medium">{track.name}</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {formatTime(track.duration)} • {track.type}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button size="sm" variant="outline">
                              <Play className="h-3 w-3" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Settings className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Volume2 className="h-4 w-4" />
                            <Slider
                              value={[track.volume]}
                              onValueChange={(value) => {
                                setAudioTracks(prev => prev.map(t => 
                                  t.id === track.id ? { ...t, volume: value[0] } : t
                                ));
                              }}
                              max={100}
                              step={1}
                              className="flex-1"
                            />
                            <span className="text-sm text-gray-600 dark:text-gray-400 min-w-[3rem]">
                              {track.volume}%
                            </span>
                          </div>
                          
                          {track.effects.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {track.effects.map((effect, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {effect}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>

            <div className="p-4 border-t border-gray-200 dark:border-gray-700">
              <div className="flex space-x-2">
                <Button className="flex-1">
                  <Download className="h-4 w-4 mr-2" />
                  Export Audio
                </Button>
                <Button variant="outline">
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Reset
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}