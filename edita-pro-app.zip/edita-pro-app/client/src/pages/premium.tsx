import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Crown,
  Check,
  Star,
  Zap,
  Shield,
  Infinity,
  Video,
  Users,
  Cloud,
  Sparkles,
  Gift,
  ArrowRight,
  CreditCard,
  Calendar
} from 'lucide-react';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

// Initialize Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY!);

interface PricingPlan {
  id: string;
  name: string;
  price: number;
  period: 'month' | 'year';
  stripePriceId: string;
  features: string[];
  popular: boolean;
  savings?: number;
}

interface PaymentFormProps {
  selectedPlan: PricingPlan;
  onSuccess: () => void;
}

function PaymentForm({ selectedPlan, onSuccess }: PaymentFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const { toast } = useToast();

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setLoading(true);

    try {
      // Create subscription
      const response = await apiRequest('POST', '/api/create-subscription', {
        priceId: selectedPlan.stripePriceId,
        userId: 1, // Mock user ID - in real app, get from auth context
        email: email
      });

      const { clientSecret } = await response.json();

      // Confirm payment
      const { error } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement)!,
          billing_details: {
            email: email,
          },
        }
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Subscription Activated!",
          description: `Welcome to Edita Pro ${selectedPlan.name}!`,
        });
        onSuccess();
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    }

    setLoading(false);
  };

  return (
    <Card className="bg-slate-800/50 border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <CreditCard className="h-5 w-5 text-purple-400" />
          Complete Your Subscription
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg border border-purple-500/30">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-white">{selectedPlan.name}</h3>
              <p className="text-gray-300">${selectedPlan.price}/{selectedPlan.period}</p>
            </div>
            <Crown className="h-8 w-8 text-yellow-400" />
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm text-gray-300 mb-2 block">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
              placeholder="your@email.com"
            />
          </div>

          <div>
            <label className="text-sm text-gray-300 mb-2 block">Payment Information</label>
            <div className="p-3 bg-slate-700 border border-slate-600 rounded">
              <CardElement
                options={{
                  style: {
                    base: {
                      fontSize: '16px',
                      color: '#ffffff',
                      '::placeholder': {
                        color: '#9ca3af',
                      },
                    },
                  },
                }}
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={!stripe || loading}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 h-12"
          >
            {loading ? (
              <div className="flex items-center gap-2">
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                Processing...
              </div>
            ) : (
              <>
                Subscribe to {selectedPlan.name} - ${selectedPlan.price}/{selectedPlan.period}
              </>
            )}
          </Button>
        </form>

        <div className="text-center text-sm text-gray-400">
          <p>Secure payment powered by Stripe</p>
          <p>Cancel anytime • 30-day money-back guarantee</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default function PremiumPage() {
  const [selectedPlan, setSelectedPlan] = useState<PricingPlan | null>(null);
  const [showPayment, setShowPayment] = useState(false);
  const { toast } = useToast();

  const pricingPlans: PricingPlan[] = [
    {
      id: 'free',
      name: 'Free',
      price: 0,
      period: 'month',
      stripePriceId: '',
      features: [
        'Up to 3 projects',
        '1080p export quality',
        'Basic filters',
        'Limited cloud storage (1GB)',
        'Community support'
      ],
      popular: false
    },
    {
      id: 'premium',
      name: 'Premium',
      price: 19,
      period: 'month',
      stripePriceId: 'price_premium_monthly', // Replace with your actual Stripe price ID
      features: [
        'Unlimited projects',
        '4K export quality',
        'Advanced AI filters',
        'Unlimited cloud storage',
        'Real-time collaboration',
        'Priority support',
        'Live camera editor',
        'Stock media library access'
      ],
      popular: true
    },
    {
      id: 'premium-yearly',
      name: 'Premium Yearly',
      price: 190,
      period: 'year',
      stripePriceId: 'price_premium_yearly', // Replace with your actual Stripe price ID
      features: [
        'Unlimited projects',
        '4K export quality',
        'Advanced AI filters',
        'Unlimited cloud storage',
        'Real-time collaboration',
        'Priority support',
        'Live camera editor',
        'Stock media library access',
        '2 months free!'
      ],
      popular: false,
      savings: 38
    }
  ];

  const handlePlanSelect = (plan: PricingPlan) => {
    if (plan.price === 0) {
      toast({
        title: "Free Plan Active",
        description: "You're already using the free plan!",
      });
      return;
    }
    
    setSelectedPlan(plan);
    setShowPayment(true);
  };

  const handlePaymentSuccess = () => {
    setShowPayment(false);
    setSelectedPlan(null);
    // Redirect to editor or show success page
  };

  if (showPayment && selectedPlan) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
        <div className="max-w-2xl mx-auto pt-20">
          <div className="mb-8 text-center">
            <Button
              onClick={() => setShowPayment(false)}
              variant="outline"
              className="mb-4 border-gray-500 text-gray-300"
            >
              ← Back to Plans
            </Button>
            <h1 className="text-3xl font-bold text-white mb-2">Complete Your Subscription</h1>
            <p className="text-gray-300">Join thousands of creators using Edita Pro Premium</p>
          </div>

          <Elements stripe={stripePromise}>
            <PaymentForm selectedPlan={selectedPlan} onSuccess={handlePaymentSuccess} />
          </Elements>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Hero Section */}
      <div className="relative pt-20 pb-16">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <div className="mb-8">
            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 mb-4">
              <Crown className="h-4 w-4 mr-2" />
              Upgrade to Premium
            </Badge>
            <h1 className="text-5xl font-bold text-white mb-4">
              Unlock the Full Power of
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent"> Edita Pro</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Create professional-quality content with unlimited projects, 4K exports, AI-powered tools, and exclusive premium features.
            </p>
          </div>

          {/* Feature Highlights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
            <Card className="bg-slate-800/50 border-purple-500/30">
              <CardContent className="p-6 text-center">
                <Video className="h-12 w-12 text-purple-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">4K Export Quality</h3>
                <p className="text-gray-300">Export your videos in stunning 4K resolution for professional results</p>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-800/50 border-pink-500/30">
              <CardContent className="p-6 text-center">
                <Sparkles className="h-12 w-12 text-pink-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">AI-Powered Tools</h3>
                <p className="text-gray-300">Advanced AI filters, auto-editing, and smart templates</p>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-800/50 border-blue-500/30">
              <CardContent className="p-6 text-center">
                <Users className="h-12 w-12 text-blue-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Real-time Collaboration</h3>
                <p className="text-gray-300">Work together with your team in real-time, like Google Docs</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Pricing Plans */}
      <div className="max-w-6xl mx-auto px-4 pb-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-4">Choose Your Plan</h2>
          <p className="text-gray-300">Start free, upgrade anytime. Cancel whenever you want.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricingPlans.map((plan) => (
            <Card 
              key={plan.id} 
              className={`relative ${
                plan.popular 
                  ? 'bg-gradient-to-b from-purple-900/50 to-pink-900/50 border-purple-500 scale-105' 
                  : 'bg-slate-800/50 border-slate-600'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
                    <Star className="h-3 w-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center">
                <CardTitle className="text-white flex items-center justify-center gap-2">
                  {plan.price === 0 ? <Shield className="h-5 w-5" /> : <Crown className="h-5 w-5 text-yellow-400" />}
                  {plan.name}
                </CardTitle>
                <div className="space-y-2">
                  <div className="text-3xl font-bold text-white">
                    ${plan.price}
                    <span className="text-lg text-gray-400">/{plan.period}</span>
                  </div>
                  {plan.savings && (
                    <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                      <Gift className="h-3 w-3 mr-1" />
                      Save ${plan.savings}!
                    </Badge>
                  )}
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                <div className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <Check className="h-4 w-4 text-green-400 flex-shrink-0" />
                      <span className="text-gray-300">{feature}</span>
                    </div>
                  ))}
                </div>

                <Button
                  onClick={() => handlePlanSelect(plan)}
                  className={`w-full h-12 ${
                    plan.popular
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600'
                      : plan.price === 0
                      ? 'bg-gray-600 hover:bg-gray-700'
                      : 'bg-slate-600 hover:bg-slate-700'
                  }`}
                  disabled={plan.price === 0}
                >
                  {plan.price === 0 ? (
                    'Current Plan'
                  ) : (
                    <>
                      Get Started
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Money-back guarantee */}
        <div className="text-center mt-12">
          <Card className="bg-slate-800/30 border-green-500/30 inline-block">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 text-green-400">
                <Shield className="h-6 w-6" />
                <span className="font-semibold">30-Day Money-Back Guarantee</span>
              </div>
              <p className="text-gray-300 mt-2">Not satisfied? Get a full refund, no questions asked.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}