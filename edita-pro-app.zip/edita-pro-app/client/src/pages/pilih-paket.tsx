import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Crown,
  Check,
  Star,
  Zap,
  Shield,
  Infinity,
  Video,
  Users,
  Cloud,
  Sparkles,
  Gift,
  ArrowRight,
  CreditCard,
  Calendar,
  Camera,
  Music,
  Palette,
  Download,
  Timer,
  Headphones
} from 'lucide-react';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface StripeCheckoutButtonProps {
  paket: PaketPremium;
  disabled?: boolean;
}

function StripeCheckoutButton({ paket, disabled }: StripeCheckoutButtonProps) {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const formatRupiah = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const handleUpgradeNow = async () => {
    if (paket.price === 0) {
      toast({
        title: "Paket Free Aktif",
        description: "Anda sudah menggunakan paket gratis!",
      });
      return;
    }

    setLoading(true);

    try {
      const stripe = await stripePromise;
      if (!stripe) {
        throw new Error('Stripe tidak tersedia');
      }

      // Create checkout session
      const response = await apiRequest('POST', '/api/create-checkout-session', {
        priceId: paket.stripePriceId,
        successUrl: `${window.location.origin}/dashboard?upgrade=success&plan=${paket.id}`,
        cancelUrl: `${window.location.origin}/pilih-paket?upgrade=cancelled`,
        userId: 1, // Mock user ID - in real app, get from auth context
        metadata: {
          plan: paket.id,
          planName: paket.name,
          source: 'pricing_page'
        }
      });

      const { sessionId } = await response.json();

      // Redirect to Stripe Checkout
      const { error } = await stripe.redirectToCheckout({
        sessionId: sessionId,
      });

      if (error) {
        throw new Error(error.message);
      }
    } catch (error: any) {
      console.error('Upgrade error:', error);
      toast({
        title: "Terjadi Kesalahan",
        description: error.message || "Silakan coba lagi dalam beberapa saat",
        variant: "destructive",
      });
      setLoading(false);
    }
  };

  if (disabled || paket.price === 0) {
    return (
      <Button
        disabled
        className="w-full h-12 bg-gray-600 hover:bg-gray-700 cursor-not-allowed"
      >
        Paket Saat Ini
      </Button>
    );
  }

  return (
    <div className="space-y-3">
      <Button
        onClick={handleUpgradeNow}
        disabled={loading}
        className={`w-full h-12 font-semibold transition-all duration-300 transform hover:scale-105 ${
          paket.popular
            ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600'
            : 'bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600'
        }`}
      >
        {loading ? (
          <div className="flex items-center gap-2">
            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
            Memproses...
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Crown className="h-4 w-4" />
            <span>Upgrade Sekarang</span>
            <ArrowRight className="h-4 w-4" />
          </div>
        )}
      </Button>
      
      <div className="text-center text-xs text-gray-400">
        <p>Pembayaran aman dengan Stripe</p>
        <p>Batal kapan saja • Garansi 30 hari</p>
      </div>
    </div>
  );
}

// Initialize Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY!);

interface PaketPremium {
  id: string;
  name: string;
  price: number;
  period: 'month' | 'year';
  stripePriceId: string;
  features: string[];
  popular: boolean;
  savings?: number;
  color: string;
}

interface FormPembayaranProps {
  selectedPaket: PaketPremium;
  onSuccess: () => void;
}

function FormPembayaran({ selectedPaket, onSuccess }: FormPembayaranProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const { toast } = useToast();

  const formatRupiah = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setLoading(true);

    try {
      // Create subscription
      const response = await apiRequest('POST', '/api/create-subscription', {
        priceId: selectedPaket.stripePriceId,
        userId: 1, // Mock user ID - in real app, get from auth context
        email: email
      });

      const { clientSecret } = await response.json();

      // Confirm payment
      const { error } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement)!,
          billing_details: {
            email: email,
          },
        }
      });

      if (error) {
        toast({
          title: "Pembayaran Gagal",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Langganan Berhasil Diaktifkan!",
          description: `Selamat datang di Edita Pro ${selectedPaket.name}!`,
        });
        onSuccess();
      }
    } catch (error: any) {
      toast({
        title: "Terjadi Kesalahan",
        description: error.message || "Silakan coba lagi",
        variant: "destructive",
      });
    }

    setLoading(false);
  };

  return (
    <Card className="bg-slate-800/50 border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <CreditCard className="h-5 w-5 text-purple-400" />
          Selesaikan Langganan Anda
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg border border-purple-500/30">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-white">{selectedPaket.name}</h3>
              <p className="text-gray-300">{formatRupiah(selectedPaket.price)}/{selectedPaket.period === 'month' ? 'bulan' : 'tahun'}</p>
              {selectedPaket.savings && (
                <p className="text-green-400 text-sm">Hemat {formatRupiah(selectedPaket.savings)}!</p>
              )}
            </div>
            <Crown className="h-8 w-8 text-yellow-400" />
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm text-gray-300 mb-2 block">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded text-white"
              placeholder="email@anda.com"
            />
          </div>

          <div>
            <label className="text-sm text-gray-300 mb-2 block">Informasi Pembayaran</label>
            <div className="p-3 bg-slate-700 border border-slate-600 rounded">
              <CardElement
                options={{
                  style: {
                    base: {
                      fontSize: '16px',
                      color: '#ffffff',
                      '::placeholder': {
                        color: '#9ca3af',
                      },
                    },
                  },
                }}
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={!stripe || loading}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 h-12"
          >
            {loading ? (
              <div className="flex items-center gap-2">
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                Memproses...
              </div>
            ) : (
              <>
                Berlangganan {selectedPaket.name} - {formatRupiah(selectedPaket.price)}
              </>
            )}
          </Button>
        </form>

        <div className="text-center text-sm text-gray-400">
          <p>Pembayaran aman dengan teknologi Stripe</p>
          <p>Batal kapan saja • Garansi uang kembali 30 hari</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default function PilihPaketPage() {
  const [selectedPaket, setSelectedPaket] = useState<PaketPremium | null>(null);
  const [showPayment, setShowPayment] = useState(false);
  const { toast } = useToast();

  const formatRupiah = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const paketPremium: PaketPremium[] = [
    {
      id: 'free',
      name: 'Free',
      price: 0,
      period: 'month',
      stripePriceId: '',
      features: [
        'Proyek tidak terbatas',
        'Export kualitas 4K Ultra HD & 8K GRATIS',
        '🎁 TRIAL GRATIS: Akses SEMUA fitur premium 7 hari',
        'Filter dasar (5 filter standar)',
        'Cloud storage 2GB',
        'Template dasar (5 template standar)',
        'Live camera editor dasar',
        'Stock media library terbatas',
        'Dukungan komunitas'
      ],
      popular: false,
      color: 'from-gray-500 to-gray-600'
    },
    {
      id: 'premium-monthly',
      name: 'Premium Bulanan',
      price: 304000,
      period: 'month',
      stripePriceId: 'price_premium_monthly',
      features: [
        'SEMUA fitur Free Plan +',
        'Filter premium (50+ filter eksklusif)',
        'Template premium (viral, cinematic, trending)',
        'AI Beauty filters canggih',
        'Cinematic color grading filters',
        'Vintage & retro filter collection',
        'Platform mood optimization (TikTok, IG, YouTube)',
        'Cloud storage 50GB',
        'Custom filter presets unlimited',
        'Template creator tools advanced',
        'Advanced filter layering',
        'Real-time collaboration',
        'Priority rendering & export',
        'Dukungan prioritas 24/7'
      ],
      popular: true,
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 'premium-yearly',
      name: 'Premium Tahunan',
      price: 3040000,
      period: 'year',
      stripePriceId: 'price_premium_yearly',
      features: [
        'SEMUA fitur Premium Bulanan',
        'Filter premium (50+ filter eksklusif)',
        'Template premium (viral, cinematic, trending)',
        'AI Beauty filters canggih',
        'Cinematic color grading filters',
        'Vintage & retro filter collection',
        'Platform mood optimization (TikTok, IG, YouTube)',
        'Cloud storage 100GB',
        'Custom filter presets unlimited',
        'Template creator tools advanced',
        'Advanced filter layering',
        'Real-time collaboration',
        'Priority rendering & export',
        'Dukungan prioritas 24/7',
        '🎉 HEMAT Rp608.000/tahun!',
        '🎁 Bonus filter & template pack eksklusif setiap bulan'
      ],
      popular: false,
      savings: 608000,
      color: 'from-yellow-500 to-orange-500'
    }
  ];

  const handlePaketSelect = (paket: PaketPremium) => {
    if (paket.price === 0) {
      toast({
        title: "Paket Free Aktif",
        description: "Anda sudah menggunakan paket gratis!",
      });
      return;
    }
    
    setSelectedPaket(paket);
    setShowPayment(true);
  };

  const handlePaymentSuccess = () => {
    setShowPayment(false);
    setSelectedPaket(null);
    // Redirect to editor or show success page
  };

  if (showPayment && selectedPaket) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
        <div className="max-w-2xl mx-auto pt-20">
          <div className="mb-8 text-center">
            <Button
              onClick={() => setShowPayment(false)}
              variant="outline"
              className="mb-4 border-gray-500 text-gray-300"
            >
              ← Kembali ke Paket
            </Button>
            <h1 className="text-3xl font-bold text-white mb-2">Selesaikan Langganan</h1>
            <p className="text-gray-300">Bergabung dengan ribuan creator yang menggunakan Edita Pro Premium</p>
          </div>

          <Elements stripe={stripePromise}>
            <FormPembayaran selectedPaket={selectedPaket} onSuccess={handlePaymentSuccess} />
          </Elements>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Hero Section */}
      <div className="relative pt-20 pb-16">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <div className="mb-8">
            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 mb-4">
              <Crown className="h-4 w-4 mr-2" />
              Pilih Paket Premium
            </Badge>
            <h1 className="text-5xl font-bold text-white mb-4">
              Unlock Filter Premium
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent"> Edita Pro</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Buat konten viral dengan 50+ filter premium eksklusif! Export 4K gratis untuk semua user, upgrade hanya untuk koleksi filter terbaik.
            </p>
          </div>

          {/* Feature Highlights */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
            <Card className="bg-slate-800/50 border-purple-500/30">
              <CardContent className="p-6 text-center">
                <Sparkles className="h-12 w-12 text-purple-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">50+ Filter Premium</h3>
                <p className="text-gray-300">Koleksi filter eksklusif untuk konten viral</p>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-800/50 border-pink-500/30">
              <CardContent className="p-6 text-center">
                <Palette className="h-12 w-12 text-pink-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">AI Beauty Filters</h3>
                <p className="text-gray-300">Filter cantik otomatis dengan teknologi AI</p>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-800/50 border-blue-500/30">
              <CardContent className="p-6 text-center">
                <Video className="h-12 w-12 text-blue-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Export 4K GRATIS</h3>
                <p className="text-gray-300">Kualitas 4K untuk semua user tanpa biaya</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-green-500/30">
              <CardContent className="p-6 text-center">
                <Timer className="h-12 w-12 text-green-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Platform Optimization</h3>
                <p className="text-gray-300">Filter otomatis untuk TikTok, IG, YouTube</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Pricing Plans */}
      <div className="max-w-6xl mx-auto px-4 pb-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-4">Pilih Paket Yang Tepat</h2>
          <p className="text-gray-300">Mulai gratis, upgrade kapan saja. Batal kapan pun Anda mau.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {paketPremium.map((paket) => (
            <Card 
              key={paket.id} 
              className={`relative ${
                paket.popular 
                  ? 'bg-gradient-to-b from-purple-900/50 to-pink-900/50 border-purple-500 scale-105' 
                  : 'bg-slate-800/50 border-slate-600'
              }`}
            >
              {paket.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
                    <Star className="h-3 w-3 mr-1" />
                    Paling Populer
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center">
                <CardTitle className="text-white flex items-center justify-center gap-2">
                  {paket.price === 0 ? (
                    <Shield className="h-5 w-5 text-gray-400" />
                  ) : (
                    <Crown className="h-5 w-5 text-yellow-400" />
                  )}
                  {paket.name}
                </CardTitle>
                <div className="space-y-2">
                  <div className="text-3xl font-bold text-white">
                    {paket.price === 0 ? 'Gratis' : formatRupiah(paket.price)}
                    {paket.price > 0 && (
                      <span className="text-lg text-gray-400">/{paket.period === 'month' ? 'bulan' : 'tahun'}</span>
                    )}
                  </div>
                  {paket.savings && (
                    <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                      <Gift className="h-3 w-3 mr-1" />
                      Hemat {formatRupiah(paket.savings)}!
                    </Badge>
                  )}
                  {paket.period === 'year' && !paket.savings && (
                    <p className="text-sm text-gray-400">
                      Setara {formatRupiah(Math.round(paket.price / 12))}/bulan
                    </p>
                  )}
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                <div className="space-y-3">
                  {paket.features.map((feature, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <Check className="h-4 w-4 text-green-400 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-300 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                <StripeCheckoutButton 
                  paket={paket}
                  disabled={paket.price === 0}
                />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Comparison Table */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold text-white text-center mb-8">Perbandingan Fitur Lengkap</h3>
          <Card className="bg-slate-800/50 border-purple-500/30">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-600">
                      <th className="text-left p-4 text-gray-300">Fitur</th>
                      <th className="text-center p-4 text-gray-300">Free</th>
                      <th className="text-center p-4 text-purple-300">Premium</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm">
                    <tr className="border-b border-slate-700">
                      <td className="p-4 text-gray-300">Kualitas Export</td>
                      <td className="p-4 text-center text-green-400">4K Ultra HD & 8K GRATIS</td>
                      <td className="p-4 text-center text-green-400">4K Ultra HD & 8K GRATIS</td>
                    </tr>
                    <tr className="border-b border-slate-700">
                      <td className="p-4 text-gray-300">Jumlah Proyek</td>
                      <td className="p-4 text-center text-green-400">Unlimited</td>
                      <td className="p-4 text-center text-green-400">Unlimited</td>
                    </tr>
                    <tr className="border-b border-slate-700">
                      <td className="p-4 text-gray-300">Filter Tersedia</td>
                      <td className="p-4 text-center text-yellow-400">5 Dasar + Trial 7 Hari</td>
                      <td className="p-4 text-center text-green-400">50+ Filter Premium Permanent</td>
                    </tr>
                    <tr className="border-b border-slate-700">
                      <td className="p-4 text-gray-300">AI Beauty Filters</td>
                      <td className="p-4 text-center text-red-400">✗</td>
                      <td className="p-4 text-center text-green-400">✓ Advanced AI</td>
                    </tr>
                    <tr className="border-b border-slate-700">
                      <td className="p-4 text-gray-300">Cinematic Filters</td>
                      <td className="p-4 text-center text-red-400">✗</td>
                      <td className="p-4 text-center text-green-400">✓ Color Grading</td>
                    </tr>
                    <tr className="border-b border-slate-700">
                      <td className="p-4 text-gray-300">Platform Optimization</td>
                      <td className="p-4 text-center text-red-400">✗</td>
                      <td className="p-4 text-center text-green-400">✓ TikTok, IG, YouTube</td>
                    </tr>
                    <tr className="border-b border-slate-700">
                      <td className="p-4 text-gray-300">Template Tersedia</td>
                      <td className="p-4 text-center text-yellow-400">5 Dasar + Trial 7 Hari</td>
                      <td className="p-4 text-center text-green-400">50+ Template Premium Permanent</td>
                    </tr>
                    <tr className="border-b border-slate-700">
                      <td className="p-4 text-gray-300">Template Creator Tools</td>
                      <td className="p-4 text-center text-red-400">✗</td>
                      <td className="p-4 text-center text-green-400">✓ Advanced Tools</td>
                    </tr>
                    <tr className="border-b border-slate-700">
                      <td className="p-4 text-gray-300">Custom Filter Presets</td>
                      <td className="p-4 text-center text-red-400">✗</td>
                      <td className="p-4 text-center text-green-400">✓ Unlimited</td>
                    </tr>
                    <tr>
                      <td className="p-4 text-gray-300">Customer Support</td>
                      <td className="p-4 text-center text-gray-400">Komunitas</td>
                      <td className="p-4 text-center text-green-400">Priority 24/7</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Guarantee */}
        <div className="text-center mt-12">
          <Card className="bg-slate-800/30 border-green-500/30 inline-block">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 text-green-400 justify-center">
                <Shield className="h-6 w-6" />
                <span className="font-semibold">Garansi Uang Kembali 30 Hari</span>
              </div>
              <p className="text-gray-300 mt-2">Tidak puas? Dapatkan refund penuh tanpa pertanyaan.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}