import React, { useState } from 'react';
import { AppNavigation } from '@/components/navigation/app-navigation';
import { FloatingActionButton, MobileFAB } from '@/components/ui/floating-action-button';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  Filter, 
  MoreVertical,
  FileText,
  Video,
  Music,
  Clock,
  Calendar,
  Trash2,
  Edit,
  Share,
  Download
} from 'lucide-react';
import { useLocation } from 'wouter';

interface Draft {
  id: string;
  title: string;
  type: 'document' | 'video' | 'audio';
  lastModified: Date;
  createdAt: Date;
  content: string;
  thumbnail?: string;
  size: string;
  status: 'draft' | 'in-progress' | 'completed';
}

export default function DraftsPage() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'document' | 'video' | 'audio'>('all');

  // Sample drafts data
  const drafts: Draft[] = [
    {
      id: '1',
      title: 'Presentasi Quarterly Report Q4',
      type: 'document',
      lastModified: new Date('2024-01-27T10:30:00'),
      createdAt: new Date('2024-01-25T09:00:00'),
      content: 'Draft presentasi untuk laporan quarterly...',
      size: '2.3 MB',
      status: 'in-progress'
    },
    {
      id: '2',
      title: 'Video Tutorial Edita Pro',
      type: 'video',
      lastModified: new Date('2024-01-27T14:15:00'),
      createdAt: new Date('2024-01-26T16:20:00'),
      content: 'Tutorial penggunaan fitur canvas...',
      size: '45.2 MB',
      status: 'draft'
    },
    {
      id: '3',
      title: 'Podcast Intro Music',
      type: 'audio',
      lastModified: new Date('2024-01-27T11:45:00'),
      createdAt: new Date('2024-01-27T08:30:00'),
      content: 'Musik intro untuk podcast mingguan...',
      size: '8.7 MB',
      status: 'completed'
    },
    {
      id: '4',
      title: 'Proposal Kerjasama Brand',
      type: 'document',
      lastModified: new Date('2024-01-26T16:20:00'),
      createdAt: new Date('2024-01-24T13:15:00'),
      content: 'Draft proposal untuk kerjasama...',
      size: '1.8 MB',
      status: 'draft'
    },
    {
      id: '5',
      title: 'Social Media Content Plan',
      type: 'video',
      lastModified: new Date('2024-01-25T12:00:00'),
      createdAt: new Date('2024-01-23T10:30:00'),
      content: 'Konten video untuk media sosial...',
      size: '28.9 MB',
      status: 'in-progress'
    }
  ];

  const getTypeIcon = (type: Draft['type']) => {
    switch (type) {
      case 'document':
        return <FileText className="h-4 w-4" />;
      case 'video':
        return <Video className="h-4 w-4" />;
      case 'audio':
        return <Music className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: Draft['status']) => {
    switch (status) {
      case 'draft':
        return 'bg-gray-500';
      case 'in-progress':
        return 'bg-yellow-500';
      case 'completed':
        return 'bg-green-500';
    }
  };

  const getStatusText = (status: Draft['status']) => {
    switch (status) {
      case 'draft':
        return 'Draft';
      case 'in-progress':
        return 'Sedang Dikerjakan';
      case 'completed':
        return 'Selesai';
    }
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return 'Baru saja';
    } else if (diffInHours < 24) {
      return `${diffInHours} jam yang lalu`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays} hari yang lalu`;
    }
  };

  const filteredDrafts = drafts.filter(draft => {
    const matchesSearch = draft.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || draft.type === filterType;
    return matchesSearch && matchesType;
  });

  const handleEditDraft = (draft: Draft) => {
    setLocation(`/editor?draft=${draft.id}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <AppNavigation currentPage="drafts" />
      
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        
        {/* Header */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white">Draft Saya</h1>
              <p className="text-gray-400">Kelola dan lanjutkan project yang sedang dikerjakan</p>
            </div>
            
            <Button
              onClick={() => setLocation('/editor')}
              className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
            >
              <Edit className="h-4 w-4 mr-2" />
              Buat Project Baru
            </Button>
          </div>

          {/* Search & Filter */}
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Cari draft..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-black/20 border-purple-500/30 text-white placeholder-gray-400"
              />
            </div>
            
            <div className="flex items-center gap-2">
              {['all', 'document', 'video', 'audio'].map((type) => (
                <Button
                  key={type}
                  onClick={() => setFilterType(type as any)}
                  variant={filterType === type ? "default" : "outline"}
                  size="sm"
                  className={filterType === type 
                    ? "bg-purple-500 hover:bg-purple-600" 
                    : "border-purple-500/30 hover:bg-purple-500/10"
                  }
                >
                  {type === 'all' ? 'Semua' : type.charAt(0).toUpperCase() + type.slice(1)}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-black/20 border-purple-500/30">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-white">{drafts.length}</div>
              <div className="text-sm text-gray-400">Total Draft</div>
            </CardContent>
          </Card>
          
          <Card className="bg-black/20 border-purple-500/30">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-yellow-400">{drafts.filter(d => d.status === 'in-progress').length}</div>
              <div className="text-sm text-gray-400">Sedang Dikerjakan</div>
            </CardContent>
          </Card>
          
          <Card className="bg-black/20 border-purple-500/30">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-400">{drafts.filter(d => d.status === 'completed').length}</div>
              <div className="text-sm text-gray-400">Selesai</div>
            </CardContent>
          </Card>
          
          <Card className="bg-black/20 border-purple-500/30">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-gray-400">{drafts.filter(d => d.status === 'draft').length}</div>
              <div className="text-sm text-gray-400">Draft</div>
            </CardContent>
          </Card>
        </div>

        {/* Drafts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDrafts.map((draft) => (
            <Card 
              key={draft.id}
              className="bg-gradient-to-br from-slate-800/80 to-purple-900/80 border border-purple-500/30 hover:border-purple-400/60 transition-all duration-300 hover:scale-105 cursor-pointer group"
              onClick={() => handleEditDraft(draft)}
            >
              <CardContent className="p-0">
                {/* Thumbnail/Preview */}
                <div className="h-32 bg-gradient-to-br from-purple-600/20 to-blue-600/20 rounded-t-lg flex items-center justify-center">
                  <div className="text-4xl text-white/40">
                    {getTypeIcon(draft.type)}
                  </div>
                </div>

                {/* Content */}
                <div className="p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <h3 className="font-semibold text-white line-clamp-2 group-hover:text-purple-300 transition-colors">
                      {draft.title}
                    </h3>
                    <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </div>

                  <p className="text-sm text-gray-400 line-clamp-2">
                    {draft.content}
                  </p>

                  <div className="flex items-center justify-between">
                    <Badge 
                      className={`${getStatusColor(draft.status)} text-white border-0 text-xs`}
                    >
                      {getStatusText(draft.status)}
                    </Badge>
                    
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      {getTypeIcon(draft.type)}
                      <span className="capitalize">{draft.type}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {formatDate(draft.lastModified)}
                    </div>
                    <span>{draft.size}</span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 pt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEditDraft(draft);
                      }}
                      variant="outline"
                      size="sm"
                      className="flex-1 border-purple-500/30 hover:bg-purple-500/20"
                    >
                      <Edit className="h-3 w-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        console.log('Share draft:', draft.id);
                      }}
                      variant="outline"
                      size="sm"
                      className="border-purple-500/30 hover:bg-purple-500/20"
                    >
                      <Share className="h-3 w-3" />
                    </Button>
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        console.log('Download draft:', draft.id);
                      }}
                      variant="outline"
                      size="sm"
                      className="border-purple-500/30 hover:bg-purple-500/20"
                    >
                      <Download className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredDrafts.length === 0 && (
          <div className="text-center py-12">
            <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Tidak ada draft ditemukan</h3>
            <p className="text-gray-400 mb-6">
              {searchQuery ? 'Coba ubah kata kunci pencarian' : 'Mulai membuat project pertama Anda'}
            </p>
            <Button
              onClick={() => setLocation('/editor')}
              className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
            >
              <Edit className="h-4 w-4 mr-2" />
              Buat Project Baru
            </Button>
          </div>
        )}

        {/* Floating Action Buttons */}
        <FloatingActionButton onCreateNew={(type) => setLocation(`/editor?type=${type}`)} />
        <MobileFAB />
      </div>
    </div>
  );
}