import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { AppHeader } from "@/components/editor/app-header";
import { Sidebar } from "@/components/editor/sidebar";
import { DocumentTabs } from "@/components/editor/document-tabs";
import { Toolbar } from "@/components/editor/toolbar";
import { EditorArea } from "@/components/editor/editor-area";
import { StatusBar } from "@/components/editor/status-bar";
import { SearchPanel } from "@/components/editor/search-panel";
import { LoadingOverlay } from "@/components/editor/loading-overlay";
import { CameraModal } from "@/components/media/camera-modal";
import { MediaGallery } from "@/components/media/media-gallery";
import { VideoEditor } from "@/components/video/video-editor";
import { AudioEditor } from "@/components/audio/audio-editor";
import { CanvasRenderer } from "@/components/canvas/canvas-renderer";
import { AnimationEngine } from "@/components/canvas/animation-engine";
import { SpeedRampingEngine } from "@/components/video/speed-ramping-engine";
import { ChromaKeyEditor } from "@/components/video/chroma-key-editor";
import { AIBackgroundRemover } from "@/components/video/ai-background-remover";
import { MotionTracker } from "@/components/video/motion-tracker";
import { AIFaceEffects } from "@/components/video/ai-face-effects";
import { MultilayerTimeline } from "@/components/video/multilayer-timeline";
import { KeyframeEditor } from "@/components/animation/keyframe-editor";
import { MotionGraphicsEngine } from "@/components/animation/motion-graphics-engine";
import { AutoVideoGenerator } from "@/components/ai/auto-video-generator";
import { SmartTemplateEngine } from "@/components/ai/smart-template-engine";
import { VisualEffectsStudio } from "@/components/effects/visual-effects-studio";
import { AdvancedExportEngine } from "@/components/export/advanced-export-engine";
import { QuickExportProfiles } from "@/components/export/quick-export-profiles";
import { RealTimeEditor } from "@/components/collaboration/real-time-editor";
import { CloudSyncManager } from "@/components/collaboration/cloud-sync-manager";
import { PlatformIntegrations } from "@/components/integrations/platform-integrations";
import { EnhancedInterface } from "@/components/ui/enhanced-interface";
import { ActionButtons, QuickActionButtons, FloatingActionButton, AchievementBadges } from "@/components/ui/action-buttons";
import { AppNavigation } from "@/components/navigation/app-navigation";
import { useEditor } from "@/hooks/use-editor";
import { useLocation } from "wouter";
import type { Document } from "@shared/schema";

export default function EditorPage() {
  const [, setLocation] = useLocation();
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [searchVisible, setSearchVisible] = useState(false);
  const [lineNumbersVisible, setLineNumbersVisible] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [cameraModalOpen, setCameraModalOpen] = useState(false);
  const [mediaGalleryOpen, setMediaGalleryOpen] = useState(false);
  const [videoEditorOpen, setVideoEditorOpen] = useState(false);
  const [audioEditorOpen, setAudioEditorOpen] = useState(false);
  const [canvasRendererOpen, setCanvasRendererOpen] = useState(false);
  const [animationEngineOpen, setAnimationEngineOpen] = useState(false);
  const [speedRampingOpen, setSpeedRampingOpen] = useState(false);
  const [chromaKeyOpen, setChromaKeyOpen] = useState(false);
  const [aiBackgroundOpen, setAiBackgroundOpen] = useState(false);
  const [motionTrackerOpen, setMotionTrackerOpen] = useState(false);
  const [faceEffectsOpen, setFaceEffectsOpen] = useState(false);
  const [multilayerTimelineOpen, setMultilayerTimelineOpen] = useState(false);
  const [keyframeEditorOpen, setKeyframeEditorOpen] = useState(false);
  const [motionGraphicsOpen, setMotionGraphicsOpen] = useState(false);
  const [autoVideoGeneratorOpen, setAutoVideoGeneratorOpen] = useState(false);
  const [smartTemplateEngineOpen, setSmartTemplateEngineOpen] = useState(false);
  const [visualEffectsStudioOpen, setVisualEffectsStudioOpen] = useState(false);
  const [advancedExportOpen, setAdvancedExportOpen] = useState(false);
  const [quickExportOpen, setQuickExportOpen] = useState(false);
  const [realTimeEditorOpen, setRealTimeEditorOpen] = useState(false);
  const [cloudSyncOpen, setCloudSyncOpen] = useState(false);
  const [platformIntegrationsOpen, setPlatformIntegrationsOpen] = useState(false);
  const [selectedVideoUrl, setSelectedVideoUrl] = useState<string>('');
  const [capturedMedia, setCapturedMedia] = useState<Array<{
    id: string;
    url: string;
    type: 'photo' | 'video' | 'audio';
    name: string;
    createdAt: Date;
  }>>([]);

  const {
    activeDocumentId,
    openDocuments,
    setActiveDocument,
    openDocument,
    closeDocument,
    createNewDocument,
    saveDocument,
    updateDocumentContent,
    updateDocumentSettings,
  } = useEditor();

  const { data: recentDocuments = [] } = useQuery<Document[]>({
    queryKey: ["/api/documents/recent"],
  });

  const activeDocument = openDocuments.find(doc => doc.id === activeDocumentId);

  const toggleSidebar = () => setSidebarVisible(!sidebarVisible);
  const toggleSearch = () => setSearchVisible(!searchVisible);
  const toggleLineNumbers = () => setLineNumbersVisible(!lineNumbersVisible);

  const handleMediaCaptured = (mediaUrl: string, type: 'photo' | 'video') => {
    const mediaItem = {
      id: Date.now().toString(),
      url: mediaUrl,
      type,
      name: `${type === 'photo' ? 'Photo' : 'Video'} ${new Date().toLocaleTimeString()}`,
      createdAt: new Date(),
    };
    setCapturedMedia(prev => [mediaItem, ...prev]);
    setCameraModalOpen(false);
  };

  const handleInsertMedia = (mediaUrl: string, type: string) => {
    if (activeDocument) {
      const mediaElement = type === 'photo' 
        ? `\n\n![Image](${mediaUrl})\n\n`
        : type === 'video'
        ? `\n\n[Video](${mediaUrl})\n\n`
        : `\n\n[Audio](${mediaUrl})\n\n`;
      
      updateDocumentContent(activeDocument.id, activeDocument.content + mediaElement);
    }
  };

  const handleAudioAdded = (audioUrl: string, type: string) => {
    const mediaItem = {
      id: Date.now().toString(),
      url: audioUrl,
      type: 'audio' as const,
      name: `${type} ${new Date().toLocaleTimeString()}`,
      createdAt: new Date(),
    };
    setCapturedMedia(prev => [mediaItem, ...prev]);
  };

  const handleOpenVideoEditor = () => {
    // Check if there are any videos in captured media
    const videos = capturedMedia.filter(media => media.type === 'video');
    if (videos.length > 0) {
      setSelectedVideoUrl(videos[0].url);
      setVideoEditorOpen(true);
    } else {
      // If no videos, show camera to record one first
      setCameraModalOpen(true);
    }
  };

  const handleSaveEditedVideo = (editedVideoUrl: string) => {
    // Add the edited video to captured media
    const newVideo = {
      id: Date.now().toString(),
      url: editedVideoUrl,
      type: 'video' as const,
      name: `Edited Video ${Date.now()}`,
      createdAt: new Date()
    };
    setCapturedMedia(prev => [...prev, newVideo]);
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case 'f':
            e.preventDefault();
            toggleSearch();
            break;
          case 's':
            e.preventDefault();
            if (activeDocument) {
              saveDocument(activeDocument.id);
            }
            break;
          case 'n':
            e.preventDefault();
            createNewDocument();
            break;
          case 'b':
            e.preventDefault();
            toggleSidebar();
            break;
        }
      }
      
      if (e.key === 'Escape' && searchVisible) {
        setSearchVisible(false);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [activeDocument, searchVisible]);

  return (
    <div className="flex h-screen app-container">
      {/* Floating Shapes Background */}
      <div className="floating-shapes" />
      
      {/* App Header */}
      <div className="fixed top-0 left-0 right-0 z-30">
        <AppHeader 
          activeDocument={activeDocument}
          onToggleSidebar={toggleSidebar}
        />
      </div>

      <div className="flex flex-1 pt-14">
        {/* Sidebar */}
        {sidebarVisible && (
          <div className="w-64 flex-shrink-0">
            <Sidebar
              recentDocuments={recentDocuments}
              onNewDocument={createNewDocument}
              onOpenDocument={openDocument}
            />
          </div>
        )}

        {/* Main Editor Area */}
        <main className="flex-1 flex flex-col bg-white dark:bg-gray-800">
          {/* Document Tabs */}
          <DocumentTabs
            documents={openDocuments}
            activeDocumentId={activeDocumentId}
            onSelectDocument={setActiveDocument}
            onCloseDocument={closeDocument}
            onNewDocument={createNewDocument}
          />

          {/* Toolbar */}
          <Toolbar
            activeDocument={activeDocument}
            onSave={() => activeDocument && saveDocument(activeDocument.id)}
            onExportPDF={() => setIsExporting(true)}
            onToggleSearch={toggleSearch}
            onToggleLineNumbers={toggleLineNumbers}
            lineNumbersVisible={lineNumbersVisible}
            onUpdateSettings={updateDocumentSettings}
            onOpenCamera={() => setCameraModalOpen(true)}
            onOpenMediaGallery={() => setMediaGalleryOpen(true)}
            onOpenVideoEditor={handleOpenVideoEditor}
            onOpenAudioEditor={() => setAudioEditorOpen(true)}
          />

          {/* Editor Content */}
          <div className="flex-1 relative">
            <EditorArea
              document={activeDocument}
              onContentChange={updateDocumentContent}
              showLineNumbers={lineNumbersVisible}
            />

            {/* Search Panel */}
            {searchVisible && (
              <SearchPanel onClose={() => setSearchVisible(false)} />
            )}
          </div>

          {/* Action Buttons */}
          <div className="p-4 border-t border-gray-200 dark:border-gray-700">
            <ActionButtons
              onPlay={() => console.log('Play clicked')}
              onPause={() => console.log('Pause clicked')}
              onStop={() => console.log('Stop clicked')}
              onDownload={() => activeDocument && exportToPDF(activeDocument.content, activeDocument.title)}
              onShare={() => console.log('Share clicked')}
              onLike={() => console.log('Like clicked')}
              onBookmark={() => console.log('Bookmark clicked')}
              isPlaying={false}
              isLiked={false}
              isBookmarked={false}
              downloadCount={0}
              likeCount={0}
            />
          </div>

          {/* Status Bar */}
          <StatusBar document={activeDocument} />
        </main>
      </div>

      {/* Quick Actions Panel */}
      <div className="fixed bottom-4 left-4 right-4 z-40">
        <QuickActionButtons 
          onOpenCanvas={() => setCanvasRendererOpen(true)}
          onOpenAnimation={() => setAnimationEngineOpen(true)}
          onOpenSpeedRamping={() => setSpeedRampingOpen(true)}
          onOpenChromaKey={() => setChromaKeyOpen(true)}
          onOpenAIBackground={() => setAiBackgroundOpen(true)}
          onOpenMotionTracker={() => setMotionTrackerOpen(true)}
          onOpenFaceEffects={() => setFaceEffectsOpen(true)}
          onOpenMultilayerTimeline={() => setMultilayerTimelineOpen(true)}
          onOpenKeyframeEditor={() => setKeyframeEditorOpen(true)}
          onOpenMotionGraphics={() => setMotionGraphicsOpen(true)}
          onOpenAutoVideoGenerator={() => setAutoVideoGeneratorOpen(true)}
          onOpenSmartTemplateEngine={() => setSmartTemplateEngineOpen(true)}
          onOpenVisualEffectsStudio={() => setVisualEffectsStudioOpen(true)}
          onOpenAdvancedExport={() => setAdvancedExportOpen(true)}
          onOpenQuickExport={() => setQuickExportOpen(true)}
          onOpenRealTimeEditor={() => setRealTimeEditorOpen(true)}
          onOpenCloudSync={() => setCloudSyncOpen(true)}
          onOpenPlatformIntegrations={() => setPlatformIntegrationsOpen(true)}
        />
      </div>

      {/* Achievement Badges */}
      <div className="fixed top-20 right-4 z-40">
        <AchievementBadges />
      </div>

      {/* Floating Action Button */}
      <FloatingActionButton 
        onClick={() => createNewDocument()}
        variant="primary"
      />

      {/* Camera Modal */}
      <CameraModal
        open={cameraModalOpen}
        onClose={() => setCameraModalOpen(false)}
        onMediaCaptured={handleMediaCaptured}
      />

      {/* Media Gallery */}
      <MediaGallery
        open={mediaGalleryOpen}
        onClose={() => setMediaGalleryOpen(false)}
        onInsertMedia={handleInsertMedia}
        capturedMedia={capturedMedia}
      />

      {/* Video Editor */}
      <VideoEditor
        open={videoEditorOpen}
        onClose={() => setVideoEditorOpen(false)}
        videoUrl={selectedVideoUrl}
        onSaveVideo={handleSaveEditedVideo}
      />

      {/* Audio Editor */}
      <AudioEditor
        open={audioEditorOpen}
        onClose={() => setAudioEditorOpen(false)}
        onAudioAdded={handleAudioAdded}
      />

      {/* Canvas Renderer */}
      {canvasRendererOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <CanvasRenderer 
              width={1920}
              height={1080}
              onExport={(dataUrl) => {
                console.log('Canvas exported:', dataUrl);
                setCanvasRendererOpen(false);
              }}
            />
            <button
              onClick={() => setCanvasRendererOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Animation Engine */}
      {animationEngineOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <AnimationEngine 
              onAnimationUpdate={(project) => {
                console.log('Animation updated:', project);
              }}
            />
            <button
              onClick={() => setAnimationEngineOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Speed Ramping Engine */}
      {speedRampingOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <SpeedRampingEngine 
              videoDuration={60}
              onExport={(data) => {
                console.log('Speed ramping exported:', data);
                setSpeedRampingOpen(false);
              }}
            />
            <button
              onClick={() => setSpeedRampingOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Chroma Key Editor */}
      {chromaKeyOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <ChromaKeyEditor 
              onProcessed={(processedVideo) => {
                console.log('Chroma key processed:', processedVideo);
                setChromaKeyOpen(false);
              }}
              onClose={() => setChromaKeyOpen(false)}
            />
            <button
              onClick={() => setChromaKeyOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* AI Background Remover */}
      {aiBackgroundOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <AIBackgroundRemover 
              onProcessed={(processedVideo) => {
                console.log('AI background removed:', processedVideo);
                setAiBackgroundOpen(false);
              }}
              onClose={() => setAiBackgroundOpen(false)}
            />
            <button
              onClick={() => setAiBackgroundOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Motion Tracker */}
      {motionTrackerOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <MotionTracker 
              onTracked={(trackingData) => {
                console.log('Motion tracked:', trackingData);
                setMotionTrackerOpen(false);
              }}
              onClose={() => setMotionTrackerOpen(false)}
            />
            <button
              onClick={() => setMotionTrackerOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* AI Face Effects */}
      {faceEffectsOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <AIFaceEffects 
              onProcessed={(processedVideo) => {
                console.log('Face effects processed:', processedVideo);
                setFaceEffectsOpen(false);
              }}
              onClose={() => setFaceEffectsOpen(false)}
            />
            <button
              onClick={() => setFaceEffectsOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Multilayer Timeline */}
      {multilayerTimelineOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <MultilayerTimeline 
              onLayersChange={(layers) => {
                console.log('Layers updated:', layers);
              }}
              projectDuration={60}
            />
            <button
              onClick={() => setMultilayerTimelineOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Keyframe Editor */}
      {keyframeEditorOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <KeyframeEditor 
              onAnimationUpdate={(layers) => {
                console.log('Animation layers updated:', layers);
              }}
              projectDuration={10}
            />
            <button
              onClick={() => setKeyframeEditorOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Motion Graphics Engine */}
      {motionGraphicsOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <MotionGraphicsEngine 
              onAnimationUpdate={(objects) => {
                console.log('Motion graphics updated:', objects);
              }}
              canvasWidth={1920}
              canvasHeight={1080}
            />
            <button
              onClick={() => setMotionGraphicsOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Auto Video Generator */}
      {autoVideoGeneratorOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <AutoVideoGenerator 
              onVideoGenerated={(project) => {
                console.log('AI video generated:', project);
                setAutoVideoGeneratorOpen(false);
              }}
              onClose={() => setAutoVideoGeneratorOpen(false)}
            />
            <button
              onClick={() => setAutoVideoGeneratorOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Smart Template Engine */}
      {smartTemplateEngineOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <SmartTemplateEngine 
              onTemplateSelect={(template) => {
                console.log('Template selected:', template);
              }}
              onCustomize={(template, customizations) => {
                console.log('Template customized:', template, customizations);
                setSmartTemplateEngineOpen(false);
              }}
            />
            <button
              onClick={() => setSmartTemplateEngineOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Visual Effects Studio */}
      {visualEffectsStudioOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <VisualEffectsStudio 
              onEffectApply={(effects) => {
                console.log('Visual effects applied:', effects);
                setVisualEffectsStudioOpen(false);
              }}
              onClose={() => setVisualEffectsStudioOpen(false)}
            />
            <button
              onClick={() => setVisualEffectsStudioOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Advanced Export Engine */}
      {advancedExportOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative">
            <AdvancedExportEngine 
              onExport={(settings) => {
                console.log('Advanced export settings:', settings);
                setIsExporting(true);
                setAdvancedExportOpen(false);
              }}
              onClose={() => setAdvancedExportOpen(false)}
              isLoggedIn={false} // TODO: Replace with actual login status
            />
            <button
              onClick={() => setAdvancedExportOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Quick Export Profiles */}
      {quickExportOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative overflow-auto">
            <QuickExportProfiles 
              onExportStart={(profileId) => {
                console.log('Quick export started:', profileId);
                setIsExporting(true);
                setQuickExportOpen(false);
              }}
              isLoggedIn={false} // TODO: Replace with actual login status
            />
            <button
              onClick={() => setQuickExportOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Real-Time Collaboration */}
      {realTimeEditorOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative overflow-auto">
            <RealTimeEditor 
              onCollaborationStart={(collaborators) => {
                console.log('Collaboration started:', collaborators);
              }}
              onDocumentSync={(content) => {
                console.log('Document synced:', content);
              }}
            />
            <button
              onClick={() => setRealTimeEditorOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Cloud Sync Manager */}
      {cloudSyncOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-7xl h-full max-h-[95vh] relative overflow-auto">
            <CloudSyncManager 
              onSyncStart={() => {
                console.log('Manual sync started');
              }}
              onSyncComplete={() => {
                console.log('Sync completed');
              }}
              onConflictResolve={(conflicts) => {
                console.log('Conflicts resolved:', conflicts);
              }}
            />
            <button
              onClick={() => setCloudSyncOpen(false)}
              className="absolute top-6 right-6 text-white bg-red-500/80 hover:bg-red-600 rounded-full p-3 transition-all duration-200 hover:scale-110 z-10"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Loading Overlay */}
      {isExporting && (
        <LoadingOverlay 
          onComplete={() => setIsExporting(false)}
        />
      )}
    </div>
  );
}
