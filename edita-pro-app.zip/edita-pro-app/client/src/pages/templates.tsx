import React from 'react';
import { AppNavigation } from '@/components/navigation/app-navigation';
import { LobbyDashboard } from '@/components/lobby/lobby-dashboard';
import { FloatingActionButton } from '@/components/ui/floating-action-button';
import { useLocation } from 'wouter';

export default function TemplatesPage() {
  const [, setLocation] = useLocation();

  const handleCreateNew = () => {
    setLocation('/editor');
  };

  const handleSelectTemplate = (template: any) => {
    console.log('Selected template:', template);
    setLocation('/editor');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <AppNavigation currentPage="templates" />
      <div className="pt-6">
        <LobbyDashboard 
          onCreateNew={handleCreateNew}
          onSelectTemplate={handleSelectTemplate}
        />
      </div>
      
      {/* Floating Action Button */}
      <FloatingActionButton onCreateNew={(type) => setLocation(`/editor?type=${type}`)} />
    </div>
  );
}