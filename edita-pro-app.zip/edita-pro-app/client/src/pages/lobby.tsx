import React from 'react';
import { AppNavigation } from '@/components/navigation/app-navigation';
import { LobbyDashboard } from '@/components/lobby/lobby-dashboard';
import { FloatingActionButton, AdvancedFAB } from '@/components/ui/floating-action-button';
import { ProjectManager } from '@/components/projects/project-manager';
import { useLocation } from 'wouter';

export default function LobbyPage() {
  const [, setLocation] = useLocation();

  const handleCreateNew = () => {
    setLocation('/editor');
  };

  const handleSelectTemplate = (template: any) => {
    console.log('Selected template:', template);
    // Navigate to editor with template data
    setLocation('/editor');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <AppNavigation currentPage="lobby" />
      <div className="pt-6">
        <LobbyDashboard 
          onCreateNew={handleCreateNew}
          onSelectTemplate={handleSelectTemplate}
        />
        
        {/* Enhanced Project Manager */}
        <ProjectManager 
          onProjectOpen={(project) => {
            console.log('Opening project:', project);
            setLocation('/editor');
          }}
          onProjectDelete={(projectId) => {
            console.log('Deleting project:', projectId);
          }}
          onProjectEdit={(project) => {
            console.log('Editing project:', project);
            setLocation('/editor');
          }}
        />
      </div>
      
      {/* Floating Action Buttons */}
      <FloatingActionButton onCreateNew={(type) => setLocation(`/editor?type=${type}`)} />
      <AdvancedFAB />
    </div>
  );
}