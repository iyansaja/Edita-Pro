import { useState, useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Document, InsertDocument } from "@shared/schema";

export function useEditor() {
  const [openDocuments, setOpenDocuments] = useState<Document[]>([]);
  const [activeDocumentId, setActiveDocumentId] = useState<number | undefined>();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Create new document mutation
  const createDocumentMutation = useMutation({
    mutationFn: async (document: InsertDocument) => {
      const response = await apiRequest("POST", "/api/documents", document);
      return response.json();
    },
    onSuccess: (newDocument: Document) => {
      setOpenDocuments(prev => [...prev, newDocument]);
      setActiveDocumentId(newDocument.id);
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      queryClient.invalidateQueries({ queryKey: ["/api/documents/recent"] });
      toast({
        title: "Document created",
        description: `${newDocument.name} has been created successfully.`,
      });
    },
  });

  // Update document mutation
  const updateDocumentMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<InsertDocument> }) => {
      const response = await apiRequest("PATCH", `/api/documents/${id}`, updates);
      return response.json();
    },
    onSuccess: (updatedDocument: Document) => {
      setOpenDocuments(prev =>
        prev.map(doc => doc.id === updatedDocument.id ? updatedDocument : doc)
      );
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      queryClient.invalidateQueries({ queryKey: ["/api/documents/recent"] });
    },
  });

  const createNewDocument = useCallback(() => {
    const name = `Untitled Document ${openDocuments.length + 1}`;
    createDocumentMutation.mutate({
      name,
      content: "",
      fontSize: 16,
      fontFamily: "Inter",
      saved: true,
    });
  }, [openDocuments.length, createDocumentMutation]);

  const openDocument = useCallback((document: Document) => {
    const existingDoc = openDocuments.find(doc => doc.id === document.id);
    if (existingDoc) {
      setActiveDocumentId(document.id);
    } else {
      setOpenDocuments(prev => [...prev, document]);
      setActiveDocumentId(document.id);
    }
  }, [openDocuments]);

  const closeDocument = useCallback((id: number) => {
    setOpenDocuments(prev => prev.filter(doc => doc.id !== id));
    if (activeDocumentId === id) {
      const remainingDocs = openDocuments.filter(doc => doc.id !== id);
      setActiveDocumentId(remainingDocs.length > 0 ? remainingDocs[0].id : undefined);
    }
  }, [activeDocumentId, openDocuments]);

  const setActiveDocument = useCallback((id: number) => {
    setActiveDocumentId(id);
  }, []);

  const saveDocument = useCallback((id: number) => {
    const document = openDocuments.find(doc => doc.id === id);
    if (document && !document.saved) {
      updateDocumentMutation.mutate({
        id,
        updates: { saved: true },
      });
      toast({
        title: "Document saved",
        description: `${document.name} has been saved successfully.`,
      });
    }
  }, [openDocuments, updateDocumentMutation, toast]);

  const updateDocumentContent = useCallback((id: number, content: string) => {
    setOpenDocuments(prev =>
      prev.map(doc =>
        doc.id === id
          ? { ...doc, content, saved: false }
          : doc
      )
    );

    // Auto-save after 2 seconds of inactivity
    const timeoutId = setTimeout(() => {
      updateDocumentMutation.mutate({
        id,
        updates: { content, saved: true },
      });
    }, 2000);

    return () => clearTimeout(timeoutId);
  }, [updateDocumentMutation]);

  const updateDocumentSettings = useCallback((id: number, settings: { fontSize?: number; fontFamily?: string }) => {
    setOpenDocuments(prev =>
      prev.map(doc =>
        doc.id === id
          ? { ...doc, ...settings }
          : doc
      )
    );

    updateDocumentMutation.mutate({
      id,
      updates: settings,
    });
  }, [updateDocumentMutation]);

  return {
    openDocuments,
    activeDocumentId,
    setActiveDocument,
    openDocument,
    closeDocument,
    createNewDocument,
    saveDocument,
    updateDocumentContent,
    updateDocumentSettings,
    isCreatingDocument: createDocumentMutation.isPending,
    isUpdatingDocument: updateDocumentMutation.isPending,
  };
}
