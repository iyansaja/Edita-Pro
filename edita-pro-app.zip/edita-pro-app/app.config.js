module.exports = {
  name: 'Edita Pro',
  slug: 'edita-pro',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/images/icon.png',
  splash: {
    image: './assets/images/splash.png',
    resizeMode: 'contain',
    backgroundColor: '#121212'
  },
  android: {
    adaptiveIcon: {
      foregroundImage: './assets/images/adaptive-icon.png',
      backgroundColor: '#121212'
    },
    package: 'com.yourusername.editapro'
  },
  ios: {
    bundleIdentifier: 'com.yourusername.editapro',
    supportsTablet: true
  },
  extra: {
    eas: {
      projectId: 'your-project-id'
    }
  }
};