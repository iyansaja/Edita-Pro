import { StyleSheet, View, Text, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Plus, Search } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import ProjectItem from '@/components/ProjectItem';
import { router } from 'expo-router';

export default function ProjectsScreen() {
  // Mock data for projects
  const projects = [
    { id: '1', title: 'Beach Trip', duration: '01:45', date: '2023-05-15', thumbnailUrl: 'https://images.pexels.com/photos/1032650/pexels-photo-1032650.jpeg?auto=compress&cs=tinysrgb&w=800' },
    { id: '2', title: 'Birthday Party', duration: '03:12', date: '2023-06-20', thumbnailUrl: 'https://images.pexels.com/photos/7180788/pexels-photo-7180788.jpeg?auto=compress&cs=tinysrgb&w=800' },
    { id: '3', title: 'Travel Vlog', duration: '05:30', date: '2023-07-10', thumbnailUrl: 'https://images.pexels.com/photos/2747893/pexels-photo-2747893.jpeg?auto=compress&cs=tinysrgb&w=800' },
    { id: '4', title: 'Cooking Tutorial', duration: '08:45', date: '2023-08-05', thumbnailUrl: 'https://images.pexels.com/photos/1640773/pexels-photo-1640773.jpeg?auto=compress&cs=tinysrgb&w=800' },
    { id: '5', title: 'Product Review', duration: '04:20', date: '2023-09-12', thumbnailUrl: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=800' },
  ];

  const renderItem = ({ item }: { item: any }) => (
    <ProjectItem
      project={item}
      onPress={() => router.push('/editor')}
    />
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Projects</Text>
        <TouchableOpacity>
          <Search size={24} color={Colors.text} />
        </TouchableOpacity>
      </View>
      
      <FlatList
        data={projects}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
      
      <TouchableOpacity 
        style={styles.newProjectButton}
        onPress={() => router.push('/editor')}
      >
        <Plus size={24} color="#FFF" />
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: {
    fontSize: 22,
    fontFamily: 'Inter-Bold',
    color: Colors.text,
  },
  listContent: {
    padding: 16,
  },
  newProjectButton: {
    position: 'absolute',
    right: 24,
    bottom: 24,
    backgroundColor: Colors.primary,
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 8,
  },
});