import { useState, useRef, useEffect } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Video } from 'expo-av';
import { ChevronLeft, Upload, Save, Scissors, Image as ImageIcon, Music, Text as TextIcon } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import VideoTrimmer from '@/components/VideoTrimmer';
import FilterSelector from '@/components/FilterSelector';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import * as Sharing from 'expo-sharing';
import { router } from 'expo-router';

export default function EditorScreen() {
  const [videoUri, setVideoUri] = useState<string | null>(null);
  const [status, setStatus] = useState<any>({});
  const [trimValues, setTrimValues] = useState({ start: 0, end: 0 });
  const [currentFilter, setCurrentFilter] = useState('normal');
  const [activeTab, setActiveTab] = useState('trim');
  const videoRef = useRef<Video>(null);

  useEffect(() => {
    requestMediaLibraryPermissions();
  }, []);

  const requestMediaLibraryPermissions = async () => {
    const { status } = await MediaLibrary.requestPermissionsAsync();
    if (status !== 'granted') {
      alert('Sorry, we need media library permissions to make this work!');
    }
  };

  const pickVideo = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos,
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      setVideoUri(result.assets[0].uri);
      if (videoRef.current) {
        await videoRef.current.loadAsync({ uri: result.assets[0].uri });
      }
    }
  };

  const handleSave = async () => {
    if (!videoUri) return;
    
    // In a real app, you would process the video with the selected trimValues and filter
    // For now, we'll just save/share the original video
    
    if (Platform.OS === 'web') {
      alert('Saving videos is not supported on web.');
      return;
    }
    
    try {
      if (Platform.OS === 'ios' || Platform.OS === 'android') {
        const { status } = await MediaLibrary.requestPermissionsAsync();
        
        if (status === 'granted') {
          const asset = await MediaLibrary.createAssetAsync(videoUri);
          await MediaLibrary.createAlbumAsync('Edita Pro', asset, false);
          alert('Video saved to your media library!');
        }
      }
    } catch (error) {
      console.error('Error saving video:', error);
      alert('Failed to save video');
    }
  };

  const handleShare = async () => {
    if (!videoUri) return;
    
    try {
      if (Platform.OS !== 'web') {
        const isAvailable = await Sharing.isAvailableAsync();
        
        if (isAvailable) {
          await Sharing.shareAsync(videoUri);
        } else {
          alert('Sharing is not available on this device');
        }
      } else {
        alert('Sharing is not available on web');
      }
    } catch (error) {
      console.error('Error sharing video:', error);
      alert('Failed to share video');
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'trim':
        return (
          <VideoTrimmer
            duration={status.durationMillis || 0}
            onValueChange={setTrimValues}
            initialValues={trimValues}
          />
        );
      case 'filter':
        return (
          <FilterSelector
            currentFilter={currentFilter}
            onSelectFilter={setCurrentFilter}
          />
        );
      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <ChevronLeft size={24} color={Colors.text} />
        </TouchableOpacity>
        <Text style={styles.title}>Video Editor</Text>
        <TouchableOpacity onPress={handleShare}>
          <Upload size={24} color={Colors.text} />
        </TouchableOpacity>
      </View>

      <View style={styles.videoContainer}>
        {videoUri ? (
          <Video
            ref={videoRef}
            style={styles.video}
            source={{ uri: videoUri }}
            useNativeControls
            resizeMode="contain"
            isLooping
            onPlaybackStatusUpdate={status => setStatus(() => status)}
          />
        ) : (
          <View style={styles.placeholderContainer}>
            <TouchableOpacity style={styles.uploadButton} onPress={pickVideo}>
              <Upload size={32} color={Colors.primary} />
              <Text style={styles.uploadText}>Select Video</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      <View style={styles.toolsContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.toolsTabs}>
          <TouchableOpacity 
            style={[styles.toolTab, activeTab === 'trim' && styles.activeToolTab]}
            onPress={() => setActiveTab('trim')}
          >
            <Scissors size={20} color={activeTab === 'trim' ? Colors.primary : Colors.text} />
            <Text style={[styles.toolTabText, activeTab === 'trim' && styles.activeToolTabText]}>Trim</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.toolTab, activeTab === 'filter' && styles.activeToolTab]}
            onPress={() => setActiveTab('filter')}
          >
            <ImageIcon size={20} color={activeTab === 'filter' ? Colors.primary : Colors.text} />
            <Text style={[styles.toolTabText, activeTab === 'filter' && styles.activeToolTabText]}>Filter</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.toolTab, activeTab === 'audio' && styles.activeToolTab]}
            onPress={() => setActiveTab('audio')}
          >
            <Music size={20} color={activeTab === 'audio' ? Colors.primary : Colors.text} />
            <Text style={[styles.toolTabText, activeTab === 'audio' && styles.activeToolTabText]}>Audio</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.toolTab, activeTab === 'text' && styles.activeToolTab]}
            onPress={() => setActiveTab('text')}
          >
            <TextIcon size={20} color={activeTab === 'text' ? Colors.primary : Colors.text} />
            <Text style={[styles.toolTabText, activeTab === 'text' && styles.activeToolTabText]}>Text</Text>
          </TouchableOpacity>
        </ScrollView>
        
        <View style={styles.toolContent}>
          {renderTabContent()}
        </View>
      </View>

      <View style={styles.footer}>
        <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
          <Save size={18} color="#FFF" />
          <Text style={styles.saveButtonText}>Save Project</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: Colors.text,
  },
  videoContainer: {
    height: 250,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  video: {
    width: '100%',
    height: '100%',
  },
  placeholderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  uploadButton: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  uploadText: {
    marginTop: 12,
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: Colors.primary,
  },
  toolsContainer: {
    flex: 1,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  toolsTabs: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  toolTab: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 12,
    borderRadius: 20,
    backgroundColor: Colors.cardBackground,
  },
  activeToolTab: {
    backgroundColor: `${Colors.primary}20`,
  },
  toolTabText: {
    marginLeft: 6,
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.text,
  },
  activeToolTabText: {
    color: Colors.primary,
  },
  toolContent: {
    flex: 1,
    padding: 16,
  },
  footer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  saveButton: {
    backgroundColor: Colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 14,
    borderRadius: 8,
  },
  saveButtonText: {
    color: '#FFF',
    fontFamily: 'Inter-Medium',
    fontSize: 16,
    marginLeft: 8,
  },
});