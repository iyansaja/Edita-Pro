import { StyleSheet, View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Plus, Film, Play } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import RecentProjectItem from '@/components/RecentProjectItem';

export default function HomeScreen() {
  // Mock data for recent projects
  const recentProjects = [
    { id: '1', title: 'Beach Trip', duration: '01:45', date: '2 days ago' },
    { id: '2', title: 'Birthday Party', duration: '03:12', date: 'Yesterday' },
    { id: '3', title: 'Travel Vlog', duration: '05:30', date: 'Just now' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Edita Pro</Text>
      </View>
      
      <ScrollView style={styles.content}>
        <View style={styles.welcomeCard}>
          <View style={styles.welcomeContent}>
            <Film size={30} color={Colors.primary} />
            <Text style={styles.welcomeText}>
              Create amazing videos with professional editing tools
            </Text>
          </View>
          <TouchableOpacity 
            style={styles.createButton}
            onPress={() => router.push('/editor')}
          >
            <Play size={16} color="#FFF" />
            <Text style={styles.createButtonText}>Start Editing</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Projects</Text>
            <TouchableOpacity onPress={() => router.push('/projects')}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          {recentProjects.map(project => (
            <RecentProjectItem key={project.id} project={project} />
          ))}
        </View>
      </ScrollView>
      
      <TouchableOpacity 
        style={styles.newProjectButton}
        onPress={() => router.push('/editor')}
      >
        <Plus size={24} color="#FFF" />
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: {
    fontSize: 22,
    fontFamily: 'Inter-Bold',
    color: Colors.text,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  welcomeCard: {
    backgroundColor: Colors.cardBackground,
    borderRadius: 12,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  welcomeContent: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  welcomeText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: Colors.text,
    marginLeft: 12,
    flex: 1,
  },
  createButton: {
    backgroundColor: Colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 8,
  },
  createButtonText: {
    color: '#FFF',
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    marginLeft: 8,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: Colors.text,
  },
  seeAllText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.primary,
  },
  newProjectButton: {
    position: 'absolute',
    right: 24,
    bottom: 24,
    backgroundColor: Colors.primary,
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 8,
  },
});