import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import * as VideoThumbnails from 'expo-video-thumbnails';
import { Platform } from 'react-native';

// Generate a thumbnail from a video
export async function generateThumbnail(videoUri: string): Promise<string> {
  try {
    const { uri } = await VideoThumbnails.getThumbnailAsync(
      videoUri,
      {
        time: 1000,
        quality: 0.8
      }
    );
    return uri;
  } catch (e) {
    console.error('Error generating thumbnail:', e);
    throw e;
  }
}

// Save a video to the device's media library
export async function saveVideoToLibrary(videoUri: string): Promise<void> {
  if (Platform.OS === 'web') {
    throw new Error('This feature is not available on web');
  }

  try {
    const { status } = await MediaLibrary.requestPermissionsAsync();
    
    if (status !== 'granted') {
      throw new Error('Media library permission not granted');
    }
    
    const asset = await MediaLibrary.createAssetAsync(videoUri);
    await MediaLibrary.createAlbumAsync('Edita Pro', asset, false);
  } catch (e) {
    console.error('Error saving video to library:', e);
    throw e;
  }
}

// Apply a video filter (mock implementation)
export function applyFilter(videoUri: string, filter: string): string {
  // In a real app, this would process the video with the selected filter
  // For this demo, we'll just return the original URI
  console.log(`Applying ${filter} filter to ${videoUri}`);
  return videoUri;
}

// Trim a video (mock implementation)
export function trimVideo(videoUri: string, startTime: number, endTime: number): string {
  // In a real app, this would trim the video based on the start and end times
  // For this demo, we'll just return the original URI
  console.log(`Trimming video ${videoUri} from ${startTime}ms to ${endTime}ms`);
  return videoUri;
}