package com.ikonexplorer.game;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

    private MediaPlayer clickSound;
    private MediaPlayer bgMusic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        clickSound = MediaPlayer.create(this, R.raw.click);
        bgMusic = MediaPlayer.create(this, R.raw.lobby_music);
        bgMusic.setLooping(true);
        bgMusic.start();

        Button startGameButton = findViewById(R.id.start_game_button);
        Button multiplayerButton = findViewById(R.id.multiplayer_button);
        Button settingsButton = findViewById(R.id.settings_button);

        startGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickSound.start();
                Toast.makeText(MainActivity.this, "Mulai Permainan", Toast.LENGTH_SHORT).show();
                // Intent to game activity here
            }
        });

        multiplayerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickSound.start();
                Toast.makeText(MainActivity.this, "Masuk ke Mode Multiplayer", Toast.LENGTH_SHORT).show();
                // Intent to multiplayer activity here
            }
        });

        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickSound.start();
                Toast.makeText(MainActivity.this, "Pengaturan", Toast.LENGTH_SHORT).show();
                // Intent to settings activity here
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bgMusic != null) {
            bgMusic.stop();
            bgMusic.release();
        }
    }
}