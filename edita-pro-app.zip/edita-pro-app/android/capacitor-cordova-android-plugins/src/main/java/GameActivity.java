package com.ikonexplorer.game;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;
import android.view.View;
import android.widget.Button;

public class GameActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        Toast.makeText(this, "Selamat Datang di Dunia iKON Explorer!", Toast.LENGTH_SHORT).show();

        Button openMapButton = findViewById(R.id.open_map_button);
        Button interactButton = findViewById(R.id.interact_button);
        Button inventoryButton = findViewById(R.id.inventory_button);

        openMapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(GameActivity.this, "Membuka Peta", Toast.LENGTH_SHORT).show();
                // Tambahkan logic membuka map
            }
        });

        interactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(GameActivity.this, "Interaksi dengan NPC atau Objek", Toast.LENGTH_SHORT).show();
                // Tambahkan logic interaksi
            }
        });

        inventoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(GameActivity.this, "Membuka Inventori", Toast.LENGTH_SHORT).show();
                // Tambahkan logic inventori
            }
        });
    }
}