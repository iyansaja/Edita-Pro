const Colors = {
  background: '#121212',
  cardBackground: '#1E1E1E',
  primary: '#FF6B6B',
  secondary: '#4ECDC4',
  accent: '#FFD166',
  text: '#FFFFFF',
  secondaryText: '#AAAAAA',
  inactive: '#777777',
  border: '#333333',
  danger: '#FF4757',
};

export default Colors;