export interface Project {
  id: string;
  title: string;
  duration: string;
  date: string;
  thumbnailUrl?: string;
}

export interface VideoFilter {
  id: string;
  name: string;
  preview?: string;
}

export interface TrimRange {
  start: number;
  end: number;
}

export interface ExportOptions {
  resolution: '720p' | '1080p' | '4k';
  format: 'mp4' | 'mov' | 'webm';
  quality: 'low' | 'medium' | 'high';
}